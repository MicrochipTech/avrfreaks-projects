
Openhome - An Open Source Home Automation System

This archive contains all sources of my own home automation system which
is currently under development. It consists of a general purpose protocol
stack, a main panel and some applications.

The protocol has the following features:

	- implements a collision avoidance scheme
	- clearly structured protocol stack
	- supports multicast (group addressing)
	- provides packet ordering and duplicate detection
	- reliable packet delivery and request/respond service

See OpenHome.doc for a detailed description of the protocol. See
doc/net/html/index.html to get a idea how to use the protocol stack.

For suggestions, bug reports and stuff like that contact me at:
Jan Kl�tzke <jk177883@inf.tu-dresden.de>

Have fun


