/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include <stddef.h>
#include "net/link.h"
#include "net/network.h"
#include "net/transport.h"
#include "net/application.h"
#include "io1/switch.h"
#include "io1/dimmer.h"

static uint8_t timer_flag;

// 8ms timer constant
#define TIMER	0xbb80

// called every 1ms
SIGNAL(SIG_OUTPUT_COMPARE1B)
{	
	OCR1B = TCNT1 + TIMER;
	timer_flag++;
	sei();
	
	switch_sense();
}

int main(void)
{
	// configure io-pins
	PORTA = 0x03;
	PORTB = 0x0f;
	PORTC = 0x00;
	DDRA  = 0x03;
	DDRC  = 0xc0;
	
	// init subsystems
	sei();
	lnk_init();
	app_init();
	dim_init();
	switch_init();
	
	// enable 8ms timer
	//TCCR1B |= _BV(CS10);
	sbi(TIMSK, OCIE1B);	

	for (;;) {
		while (timer_flag > 0) {
			timer_flag--;
			tsp_check_timeout();
		}
		lnk_process();
		tsp_process();
		app_process();
	}

	return 0;
}
