/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include <stddef.h>
#include "net/application.h"
#include "net/snt.h"

static snt_switch states[4];	// switch states
static uint8_t behavior;	// behaviours (bit mask, lower nibble=dimmer/switch, upper nibble=dimming direction)
static uint8_t keys[4];
static uint8_t dirty;
static uint8_t cycle;

uint8_t ee_speed[4] __attribute__(( section(".eeprom") ));
uint8_t ee_behavior __attribute__(( section(".eeprom") ));

// events
#define SW_ON_CLICK	0
#define SW_ON_SWITCH	1

// methods
#define SW_SWITCH_FB	0
#define SW_SET_BEHAV	1
#define SW_GET_BEHAV	2
#define SW_SET_SPEED	3
#define SW_GET_SPEED	4

// parameter tables
static param_desc_t switch_prop[] = {{2,0}, {1,0}, {0,1}, {1,0}, {0,1}};
static param_desc_t switch_events[] = {{0,0}, {0,2}};

// forward definitions
void switch1_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated);
void switch2_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated);
void switch3_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated);
void switch4_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated);

// application object definitions
struct AppObject PROGMEM switch1 = {switch_prop, switch_events, switch1_cb};
struct AppObject PROGMEM switch2 = {switch_prop, switch_events, switch2_cb};
struct AppObject PROGMEM switch3 = {switch_prop, switch_events, switch3_cb};
struct AppObject PROGMEM switch4 = {switch_prop, switch_events, switch4_cb};

void switch_method(uint8_t id, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case SW_SWITCH_FB:
			// only store feedback if not dimming
			if (keys[id] == 0) states[id] = *((snt_switch*)buf);
			break;
		case SW_SET_BEHAV:
			if (*((sw_behav_e*)buf) == SB_SWITCH)
				behavior &= !(1<<id);
			else
				behavior |= (1<<id);
			eeprom_write_byte(&ee_behavior, behavior);
			break;
		case SW_GET_BEHAV:
			if ((behavior & (1<<id)) != 0)
				*((sw_behav_e*)buf) = SB_DIMMER;
			else
				*((sw_behav_e*)buf) = SB_SWITCH;
			break;
		case SW_SET_SPEED:
			eeprom_write_byte(&ee_speed[id], *buf);
			break;
		case SW_GET_SPEED:
			*buf = eeprom_read_byte(&ee_speed[id]);
			break;
		case SW_ON_SWITCH|0x80:
			*((snt_switch*)result) = states[id];
			break;
	}
}

// methods
void switch1_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch_method(0, property, buf, result, repeated);
}
void switch2_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch_method(1, property, buf, result, repeated);
}
void switch3_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch_method(2, property, buf, result, repeated);
}
void switch4_cb(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch_method(3, property, buf, result, repeated);
}



#define KEY_PRESS	5
#define KEY_REPEAT	96
//#define KEY_NEW_REP	72
#define KEY_NEW_REP	90

// call every 8ms
void switch_sense(void)
{
	uint8_t key, mask, step;
	
	mask = 0x01;
	for (key=0; key<4; key++) {
		if ((PINB&mask) == 0) {
			keys[key]++;
		} else {
			if ((keys[key] >= KEY_PRESS) && (keys[key] < KEY_NEW_REP)) {
				states[key].state = !states[key].state;
				dirty |= mask;
			}
			keys[key] = 0;
		}
		
		if ((keys[key] > KEY_REPEAT) && ((behavior&mask) != 0)) {
			keys[key] = KEY_NEW_REP;
			dirty |= mask;
			
			states[key].state = 1;
			step = eeprom_read_byte(&ee_speed[key]);
			if ((behavior&((uint8_t)(mask<<4))) != 0) {
				// dim up
				if (states[key].value >= (uint8_t)(0xff-step))
					states[key].value = 0xff;
				else
					states[key].value += step;
			} else {
				// dim down
				if (states[key].value <= step)
					states[key].value = 0;
				else
					states[key].value -= step;
			}
		} else if ((keys[key] >= KEY_NEW_REP) && ((behavior&mask) == 0)) {
			keys[key] = KEY_PRESS+1;
		} else if (keys[key] == KEY_PRESS) {
			behavior ^= mask<<4;
			app_trigger_event(1+key, SW_ON_CLICK);
		}		
		
		mask <<= 1;
	}
	
	// send updates if necessary
	if (cycle == 0) {
		mask = 0x01;
		for (key=0; key<4; key++) {
			if ((dirty&mask) != 0) {
				app_trigger_event(1+key, SW_ON_SWITCH);
				cycle = 13;
			}
			mask <<= 1;
		}
		dirty = 0;
	} else {
		cycle--;
	}
}

void switch_init(void)
{
	behavior = eeprom_read_byte(&ee_behavior);
}
