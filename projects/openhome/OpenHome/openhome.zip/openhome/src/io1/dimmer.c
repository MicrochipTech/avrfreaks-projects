/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include "net/application.h"
#include "net/snt.h"

#define REACT	0x00ff
static uint16_t preset = 9000;	// aprox. 15%
static uint16_t icp, cycle;
static uint16_t delta1 = 0xffff, delta2 = 0xffff;
static uint8_t mask1 = 0xfe, mask2 = 0xfd;

static snt_switch states[2];	// relay states

// events
#define DIM_ON_CHANGE	0

// methods
#define DIM_SET_VALUE	0

// parameter tables
static param_desc_t dim_prop[] = {{2,0}};
static param_desc_t dim_events[] = {{0,2}};

// forward definitions
static void dim1_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);
static void dim2_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);

// application object definitions
struct AppObject PROGMEM dim1 = {dim_prop, dim_events, dim1_cb};
struct AppObject PROGMEM dim2 = {dim_prop, dim_events, dim2_cb};

static uint16_t calc_delta(uint8_t value)
{
	uint16_t result;
	
	if (value == 0)
		result = 0xef00;
	else if (value == 0xff)
		result = 0;
	else {
		result = REACT+((cycle-REACT-preset) >> 8)*(0xff-value);
	}
	return result;
}

static void update(void)
{
	uint8_t val1, val2;
	
	val1 = (states[0].state)?(states[0].value):0;
	val2 = (states[1].state)?(states[1].value):0;
	if (val1 > val2) {
		delta1 = calc_delta(val1);
		delta2 = calc_delta(val2);
		mask1 = 0xfe;
		mask2 = 0xfd;
	} else {
		delta1 = calc_delta(val2);
		delta2 = calc_delta(val1);
		mask1 = 0xfd;
		mask2 = 0xfe;
	}
}

static void dim_method(uint8_t obj, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case DIM_SET_VALUE:
			app_trigger_event(7+obj, DIM_ON_CHANGE);
			states[obj] = *((snt_switch*)buf);
			update();
			break;
		case DIM_ON_CHANGE|0x80:
			*((snt_switch*)result) = states[obj];
			break;
	}
}

static void dim1_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	dim_method(0, method, buf, result, repeated);
}

static void dim2_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	dim_method(1, method, buf, result, repeated);
}

void dim_init(void)
{
	TCCR1B = _BV(CS10);
	TIMSK |= _BV(OCIE1A) | _BV(ICF1);
}

// turn on triacs
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
	PORTA &= mask1;		// turn on ch1
	OCR1A = icp+delta2;	// load time for ch2
	
	// ch2 reached?
	if ((TCNT1-(icp+delta2)) < 0x1000) PORTA &= mask2;
}

// zero crossing
SIGNAL(SIG_INPUT_CAPTURE1)
{
	if (delta1 == 0) PORTA &= mask1; else PORTA |= ~mask1;
	if (delta2 == 0) PORTA &= mask2; else PORTA |= ~mask2;
	
	cycle = ICR1-icp;		// calculate cycle count
	icp = ICR1;			// save this zero crossing
	
	OCR1A = icp+delta1;		// interrupt for brightest lamp
}
