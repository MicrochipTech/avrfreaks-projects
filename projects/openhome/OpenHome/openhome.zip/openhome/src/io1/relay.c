/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <avr/io.h>
#include <inttypes.h>
#include "net/application.h"
#include "net/snt.h"

static snt_switch states[2];	// relay states

// events
#define REL_ON_CHANGE	0

// methods
#define REL_SET_VALUE	0

// parameter tables
static param_desc_t relay_prop[] = {{2,0}};
static param_desc_t relay_events[] = {{0,2}};

// forward definition
static void relay1_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);
static void relay2_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);

// application object definitions
struct AppObject PROGMEM relay1 = {relay_prop, relay_events, relay1_cb};
struct AppObject PROGMEM relay2 = {relay_prop, relay_events, relay2_cb};


// methods
static void relay1_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case REL_SET_VALUE:
			states[0] = *((snt_switch*)buf);
			if (states[0].state != 0) sbi(PORTC, PC7); else cbi(PORTC, PC7);
			app_trigger_event(5, REL_ON_CHANGE);
			break;
		case REL_ON_CHANGE|0x80:
			*((snt_switch*)result) = states[0];
			break;
	}
}

static void relay2_cb(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case REL_SET_VALUE:
			states[1] = *((snt_switch*)buf);
			if (states[1].state != 0) sbi(PORTC, PC6); else cbi(PORTC, PC6);
			app_trigger_event(6, REL_ON_CHANGE);
			break;
		case REL_ON_CHANGE|0x80:
			*((snt_switch*)result) = states[1];
			break;
	}
}
