/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __NET_H
#define __NET_H

/***
 * Feature definitions. Adjust according to your destination CPU and needs.
 */

/*******************************************************************************
 * Link layer definitions.
 */

/***
 * Specify your desired baud rate and current master clock frequency.
 * Note that the actual baud rate may differ. (see manual)
 * Also keep in mind that high rates may not be feasible due to edm and
 * protocol processing time and other interrupts.
 */
#define LNK_BAUD_RATE	9600		/* desired baud rate    */
#define LNK_F_CLK	6000000		/* your clock frequency */

/***
 * Send pin
 */
#define LNK_SEND_PORT	PORTD
#define LNK_SEND_DDR	DDRD
#define LNK_SEND_PIN	PD4

/***
 * Receive buffer size
 */
#define LNK_BUFFER_SIZE	64

/***
 * beta1: idle time to signal packet end
 * beta2: minimum idle time after packet
 */
#define LNK_BETA_1	18
#define LNK_BETA_2	24

#define LNK_ALPHA_TIME	0xd0	/* value loaded into TCNT0             */
#define LNK_ALPHA_PRESC	0x02	/* timer 0 prescaler, written to TCCR0 */


#define LNK_EXT_INT	INT0
#define LNK_EXT_ISCx1	ISC01
#define LNK_EXT_SIG	SIG_INTERRUPT0

/*******************************************************************************
 * Network layer definitions.
 */

#define NET_LOGIC_ADDR		0x0002
#define NET_PHYSICAL_ADDR	0x55500002


/*******************************************************************************
 * Transport layer definitions.
 */

#define TSP_TIMEOUT	200

#define TSP_MAX_GROUPS	128

// address cache size
#define TSP_CACHE_SIZE	4	/* number of max simultanious transactions */
#define TSP_REPLY_SIZE	8	/* this MUST be a power of two             */

/*******************************************************************************
 * Appliction layer definitions.
 */

#define APP_STATIC

#define APP_BUFFER_SIZE 64

#define APP_MAX_ASSOC	32

#define APP_OBJECTS OBJECT(switch1, 2) OBJECT(switch2, 2) OBJECT(switch3, 2) \
	OBJECT(switch4, 2) OBJECT(relay1, 1) OBJECT(relay2, 1) OBJECT(dim1, 1)   \
	OBJECT(dim2, 1)

#define APP_MAX_EVENTS	8	/* Number of max. pending events. MUST be a power of two! */

#endif
