/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file link.c
 * \brief Link layer implementation.
 *
 * This layer is rather hardware specific. Read the following carefully to
 * understand what parts are used and how. I assume you are familiar with
 * the protocol itself. If not read OpenHome.doc.
 *
 * In the first place it uses Timer/Counter0 exclusively for slot timing. The
 * timer is configured through to following definitions located in your 
 * \link net_h net.h\endlink:
 * - LNK_ALPHA_TIME: this value is loaded into TCNT0
 * - LNK_ALPHA_PRESC: prescaler, written into TCCR0
 *
 * Both values must be adjusted that Timer/Counter0 meets the desired slot
 * time. Use the lowest prescaler that is possible to reach a
 * maximum resulution. Otherwise the timing is prone to jitter and might be
 * inconsistent between different nodes in the network which increases the
 * possibility of collisions!
 *
 * \attention Since timing is done in software it must also be ensured that interrupts
 * are not disabled too long. This implies that you should use SIGNAL()'s
 * only if really neccesary and keep them as short as possible. Always consider
 * using INTERRUPT() instead. In most cases it should be possible to disable
 * interrupts only for a minimum of time. Take it as a sign of inefficient
 * coding if your code contains large code blocks with disabled interrupts.
 * 
 * Secondly a external interrupt is used which can sense falling edges. See
 * \ref net_h for configuring the actial interrupt line. It is used to immidiately
 * detect the start bit if another node on the bus starts transmitting. As this
 * is also a time-critical task keep the previous paragraph in mind.
 *
 * \author Jan Kl�tzke
 *
 * <b>History:</b>
 * 	- 04.07.2003: first version
 * 	- 27.07.2003: major bugfixes
 * 	- 08.08.2003: fixed racing condition between lnk_process and SIG_OVERFLOW0
 */
 
#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include "net/link.h"
#include "net/buffers.h"
#include "net.h"

// external interrupt functions
#ifdef EIMSK
#	define ext_init()	sbi(EICR, LNK_EXT_ISCx1)
#	define ext_enable()	{EIFR = _BV(LNK_EXT_INT); sbi(EIMSK, LNK_EXT_INT);}
#	define ext_disable()	cbi(EIMSK, LNK_EXT_INT)
#else
#	define ext_init()	sbi(MCUCR, LNK_EXT_ISCx1)
#	define ext_enable()	{GIFR = _BV(LNK_EXT_INT); sbi(GIMSK, LNK_EXT_INT);}
#	define ext_disable()	cbi(GIMSK, LNK_EXT_INT)
#endif

/** \brief Actual receive state. */
enum recv_stat_e {
	RECV_STAT_FREE,		///< listen for packet
	RECV_STAT_RECEIVING,	///< receiving packet
	RECV_STAT_EXAMINE	///< examine packet
};

/** \brief Actual send state. */
enum send_stat_e {
	SEND_STAT_IDLE,		///< nothing to do
	SEND_STAT_WAIT,		///< wait for a free slot
	SEND_STAT_SEND_DATA,	///< currently sending data
	SEND_STAT_INFORM	///< inform network layer that packet was sent
};

/** \brief Structure containing all variables concerning packet reception. */
struct receive_info_t {
	enum recv_stat_e status;	///< current state
	uint16_t slots;			///< number of passed slots since last byte (slot timer)
	uint16_t crc16;			///< checksum of already received data
	uint8_t pos;			///< pointer into receive buffer
	uint8_t buf[LNK_BUFFER_SIZE];	///< the receive buffer itself
};

/** \brief Variables needed for transmitting. */
struct send_info_t {
	enum send_stat_e status;///< current state
	uint16_t slot;		///< choosen send slot (0xffff if no slot has been assigned yet)
	uint8_t backlog;	///< current backlog counter
	uint8_t backlog_add;	///< backlog to add when finished sending
	net_buf_t data;		///< data which is to be sent
};

// global vars
static struct send_info_t send;		//< transmit variables
static struct receive_info_t receive;	//< receive variables
static struct lnk_err_t err;		//< error statistics

/// CCITT CRC polynominal
#define	POLY_CRC16	0x1021

/**
 * \brief Called if UART received a character.
 *
 * This ISR is called every time the UART received a character. Note that the
 * CRC is calculated on the fly which may limit the maximum baud rate.
 */
SIGNAL(SIG_UART_RECV)
{
	uint8_t i, value;
	
	// handle bus timing, (re)start counting slots
	TCNT0 = LNK_ALPHA_TIME;
	receive.slots = 0;
	
	// get byte
	if ((USR & _BV(FE)) != 0) err.rx_fe++;
	value = UDR;
	if ((USR & _BV(DOR)) != 0) err.rx_ovr++;
		
	// expecting to receive sth? if not, simply ignore byte
	// This could happen if we could not process a packet fast enough so
	// the next has already started. This leads to missing bytes in the
	// buffer but should be handled by crc and length comparison. Beta2
	// should be increased to prevent this.
	if (receive.status > RECV_STAT_RECEIVING) {
		err.rx_ovr++;
		return;
	}
	receive.status = RECV_STAT_RECEIVING;
	
	// critical section handled
	sei();
	
	
	// store in buffer
	if (receive.pos < LNK_BUFFER_SIZE) receive.buf[receive.pos++] = value;
	
	// calculate checksum (add only header+data, not checksum itself)
	if ((uint8_t)(receive.buf[0]+2) >= receive.pos) {
		receive.crc16 ^= ((uint16_t)value << 8);
		for (i=0; i<8; i++) {
			if (receive.crc16 & 0x8000)
				receive.crc16 = (receive.crc16 << 1) ^ POLY_CRC16;
			else
				receive.crc16 <<= 1;
		}
	}
}

/**
 * \brief Slot timer.
 *
 * This ISR eats up aprox. 20% of processor time at 6 MHz and 64us slot time!
 * Maybe implement this in pure assambler to get max speed...
 */
SIGNAL(SIG_OVERFLOW0)
{
	TCNT0 += LNK_ALPHA_TIME;
	receive.slots++;
	
	// receive: detect end of packet and switch to examine mode
	// this will also be executed if we sent a packet!
	if (receive.slots == LNK_BETA_1) {
		if (receive.status == RECV_STAT_RECEIVING) {
			receive.status = RECV_STAT_EXAMINE;	// signal that data arrived
			ext_enable();				// start detection of new data
		}
	}
	
	// send: start sending if right slot reached
	if (receive.slots >= send.slot) {
		cbi(TIMSK, TOIE0);			// disable slot timer
		ext_disable();				// disable detection of new data
		cbi(UCR, RXEN);				// disable receiver
		sbi(UCR, TXEN);				// enable transmitter
		cbi(LNK_SEND_PORT, LNK_SEND_PIN);	// enable driver
		
		UDR = *send.data.data++;		// send first byte
		send.data.len--;
		send.status = SEND_STAT_SEND_DATA;
		send.slot = 0xffff;
		sbi(UCR, UDRIE);			// enable UDRIE
	}
}

/**
 * \brief Called if another device started to send.
 *
 * This ISR can only be executed if the end of a packet was detected. Once a
 * start bit has been detected the ISR diables itself.
 */
SIGNAL(LNK_EXT_SIG)
{
	ext_disable();		// disable detection
	TCNT0 = LNK_ALPHA_TIME;	// restart...
	receive.slots = 0;	// ...slot counting
	send.slot = 0xffff;	// under no circumstances can we send data
}

/**
 * \brief UART data register empty interrupt.
 *
 * Feeds the UART with new data if there is any. If no further data is
 * availible it disables itself. This causes then that SIGNAL(SIG_UART_TRANS)
 * will be called if the last byte has been shifted out.
 */
SIGNAL(SIG_UART_DATA)
{
	if (send.data.len > 0) {
		UDR = *send.data.data++;
		send.data.len--;
	} else {
		cbi(UCR, UDRIE);
	}
}

/**
 * \brief Transmission complete interrupt.
 *
 * Reverts to listening mode and sets the transmission-status to
 * SEND_STAT_INFORM.
 */
SIGNAL(SIG_UART_TRANS)
{
	sbi(LNK_SEND_PORT, LNK_SEND_PIN);	// disable driver
	cbi(UCR, TXEN);				// disable transmitter
	sbi(UCR, RXEN);				// enable receiver
	TCNT0 = LNK_ALPHA_TIME;			// setup...
	receive.slots = 0;			// clear...
	sbi(TIMSK, TOIE0);			// and enable slot timer
	ext_enable();				// start detection of new data
	send.status = SEND_STAT_INFORM;		// done
}

/********************************************************************************
 * Public functions
 */

extern uint8_t lnk_ind(uint8_t *buf, uint8_t len);
extern void lnk_con(void);

/**
 * \brief Perform initialization of link layer.
 *
 * This function must be called before any other network functions are called.
 */
void lnk_init(void)
{
	UBRR = LNK_F_CLK/(LNK_BAUD_RATE*16l) - 1;		// set baud rate
	sbi(LNK_SEND_PORT, LNK_SEND_PIN);			// configure send pin
	sbi(LNK_SEND_DDR, LNK_SEND_PIN);
	UCR = _BV(RXCIE)|_BV(TXCIE)|_BV(RXEN);			// enable receiver+interrupts
	
	send.slot = 0xffff;		// don't want to send
	receive.crc16 = 0;
	
	receive.slots = 0x8000;		// set up slot timer
	TCCR0 = LNK_ALPHA_PRESC;
	sbi(TIMSK, TOIE0);
	
	ext_init();
	ext_enable();			// start detection of new data
}

/**
 * \brief Process link layer specific tasks.
 *
 * Call this function as often as possible from your main loop. It processes
 * link layer specific tasks such as passing received packets to upper layers
 * and scheduling send requests.
 *
 * \attention Must not be called from a interrupt routine. The implementation
 *            is not thread-save.
 */
void lnk_process(void)
{
	// be sure that slot timer doesn't wrap
	cli();
	if (receive.slots > 0xa000) receive.slots = 0x3000;
	sei();

	// assign slot number if data is waiting
	cli();
	if ((send.status == SEND_STAT_WAIT) && (send.slot == 0xffff)) {
		// range: LNK_BETA_2+[0..16*(send.backlog+1)-1]
		send.slot = LNK_BETA_2 + ((uint16_t)random() % (16*((uint16_t)send.backlog+1)));
	}
	sei();
	
	// call lnk_con if transmitted all data
	if (send.status == SEND_STAT_INFORM) {
		// add backlog
		if (send.backlog >= (uint8_t)(0xff-send.backlog_add))
			send.backlog = 0xff;
		else
			send.backlog += send.backlog_add;
		// call network layer
		lnk_con();
		send.status = SEND_STAT_IDLE;
	}
	
	// any received packet ready for processing?
	if (receive.status == RECV_STAT_EXAMINE) {
		if (send.backlog > 0) send.backlog--;
		// call network layer only if valid packet (length && crc right)
		if ((receive.pos == receive.buf[0]+4) &&
		    (receive.crc16 == *((uint16_t*)(receive.buf+receive.pos-2)))) {
			// add backlog delta
			if (send.backlog >= (uint8_t)(0xff-receive.buf[1]))
				send.backlog = 0xff;
			else
				send.backlog += receive.buf[1];
			// call network layer
			lnk_ind(receive.buf+2, receive.buf[0]);
		} else {
			if (receive.pos != receive.buf[0]+4)
				err.rx_len++;
			else
				err.rx_crc++;
		}
		// return to normal operation
		receive.pos = 0;
		receive.crc16 = 0;
		receive.status = RECV_STAT_FREE;
	}
}

/**
 * \brief Schedule a packet for sending.
 *
 * This function returns without waiting for the packet to be sent. If the
 * packet is fully transmitted then lnk_con is called.
 *
 * \param buf A network buffer containing the data to be sent. Must not be
 *            released until lnk_con() is called.
 * \param backlog Link layer backlog field. See OpenHome.doc for a detailed
 *                discussion of this field.
 * \return Zero if a transmission is already in progress and the packet
 *         could not be processed. Otherwise it returns a nonzero value.
 */
int8_t lnk_requ(net_buf_t *buf, uint8_t backlog)
{
	uint8_t len, *data, i;
	uint16_t crc;
	
	// already sending?
	if (send.status != SEND_STAT_IDLE) return 0;
	
	// prepend link layer header
	len = buf_len(buf);
	buf_prep_char(buf, backlog);
	buf_prep_char(buf, len);
	
	// calculate and append checksum
	len += 2;
	data = buf->data;
	crc = 0;
	while (len > 0) {
		len--;
		crc ^= ((uint16_t)(*data++) << 8);
		for (i=0; i<8; i++) {
			if (crc & 0x8000)
				crc = (crc << 1) ^ POLY_CRC16;
			else
				crc <<= 1;
		}		
	}
	buf_app_int(buf, crc);
	
	// prepare for sending
	send.data = *buf;
	send.backlog_add = backlog;
	send.slot = 0xffff;
	send.status = SEND_STAT_WAIT;
	return 1;
}

/**
 * \brief Check if link layer is able to process further packets.
 *
 * \return Returns a nonzero value if the link layer is ready to process
 *         the next packet.
 */
uint8_t lnk_clear_to_send(void)
{
	return send.status == SEND_STAT_IDLE;
}

/**
 * \brief Fill a buffer with link layer error statistics.
 *
 * \param buf A pointer to a structure receiving the error statistics.
 */
void lnk_get_error_stats(struct lnk_err_t *buf)
{
	memcpy(buf, &err, sizeof(err));
}
