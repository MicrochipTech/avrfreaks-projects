/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file application.c
 * \brief Presentation layer implementation and application layer manager.
 *
 * This file implements the OpenHome presentation layer and manages all
 * application objects. It also contains the system object which is responsible
 * for network management and node configuration.
 *
 * All application defined objects must have a predefined structure to be
 * accessable by this layer. Assuming that your application should contain a
 * object called "switch1" you have to define and implement the following:
 *
 * \code
 * #include <avr/pgmspace.h>
 * #include <inttypes.h>
 * #include "net/application.h"
 * 
 * #define METHOD_0	0x00
 * #define METHOD_1	0x01
 * #define EVENT_0	0x80
 * 
 * void switch1_callback(void *self,       // pointer to application object
 *                       uint8_t method,   // method which is called
 *                       uint8_t *buf,     // pointer to parameters buffer
 *                       uint8_t *result,  // pointer to result buffer
 *                       uint8_t repeated) // indicated duplicate requests
 * {
 * 	switch (method) {
 * 		case METHOD_0:
 * 			DoSomethingUseful();
 * 			break;
 * 		case METHOD_1:
 * 			break;
 * 		case EVENT_0:
 * 			ProvideDataToResultPointer();
 * 			break;
 * 	}
 * }
 * 
 * static param_desc_t switch1_methods[] = {{2,0}, {1,0}, {0,1}, {1,0}, {0,1}};
 * static param_desc_t switch1_events[] = {{0,0}, {0,2}};
 * \endcode
 *
 * The purpose of the callback method should be evident. The function is also
 * called if a event was triggered in order to collect the outgoing parameters.
 * Note that 0x80 is added to "method" to indicate a event!
 *
 * The tricky part now is the definition of the two tables. They define the
 * size of the parameters for all methods and events. The above definition of
 * switch1_methods indicate that method 0 expects two bytes as input parameters
 * and does not return any data while method 2 expects no parameters and
 * returns one byte. It is up to the applications how these bytes are
 * interpreted. Exactly as the switch1_methods-table the switch1_events-table
 * defines the size of the in- and outgoing parameters for all events.
 *
 * It is possible to compile this file in two versions: static and dynamic.
 * This influences the way the actual application objects are defined and
 * registered.
 *
 * <b>Static version</b><br>
 * The static version defines all object tables to be stored in flash memory.
 * It is intended for non-interactive nodes with limited memory. To compile
 * this version you have to define the following in your \link net_h net.h\endlink:
 *
 * \code
 * #define APP_STATIC
 * #define APP_OBJECTS OBJECT(switch1, 2) OBJECT(switch2, 2)
 * \endcode
 *
 * The above definitions tells the application layer to be compiled as static
 * version and that the application contains two objects called "switch1" and
 * "switch2" which both have two events. The number of events must be specified
 * to enable the application layer to reserve the right amount of eeprom space.
 *
 * The actual application objects must be defined the following:
 *
 * \code
 * struct AppObject PROGMEM switch1 = {
 * 	switch1_methods,
 * 	switch1_events,
 * 	switch1_callback
 * };
 * struct AppObject PROGMEM switch2 = {
 * 	switch2_methods,
 * 	switch2_events,
 * 	switch2_callback
 * };
 * \endcode
 *
 * <b>Dynamic version</b><br>
 * The dynamic version stores all object tables in ram and is suited for
 * interactive nodes with sufficient memory. It enables the node to dynamically
 * generate and register objects during initialization.
 *
 * To compile for this version make sure that the APP_STATIC token is not
 * defined. Application objects are registered through a call of
 * app_register_obj() and should be defined and initialized the following:
 *
 * \code
 * struct AppObject *switch1;
 * 
 * void init(void)
 * {
 * 	switch1 = malloc(sizeof(struct AppObject));
 * 	switch1->method_sizes = switch1_methods;
 * 	switch1->event_sizes = switch1_events;
 * 	switch1->Callback = switch1_callback;
 * 	app_register_obj(switch1, 2);
 * }
 * \endcode
 *
 * \author Jan Kl�tzke
 *
 * History:
 * - 02.08.2003: first version
 * - 15.08.2003: added support for non-static object definitions (= nearly rewritten)
 */

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <inttypes.h>
#include <stddef.h>
#include "net/application.h"
#include "net/network.h"
#include "net/link.h"
#include "net/buffers.h"
#include "net.h"
#include "utils.h"

// local type definitions
/** \internal
 * \brief Structure containing event configuration.
 *
 * Used internally to store the configuration of an event in eeprom.
 */
typedef struct {
		net_addr_t addr;		///< Peer network address.
		enum tsp_service_e service;	///< Transport layer service type.
		uint8_t assoc;			///< Association which is referenced.
	} event_desc_t;

/** \internal
 * \brief An association.
 */
typedef struct {
		uint8_t id;	///< Association id.
		uint8_t obj;	///< Object pointing to.
		uint8_t method; ///< Method of referenced object.
	} assoc_t;

/** \internal
 * \brief Event ring buffer entry.
 */
typedef struct {
		uint8_t obj;
		uint8_t event;
	} event_t;

// forward definitions for local object functions
static void __sys_obj_method(void *self, uint8_t property, uint8_t *buf, uint8_t *result, uint8_t repeated);
static param_desc_t __sys_obj_prop[];

#ifdef APP_STATIC
	#define READ_WORD(x)	pgm_read_word(&(x))
	
	// system object
	static struct AppObject PROGMEM __sys_obj = {__sys_obj_prop, NULL, __sys_obj_method};

	// generate list of external object references
	#define OBJECT(x, y)	extern struct AppObject PROGMEM x;
	APP_OBJECTS
	#undef OBJECT

	// allocate eeprom for events
	#define OBJECT(x, y)	event_desc_t x##_ev[y] EEPROM;
	APP_OBJECTS
	#undef OBJECT

	// generate application object table
	#define OBJECT(x, y)	,&x
	static const struct AppObject *  PROGMEM app_object_table[] = {&__sys_obj APP_OBJECTS};
	#undef OBJECT
	
	// generate event table
	#define OBJECT(x, y)	,x##_ev
	static event_desc_t * PROGMEM events_table[] = {NULL APP_OBJECTS};
	#undef OBJECT
#else
	#define READ_WORD(x)	(x)
	extern char __eeprom_end;

	// system object
	static struct AppObject __sys_obj = {__sys_obj_prop, NULL, __sys_obj_method};
	
	// tables
	static struct AppObject * app_object_table[16];
	static event_desc_t *events_table[16];
	
	static uint8_t next_obj = 1;
	void *next_eeprom_addr = &__eeprom_end;
#endif

// assiciation table
assoc_t ee_assoc[APP_MAX_ASSOC] EEPROM;

// sending network buffer
static net_buf_t buffer_info;
static struct main_buf_t {
		uint8_t header[13];
		uint8_t data[APP_BUFFER_SIZE];
	} buffer;
static uint8_t lock;

// event ring buffer (pre increment)
static event_t	event_buffer[APP_MAX_EVENTS];
static uint8_t event_rd, event_wr;
static net_addr_t dest;

/***
 * System network management object.
 */

#define SYS_ADDR_LOGIC_SET	0
#define SYS_ADDR_LOGIC_GET	1
#define SYS_ADDR_GROUP_SET	2
#define SYS_ADDR_GROUP_GET	3
#define SYS_SIZE_SEGMENT_SET	4
#define SYS_SIZE_SEGMENT_GET	5
#define SYS_SIZE_GROUP_SET	6
#define SYS_SIZE_GROUP_GET	7
#define SYS_ASSOC_SET		8
#define SYS_ASSOC_GET		9
#define SYS_GET_ERROR_STATS	10

static param_desc_t __sys_obj_prop[] = {{2,0}, {0,2}, {3,0}, {1,2}, {1,0},
	{0,1}, {2,0}, {1,1}, {4,0}, {1,3}, {0,8}};

static void __sys_obj_method(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case SYS_ADDR_LOGIC_SET:
			net_set_logic_addr(*((uint16_t*)buf));
			break;
		case SYS_ADDR_LOGIC_GET:
			*(uint16_t*)result = net_get_logic_addr();
			break;
		case SYS_ADDR_GROUP_SET:
			net_set_group_addr(buf[0], *((uint16_t*)(buf+1)));
			break;
		case SYS_ADDR_GROUP_GET:
			*((uint16_t*)result) = net_get_group_addr(buf[0]);
			break;
		case SYS_SIZE_SEGMENT_SET:
			tsp_set_segment_size(buf[0]);
			break;
		case SYS_SIZE_SEGMENT_GET:
			*result = tsp_get_segment_size();
			break;
		case SYS_SIZE_GROUP_SET:
			tsp_set_group_size(buf[0], buf[1]);
			break;
		case SYS_SIZE_GROUP_GET:
			*result = tsp_get_group_size(buf[0]);
			break;
		case SYS_ASSOC_SET:
			eeprom_write_byte(&ee_assoc[buf[0]].obj, buf[1]);
			eeprom_write_byte(&ee_assoc[buf[0]].method, buf[2]);
			// FIXME
			break;
		case SYS_ASSOC_GET:
			result[0] = eeprom_read_byte(&ee_assoc[buf[0]].obj);
			result[1] = eeprom_read_byte(&ee_assoc[buf[0]].method);
			// FIXME
			break;
		case SYS_GET_ERROR_STATS:
			lnk_get_error_stats((struct lnk_err_t *)result);
			break;
	}
}

/** \internal
 * \brief Call an object method respectively configure an event.
 *
 * \param obj Id of called object.
 * \param method Method which should be called. Add 0x80 to configure a event.
 * \param buf Pointer to method parameters.
 * \param len Length of method parameters buffer.
 * \param session Session flag from transport layer.
 */
static void call_method(uint8_t obj, uint8_t method, uint8_t *buf, uint8_t len, uint8_t session)
{
	struct AppObject *app;
	appObjCallback_t *obj_method;
	param_desc_t *params;
	event_desc_t *event;

	// event or method?
	if ((method&0x80) != 0) {
		event = (event_desc_t*)READ_WORD(events_table[obj]);
		// event written?
		if ((session != 2) && (len == sizeof(event_desc_t))) {
			eeprom_write_block(&event[method&0x7f], buf, sizeof(event_desc_t));
		}
		// event read?
		if (session) {
			lock = 1;
			buf_init(buffer_info, &buffer.data, sizeof(event_desc_t));
			eeprom_read_block(&buffer.data, &event[method&0x7f], sizeof(event_desc_t));
		}
	} else {
		app = (struct AppObject*)READ_WORD(app_object_table[obj]);
		params = (param_desc_t*)READ_WORD(app->method_sizes);
		if (len != PRG_RDB(&params[method].in)) return;
		
		obj_method = (appObjCallback_t*)READ_WORD(app->Callback);
		if (session) {
			lock = 1;
			buf_init(buffer_info, &buffer.data, PRG_RDB(&params[method].out));
			obj_method(app, method, buf, buffer.data, session==2);
		} else {
			obj_method(app, method, buf, NULL, 0); 
		}
	}
}

/********************************************************************************
 * functions called from transport layer
 */

/**
 * \brief Called from transport layer if a packet arrived.
 *
 * \param buf Pointer to the data of the packet.
 * \param len Length of the packet.
 * \param session Flag indicating duplicate requests.
 *                 - 0: Packet is not related to a session.
 *                 - 1: First request in a session.
 *                 - 2: Additional request in a session.
 */
net_buf_t *tsp_ind(uint8_t *buf, uint8_t len, uint8_t session)
{
	uint8_t obj, method, cnt, id;
	
	// can we fulfill request?
	if ((session) && (lock != 0)) return NULL;
	
	// examine object id
	if (buf[0] < 32) {
		// direct object addressing
		obj = buf[0];
		method = buf[1];
		call_method(obj, method, buf+2, len-2, session);
	} else {
		// association, look up association table
		len--;
		cnt = 0;
		do {
			id = eeprom_read_byte(&ee_assoc[cnt].id);
			if (id == buf[0]) {
				obj = eeprom_read_byte(&ee_assoc[cnt].obj);
				method = eeprom_read_byte(&ee_assoc[cnt].method);
				call_method(obj, method, buf+1, len, session);
			}
			cnt++;
		} while ((cnt < APP_MAX_ASSOC) && (id <= buf[0]));
	}
	
	return &buffer_info;
}

/**
 * \brief Called from transport layer if a reply to a request arrived.
 *
 * \param buf Pointer to data of the reply.
 * \param len Length of the reply.
 */
void tsp_con(uint8_t *buf, uint8_t len)
{
	uint8_t obj, event;
	struct AppObject *app;
	appObjCallback_t *obj_method;

	// get active event	
	obj = event_buffer[event_rd].obj;
	event = event_buffer[event_rd].event;
	
	// set data
	app = (struct AppObject*)READ_WORD(app_object_table[obj]);
	obj_method = (appObjCallback_t*)READ_WORD(app->Callback);
	obj_method(app, event|0x80, buf, NULL, 0);
}

/**
 * \brief Called from transport layer if a request was finished.
 *
 * \param status Zero if the request failed, otherwise non-zero.
 */
void tsp_con_fin(uint8_t status)
{
	lock = 0;
}

/********************************************************************************
 * Public functions
 */

/**
 * \brief Initialize layer.
 *
 * Should be called after lnk_init().
 */
void app_init(void)
{
	#ifndef APP_STATIC
	app_object_table[0] = &__sys_obj;
	#endif
}

/**
 * \brief Process waiting events.
 *
 * This function should be called from your main loop.
 *
 * \attention Must not be called from a interrupt routine. The implementation
 *            is not thread-save.
 */
void app_process(void)
{
	struct AppObject *app;
	appObjCallback_t *obj_method;
	param_desc_t *params;
	event_desc_t *ed;
	uint8_t len, obj, event;
	enum tsp_service_e service;

	// can we send at all?
	if (!tsp_clear_to_send() || (lock != 0)) return;
	
	// process pending events
	if (event_rd != event_wr) {
		// get event
		obj = event_buffer[(event_rd+1)&(APP_MAX_EVENTS-1)].obj;
		event = event_buffer[(event_rd+1)&(APP_MAX_EVENTS-1)].event;
		
		// prepare buffer
		app = (struct AppObject*)READ_WORD(app_object_table[obj]);
		params = (param_desc_t*)READ_WORD(app->event_sizes);
		len = PRG_RDB(&params[event].out);
		buf_init(buffer_info, &buffer.data, len);
		
		// get data
		obj_method = (appObjCallback_t*)READ_WORD(app->Callback);
		obj_method(app, event|0x80, NULL, buffer.data, 0);
		
		// add header, get destination info
		ed = (event_desc_t*)READ_WORD(events_table[obj]);
		eeprom_read_block(&dest, &ed[event].addr, sizeof(net_addr_t));
		service = (enum tsp_service_e)eeprom_read_byte(&ed[event].service);
		buf_prep_char(&buffer_info, eeprom_read_byte(&ed[event].assoc));
		
		// send...
		switch (tsp_requ(&buffer_info, &dest, service)) {
			case 1:
				lock = 1;
			case -1: 
				event_rd = (event_rd+1)&(APP_MAX_EVENTS-1);
			default:
				break;
		}
	}
}

/**
 * \brief Fire an event.
 *
 * \param obj Id of Object whose event should be triggered. This id is returned
 *            by app_register_object() or, in case of the static version, must
 *            be manually calculated.
 * \param event Event id.
 */
void app_trigger_event(uint8_t obj, uint8_t event)
{
	event_wr = (event_wr+1)&(APP_MAX_EVENTS-1);
	event_buffer[event_wr].obj = obj;
	event_buffer[event_wr].event = event;
}

#ifndef APP_STATIC

/**
 * \brief Dynamically register an object.
 *
 * In the current implementation it is not possible to unregister an object.
 * Furthermore all objects must be registered in the same order if a reset
 * occurs. Otherwise the event configurations will be corrupted.
 *
 * \param obj Pointer to application object.
 * \param events Number of events which the object has.
 */
uint8_t app_register_obj(struct AppObject *obj, uint8_t events)
{
	app_object_table[next_obj] = obj;
	events_table[next_obj] = next_eeprom_addr;
	(uint8_t*)next_eeprom_addr += events*sizeof(event_desc_t);
	return next_obj++;
}

#endif
