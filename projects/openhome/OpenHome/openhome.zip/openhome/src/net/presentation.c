/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <avr/pgmspace.h>
#include <inttypes.h>
#include "net/presentation.h"

static prog_uchar length_table[] = {0, 0, 1, 2, 4, 8, 4};
static uint8_t *tag_position, *dat_position;
static uint8_t length;

/***
 * Prepare to parse a given buffer.
 */
void prs_init(uint8_t* buf, uint8_t len)
{
	tag_position = buf;
	dat_position = (uint8_t*)0;
	length = len;
}

/***
 * Return current tag and advance to next one.
 *
 * If the end of the current buffer is reached 0xff will be returned.
 */
uint8_t prs_get_tag(void)
{
	uint8_t result, size;
	
	if (length == 0) return 0xff;
	
	result = *tag_position;
	tag_position++;
	dat_position = tag_position;
	length--;
	if ((result & P_TYPE_MASK) == P_TYPE_STRING) {
		// skip strings
		while ((*tag_position != 0) && (length-- > 0)) tag_position++;
		if (length > 0) {
			tag_position++;
			length--;
		}
	} else {
		size = __LPM(length_table+(result & P_TYPE_MASK));
		if (size <= length) {
			tag_position += size;
			length -= size;
		} else length = 0;
	}
	return result;
}

/***
 * Skip current tag.
 *
 * Parameter "tag" must hold the tag which was peviously returned
 * by "prs_get_tag()".
 */
void prs_skip(uint8_t tag)
{
	uint8_t level;
	
	// was the last tag a compound tag or only a value?
	if ((tag & P_TYPE_MASK) != P_TYPE_COMPOUND_OPEN) return;
	
	// we are inside a compund tag, skip it with all contents
	level = 1;
	do {
		tag = prs_get_tag();
		if (tag == 0xff) return;
		switch (tag & P_TYPE_MASK) {
			case P_TYPE_COMPOUND_OPEN:
				level++;
				break;
			case P_TYPE_COMPOUND_CLOSE:
				level--;
				break;
			default:
				break;
		}
	} while (level > 0);
}

uint8_t prs_get_char(void)
{
	return *dat_position;
}

uint16_t prs_get_int(void)
{
	return *((uint16_t*)dat_position);
}

char* prs_get_str(void)
{
	return dat_position;
}
