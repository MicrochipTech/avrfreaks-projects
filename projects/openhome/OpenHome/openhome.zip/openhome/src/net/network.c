/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file network.c
 * \brief Network layer implementation.
 *
 * Implements the OpenHome network layer. The code is quite straight forward
 * and rather self explainary.
 *
 * \attention Define a unique physical address (NET_LOGIC_ADDR) in your \link
 *            net_h net.h\endlink for each device.
 *
 * \author Jan Kl�tzke
 *
 * <b>History:</b>
 *	- 06.07.2003: first version
 */
 

#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include "net/link.h"
#include "net/network.h"
#include "net.h"
#include "utils.h"

// local variables
static net_ind_t ind;

// eeprom variables
uint16_t ee_addr_logic __attribute__(( section(".eeprom") ));
uint16_t ee_addr_group[8] __attribute__(( section(".eeprom") ));

// address length tables
static prog_uchar dest_length_table[] = {2,1,4,0};
static prog_uchar src_length_table[] = {2,2,4,0};

// header bit masks
#define DAF_MASK	0x03
#define SAF_MASK	0x0c
#define PDU_MASK	0x30

// external functions (transport layer)
extern void net_ind(uint8_t *buf, uint8_t len, const net_ind_t *ind);
extern void net_con(void);

/********************************************************************************
 * functions called from link layer
 */

/**
 * \brief Called from link layer if a packet has been received. 
 *
 * This function is also called for locally generated packets to determine if
 * the packet should be transmitted on the bus. If the destination address
 * of the packet matches a local one then net_ind() is called to pass it to
 * upper layers.
 *
 * \param buf Pointer to the data of the packet.
 * \param len Length of the packet.
 * \return One if the packet is only for this peer and should
 * not be sent across network, otherwise it returns zero.
 *
 * \note This function uses the local variable "ind" and passes a reference
 * to the transport layer through net_ind(). Though this is not a good practice
 * it saves stack and text space and should not lead to problems since the link
 * layer processes only one packet at the same time.
 */
uint8_t lnk_ind(uint8_t *buf, uint8_t len)
{
	uint8_t i, src_offset, src_len, result;
	
	// is this packet for us?
	result = 0;
	switch (buf[0] & DAF_MASK) {
		case NAF_LOGIC:
			if (*(uint16_t*)(buf+1) == eeprom_read_word(&ee_addr_logic)) {
				ind.rat = AT_LOGIC;
				result = 1;
				goto addr_match;
			}
			break;
		case NAF_GROUP:
			for (i=0;i<8;i++) 
				if (buf[1] == eeprom_read_byte(&ee_addr_group[i])) {
					ind.rat = AT_GROUP0+i;
					goto addr_match;
				}
			break;
		case NAF_PHYSIC:
			if (*(uint32_t*)(buf+1) == NET_PHYSICAL_ADDR) {
				result = 1;
				ind.rat = AT_PHYSIC;
				goto addr_match;
			}
			break;
		case NAF_BROADCAST:
			ind.rat = AT_PHYSIC;
			goto addr_match;
		default:
			break;
	}
	return 0;

addr_match:
	ind.pdu = (buf[0]>>4) & 0x03;
	ind.src.format = (buf[0] & SAF_MASK) >> 2;
	src_len = __LPM(&src_length_table[ind.src.format]);
	src_offset = __LPM(&dest_length_table[buf[0] & DAF_MASK])+1;
	buf += src_offset;
	for (i=0;i<src_len;i++) ind.src.addr[i] = *buf++;
	len -= src_len+src_offset;
	net_ind(buf, len, &ind);
	return result;
}

/**
 * \brief Called from link layer if a packet was delivered.
 *
 * Simply passes event to upper layers.
 */
void lnk_con(void)
{
	net_con();
}

/********************************************************************************
 * Public functions
 */

/**
 * \brief Send a packet.
 *
 * This functions adds the network layer specific header and passes
 * the packet to the link layer. Also checks if it should be delivered
 * locally.
 *
 * \param buf A network buffer containing the data to be sent. Must not be
 *            released until lnk_con() is called.
 * \param requ Structure containing network layer details such as the
 *             destination address.
 * \return A nonzero value if the packet could be scheduled for delivery,
 *         otherwise zero.
 */
uint8_t net_requ(net_buf_t *buf, const net_requ_t *requ)
{
	uint8_t hdr, i;
	
	// can we queue packet?
	if (!lnk_clear_to_send()) return 0;
	
	// prepare header
	hdr = (requ->pdu << 4) | requ->dest.format;
	
	// prepend source address
	if (requ->src == AT_LOGIC) {
		hdr |= NAF_LOGIC << 2;
		buf_prep_int(buf, eeprom_read_word(&ee_addr_logic));
	} else if (requ->src == AT_PHYSIC) {
		hdr |= NAF_PHYSIC << 2;
		buf_prep_long(buf, NET_PHYSICAL_ADDR);
	} else {
		hdr |= NAF_GROUP << 2;
		buf_prep_int(buf, eeprom_read_word(&ee_addr_group[requ->src-AT_GROUP0]));
	}
	
	// prepend destination address
	i = __LPM(&dest_length_table[requ->dest.format]);
	while (i > 0) buf_prep_char(buf, requ->dest.addr[--i]);
	
	// prepend header
	buf_prep_char(buf, hdr);
	
	// and go...
	if (lnk_ind(buf->data, buf->len)) {
		net_con();
		return 1;
	} else {
		return lnk_requ(buf, requ->backlog);
	}
}

/**
 * \brief Compares two source network addresses.
 *
 * Since source and destination addresses differ in the group address format
 * this function only compares two SOURCE network addresses.
 *
 * \param addr1 First source address.
 * \param addr2 Second source address.
 * \return One if the addresses match, otherwise zero.
 */
uint8_t net_compare_src_addr(const net_addr_t *addr1, const net_addr_t *addr2)
{
	uint8_t i, len;
	
	if (addr1->format != addr2->format) return 0;
	len = __LPM(&src_length_table[addr1->format]);
	for (i=0;i<len;i++) if (addr1->addr[i] != addr2->addr[i]) return 0;
	return 1;
}

/**
 * \brief Returns local member number for a group.
 *
 * \param group Group from which the node's member number should be returned.
 *              Use AT_GROUP* constants.
 * \return Group member number.
 */
uint8_t net_get_local_member_id(uint8_t group)
{
	return eeprom_read_byte(&ee_addr_group[group-AT_GROUP0]+1);
}

/**
 * \brief Check if another packet can be scheduled for transmission.
 *
 * \return Returns a nonzero value if a new packet could be passed to the
 *         network layer.
 */
uint8_t net_clear_to_send(void)
{
	return lnk_clear_to_send();
}

/**
 * \brief Set logic address.
 *
 * \param addr New logic address.
 */
void net_set_logic_addr(uint16_t addr)
{
	eeprom_write_word(&ee_addr_logic, addr);
}

/**
 * \brief Get logic address.
 *
 * \return Current logic address.
 */
uint16_t net_get_logic_addr(void)
{
	return eeprom_read_word(&ee_addr_logic);
}

/**
 * \brief Set address of a group.
 *
 * \param group Number of group which to set. [0..7]
 * \param addr Full qualified group node address.
 */
void net_set_group_addr(uint8_t group, uint16_t addr)
{
	eeprom_write_word(&ee_addr_group[group], addr);
}

/**
 * \brief Get group address.
 *
 * \param group Number of group.
 * \return Group node address.
 */
uint16_t net_get_group_addr(uint8_t group)
{
	return eeprom_read_word(&ee_addr_group[group]);
}
