/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file transport.c
 * \brief Transport layer implementation.
 *
 * The transport layer is responsible for reliable packet delivery and to
 * provide a request/response (session) service. For correct function of this
 * layer you have to call some special functions.
 *
 * Firstly tsp_process(), preferably directly from the main loop. Secondly
 * tsp_check_timeout() at a fixed rate but NOT from a timer interrupt routine.
 * This is because the implementation is not thread-save. Instead call it from
 * the main loop. See the following code to get a idea how to do it:
 *
 * \code
 * uint8_t timer_flag;
 *
 * SIGNAL(SIG_OVERFLOW1)
 * {
 * 	timer_flag++;
 * }
 *
 * void main(void)
 * {
 * 	...
 * 	for (;;) {
 * 		while (timer_flag > 0) {
 * 			timer_flag--;
 * 			tsp_check_timeout();
 * 		}
 *		tsp_process();
 * 	}
 * 	...
 * }
 * \endcode
 * 
 * <b>Standalone usage</b>
 *
 * If you use the protocol stack only for communication and not for a home
 * automation system then this is the layer to be called from your application.
 * The usage is straigt forward.
 *
 * To receive packets provide a non-static function defined as follows:
 * \code
 * net_buf_t *tsp_ind(uint8_t *buf, uint8_t len, uint8_t session)
 * {
 * }
 * \endcode
 * It will be called every time a packet is received for this node. Any passed
 * data must be processed within the function or copied to another buffer. Do
 * not save the buf-pointer since the buffer he points to will be overwritten
 * with the next received packet.
 *
 * You also have to define the following two function:
 * \code
 * void tsp_con(uint8_t *buf, uint8_t len)
 * {
 * }
 * 
 * void tsp_con_fin(uint8_t status)
 * {
 * }
 * \endcode
 * They will be called if a request generated reply data and when a transaction
 * has been finished.
 * \note Currently tsp_con_fin() is also called if tsp_ind() indicated a
 * session, a reply was provided and the reply has been transmitted. This
 * behaviour is used to signal upper layers that the provided buffer can now be
 * used for other things. Expect this to be changed in fututre because firstly
 * it is not a clean solution and secondly it is unclear what a call to
 * tsp_con_fin() means if multiple sessions are running.
 * 
 * \author Jan Kl�tzke
 *
 * History:
 * - 09.07.2003: started first version
 * - 28.07.2003: 
 *	         - fixed tnr overflow bug
 *               - only sessions now call tsp_con
 * - 01.08.2003: added session flag to tsp_ind
 *		 (0=no session; 1=session, first call; 2=session, further call)
 * - 02.08.2003: added tsp_clear_to_send
 * - 07.08.2003: added local generation of tsp_con_fin for unacknowledged packets
 */

#include <avr/eeprom.h>
#include <inttypes.h>
#include <stddef.h>
#include <string.h>
#include "net/network.h"
#include "net/transport.h"
#include "utils.h"
#include "net.h"

// group and segment sizes
uint8_t ee_group_size[TSP_MAX_GROUPS] EEPROM;
uint8_t ee_segment_size EEPROM;

// some bit masks
#define TPDU_MASK	0x30
#define SEQU_MASK	0x0f

// transport layer pdu types
#define TPDU_ACKED_MSG	0x00
#define TPDU_UACKED_MSG	0x01
#define TPDU_ACK	0x02
#define TPDU_REMINDER	0x03


/** \internal
 * \brief Cache entry holding information about a transaction.
 *
 * To keep track of all running transactions (and to eleminate duplicates) a
 * cache stores all relevant informations.
 */
struct cache_entry_t {
		net_addr_t addr;	///< Address of peer.
		uint8_t sequ;		///< Actual sequence number.
		uint8_t got_ack;	///< Did the client got our ack?
	};

/** \internal
 * \brief Ring buffer entry for pending packets.
 */
struct reply_entry_t {
		uint8_t header;		///< Transport layer header.
		net_requ_t requ;	///< Network layer request block.
		net_buf_t *buf;		///< What to send.
		uint8_t local_fin;	///< Should tsp_con_fin() be called? Needed for unacknowledged service.
	};
	
static struct cache_entry_t cache[TSP_CACHE_SIZE];
static struct reply_entry_t reply_buffer[TSP_REPLY_SIZE];	// pre increment
static uint8_t reply_rd, reply_wr;

// buffer for ack's and reminder
static net_buf_t buffer_info;
/** \internal \brief Internal buffer for reminder and acknowledgements. */
static struct tsp_int_buf {
		uint8_t header[12];	///< Worst case header usage.
		uint8_t ack[2];		///< Buffer for ack. (CRC goes here)
		uint8_t reminder[8];	///< Buffer for reminder bitmat.
		uint8_t dummy[2];	///< Contains checksum when sending reminder.
	} buffer;

static uint8_t tnr;			// current transaction
static uint8_t timeout;			// timeout counter
static uint8_t tries;			// remaining tries
static uint8_t remaining;		// outstanding ack's
static struct reply_entry_t current;	// current transaction/request

// external functions
extern net_buf_t *tsp_ind(uint8_t *buf, uint8_t len, uint8_t session);
extern void tsp_con(uint8_t *buf, uint8_t len);
extern void tsp_con_fin(uint8_t status);

static inline void timeout_start(void)
{
	timeout = TSP_TIMEOUT;
}

static inline void timeout_restart(void)
{
	timeout = TSP_TIMEOUT;
}

static inline void timeout_stop(void)
{
	timeout = 0;
}

/** \internal
 * \brief Refresh the tranaction cache entry for "from".
 *
 * If the address given in "from" does not exist in the cache a new entry will
 * be created and the oldest one will be removed. Otherwise the entry is moved to
 * top of the cache. You can alway assume that cache[0] is holding the
 * appropriate entry after calling this function.
 *
 * \param from Network address for which the cache should be updated.
 *
 * \todo Check if cache organization would be better as linked list.
 */
static void cache_refresh(const net_addr_t *from)
{
	uint8_t i;
	struct cache_entry_t tmp;
	
	// check cache for address match
	i = 0;
	while (i < TSP_CACHE_SIZE) {
		if (net_compare_src_addr(from, &cache[i].addr)) goto match;
		i++;
	}
	
	// entry not found in cache, create new
	for (i=TSP_CACHE_SIZE-1;i>0;i--) cache[i] = cache[i-1];
	cache[0].addr = *from;
	cache[0].sequ = 0xff;
	cache[0].got_ack = 0;
	return;
	
match:
	// move entry to top of list
	tmp = cache[i];
	while (i>0) {
		cache[i] = cache[i-1];
		i--;
	}
	cache[0] = tmp;
	return;
}

/** \internal
 * \brief Check if the peer already got our reply.
 *
 * \param sequ Current sequence number.
 * \note cache_refresh() has to be called prior to this function!
 */
static uint8_t cache_got_reply(uint8_t sequ)
{
	if (cache[0].sequ != sequ) return 0;
	return cache[0].got_ack;
}

/** \internal
 * \brief Queue a acknowledgement respectively response.
 *
 * \param ind Network layer indication block of the original packet.
 * \param buf Network buffer containing the response. NULL if a acknowledgment
 *            should be sent.
 * \param sequ Sequence number of original packet.
 */
static void queue_reply(const net_ind_t *ind, net_buf_t *buf, uint8_t sequ)
{
	reply_wr = (reply_wr+1) & (TSP_REPLY_SIZE-1);
	reply_buffer[reply_wr].header = (TPDU_ACK << 4)|sequ;
	reply_buffer[reply_wr].requ.dest = ind->src;
	reply_buffer[reply_wr].requ.src = ind->rat;
	reply_buffer[reply_wr].requ.pdu = ind->pdu;
	reply_buffer[reply_wr].requ.backlog = 0;
	reply_buffer[reply_wr].buf = buf;
}

/** \internal
 * \brief Calculate link layer backlog field for a acknowledged service.
 *
 * \param addr Destination address of the packet.
 * \return Returns expected number of replies (backlog) for the given
 * destination address.
 */
static uint8_t calc_backlog(net_addr_t *addr)
{
	switch (addr->format) {
		case NAF_LOGIC:
			return 1;
		case NAF_GROUP:
			return eeprom_read_byte(&ee_group_size[addr->addr[0]]);
		case NAF_PHYSIC:
			return 1;
		case NAF_BROADCAST:
			return eeprom_read_byte(&ee_segment_size);
	}
	return 0;
}

/********************************************************************************
 * functions called from network layer
 */

/**
 * \brief Called from network layer if a packet arrived for us...
 *
 * \param buf Pointer to the data of the packet.
 * \param len Length of the packet.
 * \param ind Structure containing network layer specific information of the 
 *            packet.
 */
void net_ind(uint8_t *buf, uint8_t len, const net_ind_t *ind)
{
	uint8_t sequ, id;
	net_buf_t *tmp;
	
	// only single message?
	if (ind->pdu == NPDU_SINGLE) {
		tsp_ind(buf, len, 0);
		return;
	}

	// we've got a transaction (or session)
	switch (buf[0] & TPDU_MASK)  {
		case TPDU_ACKED_MSG<<4:
			cache_refresh(&ind->src);		// refresh cache
			sequ = buf[0]&SEQU_MASK;
			if (cache_got_reply(sequ)) return;	// already got reply
			if (ind->pdu == NPDU_SESSION) {
				// only queue reply if tsp_ind returns a buffer
				tmp = tsp_ind(buf+1, len-1, (cache[0].sequ != sequ)?1:2);
				if (tmp != NULL) queue_reply(ind, tmp, sequ);
			} else {
				// always send ack
				queue_reply(ind, NULL, sequ);
				// only call tsp_ind if not a duplicate
				if (cache[0].sequ != sequ) tsp_ind(buf+1, len-1, 0);
			}
			cache[0].sequ = sequ;	// remember current sequence
			break;
						
		case TPDU_UACKED_MSG<<4:
			cache_refresh(&ind->src);		// refresh cache
			sequ = buf[0]&SEQU_MASK;
			if (cache[0].sequ != sequ) {
				tsp_ind(buf+1, len-1, 0);
				cache[0].sequ = sequ;
			}
			break;
			
		case TPDU_ACK<<4:
			// do we expect an ack?
			if (remaining == 0) break;
			// Look if matching current transaction. Since we will not
			// have multiple transactions running comparison of the
			// sequence number is enough.
			if ((buf[0]&SEQU_MASK) == (current.header&SEQU_MASK)) {
				// pass potential data to session layer
				if (ind->pdu == NPDU_SESSION) tsp_con(buf+1, len-1);
				// if a multicast source address is used, update reminder
				if (ind->src.format == NAF_GROUP) {
					id = ind->src.addr[1];
					// have we already got an ack from this peer?
					if ((buffer.reminder[id>>3] & (1<<(id&0x07))) == 0) {
						buffer.reminder[id>>3] |= 1<<(id&0x07);
						remaining--;
					}
				} else {
					// single cast, all done...
					remaining = 0;
				}
				// transaction finished?
				if (remaining == 0) {
					timeout_stop();
					tsp_con_fin(1);
				}
			}
			break;
			
		case TPDU_REMINDER<<4:
			cache_refresh(&ind->src);
			// only for running transaction
			if (cache[0].sequ != (buf[0]&SEQU_MASK)) return;
			// look in bitmat if peer got ack
			id = net_get_local_member_id(ind->rat);
			if (buf[(id>>3)+1] & (1 << (id&0x07))) cache[0].got_ack = 1;
			break;
	}
}

/**
 * \brief Called from network layer if a queued packet was sent.
 *
 * Checks if tsp_con_fin() should be called.
 */
void net_con(void)
{
	if (reply_buffer[reply_rd].local_fin) tsp_con_fin(1);
}


/********************************************************************************
 * Public functions
 */

/**
 * \brief Process waiting packets and schedule them for transmission.
 *
 * This function should be called from your main loop.
 *
 * \attention Must not be called from a interrupt routine. The implementation
 *            is not thread-save.
 */
void tsp_process(void)
{
	net_buf_t *buf;
	
	// check if network layer accepts packet
	if (!net_clear_to_send()) return;

	// anything to send?
	if (reply_rd != reply_wr) {
		reply_rd = (reply_rd+1) & (TSP_REPLY_SIZE-1);
		
		// determine data to send and copy to buffer_info
		buf = reply_buffer[reply_rd].buf;
		if (reply_buffer[reply_rd].requ.pdu == NPDU_SINGLE) {
			// single message, add no header
			buffer_info = *buf;
		} else {
			// transaction
			switch (reply_buffer[reply_rd].header&TPDU_MASK) {
				case TPDU_ACK<<4:
					if (buf == NULL) {
						// do not overwrite reminder with checksum!
						buf_init(buffer_info, &buffer.ack, 0);
					} else {
						buffer_info = *buf;
						/// \todo Remove dirty hack ensuring that buffer of sesion
						/// reply gets released.
						reply_buffer[reply_rd].local_fin = 1;
					}
					break;
				case TPDU_REMINDER<<4:
					buf_init(buffer_info, &buffer.reminder, 1+sizeof(buffer.reminder));
					break;
				default:
					buffer_info = *buf;
			}
			buf_prep_char(&buffer_info, reply_buffer[reply_rd].header);
		}
		// try to send, if not successful leave current entry
		if (!net_requ(&buffer_info, &reply_buffer[reply_rd].requ)) {
			reply_rd = (reply_rd-1) & (TSP_REPLY_SIZE-1);
		}
	}
}

/**
 * \brief Check transport layer timeouts.
 *
 * This function must be called at a fixed rate from the main loop.
 *
 * \attention It cannot be called from a timer interrupt because it is not
 * thread save!
 */
void tsp_check_timeout(void)
{
	if (remaining == 0) return;
	if (timeout == 0) return;

	timeout--;
	if (timeout == 0) {
		if (tries > 0) {
			// try again
			tries--;
			// do we have to send a reminder?
			if (current.requ.dest.format == NAF_GROUP) {
				reply_buffer[reply_wr] = current;
				reply_buffer[reply_wr].header = (reply_buffer[reply_wr].header&SEQU_MASK) | (TPDU_REMINDER<<4);
				reply_buffer[reply_wr].requ.backlog = 0;
				reply_wr = (reply_wr+1) & (TSP_REPLY_SIZE-1);
			}
			reply_wr = (reply_wr+1) & (TSP_REPLY_SIZE-1);
			reply_buffer[reply_wr] = current;
			reply_buffer[reply_wr].requ.backlog = remaining;
			timeout = TSP_TIMEOUT;
		} else {
			// request failed
			remaining = 0;
			tsp_con_fin(0);
		}
	}
}

/**
 * \brief Send a packet using a transport layer sevice.
 *
 * This function does return without waiting for the packet to be transmitted.
 * Check the return value if the packet was scheduled for transmission.
 *
 * \param buf Network buffer containing the packet data.
 * \param dest Destination network address.
 * \param service Transport layer service used for transmission.
 * \return Returns -1 for a invalid request, 0 if the request could not be
 *         processed currently or 1 if successfull.
 */
int8_t tsp_requ(net_buf_t *buf, net_addr_t *dest, enum tsp_service_e service)
{
	uint8_t i;
	
	// transaction running?
	if (remaining != 0) return 0;
		
	// determine service parameters
	i = 1;
	current.requ.dest = *dest;
	current.requ.src = AT_LOGIC;
	current.buf = buf;
	current.local_fin = 0;
	switch (service) {
		case S_DGRAM:
			current.requ.pdu = NPDU_SINGLE;
			current.requ.backlog = 0;
			break;
		case S_REPEATED:
			current.header = (TPDU_UACKED_MSG<<4)|(tnr&SEQU_MASK);
			current.requ.pdu = NPDU_TRANSACTION;
			current.requ.backlog = 0;
			tnr++;
			i = 4;
			break;
		case S_ACKED:
			current.header = (TPDU_ACKED_MSG<<4)|(tnr&SEQU_MASK);
			current.requ.pdu = NPDU_TRANSACTION;
			current.requ.backlog = calc_backlog(dest);
			timeout_start();
			tnr++;
			break;			
		case S_REQUEST:
			current.requ.pdu = NPDU_SESSION;
			current.header = (TPDU_ACKED_MSG<<4)|(tnr&SEQU_MASK);
			current.requ.backlog = calc_backlog(dest);
			timeout_start();
			tnr++;
			break;
		default:
			return -1;
	}
	
	// clear reminder
	memset(&buffer.reminder, 0, sizeof(buffer.reminder));
	
	// queue message(s)
	remaining = current.requ.backlog;
	tries = 3;
	while (i > 0) {
		// generate local tsp_con_fin for last unacknowledged packet
		if ((i==1) && (service <= S_REPEATED)) current.local_fin = 1;
		reply_wr = (reply_wr+1) & (TSP_REPLY_SIZE-1);
		reply_buffer[reply_wr] = current;
		i--;
	}
	
	return 1;
}

/**
 * \brief Returns a nonzero value if a new packet could be passed to the transport layer.
 */
uint8_t tsp_clear_to_send(void)
{
	return remaining == 0;
}

/**
 * \brief Set size of segment.
 *
 * \param size New segment size.
 */
void tsp_set_segment_size(uint8_t size)
{
	eeprom_write_byte(&ee_segment_size, size);
}

/**
 * \brief Get segment size.
 *
 * \return Current segment size.
 */
uint8_t tsp_get_segment_size(void)
{
	return eeprom_read_byte(&ee_segment_size);
}

/**
 * \brief Set size of a group.
 *
 * \param group Group number of group which size is about to be set. [0..TSP_MAX_GROUPS-1]
 * \param size The new group size.
 */
void tsp_set_group_size(uint8_t group, uint8_t size)
{
	eeprom_write_byte(&ee_group_size[group], size);
}

/**
 * \brief Get size of a group.
 *
 * \param group Group number. [0..TSP_MAX_GROUPS-1]
 * \return Size of group.
 */
uint8_t tsp_get_group_size(uint8_t group)
{
	return eeprom_read_byte(&ee_group_size[group]);
}
