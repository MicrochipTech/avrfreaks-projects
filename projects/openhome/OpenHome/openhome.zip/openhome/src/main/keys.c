/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file keys.c
 * \brief Keypad management routines.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <inttypes.h>
#include "main/keys.h"

#define KEY_PRESS	5
#define KEY_REPEAT	96
#define KEY_DELAY	12

static uint8_t cycle = 0;
static uint8_t leds, status;
static uint8_t key_counter[8];
static uint8_t key_buffer[8];
static uint8_t key_repeat_mask = 0;
static volatile uint8_t kbd_rd, kbd_wr = 0;

/**
 * \brief Scans through all keys and, if a keypress is detected, stores the
 * key-code in the keyboard buffer.
 *
 * Also drives key-leds. Called every millisecond.
 */
void keys_sense_keys(void)
{
	uint8_t key, mask, stat;
	
	// drive led's and capture key stats
	cycle++;
	if (cycle & 0x01) {
		// ch2
		cbi(PORTD, PD5);
		PORTC = (PORTC & 0xf0) | (leds >> 4);
		sbi(PORTD, PD4);
		asm volatile ("nop");
		status = (status & 0x0f) | (PINF & 0xf0);
	} else {
		// ch1
		cbi(PORTD, PD4);
		PORTC = (PORTC & 0xf0) | (leds & 0x0f);
		sbi(PORTD, PD5);
		asm volatile ("nop");
		status = (status & 0xf0) | (PINF >> 4);
	}
	
	// scan for keypress every 8ms
	if (cycle < 8) return;
	cycle = 0;
	stat = status;
	mask = key_repeat_mask;
	for (key=0; key<8; key++) {
		if (stat & 1) {
			key_counter[key]++;	// key pressed
		} else {
			key_counter[key] = 0;	// key released
		}

		if (key_counter[key] > KEY_REPEAT) {
			key_counter[key] -= KEY_DELAY;
			if ((mask & 1) == 0) goto skip;
		} else {
			if (key_counter[key] != KEY_PRESS) goto skip;
		}
		key_buffer[kbd_wr++] = key+1;
		kbd_wr &= 7;

	skip:
		mask >>= 1;
		stat >>= 1;
	}
}

/**
 * Check if key was pressed.
 */
uint8_t keys_key_pressed(void)
{
	return kbd_rd != kbd_wr;
}

/**
 * Get next key-code.
 */
uint8_t keys_get_key(void)
{
	uint8_t result;
	
	while (kbd_rd == kbd_wr);
	result = key_buffer[kbd_rd++];
	kbd_rd &= 7;
	return result;
}

/**
 * Set brightness of all LED's. Use LED_* constants.
 */
void keys_set_leds(uint8_t mask)
{
	leds = ~mask;
}

/**
 * Set the repeat-mask for all keys.
 */
void keys_set_repeat_mask(uint8_t mask)
{
	key_repeat_mask = mask;
}
