/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include "net/application.h"
#include "net/snt.h"
#include "main/keys.h"
#include "main/lcd.h"
#include "main/rom.h"
#include "main/menu.h"
#include "main/dimmer.h"

// methods
#define SW_SWITCH_FB	0

// events
#define SW_ON_SWITCH	0

// parameter tables
static param_desc_t dimmer_prop[] = {{2,0}};
static param_desc_t dimmer_events[] = {{0,2}};

// forward definition
static void DimmerAppObj_Callback(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);


Dimmer::Dimmer(void)
{
	struct DimmerAppObj *app;

	app = new DimmerAppObj;
	app->property_sizes = dimmer_prop;
	app->event_sizes = dimmer_events;
	app->Callback = DimmerAppObj_Callback;
	app->state.value = 0xff;
	app->parent = this;
	app->id = app_register_obj((struct AppObject*)app, 1);

	this->app = app;
}

bool Dimmer::Activate(void)
{
	menu_set_hook(2, i_tray_dim_down, this);
	menu_set_hook(3, i_tray_dim_up, this);
	menu_set_hook(4, i_tray_switch_off, this);
	menu_set_hook(5, i_tray_switch_on, this);
	keys_set_repeat_mask(REP_FUNC_3|REP_FUNC_4);
	keys_set_leds(LED_FUNC_3|LED_FUNC_4|LED_FUNC_5|LED_FUNC_6|LED_MENU_UP|LED_MENU_DOWN);
	return VisibleObject::Activate();
}

void Dimmer::Deactivate(void)
{
	VisibleObject::Deactivate();
	menu_remove_hook(2);
	menu_remove_hook(3);
	menu_remove_hook(4);
	menu_remove_hook(5);
}

void Dimmer::Display(void)
{
	if (active) {
		if (app->state.state) {
			lcd_put_image(x, y, i_dim_on);
		} else {
			lcd_put_image(x, y, i_dim_off);
		}
	} else {
		if (app->state.state) {
			lcd_put_image(x, y, i_dim_on_na);
		} else {
			lcd_put_image(x, y, i_dim_off_na);
		}
	}
	lcd_h_line(x+13, x+13+((47*app->state.value) >> 8), y+2);
	lcd_h_line(x+13, x+13+((45*app->state.value) >> 8), y+3);
	lcd_h_line(x+13, x+13+((41*app->state.value) >> 8), y+4);
}

void Dimmer::KeyCallback(uint8_t key)
{
	switch (key) {
		case 2: if (app->state.value > 5) 
				app->state.value -= 5;
			else 
				app->state.value = 0;
			app->state.state = 1;
			break;
		case 3: if (app->state.value < 250)
				app->state.value += 5;
			else
				app->state.value = 255;
			app->state.state = 1;
			break;
		case 4: app->state.state = 0; break;
		case 5: app->state.state = 1; break;
	}
	app_trigger_event(app->id, SW_ON_SWITCH);
	Display();
}

// DimmerAppObj
static void DimmerAppObj_Callback(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case SW_SWITCH_FB:
			((struct DimmerAppObj*)self)->state = *((snt_switch*)buf);
			// FIXME: must not display if parent is hidden
			((struct DimmerAppObj*)self)->parent->Display();
			break;
		case SW_ON_SWITCH|0x80:
			*((snt_switch*)result) = ((struct DimmerAppObj*)self)->state;
			break;
	}
}
