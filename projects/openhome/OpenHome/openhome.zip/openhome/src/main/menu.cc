/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <avr/pgmspace.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include "net/presentation.h"
#include "main/menu.h"
#include "main/rom.h"
#include "main/lcd.h"
#include "main/keys.h"
#include "utils.h"

#include "main/switch.h"
#include "main/dimmer.h"

#define MAX_CHILDS	8

/**
 * \brief Label widget. 
 *
 * Simply displays a piece of text.
 */
class Label : public VisibleObject {
private:
	char *text;

public:	
	bool Activate(void);
	void Display(void);
	void LoadProperties(uint8_t tag);
};


/**
 * \brief Icon widget. 
 *
 * Displays a icon located in flash memory.
 */
class Icon : public VisibleObject {
private:
	PGM_VOID_P image;

public:
	bool Activate(void);
	void Display(void);
	void LoadProperties(uint8_t tag);
};


static VisibleObject* root;
static VisibleObject* callbacks[6];

static VisibleObject* menu_factory(uint8_t id)
{
	switch (id) {
		case 0: return new Container;
		case 1: return new Label;
		case 2: return new Icon;
		case 3: return new Switch;
		case 4: return new Dimmer;
		default: return NULL;
	}
}

/*******************************************************************************
 * VisibleObject
 */

/**
 * \brief Object is activated, that is it gains the focus. 
 *
 * Derived objects will overwrite this function to install menu hooks and set
 * keypad leds.
 */
bool VisibleObject::Activate(void)
{
	active = 1;
	return true;
}

/**
 * \brief Object looses focus.
 */
void VisibleObject::Deactivate(void)
{
	active = 0;
}

/**
 * \brief Parse a tag-id. 
 *
 * This method is responsible for parsing tags coming from an application
 * image. Custom objects should overwrite this method to analyse their specific
 * tags. The menu loader will call this function for every tag. If a custom
 * object does not recognize a tag then it should be passed to it's parent
 * class.
 */
void VisibleObject::LoadProperties(uint8_t tag)
{
	switch (tag) {
		case P_TAG_X|P_TYPE_CHAR:
			x = prs_get_char();
			break;
		case P_TAG_Y|P_TYPE_CHAR:
			y = prs_get_char();
			break;
		default:
			prs_skip(tag);
			break;
	}
}

/**
 * Shift the focus up or down. 
 *
 * Only meaningful for objects containing other objects. If the focus could not
 * be shifted the method returns false, otherwise true.
 */
bool VisibleObject::Shift(uint8_t dir)
{
	return false;
}

/**
 * \brief Callback function for menu hooks. 
 *
 * If an object installed a menu hook then this method will be called if the
 * appropriate key was pressed.
 */
void VisibleObject::KeyCallback(uint8_t key)
{
}

/*******************************************************************************
 * Container
 */

/**
 * Allocates a fixed amount of child pointers (MAX_CHILDS) since realloc() is
 * not availible in avr-libc at the moment.
 */
Container::Container(void)
{
	childs = new (VisibleObject*)[MAX_CHILDS]; // malloc(MAX_CHILDS*2);
}

/**
 * \brief Activate the container. 
 * 
 * A container itself cannot be activated. Only if a child exists and it could
 * be activated this function will return true.
 */
bool Container::Activate(void)
{
	// only call if child exists
	if (count > 0) {
		if (childs[current]->Activate()) {
			return VisibleObject::Activate();
		} else {
			return false;
		}
	} else {
		return false;
	}
}

void Container::Deactivate(void)
{
	VisibleObject::Deactivate();

	// only call if child exists
	if (count > 0) childs[current]->Deactivate();
}

/**
 * \brief Simply displays all owned objects.
 */
void Container::Display(void)
{
	uint8_t n = count;
	VisibleObject **child = childs;

	while (n > 0) {
		(*child)->Display();
		child++;
		n--;
	}
}

void Container::LoadProperties(uint8_t tag)
{
	if ((tag&P_TYPE_MASK) == P_TYPE_COMPOUND_OPEN) {
		VisibleObject *newObj;

		// create new object
		newObj = menu_factory(tag>>3);
		AddChild(newObj);

		// feed new object with it's properties
		while (((tag = prs_get_tag()) & P_TYPE_MASK) != P_TYPE_COMPOUND_CLOSE)
			newObj->LoadProperties(tag);
	} else {
		// tag not handled here
		VisibleObject::LoadProperties(tag);
	}
}

/**
 * \brief Shift the focus to the next or previous owned object. 
 *
 * First it is tried if the current active child can shift the focus. If this
 * fails the focus is passed to another child. If no other child could be
 * activated the method returns false.
 */
bool Container::Shift(uint8_t dir)
{
	VisibleObject *child;
	uint8_t ind;

	// call child
	child = childs[current];
	if (child->Shift(dir)) return true;

	// change focus locally or revert to higher level
	ind = current;
	child->Deactivate();
	child->Display();
	do {
		if (dir) {
			if (ind >= count-1) {
				child = childs[current];
				child->Activate();
				child->Display();
				return false;
			} else {
				ind++;
			}
		} else {
			if (ind == 0) {
				child = childs[current];
				child->Activate();
				child->Display();
				return false;
			} else {
				ind--;
			}
		}
		child = childs[ind];
	} while (!child->Activate());

	child->Display();
	current = ind;
	return true;
}

void Container::AddChild(VisibleObject *child)
{
	childs[count++] = child;
}

/*******************************************************************************
 * Label
 */

/**
 * Always returns false since labels cannot be activated.
 */
bool Label::Activate(void)
{
	return false;
}

void Label::Display(void)
{
	if (text != NULL) lcd_print(x, y, 0, text);
}

void Label::LoadProperties(uint8_t tag)
{
	if (tag == (P_TAG_DEFAULT|P_TYPE_STRING)) {
		if (text != NULL) free(text);
		text = (char*)malloc(strlen(prs_get_str())+1);
		strcpy(text, prs_get_str());
	} else {
		VisibleObject::LoadProperties(tag);
	}
}

/*******************************************************************************
 * Icon
 */

/**
 * Always returns false since icons cannot be activated.
 */
bool Icon::Activate(void)
{
	return false;
}

void Icon::Display(void)
{
	if (image != NULL) lcd_put_image(x, y, (PGM_P)image);
}

void Icon::LoadProperties(uint8_t tag)
{
	if (tag == (P_TAG_IMAGE|P_TYPE_CHAR)) {
		switch (prs_get_char()) {
			case 0: image = &i_main_menu; break;
		}
	} else {
		VisibleObject::LoadProperties(tag);
	}
}

/*******************************************************************************
 * Global functions.
 */

/**
 * \brief Initialize menu. 
 *
 * This function loads the application image, creates the root object and feeds
 * it with it's properties.
 */
extern "C" void menu_init(void)
{
	uint8_t *buf;
	uint8_t tag;

	buf = (uint8_t*)malloc(255);
	memcpy_P(buf, &e_menu, 255);
	prs_init(buf, 255);

	// create new root object
	tag = prs_get_tag();
	root = menu_factory(tag>>3);
	while (((tag = prs_get_tag()) & P_TYPE_MASK) != P_TYPE_COMPOUND_CLOSE)
		root->LoadProperties(tag);

	free(buf);

	lcd_put_image(0, 0, i_main_menu);
	if (!root->Activate()) root->Shift(1);
	root->Display();
}

/**
 * \brief Process menu events. 
 *
 * Dispatches and processes keypad events.
 */
extern "C" void menu_process(void)
{
	if (keys_key_pressed()) {
		uint8_t key = keys_get_key();
		switch (key) {
			case KEY_FUNC_1:
				if (callbacks[0] != NULL)
					callbacks[0]->KeyCallback(0);
				break;
			case KEY_FUNC_2:
				if (callbacks[1] != NULL)
					callbacks[1]->KeyCallback(1);
				break;
			case KEY_FUNC_3:
				if (callbacks[2] != NULL)
					callbacks[2]->KeyCallback(2);
				break;
			case KEY_FUNC_4:
				if (callbacks[3] != NULL)
					callbacks[3]->KeyCallback(3);
				break;
			case KEY_FUNC_5:
				if (callbacks[4] != NULL)
					callbacks[4]->KeyCallback(4);
				break;
			case KEY_FUNC_6:
				if (callbacks[5] != NULL)
					callbacks[5]->KeyCallback(5);
				break;
			case KEY_MENU_UP:
				root->Shift(0);
				break;
			case KEY_MENU_DOWN:
				root->Shift(1);
				break;
		}
	}
}

/**
 * \brief Install a menu hook. 
 *
 * After invoking this function object "obj" will receive keypad events for
 * key "index".
 * 
 * \param index Key for which the hook should be installed. [0..5]
 * \param image Pointer to softkey-image.
 * \param obj Object which receives subsequent keypad events.
 */
void menu_set_hook(uint8_t index, PGM_VOID_P image, VisibleObject* obj)
{
	callbacks[index] = obj;
	lcd_put_image(8+index*20, 56, (PGM_P)image);
}

/**
 * \brief Remove a menu hook. 
 *
 * A object will receive no further key events for key "index". 
 */
void menu_remove_hook(uint8_t index)
{
	callbacks[index] = NULL;
	lcd_put_image(8+index*20, 56, i_tray_empty);
}
