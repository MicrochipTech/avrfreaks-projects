/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file main.c
 * \brief Main module.
 *
 * This file includes all relevant packages. It is responsible for initialization
 * and running the main loop.
 */

#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include "main/keys.h"
#include "main/lcd.h"
#include "main/rom.h"
#include "net/link.h"
#include "net/transport.h"
#include "net/application.h"
#include "net/presentation.h"
#include "delay.h"
#include "main/menu.h"
#include "main/dcf77.h"

static uint8_t timer_flag, timer;
static uint16_t backlight;

/**
 * \brief Timer ISR which is called every 1ms.
 *
 * Manages lcd backlight and sense keypad.
 */
INTERRUPT(SIG_OUTPUT_COMPARE2)
{	
	timer++;
	timer_flag++;
	keys_sense_keys();
	
	// manage backlight
	if (keys_key_pressed()) {
		backlight = 10000;
		lcd_enable_backlight();
	}
	if (backlight > 0) {
		backlight--;
		if (backlight == 0) lcd_disable_backlight();
	}
}

void print_hex(uint8_t value, uint8_t x, uint8_t y)
{
	uint8_t buf[3];
	uint8_t hex[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	
	buf[0] = hex[value >> 4];
	buf[1] = hex[value & 0x0f];
	buf[2] = 0x00;
	lcd_print(x, y, 0, buf);
}



void print_time(void)
{
	struct snt_time_stamp t;
	
	dcf_get_time(&t);
	print_hex(t.hour, 0, 0);
	print_hex(t.minute, 10, 0);
	print_hex(t.second, 20, 0);
}


/** 
 * \brief The good old main function.
 *
 * Initializes ports, all subsystems and runs the main loop.
 */
int main(void)
{
	// configure io-pins
	PORTE = 0x05;
	DDRD  = 0xff;
	DDRE  = 0x3e;
	
	// init subsystems
	sei();
	lcd_init();
	lnk_init();
	app_init();
	dcf_init();
	
	// configure timer 2 to 1ms
	// use compare match, prescaler to CLK/64
	OCR2 = 0x5d;
	TCCR2 = _BV(CTC2) | _BV(CS21) | _BV(CS20);
	sbi(TIMSK, OCIE2);

	keys_set_leds(0xff);

	lcd_activate();
	lcd_disable_backlight();
	
	menu_init();
	
	for (;;) {
		while (timer_flag) {
			timer_flag--;
			tsp_check_timeout();
		}
		lnk_process();
		tsp_process();
		app_process();
		menu_process();
		dcf_process();
		
		if (timer == 0) print_time();
	}
	return 0;
}
