/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file dcf77.c
 * \brief DCF77 decoder and network object.
 */

#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <inttypes.h>
#include "net/application.h"
#include "main/dcf77.h"
#include "utils.h"

/* Nonzero if YEAR is a leap year (every 4 years,
   except every 100th isn't, and every 400th is).  */
# define __isleap(year)	\
  ((year) % 4 == 0 && ((year) % 100 != 0 || (year) % 400 == 0))

/* days of each month (0-11).  */
static prog_uchar __dom[2][12] = {
	/* Normal years.  */
	{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
	/* Leap years.  */
	{31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
};

/******************
 * Network stuff
 */

// methods
#define TK_SET_TIME		0
#define TK_GET_TIME		1
#define TK_SET_UPDATE_INTERVAL	2
#define TK_GET_UPDATE_INTERVAL	3

// events
#define TK_ON_UPDATE		0

// parameter tables
static param_desc_t tk_methods[] = {
	{sizeof(struct snt_time_stamp),0},
	{0,sizeof(struct snt_time_stamp)},
	{2,0},
	{0,2}};
static param_desc_t tk_events[] = {{0,sizeof(struct snt_time_stamp)}};

// forward definition
static void TimeKeeper_Callback(struct AppObject *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);

// TimeKeeper Application Object
static struct AppObject timeKeeper = {
	tk_methods,
	tk_events,
	TimeKeeper_Callback
};
static uint8_t tk_id;

// update interval
static uint16_t ee_update_interval EEPROM;
static uint16_t update_interval;

/********************
 * TimeKeeper stuff
 */

// decoder variables
static uint8_t analyze, valid;
static uint8_t period;
static uint8_t sec;
static uint8_t buffer[8];

// get bit status
static uint8_t gb_act, gb_index, gb_parity;

// time management
static struct snt_time_stamp tel;				// last time telegram
static struct snt_time_stamp clock = {0, 0, 0, 1, 0, 1, 2000};	// software time
static uint8_t sec10;


// called exactly every 10ms
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
	uint8_t byte, bit;

	period++;
	if (period == 13) {
		// got new bit, buffer is overwritten
		valid = 0;
		sei();
		
		// we are 130ms after the start of a second
		// calculate bit position
		if (sec < 64) {
			bit = 1 << (sec & 0x07);
			byte = sec >> 3;
			sec++;
		
			// store bit in buffer
			if (bit_is_set(PINE, PE7)) {
				buffer[byte] |= bit;
			} else {
				buffer[byte] &= ~bit;
			}
		}
	} else if (period == 150) {
		// a new second was expected but did not start
		// -> gap detected -> just before a new minute
		
		// analyse time telegram
		if (sec == 59) analyze = 1;
		sec = 0;
	}
	sei();
	
	// advance software clock
	sec10+=1;
	if (sec10 >= 100) {
		sec10 = 0;
		clock.second++;
		
		// need to send update?
		if (update_interval > 0) {
			update_interval--;
			if (update_interval == 0) {
				app_trigger_event(tk_id, TK_ON_UPDATE);
				update_interval = eeprom_read_word(&ee_update_interval);
			}
		}
		
		if (clock.second >= 60) {
			clock.second = 0;
			clock.minute++;
			if (clock.minute >= 60) {
				clock.minute=0;
				clock.hour++;
				if (clock.hour >= 24) {
					clock.hour = 0;
					clock.day++;
					clock.dow = (clock.dow+1)%7;
					PGM_VOID_P dom = &__dom[__isleap(clock.year)?1:0][clock.month-1];
					if (clock.day > PRG_RDB(dom)) {
						clock.day = 1;
						clock.month++;
						if (clock.month > 12) {
							clock.month = 1;
							clock.year++;
						}
					}
				}
			}
		}
	}
}

// called on every raising edge of dcf77 input
// indicates start of a second
SIGNAL(SIG_INTERRUPT7)
{
	if (period > 150) {
		// new minute started
		period = 0;
		sei();
		
		// apply last telegram?
		if (!valid) return;
		
		// TODO: wait for three diff's
		clock = tel;
	} else {
		// just normal second
		period = 0;
	}
}

/** \internal
 * \brief Read one bit from the telegram buffer.
 *
 * \note The returned bit is added to the current parity counter. (gb_parity)
 */
static uint8_t get_bit(void)
{
	if ((gb_index & 0x07) == 0) {
		gb_act = buffer[gb_index >> 3];
	} else {
		gb_act >>= 1;
	}
	gb_index++;
	
	gb_parity ^= (gb_act & 0x01);
	return gb_act & 0x01;
}

/** \internal
 * \brief Read a BCD-coded value from the telegram buffer.
 *
 * This function reads "bits"-bit from the telegram buffer and interpretes
 * them as a little endian bcd coded number.
 *
 * \param bits Amount of bits to read.
 * \returns Read number in le binary coding.
 */
static uint8_t read_bcd(uint8_t bits)
{
	uint8_t value = 0;
	uint8_t i;
	
	for (i=1; (i<=8)&&(bits>0); i<<=1, bits--) if (get_bit()) value += i;
	for (i=10; (i<=80)&&(bits>0); i<<=1, bits--) if (get_bit()) value += i;
	return value;
}

/**
 * \brief Initialize dcf77 receiver harware and timer.
 *
 * Also registers TimeKeeper object.
 * After calling this function the clock starts running from
 * 01.01.2000 00:00:00. When a valid time telegrams is received
 * the clock is adjusted according to these telegram.
 */
void dcf_init(void)
{
	// init timer
	cli();
	OCR1A = 60000-1;		// set compare match to 10 ms
	sei();
	TCCR1A = 0x00;
	TCCR1B = _BV(CTC1) | _BV(CS10);	// Clear on compare match, PRESC=1
	TIMSK |= _BV(OCIE1A);		// Output compare math A enabled
	
	// init dcf77 input
	EICR |= _BV(ISC71) | _BV(ISC70);
	EIMSK |= _BV(INT7);
	
	// read update interval
	update_interval = eeprom_read_word(&ee_update_interval);
	
	// register object
	tk_id = app_register_obj(&timeKeeper, 1);
}

/**
 * \brief Process received time telegrams.
 *
 * Should be called periodically from the main loop but not from a timer ISR
 * since the implementation is not thread save.
 */
void dcf_process(void)
{
	uint8_t i;

	// new telegram to process?
	if (!analyze) return;
	analyze = 0;
	
	// parse time telegram
	gb_index = 0;
	valid = 0;
	
	if (get_bit()) return;		// bit 0 must be zero
	for (i=0; i<19; i++) get_bit();	// next 19 bits are not interesting
	if (!get_bit()) return;		// bit 20 must be high
	
	// minute block
	gb_parity = 0;
	tel.minute = read_bcd(7);
	if (tel.minute > 59) return;
	get_bit();
	if (gb_parity) return;
	
	// hour block
	gb_parity = 0;
	tel.hour = read_bcd(6);
	if (tel.hour > 23) return;
	get_bit();
	if (gb_parity) return;
	
	// date block
	gb_parity = 0;
	tel.day = read_bcd(6);
	if ((tel.day == 0) || (tel.day > 31)) return;
	tel.dow = read_bcd(3);
	if ((tel.dow == 0) || (tel.dow > 7)) return;
	tel.month = read_bcd(5);
	if ((tel.month == 0) || (tel.month > 12)) return;
	tel.year = read_bcd(8)+2000;
	get_bit();
	if (gb_parity) return;
	
	// got a valid telegram
	tel.dow--;
	valid = 1;
}

/**
 * \brief Get current time.
 *
 * \param time Structure receiving the current time and date.
 */
void dcf_get_time(struct snt_time_stamp *time)
{
	*time = clock;
}

static void TimeKeeper_Callback(struct AppObject *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case TK_SET_TIME:
			clock = *(struct snt_time_stamp*)buf;
			break;
		case TK_GET_TIME:
		case TK_ON_UPDATE|0x80:
			*(struct snt_time_stamp*)result = clock;
			break;
		case TK_SET_UPDATE_INTERVAL:
			update_interval = *(uint16_t*)buf;
			eeprom_write_word(&ee_update_interval, update_interval);
			break;
		case TK_GET_UPDATE_INTERVAL:
			*(uint16_t*)result = update_interval;
			break;
	}
}
