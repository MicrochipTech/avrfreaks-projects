/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include "net/application.h"
#include "net/snt.h"
#include "main/keys.h"
#include "main/lcd.h"
#include "main/rom.h"
#include "main/menu.h"
#include "main/switch.h"

// methods
#define SW_SWITCH_FB	0

// events
#define SW_ON_SWITCH	0

// parameter tables
static param_desc_t switch_prop[] = {{2,0}};
static param_desc_t switch_events[] = {{0,2}};

// forward definition
static void SwitchAppObj_Callback(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);

Switch::Switch(void)
{
	struct SwitchAppObj *app;

	app = new SwitchAppObj;
	app->property_sizes = switch_prop;
	app->event_sizes = switch_events;
	app->Callback = SwitchAppObj_Callback;
	app->state.value = 0xff;
	app->parent = this;
	app->id = app_register_obj((struct AppObject*)app, 1);  
	this->app = app;
}

bool Switch::Activate(void)
{
	menu_set_hook(4, i_tray_switch_off, this);
	menu_set_hook(5, i_tray_switch_on, this);
	keys_set_repeat_mask(0);
	keys_set_leds(LED_FUNC_5|LED_FUNC_6|LED_MENU_UP|LED_MENU_DOWN);
	return VisibleObject::Activate();
}

void Switch::Deactivate(void)
{
	VisibleObject::Deactivate();
	menu_remove_hook(4);
	menu_remove_hook(5);
}

void Switch::Display(void)
{
	if (active) {
		if (app->state.state) {
			lcd_put_image(x, y, i_switch_on);
		} else {
			lcd_put_image(x, y, i_switch_off);
		}
	} else {
		if (app->state.state) {
			lcd_put_image(x, y, i_switch_on_na);
		} else {
			lcd_put_image(x, y, i_switch_off_na);
		}
	}
}

void Switch::KeyCallback(uint8_t key)
{
	if (key == 4)
		app->state.state = 0;
	else
		app->state.state = 1;
	app_trigger_event(app->id, SW_ON_SWITCH);
	Display();
}

static void SwitchAppObj_Callback(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated)
{
	switch (method) {
		case SW_SWITCH_FB:
			((SwitchAppObj*)self)->state = *((snt_switch*)buf);
			// FIXME: must not display if parent is hidden
			((SwitchAppObj*)self)->parent->Display();
			break;
		case SW_ON_SWITCH|0x80:
			*((snt_switch*)result) = ((SwitchAppObj*)self)->state;
			break;
	}
}
