/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file lcd.c
 * \brief LCD routines.
 *
 * This file contains basic low level routines to drive a lcd using the ks0108b
 * segemtn driver.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include "main/lcd.h"
#include "main/rom.h"
#include "delay.h"
#include "utils.h"

#define WBF_MASTER	0x04	/* write to master                 */
#define WBF_SLAVE	0x02	/* write to slave                  */
#define WBF_MODE_DATA	0x01	/* normal data                     */
#define WBF_MODE_CMD	0x00	/* interpret value as command      */

#define CMD_DISPLAY_ON	0x3f	/* switch display on               */
#define CMD_DISPLAY_OFF	0x3e	/* switch display off              */
#define CMD_SET_START	0xC0	/* set display start line (0-31)   */
#define CMD_SET_PAGE	0xB8	/* set page address register (0-3) */
#define CMD_SET_COLUMN	0x40	/* set column address (0-79)       */

#define send_cmd(a, b)	write_byte(a, b | WBF_MODE_CMD)
#define send_all_cmd(a)	send_cmd(a, WBF_MASTER | WBF_SLAVE)

// define layout specific pins
#define RES_PORT	PORTC
#define RES_BIT		PC5
#define RS_PORT		PORTE
#define RS_BIT		PE3
#define RW_PORT		PORTE
#define RW_BIT		PE4
#define E_PORT		PORTE
#define E_BIT		PE5
#define CS1_PORT	PORTC
#define CS1_BIT		PC7
#define CS2_PORT	PORTC
#define CS2_BIT		PC6
#define LED_PORT	PORTD
#define LED_BIT		PD7

/** \internal
 * \brief Write data to display.
 *
 * \param value Byte to be written to the display.
 * \param flags Combination of WBF_* constants.
 */
static void write_byte(uint8_t value, uint8_t flags)
{
	DDRA  = 0xff;		// port a as output
	PORTA = value;
	if (flags & WBF_MODE_DATA) sbi(RS_PORT, RS_BIT); else cbi(RS_PORT, RS_BIT);
	cbi(RW_PORT, RW_BIT);
	nop();
	if (flags & WBF_MASTER) sbi(CS1_PORT, CS1_BIT);
	if (flags & WBF_SLAVE)  sbi(CS2_PORT, CS2_BIT);
	nop(); nop();
	sbi(E_PORT, E_BIT);
	nop(); nop(); nop();
	cbi(E_PORT, E_BIT);
	nop(); nop();
	cbi(CS1_PORT, CS1_BIT);
	cbi(CS2_PORT, CS2_BIT);
	PORTA = 0x00;
	DDRA  = 0x00;		// port a as input, no pullups
	delay(3);
}

/**
 * \brief Read data from display.
 *
 * WBF_MODE_DATA returns display ram content, while WBF_MODE_CMD reads the
 * status byte.
 *
 * \note When reading the display ram one dummy read is nescessary after
 *       setting the column address.
 */
static uint8_t read_byte(uint8_t flags)
{
	uint8_t result;
	
	// read byte from display
	if (flags & WBF_MODE_DATA) sbi(RS_PORT, RS_BIT); else cbi(RS_PORT, RS_BIT);
	sbi(RW_PORT, RW_BIT);
	if (flags & WBF_MASTER) {
		sbi(CS1_PORT, CS1_BIT);
	} else {
		if (flags & WBF_SLAVE) sbi(CS2_PORT, CS2_BIT);
	}	
	
	nop(); nop();
	sbi(E_PORT, E_BIT);
	nop(); nop(); nop();
	result = PINA;
	cbi(E_PORT, E_BIT);
	nop();
	cbi(CS1_PORT, CS1_BIT);
	cbi(CS2_PORT, CS2_BIT);
	delay(3);
	
	return result;
}

/**
 * \brief Calculate string width in pixels.
 */
uint8_t lcd_str_width(uint8_t *text)
{
	uint8_t chr, cnt;
	uint8_t result = 0;
	uint16_t charset;
	
	while ((chr = *text++) != 0x00) {
		charset = ((uint16_t)(&i_small_charset)) + ((uint16_t)chr * SMALL_CHAR_SIZE) + 2;
		for (cnt=0; cnt<8; cnt++) {
			chr = pgm_read_byte(charset);
			charset++;
			result++;
			if (chr == 0x00) break;
		}
	}
	return result;
}

/**
 * \brief Print string on display.
 *
 * \note The y coordinate is rounded to the next display page. ( y = {0,8,16,24,..} )
 */
void lcd_print(uint8_t x, uint8_t y, uint8_t inverted, char *text)
{
	uint8_t chip, chr, cnt;
	uint16_t charset;

	if (x > 127) return;
	
	// set page and column address
	send_all_cmd(CMD_SET_PAGE | (y >> 3));
	if (x < 64) {
		chip = WBF_MASTER;
		send_cmd(CMD_SET_COLUMN | x, WBF_MASTER);
		send_cmd(CMD_SET_COLUMN | 0, WBF_SLAVE);
	} else {
		chip = WBF_SLAVE;
		send_cmd(CMD_SET_COLUMN | (x-64), WBF_SLAVE);
	}
	
	while ((chr = *text++) != 0x00) {
		// calculate address of char
		charset = ((uint16_t)(&i_small_charset)) + ((uint16_t)chr * SMALL_CHAR_SIZE) + 2;
		
		// print char column by column
		for (cnt=0; cnt<8; cnt++) {
			// change to slave-chip?
			if (x == 64) chip = WBF_SLAVE;
			// print column
			chr = pgm_read_byte(charset);
			charset++;
			write_byte((inverted)?~chr:chr, chip | WBF_MODE_DATA);
			x++;
			// char finished?
			if (chr == 0x00) break;
		}
	}
}

/**
 * \brief Draw a vertical line.
 */
void lcd_v_line(uint8_t x, uint8_t y1, uint8_t y2)
{
	uint8_t chip, cnt, chr;
	uint8_t buffer[8];
	
	if (x > 63) {
		x-=64;
		chip = WBF_SLAVE;
	} else {
		chip = WBF_MASTER;
	}

	// TODO: render directly to vram
	
	// first render to memory buffer
	for (cnt=0; cnt<8; cnt++) buffer[cnt] = 0;
	for (cnt=y1; cnt<=y2; cnt++) buffer[cnt >> 3] |= 1 << (cnt & 0x07);
	
	// transfer buffer to display
	for (cnt=0; cnt<8; cnt++) {
		send_cmd(CMD_SET_PAGE | cnt, chip);
		send_cmd(CMD_SET_COLUMN | x, chip);
		read_byte(chip | WBF_MODE_DATA);	// dummy read, absolutely needed
		chr = read_byte(chip | WBF_MODE_DATA);
		send_cmd(CMD_SET_COLUMN | x, chip);
		write_byte(chr | buffer[cnt], chip | WBF_MODE_DATA);
	}
}

/**
 * \brief Draw a horizontal line.
 */
void lcd_h_line(uint8_t x1, uint8_t x2, uint8_t y)
{
	uint8_t chip, posi, mask, chr;
	
	mask = 1 << (y & 0x07);
	send_all_cmd(CMD_SET_PAGE | (y >> 3));
	if (x1 < 64) {
		chip = WBF_MASTER;
		posi = x1;
		send_cmd(CMD_SET_COLUMN | 0, WBF_SLAVE);
	} else {
		chip = WBF_SLAVE;
		posi = x1-64;
	}
	send_cmd(CMD_SET_COLUMN | posi, chip);
	
	while (x1 <= x2) {
		if (x1 == 64) {
			chip = WBF_SLAVE;
			posi = 0;
		}
		send_cmd(CMD_SET_COLUMN | x1, chip);
		read_byte(chip | WBF_MODE_DATA);	// dummy read
		chr = read_byte(chip | WBF_MODE_DATA);
		send_cmd(CMD_SET_COLUMN | x1, chip);
		write_byte(chr | mask, chip | WBF_MODE_DATA);
		posi++;
		x1++;
	}
}

/**
 * \brief Put an image on the display.
 *
 * \note The y coordinate of the image must be a multiple of eight.
 */
void lcd_put_image(uint8_t x, uint8_t y, PGM_P image)
{
	uint8_t chip, cnt, posi, w;
	uint8_t width, height;
	
	y = y >> 3;
	width = PRG_RDB(image++);
	height = PRG_RDB(image++);
	
	for (cnt=0; cnt<height; cnt++) {
		posi = x;
		
		if (posi < 64) {
			chip = WBF_MASTER;
			send_cmd(CMD_SET_COLUMN | posi, WBF_MASTER);
			send_cmd(CMD_SET_COLUMN | 0, WBF_SLAVE);
		} else {
			chip = WBF_SLAVE;
			send_cmd(CMD_SET_COLUMN | (posi-64), WBF_SLAVE);
		}
		send_all_cmd(CMD_SET_PAGE | (y+cnt));
	
		w = width;	
		while (w--) {
			if (posi == 64) chip = WBF_SLAVE;
			write_byte(pgm_read_byte(image++), chip | WBF_MODE_DATA);
			posi++;
		}
	}
}

/**
 * Clear a part of a page.
 */
void lcd_clear_line(uint8_t x1, uint8_t x2, uint8_t y)
{
	uint8_t chip;
	
	send_all_cmd(CMD_SET_PAGE | (y >> 3));
	if (x1 < 64) {
		chip = WBF_MASTER;
		send_cmd(CMD_SET_COLUMN | x1, WBF_MASTER);
		send_cmd(CMD_SET_COLUMN | 0, WBF_SLAVE);
	} else {
		chip = WBF_SLAVE;
		send_cmd(CMD_SET_COLUMN | (x1-64), WBF_SLAVE);
	}
	
	while (x1 <= x2) {
		if (x1 == 64) chip = WBF_SLAVE;
		x1++;
		write_byte(0, chip | WBF_MODE_DATA);
	}
}

/**
 * Clear diplay.
 */
void lcd_clear(void)
{
	uint8_t page_cnt, col_cnt;
	
	for (page_cnt = 0; page_cnt < 8; page_cnt++) {
		send_all_cmd(CMD_SET_PAGE | page_cnt);
		send_all_cmd(CMD_SET_COLUMN | 0);
		for (col_cnt = 0; col_cnt < 64; col_cnt++)
			write_byte(0x00, WBF_MASTER | WBF_SLAVE | WBF_MODE_DATA);
	}
}

/**
 * Initialize lcd-display.
 */
void lcd_init(void)
{
	// hw-reset
	sbi(RES_PORT, RES_BIT);
	delay(1000);
	cbi(RES_PORT, RES_BIT);
	delay(1000);
	sbi(RES_PORT, RES_BIT);
	delay(1000);
	
	lcd_clear();
}

/**
 * Activate display.
 */
void lcd_activate(void)
{
	sbi(LED_PORT, LED_BIT);		// backlight on
	send_all_cmd(CMD_DISPLAY_ON);	// show all pixels
}

/**
 * Enter power save mode.
 */
void lcd_deactivate(void)
{
	cbi(LED_PORT, LED_BIT);		// backlight off
	send_all_cmd(CMD_DISPLAY_OFF);	// enter power save mode
}

/**
 * Switch backlight on.
 */
void lcd_enable_backlight(void)
{
	sbi(LED_PORT, LED_BIT);
}

/**
 * Switch backlight off.
 */
void lcd_disable_backlight(void)
{
	cbi(LED_PORT, LED_BIT);
}
