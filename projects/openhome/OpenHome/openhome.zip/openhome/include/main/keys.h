/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __KEYS_H
#define __KEYS_H

#include <inttypes.h>

#define KEY_NONE	0
#define KEY_FUNC_1	1
#define KEY_FUNC_2	2
#define KEY_FUNC_3	8
#define KEY_FUNC_4	7
#define KEY_FUNC_5	6
#define KEY_FUNC_6	5
#define KEY_MENU_UP	4
#define KEY_MENU_DOWN	3

#define LED_FUNC_1	0x08
#define LED_FUNC_2	0x04
#define LED_FUNC_3	0x10
#define LED_FUNC_4	0x20
#define LED_FUNC_5	0x40
#define LED_FUNC_6	0x80
#define LED_MENU_UP	0x01
#define LED_MENU_DOWN	0x02
#define LED_ALL_ON	0xff
#define LED_ALL_OFF	0x00

#define REP_FUNC_1	0x01
#define REP_FUNC_2	0x02
#define REP_FUNC_3	0x80
#define REP_FUNC_4	0x40
#define REP_FUNC_5	0x20
#define REP_FUNC_6	0x10
#define REP_MENU_UP	0x08
#define REP_MENU_DOWN	0x04

#ifdef __cplusplus
extern "C" {
#endif

void keys_sense_keys(void);
uint8_t keys_key_pressed(void);
uint8_t keys_get_key(void);

void keys_set_leds(uint8_t mask);
void keys_set_repeat_mask(uint8_t mask);

#ifdef __cplusplus
}
#endif

#endif
