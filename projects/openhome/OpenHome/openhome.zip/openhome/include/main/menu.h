/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file menu.h */

#ifndef __MENU_H
#define __MENU_H

#include <avr/pgmspace.h>
#include <inttypes.h>

#ifdef __cplusplus

class VisibleObject;
class Container;

/**
 * \brief Abstract root of all visible objects.
 */
class VisibleObject {
protected:
	uint8_t x, y;
	uint8_t active;
public:
	virtual void KeyCallback(uint8_t key);
	virtual bool Activate(void);
	virtual void Deactivate(void);
	virtual void Display(void) = NULL;
	virtual void LoadProperties(uint8_t tag);
	virtual bool Shift(uint8_t dir);
};

/**
 * \brief Basic visible object which can contain other objects.
 */
class Container : public VisibleObject {
private:
	uint8_t current;
	uint8_t count;
	VisibleObject **childs;

protected:
	void AddChild(VisibleObject *child);

public:
	Container();
	virtual bool Activate(void);
	virtual void Deactivate(void);
	virtual void Display(void);
	virtual void LoadProperties(uint8_t tag);
	virtual bool Shift(uint8_t dir);	
};

void menu_set_hook(uint8_t index, PGM_VOID_P image, VisibleObject* obj);
void menu_remove_hook(uint8_t index);

#endif /* __cplusplus */

/***
 * Global methods;
 */

#ifdef __cplusplus
extern "C" {
#endif

void menu_init(void);
void menu_process(void);

#ifdef __cplusplus
}
#endif

#endif
