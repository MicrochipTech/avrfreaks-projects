/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#ifndef __LCD_H
#define __LCD_H

#include <avr/pgmspace.h>
#include <inttypes.h>

#define SMALL_CHAR_SIZE	8

#ifdef __cplusplus
extern "C" {
#endif

void lcd_print(uint8_t x, uint8_t y, uint8_t inverted, char *text);
uint8_t lcd_str_width(uint8_t *text);

void lcd_v_line(uint8_t x, uint8_t y1, uint8_t y2);
void lcd_h_line(uint8_t x1, uint8_t x2, uint8_t y);

void lcd_put_image(uint8_t x, uint8_t y, PGM_P image);
void lcd_clear_line(uint8_t x1, uint8_t x2, uint8_t y);
void lcd_clear(void);

void lcd_init(void);
void lcd_activate(void);
void lcd_deactivate(void);
void lcd_enable_backlight(void);
void lcd_disable_backlight(void);

#ifdef __cplusplus
}
#endif

#endif
