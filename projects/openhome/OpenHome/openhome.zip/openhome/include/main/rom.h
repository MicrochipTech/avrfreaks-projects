#ifndef __ROM_H
#define __ROM_H

#include <avr/pgmspace.h>

extern prog_char i_small_charset[];
extern prog_char i_main_menu[];
extern prog_char i_switch_on[];
extern prog_char i_switch_on_na[];
extern prog_char i_switch_off[];
extern prog_char i_switch_off_na[];
extern prog_char i_tray_switch_on[];
extern prog_char i_tray_switch_off[];
extern prog_char i_tray_empty[];
extern prog_char i_dim_on[];
extern prog_char i_dim_on_na[];
extern prog_char i_dim_off[];
extern prog_char i_dim_off_na[];
extern prog_char i_tray_dim_up[];
extern prog_char i_tray_dim_down[];
extern prog_char waswasi[];
extern prog_char e_menu[];

#endif
