/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __DELAY_H
#define __DELAY_H

#include <inttypes.h>

/* constants/macros */
#define F_CPU        6000000               		/* 6MHz processor */
#define CYCLES_PER_US ((F_CPU+500000)/1000000) 	/* cpu cycles per microsecond */

/* prototypes */

#ifdef __cplusplus
extern "C" {
#endif

// uS delay
void delay(uint16_t us);

// mS delay
void delayms(uint16_t ms);

#ifdef __cplusplus
}
#endif


#endif
