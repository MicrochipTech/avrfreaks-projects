/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


/** \file network.h
 * \brief Network layer include file.
 *
 * Constants and definitions of the network layer.
 */

#ifndef __NET_NET_H
#define __NET_NET_H

#include <inttypes.h>
#include "net/buffers.h"

// network address families
#define NAF_LOGIC	0x00	///< Logic address.
#define NAF_GROUP	0x01	///< Group address.
#define NAF_PHYSIC	0x02	///< Physical address.
#define NAF_BROADCAST	0x03	///< Broadcast.

// address types
#define AT_LOGIC	0x00	///< Node's logical address.
#define AT_PHYSIC	0x01	///< Node's physical address.
#define AT_GROUP0	0x02
#define AT_GROUP1	0x03
#define AT_GROUP2	0x04
#define AT_GROUP3	0x05
#define AT_GROUP4	0x06
#define AT_GROUP5	0x07
#define AT_GROUP6	0x08
#define AT_GROUP7	0x09

// network layer pdu types
#define NPDU_SINGLE		0x00	///< Single message.
#define NPDU_TRANSACTION	0x01	///< Transaction.
#define NPDU_SESSION		0x02	///< Session.


/**
 * \brief Network address structure.
 *
 * Generic struct which can contain any network address.
 */
typedef struct {
		uint8_t format;		///< Network address family. (NAF_*)
		uint8_t addr[4];	///< Actual address.
	} net_addr_t;

/**
 * \brief Network layer indication information.
 *
 * Contains network layer information of a received packet.
 */
typedef struct {
		uint8_t pdu;		///< Network protocol data unit. (NPDU_*)
		uint8_t rat;		///< Reply address type. Use this value for net_requ_t::src if you send a reply. (AT_*)
		net_addr_t src;		///< Source address.
	} net_ind_t;

/**
 * \brief Network layer request block.
 *
 * Specifies network layer parameters for net_requ().
 */
typedef struct {
		net_addr_t dest;	///< Destination address.
		uint8_t src;		///< Source address type. (AT_*)
		uint8_t pdu;		///< Network protocol data unit (NPDU_*)
		uint8_t backlog;	///< Backlog passed to link layer.
	} net_requ_t;

#ifdef __cplusplus
extern "C" {
#endif

/***
 * global functions
 */
uint8_t net_requ(net_buf_t *buf, const net_requ_t *requ);
uint8_t net_compare_src_addr(const net_addr_t *addr1, const net_addr_t *addr2);
uint8_t net_get_local_member_id(uint8_t group);
uint8_t net_clear_to_send(void);
void net_set_logic_addr(uint16_t addr);
uint16_t net_get_logic_addr(void);
void net_set_group_addr(uint8_t group, uint16_t addr);
uint16_t net_get_group_addr(uint8_t group);

#ifdef __cplusplus
}
#endif

#endif
