/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


/** \file transport.h
 * \brief Transport layer include file.
 *
 * Constants and definitions of the transport layer.
 */

#ifndef __TRANSPORT_H
#define __TRANSPORT_H

#include <inttypes.h>
#include "net/network.h"

/**
 * \brief Transport layer service types.
 */
enum tsp_service_e {
	S_DGRAM=0,	///< Unacknowledged (not repeated) service.
	S_REPEATED,	///< Unacknowledged repeated service.
	S_ACKED,	///< Acknowledged service.
	S_REQUEST,	///< Session service.
	S_INVALID=0xff	///< No service. tsp_requ() will fail.
};

#ifdef __cplusplus
extern "C" {
#endif

// global functions
void tsp_check_timeout(void);
void tsp_process(void);
int8_t tsp_requ(net_buf_t *buf, net_addr_t *dest, enum tsp_service_e service);
uint8_t tsp_clear_to_send(void);
void tsp_set_segment_size(uint8_t size);
uint8_t tsp_get_segment_size(void);
void tsp_set_group_size(uint8_t group, uint8_t size);
uint8_t tsp_get_group_size(uint8_t group);

#ifdef __cplusplus
}
#endif

#endif
