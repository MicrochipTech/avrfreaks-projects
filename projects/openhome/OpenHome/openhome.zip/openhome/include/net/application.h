/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/** \file application.h
 * \brief Application layer include file.
 *
 * Constants and definitions of the application layer.
 */

#ifndef __APPLICATION_H
#define __APPLICATION_H

#include <avr/pgmspace.h>
#include <inttypes.h>
#include "net/buffers.h"
#include "net/network.h"
#include "net/transport.h"
#include "net.h"

/**
 * \brief Structure describing a method parameter or an event.
 */
typedef struct {
		uint8_t in;	///< Size of parameters.
		uint8_t out;	///< Size of returned values.
	} param_desc_t PROGMEM;

typedef void appObjCallback_t(void *self, uint8_t method, uint8_t *buf, uint8_t *result, uint8_t repeated);

/**
 * \brief An application object.
 *
 * Create an instance of this structure to define a application object. Must
 * be registered through app_register_obj() or in your net.h, depending on
 * which version you compiled.
 */
struct AppObject {
	const param_desc_t *method_sizes;	///< Pointer to an array of param_desc_t's.
	const param_desc_t *event_sizes;	///< Same as method_sizes.
	appObjCallback_t *Callback;		///< Pointer to object callback function.
};

#ifdef __cplusplus
extern "C" {
#endif

void app_init(void);
void app_process(void);
void app_trigger_event(uint8_t obj, uint8_t event);
#ifndef APP_STATIC
uint8_t app_register_obj(struct AppObject *obj, uint8_t events);
#endif

#ifdef __cplusplus
}
#endif

#endif
