/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


/** \file link.h
 * \brief Link layer include file.
 *
 * This module implements the link layer of the OpenHome protocol stack.
 * Include it in your main module and call lnk_init() for initialization. Also
 * call lnk_process() directly from your main loop. Check net.h for static
 * configuration parameters.
 *
 * \note You may have a look at link.c for a description of implementation
 * specific details especially about harware usage!
 */

#ifndef __LINK_H
#define __LINK_H

#include <inttypes.h>
#include "net/buffers.h"

/**
 * \brief Link layer error statistics.
 *
 * Structure containing link layer error statistics. Call lnk_get_error_stats()
 * to get actual values.
 */
struct lnk_err_t {
		uint16_t rx_len;	///< Number of length mismath errors.
		uint16_t rx_crc;	///< Total CRC-errors detected.
		uint16_t rx_ovr;	///< Overrun errors reported by hardware.
		uint16_t rx_fe;		///< Number of framing errors.
	};

#ifdef __cplusplus
extern "C" {
#endif

void lnk_init(void);
void lnk_process(void);
int8_t lnk_requ(net_buf_t *buf, uint8_t backlog);
uint8_t lnk_clear_to_send(void);
void lnk_get_error_stats(struct lnk_err_t *buf);

#ifdef __cplusplus
}
#endif

#endif
