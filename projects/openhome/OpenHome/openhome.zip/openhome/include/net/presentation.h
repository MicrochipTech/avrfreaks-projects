/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __PARSER_H
#define __PARSER_H

#include <inttypes.h>

#define P_TYPE_MASK		0x07
#define P_TYPE_COMPOUND_OPEN	0x00
#define P_TYPE_COMPOUND_CLOSE	0x01
#define P_TYPE_CHAR		0x02
#define P_TYPE_INT		0x03
#define P_TYPE_LONG		0x04
#define P_TYPE_LONGLONG		0x05
#define P_TYPE_FLOAT		0x06
#define P_TYPE_STRING		0x07

#define P_TAG_MASK	0xf8
#define P_TAG_APP_IMAGE	0x00
#define P_TAG_LABEL	0x08
#define P_TAG_ICON	0x10
#define P_TAG_SWITCH	0x18
#define P_TAG_DIMMER	0x20

#define P_TAG_X		0xf8
#define P_TAG_Y		0xf0
#define P_TAG_DEFAULT	0xe8
#define P_TAG_IMAGE	0xe0
#define P_TAG_BEHAV	0xd8

#define P_SERVICE_DISCOVERY		0
#define P_SERVICE_DISCOVERY_REPLY	1
#define P_GET_PROPERTIES		2
#define P_SET_PROPERTIES		3
#define P_UPDATE			4

#define PT_SWITCH			0
#define PT_PERCENT			1

#define IT_PLUG				0
#define IT_LAMP				1

#ifdef __cplusplus
extern "C" {
#endif

void prs_init(uint8_t* buf, uint8_t len);
uint8_t prs_get_tag(void);
void prs_skip(uint8_t tag);
uint8_t prs_get_char(void);
uint16_t prs_get_int(void);
char* prs_get_str(void);

#ifdef __cplusplus
}
#endif

#endif
