/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __SNT_H
#define __SNT_H

#include <inttypes.h>

typedef struct {
		uint8_t state;
		uint8_t value;
	} snt_switch;

typedef enum {
		SB_SWITCH,
		SB_DIMMER
	} sw_behav_e;

struct snt_time_stamp {
	uint8_t second, minute, hour, day, dow, month;
	uint16_t year;
};

#endif
