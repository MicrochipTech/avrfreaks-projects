/***
 * This file is part of OpenHome, an open source home automation system.
 * Copyright (C) 2003 Jan Kl�tzke
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __BUFFERS_H
#define __BUFFERS_H

#include <inttypes.h>

typedef struct {
		uint8_t len;
		uint8_t *data;
	} net_buf_t;

#define buf_init(a, b, c)		\
	{				\
		a.len = c;		\
		a.data = (uint8_t*)b;	\
	}

#ifdef __cplusplus
extern "C" {
#endif

// prepend data
void buf_prep_char(net_buf_t *obj, uint8_t value);
void buf_prep_int(net_buf_t *obj, uint16_t value);
void buf_prep_long(net_buf_t *obj, uint32_t value);

// append data
void buf_app_int(net_buf_t *obj, uint16_t value);

#ifdef __cplusplus
}
#endif

#define buf_len(a) a->len

#endif
