#ifndef __ROM_H
#define __ROM_H

#include <avr/pgmspace.h>

extern prog_char e_services[];

#endif
