#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <math.h>

#include <delay.h>
#include <ls7266.h>
#include <s1d13700.h>

#define FOSC 14745600L // Crystal frequency in Hz.

/* This will soon be moved to its own file that will allow it to work on any AVR's with
 * an expansion bus.
 */
void
SetupXMEM(int8_t wait1, int8_t wait2)
{
	//EMCUCR &= 0x3F;
	//EMCUCR |= _BV (SRL2) | (wait1 & 0x03) << 2 | (wait2 & 0x02);
	XMCRA = 0x00;
	XMCRA |= _BV(SRL2) | (wait1 & 0x03) << 2 | (wait2 & 0x02);
	MCUCR  &= 0x3F;
	MCUCR  |= _BV (SRE) | (wait2 & 0x01) << 6;
}

#define X_CENTER H_PIXELS/2
#define Y_CENTER V_PIXELS/2
#define RADIUS (V_PIXELS/4 - 1)

#define FULLCIRCLE 360L

int
main (void)
{

	uint32_t cntr;
	int16_t foo = 0;
	int16_t bar = 0;

	double angle1, angle2, xa, ya, xb, yb;
	int16_t x1, y1, x2, y2, x3, y3;

	SetupXMEM(3,0);  // Initialize external memory interface.
	S1D13700Init();  // Initialize the s1d13700 

	S1D13700ConnectIO(); // Connect the S1d13700 to the stdio system

	S1D13700_printf(0,0, "System Initialized");
	S1D13700GClrScr();
	S1D13700PlotCircle(X_CENTER, Y_CENTER, RADIUS, G_OR);
	
	for (;;)
	{
		S1D13700_printf(H_CHARS/2-2,(Y_CENTER+RADIUS)/8+2,"%-5.5d", foo);
		S1D13700_printf(H_CHARS/2-2,(Y_CENTER+RADIUS)/8+3,"%-5.5d", bar);
		angle1 = M_PI/(FULLCIRCLE/2) * foo;
		angle2 = M_PI/(FULLCIRCLE/2) * bar;
		xa = cos(angle1);
		ya = sin(angle1);
		xb = cos(angle2);
		yb = sin(angle2);
		x1 = X_CENTER;
		y1 = Y_CENTER;
		x2 = (xa * (RADIUS)) + X_CENTER + .5;
		y2 = (ya * (RADIUS)) + Y_CENTER + .5;
		x3 = (xb * (RADIUS/2)) + X_CENTER + .5;
		y3 = (yb * (RADIUS/2)) + Y_CENTER + .5;
		S1D13700PlotLine(x1, y1, x2, y2, G_XOR);
		S1D13700PlotLine(x1, y1, x3, y3, G_XOR);
		cntr = 100000;
		while (cntr--);
		S1D13700PlotLine(x1, y1, x2, y2, G_XOR);
		S1D13700PlotLine(x1, y1, x3, y3, G_XOR);

		foo++;
		bar--;
		foo %= FULLCIRCLE;
		bar %= FULLCIRCLE;
	}
    return (0);  // We never get here... 
}

// vim: ts=4
// vim: sw=4
