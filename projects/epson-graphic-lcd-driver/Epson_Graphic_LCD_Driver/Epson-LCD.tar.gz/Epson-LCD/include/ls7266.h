/* Copyright (c) 2004, Mike Panetta (ahuitzot@mindspring.com)
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * Code to interface to an LS7266 Incremental Encoder interface via the
 * AVR expansion bus.
 *
 * All the below code is written and (c) Mike Panetta.  This code is free 
 * to use for any purpose you deem fit, and carries no warranty what so 
 * ever.  If you do decide to use this code, I ask that you keep the 
 * above notice intact.
 *
 */

#ifndef __LS7266_H__
#define __LS7266_H__

// Pointers to access the LS7266 
#define BADDR (volatile uint8_t *)0x4000
#define XDATA	*(BADDR + 0)
#define XCMD    *(BADDR + 1)
#define YDATA   *(BADDR + 2)
#define YCMD    *(BADDR + 3)

#define RLD   0x00 // RLD reg is 00
#define CMR   0x20 // CMR reg is 01
#define IOR   0x40 // IOR reg is 10
#define IDR   0x60 // IDR reg is 11
#define XY    0x80 // Select both X and Y by making D7 1

typedef enum
{
	SELX = 0,
	SELY = 1,
	SELBOTH = 2,
} Chan;

// Flag bits
typedef enum
{
	BT  = 1 << 0, // Borrow toggle FlipFlop
	CT  = 1 << 1, // Carry toggle FlipFlop
	CPT = 1 << 2, // Compare toggle FF
	SF  = 1 << 3, // Sign flag
	EF  = 1 << 4, // Error flag
	UD  = 1 << 5, // Up/Dn flag (1 up, 0 dn)
	IDX = 1 << 6, // Index flag
	NF7 = 1 << 7, // Not used, always 0
} Flags;

// RLD
typedef enum
{
	RSTNOP   = 0,      // Reset nothing
	RSTBP    = 1 << 0, // Reset BP
	RSTCNTR  = 1 << 1, // Reset counter
	RSTFLGS  = 2 << 1, // Reset flags (not the E flag though)
	RSTE     = 3 << 1, // Reset E flag
	TXNOP    = 0 << 3, // Transfer nothing
	TXPRCNTR = 1 << 3, // Transfer preset reg to counter
	TXCNTROL = 2 << 3, // Transfer counter to output latch
	TXPR0PSC = 3 << 3, // Transfer PR0 to PSC
} RLDCmd;

// CMR
// CMR counter mode
typedef enum
{
	NC  = 0, // Normal count mode
	RL  = 1, // Range limit mode
	NRC = 2, // Non-recycle count mode
	MN  = 3, // Modulo-N mode
} CntrMode;

// CMR Quad mode
typedef enum
{
	X0 = 0, // Non-quadrature mode
	X1 = 1, // Quadrature X1 mode
	X2 = 2, // Quadrature X2 mode
	X4 = 3, // Quadrature X4 mode
} QuadMode;

// IOR
typedef enum
{
	ENAB   = 1 << 0, // Enable the A and B inputs
	LOL    = 1 << 1, // LCNTR/LOL pin is Load OL input
	ABG    = 1 << 2, // RCNTR/ABG pin is A and B enable gate
	CARBOR = 0 << 3, // FLG1 is carry, FLG2 is borrow
	COMBOR = 1 << 3, // FLG1 is compare, FLG2 is borrow
	CBUD   = 2 << 3, // FLG1 is carry/borrow FLG2 is up/dn
	IDXE   = 3 << 3, // FLG1 is IDX, FLG2 is E
} IORCmd;

// Function defs go here
void LS7266Init(void);
void LS7266SetPrescale(Chan channel, int8_t value);
void LS7266InitCntr(Chan channel, CntrMode cntrMode, QuadMode quadMode);
void LS7266ResetCntr(Chan channel);
void LS7266LoadCntr(Chan channel, int32_t value);
void LS7266ReadCntr(Chan channel, int32_t * value);


#endif //__LS7266_H__

// vim: ts=4
// vim: sw=4
