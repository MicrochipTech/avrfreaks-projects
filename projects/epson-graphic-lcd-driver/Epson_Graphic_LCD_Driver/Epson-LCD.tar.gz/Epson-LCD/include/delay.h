#ifndef __DELAY_H__
#define __DELAY_H__

void delay_ms(unsigned int delay);
void delay(uint32_t delay);

#endif // __DELAY_H__
