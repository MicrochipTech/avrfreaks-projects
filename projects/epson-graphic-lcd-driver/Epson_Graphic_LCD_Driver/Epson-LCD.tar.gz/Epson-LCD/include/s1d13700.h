/* Copyright (c) 2004, Mike Panetta (ahuitzot@mindspring.com)
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * Code to interface to an S1D13700 LCD Graphic display controller via the
 * AVR expansion bus.
 *
 * All the below code is written and (c) Mike Panetta.  The Line and Circle
 * routines are based on the Bresenham's Line and Circle algorithms, and
 * pascal code found at GameDev.net.  This code is free to use for any purpose
 * you deem fit, and carries no warranty what so ever.  If you do decide to use
 * this code, I ask that you keep the above notice intact.
 *
 */

#ifndef __S1D13700_H__
#define __S1D13700_H__

// Display properties

#if defined (GEN_640x200)        // Generic 640x200 display, without controller
#	define H_PIXELS    640UL     // Display width in pixels
#	define V_PIXELS    200UL     // Display height in pixels
#	define H_CHARS     80UL      // Number of chars per line
#	define V_CHARS     25UL      // Number of chars per column
#	define F_RATE	   62UL      // Frame rate in Hz
#elif defined (GEN_320x256) 	 // Generic 320x256 display, without controller
#	define H_PIXELS    320UL     // Display width in pixels
#	define V_PIXELS    256UL     // Display height in pixels
#	define H_CHARS     40UL      // Number of chars per line
#	define V_CHARS     32UL      // Number of chars per column
#	define F_RATE	   64UL      // Frame rate in Hz
#elif defined (GEN_160x160) 	 // Generic 160x160 display, without controller
#	define H_PIXELS    160UL     // Display width in pixels
#	define V_PIXELS    160UL     // Display height in pixels
#	define H_CHARS     20UL      // Number of chars per line
#	define V_CHARS     20UL      // Number of chars per column
#	define F_RATE	   64UL      // Frame rate in Hz
#elif defined (GEN_256x128)      // Generic 256x128 display, without controller
#	define H_PIXELS    256UL     // Display width in pixels
#	define V_PIXELS    128UL     // Display height in pixels
#	define H_CHARS     32UL      // Number of chars per line
#	define V_CHARS     16UL      // Number of chars per column
#	define F_RATE	   64UL      // Frame rate in Hz
#else
#	error "No LCD defined, or unknown type given."
#endif

#ifndef S1D13700_CLK // If the clock was not defined above, use this default
#	define S1D13700_CLK 40000000UL // S1D13700 clk frequency in Hz
#endif

//These should not need to be changed
#define CHAR_WIDTH  (H_PIXELS/H_CHARS)
#define CHAR_HEIGHT (V_PIXELS/V_CHARS)

#define CLKDIV	4UL
#define BPP	1UL

#define S1D13700_CR     ((CHAR_WIDTH/8) * H_CHARS) - 1
//#define S1D13700_TCR    ((S1D13700_CLK/(9UL*F_RATE*V_PIXELS))) - 1
#define S1D13700_TCR    (((S1D13700_CLK)/(CLKDIV*BPP*CHAR_WIDTH*V_PIXELS*F_RATE))*2) - 1
#define S1D13700_LF     (V_PIXELS - 1)
#define S1D13700_AP     (uint16_t)(S1D13700_CR + 1)

// These set up the display for 2 layers, first layer txt, second gfx.
#define T_MEMSIZ       (uint16_t)(H_CHARS*V_CHARS)
#define G_MEMSIZ       (uint16_t)(H_PIXELS/8 * V_PIXELS)
#define CG_MEMSIZ	   (uint16_t)0x1000
#define T_BASE         (uint16_t)0x0000
#define G_BASE         (uint16_t)(T_BASE+T_MEMSIZ)
//#define CG_BASE        (uint16_t)(0x5000)
#define CG_BASE        (uint16_t)(G_BASE+G_MEMSIZ)


// Pointers to access the S1D13700
#define SEDBASE (volatile int8_t *)0x3000
#define SEDDAT  *(SEDBASE + 0)
#define SEDCMD  *(SEDBASE + 1)

// Command definitions
#define SYSTEM_SET  0x40
#define SLEEP_IN    0x53
#define DISPLAY_OFF 0x58
#define DISPLAY_ON  0x59
#define SCROLL      0x44
#define CSR_FORM    0x5D
#define CGRAM_ADR   0x5C
#define HDOT_SCR    0x5A
#define OVLAY       0x5B
#define GRAYSCALE   0x60

#define CSRDIR_R    0x4C
#define CSRDIR_L    0x4D
#define CSRDIR_U    0x4E
#define CSRDIR_D    0x4F

#define CSR_W	    0x46
#define CSR_R	    0x47
#define MEM_W	    0x42
#define MEM_R	    0x43

typedef enum
{
	G_AND = 0,
	G_OR  = 1,
	G_XOR = 2,
} GMode;

// Functions go here

void S1D13700Init(void);   // Init the display based on info given at the top of this file
void S1D13700ConnectIO(void); // Connect the display to a stream using fdevopen so that the print functions work
void S1D13700WMem(uint16_t caddr, uint8_t data); // Write a char to address caddr
void S1D13700RMem(uint16_t caddr, uint8_t * data); // Read a char from address caddr
void S1D13700SWMem(uint16_t caddr, size_t size, uint8_t * data); //  Write a string to address caddr
void S1D13700WCGRam(uint16_t charLoc, uint8_t * charData, size_t dataLen); // Write a character bitmap to cgram for char charLoc
void S1D13700WCGRam_P(uint16_t charLoc, PGM_P charData, size_t dataLen); // Same as above but use a program memory copy
void S1D13700TGotoXY(int8_t x, int8_t y); //  Put the cursor at an (X, Y) location on the text layer.
void S1D13700TClrScr(void); //  Clear the text layer
void S1D13700GClrScr(void); //  Clear the graphics layer
int  S1D13700_putc(char data); //  Internal function used for fdevopen to do char i/o
void S1D13700_printf(int8_t x, int8_t y, char * fmt, ...); // Print a string at location (X, Y)
void S1D13700_printf_P(int8_t x, int8_t y, PGM_P fmt, ...); //  Same as above but using a fmt string in progmem.

void S1D13700PlotDot(uint16_t x, uint8_t y, GMode mode);
void S1D13700PlotHLine(uint16_t x1, uint16_t x2, uint8_t y, GMode mode);
void S1D13700PlotVLine(uint16_t x, uint8_t y1, uint8_t y2, GMode mode);
void S1D13700PlotLine(uint16_t x1, uint8_t y1, uint16_t x2, uint8_t y2, GMode mode);
void S1D13700PlotBox(uint16_t x1, uint16_t x2, uint8_t y1, uint8_t y2, GMode mode);
void S1D13700PlotCircle(uint16_t x, uint8_t y, uint8_t radius, GMode mode);


#endif //__S1D13700_H__

// vim: ts=4
// vim: sw=4


