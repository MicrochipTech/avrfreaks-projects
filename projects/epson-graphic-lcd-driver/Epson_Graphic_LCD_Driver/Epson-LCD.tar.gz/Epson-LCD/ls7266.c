/* Copyright (c) 2004, Mike Panetta (ahuitzot@mindspring.com)
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * Code to interface to an LS7266 Incremental Encoder interface via the
 * AVR expansion bus.
 *
 * All the below code is written and (c) Mike Panetta.  This code is free 
 * to use for any purpose you deem fit, and carries no warranty what so 
 * ever.  If you do decide to use this code, I ask that you keep the 
 * above notice intact.
 *
 */

#include <inttypes.h>
#include <avr/io.h>

#include <ls7266.h>

void
LS7266Init(void)
{
	XCMD = XY | IOR | CBUD | LOL | ABG;
	XCMD = XY | RLD | RSTBP | RSTFLGS;
	//XCMD = XY | RLD | RSTFLGS;
	
	LS7266SetPrescale(SELBOTH, 0x00);   // Set both prescalers to /1
	XCMD = XY | IDR | 0x00;
	LS7266InitCntr(SELBOTH, NC, X4); // Initialize both counters to normal mode and X4 quadrature.
	
	XCMD = XY | IOR | CBUD | ENAB; // Set up the output flags for carry/borrow up/dn.
}

void 
LS7266SetPrescale(Chan channel, int8_t value)
{
	switch (channel)
	{
		case SELX:
			XCMD  = RLD | RSTBP | RSTFLGS;  // Reset XBP
			XDATA = value;  // Write XPR0
			XCMD  = RLD | TXPR0PSC | RSTE; // Transfer XPR0 to XPSC
			XCMD  = RLD | RSTCNTR | RSTBP;
			break;
		case SELY:
			YCMD  = RLD | RSTBP;  // Reset YBP
			YDATA = value;  // Write YPR0
			YCMD  = RLD | TXPR0PSC | RSTE; // Transfer YPR0 to YPSC
			YCMD  = RLD | RSTCNTR;
			break;
		case SELBOTH:
			XCMD  = XY | RLD | RSTBP;  // Reset BP
			XDATA = value;  // Write XPR0
			YDATA = value;  // Write YPR0
			XCMD  = XY | RLD | TXPR0PSC | RSTE; // Transfer PR to PSC and reset error flag
			XCMD  = XY | RLD | RSTCNTR;
			break;
	}
	
}

void
LS7266InitCntr(Chan channel, CntrMode cntrMode, QuadMode quadMode)
{
	switch (channel)
	{
		case SELX:
			XCMD = RLD | RSTCNTR;  // Reset X counter
			XCMD = CMR | (cntrMode << 1) | (quadMode << 3);  // Set X counter mode
			break;
		case SELY:
			YCMD = RLD | RSTCNTR;  // Reset Y counter
			YCMD = CMR | (cntrMode << 1) | (quadMode << 3);  // Set Y counter mode
			break;
		case SELBOTH:
			XCMD = XY | RLD | RSTCNTR;  // Reset both counters
			XCMD = XY | CMR | (cntrMode << 1) | (quadMode << 3);  //  Set both counters mode
			break;
	}
}

void
LS7266ResetCntr(Chan channel)
{
	switch (channel)
	{
		case SELX:
			XCMD = RLD | RSTCNTR;  // Reset X counter
			break;
		case SELY:
			YCMD = RLD | RSTCNTR;  // Reset Y counter
			break;
		case SELBOTH:
			XCMD = XY | RLD | RSTCNTR;  // Reset both counters
			break;
	}
}

void 
LS7266LoadCntr(Chan channel, int32_t value)
{
	switch (channel)
	{
		case SELX:
			XCMD  = RLD | RSTBP;  // Reset XBP
			XDATA = value & 0xF;  // Write XPR0
			XDATA = (value >> 8) & 0xF;  // Write XPR1
			XDATA = (value >> 16) & 0xF; // Wrire XPR2
			XCMD  = RLD | TXPRCNTR; // Transfer XPR to Counter
			break;
		case SELY:
			YCMD  = RLD | RSTBP;  // Reset YBP
			YDATA = value & 0xF;  // Write YPR0
			YDATA = (value >> 8) & 0xF;  // Write YPR1
			YDATA = (value >> 16) & 0xF; // Wrire YPR2
			YCMD  = RLD | TXPRCNTR; // Transfer YPR to Counter
			break;
		case SELBOTH:
			XCMD  = XY | RLD | RSTBP;  // Reset BP
			XDATA = value & 0xF;  // Write XPR0
			XDATA = (value >> 8) & 0xF;  // Write XPR1
			XDATA = (value >> 16) & 0xF; // Wrire XPR2
			YDATA = value & 0xF;  // Write YPR0
			YDATA = (value >> 8) & 0xF;  // Write YPR1
			YDATA = (value >> 16) & 0xF; // Wrire YPR2
			XCMD  = XY | RLD | TXPRCNTR; // Transfer PR to Counter
			break;
	}
}

void
LS7266ReadCntr(Chan channel, int32_t * value)
{
	volatile uint8_t tmpdata;

	switch (channel)
	{
		case SELX:
			XCMD  = RLD | TXCNTROL | RSTBP;  // Reset XBP and tranfer the counter to the ol
			tmpdata = XDATA;
			//SED133X_printf_P(4, 5, PSTR("%2.2x"), tmpdata);
			*value = tmpdata;
			tmpdata = XDATA;
			//SED133X_printf_P(2, 5, PSTR("%2.2x"), tmpdata);
			*value |= (uint32_t)tmpdata << 8;
			tmpdata = XDATA;
			//SED133X_printf_P(0, 5, PSTR("%2.2x"), tmpdata);
			*value |= (uint32_t)tmpdata << 16;
			break;
		case SELY:
			YCMD  = RLD | TXCNTROL | RSTBP;  // Reset YBP and tranfer the counter to the ol
			tmpdata = YDATA;
			*value = tmpdata;
			tmpdata = YDATA;
			*value |= tmpdata << 8;
			tmpdata = YDATA;
			*value |= (uint32_t)tmpdata << 16;
			break;
		case SELBOTH:
			XCMD  = RLD | TXCNTROL | RSTBP;  // Reset XBP and tranfer the counter to the ol
			tmpdata = XDATA;
			*value = tmpdata;
			tmpdata = XDATA;
			*value |= tmpdata << 8;
			tmpdata = XDATA;
			*value |= (uint32_t)tmpdata << 16;
			break;
	}

}

// vim: ts=4
// vim: sw=4

