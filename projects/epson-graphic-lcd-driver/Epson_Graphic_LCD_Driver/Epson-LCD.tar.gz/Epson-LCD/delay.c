#include <avr/io.h>
#include <inttypes.h>

void
delay_ms(unsigned int delay)
{
	unsigned int i;
	OCR3AH = 0x39;
	OCR3AL = 0x9A;          
	TCCR3B = 0x00;          // Stop Timer3
	for(i=0;i<delay;++i)
	{
		TCCR3B = 0x00;          // Stop Timer3
		TCNT3H = 0x00;          // Clear Timer3
		TCNT3L = 0x00;          
		TCCR3B = 0x09;          // Start Timer3 with clk/1
		while(!(ETIFR & 0x10));
		ETIFR |= 0x10;
	}
}

void
delay(uint32_t delay)
{
	volatile uint32_t i = delay;
	while (i--);
}
