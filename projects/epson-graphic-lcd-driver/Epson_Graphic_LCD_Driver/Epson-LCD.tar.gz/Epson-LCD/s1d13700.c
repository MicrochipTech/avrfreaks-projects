/* Copyright (c) 2004, Mike Panetta (ahuitzot@mindspring.com)
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * Code to interface to an S1D13700 LCD Graphic display controller via the
 * AVR expansion bus.
 *
 * All the below code is written and (c) Mike Panetta.  The Line and Circle
 * routines are based on the Bresenham's Line and Circle algorithms, and
 * pascal code found at GameDev.net.  This code is free to use for any purpose
 * you deem fit, and carries no warranty what so ever.  If you do decide to use
 * this code, I ask that you keep the above notice intact.
 *
 */

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <s1d13700.h>
#include <delay.h>

#define SEDDELAY 1

#ifdef SLOW
#define DELAY(x) asm volatile ("nop\n\t" \
							   "nop\n\t" \
							   "nop\n\t" \
					  ::);
#else
#define DELAY(x)
#endif

static int8_t lcdX;
static int8_t lcdY;
static FILE * lcdFP;

void
S1D13700Init(void)
{

	uint16_t charCntr;

	delay_ms(3);			// Wait for things to stablize

	// Wake the display up

	SEDCMD = SYSTEM_SET;
	SEDDAT = 0x32;
	delay_ms(3);
	
	// Execute the System Set command
	SEDCMD = SYSTEM_SET;
	DELAY(SEDDELAY);
	SEDDAT = 0x30; 						 // P1
	DELAY(SEDDELAY);
	SEDDAT = 0x80 | ((CHAR_WIDTH-1) & 0x0F); // P2, FX
	DELAY(SEDDELAY);
	SEDDAT = ((CHAR_HEIGHT-1) & 0x0F);       // P3, FY
	DELAY(SEDDELAY);
	SEDDAT = S1D13700_CR;                 // P4, C/R
	DELAY(SEDDELAY);
	SEDDAT = S1D13700_TCR;                // P5, TC/R
	DELAY(SEDDELAY);
	SEDDAT = S1D13700_LF;                 // P6, L/F
	DELAY(SEDDELAY);
	SEDDAT = (S1D13700_AP & 0xFF);        // P7, APL
	DELAY(SEDDELAY);
	SEDDAT = (S1D13700_AP >> 8);          // P8, APH
	DELAY(SEDDELAY);

	// Execute the Scroll command to set up memory
	SEDCMD = SCROLL;
	DELAY(SEDDELAY);
	SEDDAT = T_BASE & 0xFF;	             // P1, SAD1L
	DELAY(SEDDELAY);
	SEDDAT = T_BASE >> 8;	             // P2, SAD1H
	DELAY(SEDDELAY);
	//SEDDAT = S1D13700_LF + 1;			 // P3, SL1 This does not work if your display is Xx256...
	SEDDAT = S1D13700_LF;			 // P3, SL1
	DELAY(SEDDELAY);
	SEDDAT = G_BASE & 0xFF;	             // P4, SAD2L
	DELAY(SEDDELAY);
	SEDDAT = G_BASE >> 8;	             // P5, SAD2H
	DELAY(SEDDELAY);
	//SEDDAT = S1D13700_LF + 1;			 // P6, SL2 This does not work if your display is Xx256...
	SEDDAT = S1D13700_LF;			 // P6, SL2
	DELAY(SEDDELAY);

	SEDDAT = 0x00;						 // P7, SAD3L
	DELAY(SEDDELAY);
	SEDDAT = 0x00;						 // P8, SAD3H
	DELAY(SEDDELAY);
	SEDDAT = 0x00;						 // P9, SAD4L
	DELAY(SEDDELAY);
	SEDDAT = 0x00;						 // P10, SAD4H
	DELAY(SEDDELAY);

	// Execute CGRAM ADR
	SEDCMD = CGRAM_ADR;
	DELAY(SEDDELAY);
	SEDDAT = CG_BASE & 0xFF;	         // P1, SAGL
	DELAY(SEDDELAY);
	SEDDAT = CG_BASE >> 8;	             // P2, SAGH
	DELAY(SEDDELAY);
	
	// Execute HDOT SCR
	SEDCMD = HDOT_SCR;
	DELAY(SEDDELAY);
	SEDDAT = 0x00;						 // P1, # pix scroll
	DELAY(SEDDELAY);

	// Execute OVLAY
	SEDCMD = OVLAY;
	DELAY(SEDDELAY);
	SEDDAT = 0x00;						 // P1, Two layer Text mode, OR compose
	DELAY(SEDDELAY);

	// Execute DISPLAY_OFF
	SEDCMD = DISPLAY_OFF;
	DELAY(SEDDELAY);
	SEDDAT = 0x16;						 // P1, First and Second screen on, Curs on and blinking (~2Hz)
	DELAY(SEDDELAY);

	// Execute CSRDIR
	SEDCMD = CSRDIR_R;					 // Cursor moves to the right for each write to vram.
	DELAY(SEDDELAY);

	// Clear memory
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = T_BASE & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = T_BASE >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);

	SEDCMD = MEM_W;
	DELAY(SEDDELAY);
	for (charCntr = 0; charCntr < T_MEMSIZ; charCntr++)
	{
		SEDDAT = ' ';
		DELAY(SEDDELAY);
	}

	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = G_BASE & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = G_BASE >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);

	SEDCMD = MEM_W;
	DELAY(SEDDELAY);
	for (charCntr = 0; charCntr < G_MEMSIZ; charCntr++)
	{
		SEDDAT = 0x00;
		DELAY(SEDDELAY);
	}

	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = CG_BASE & 0xFF;             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = CG_BASE >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);

	SEDCMD = MEM_W;
	DELAY(SEDDELAY);
	for (charCntr = 0; charCntr < CG_MEMSIZ; charCntr++)
	{
		SEDDAT = 0x00;
		DELAY(SEDDELAY);
	}

	// Execute CSRW to place cursor at the begining of the text layer
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = T_BASE & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = T_BASE >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);

	// Execute CSR_FORM to set the cursor type and format
	SEDCMD = CSR_FORM;
	DELAY(SEDDELAY);
	SEDDAT = 0x04;						 // P1, CRX=5
	//SEDDAT = 0x07;						 // P1, CRX=5
	DELAY(SEDDELAY);
	SEDDAT = 0x80 | 0x06;	     		 // P2, Block cursor, CRY=7
	//SEDDAT = 0x80 | 0x07;	     		 // P2, Block cursor, CRY=7
	DELAY(SEDDELAY);

	SEDCMD = GRAYSCALE;
	DELAY(SEDDELAY);
	SEDDAT = 0x00;
	// Execute Display On
	SEDCMD = DISPLAY_ON;
	DELAY(SEDDELAY);
	SEDDAT = 0x16;						 // P1, First and Second screen on, Curs on and blinking
	DELAY(SEDDELAY);

}

void
S1D13700ConnectIO(void)
{
	lcdFP = fdevopen(S1D13700_putc, NULL, 0);
	if (lcdFP == NULL)
		printf("Could not connect LCD IO!\n");
}

void
S1D13700WMem(uint16_t caddr, uint8_t data)
{

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = caddr & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = caddr >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);

	SEDCMD = MEM_W;
	DELAY(SEDDELAY);
	
	while (SEDDAT & 0x40)
		DELAY(SEDDELAY);
	SEDDAT = data;
	//DELAY(SEDDELAY);
	
}

void
S1D13700RMem(uint16_t caddr, uint8_t * data)
{

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = caddr & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = caddr >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);

	SEDCMD = MEM_R;
	DELAY(SEDDELAY);
	
	*(volatile uint8_t *)data = SEDCMD;
	//DELAY(SEDDELAY);
	//*(volatile uint8_t *)data = SEDCMD;

	//DELAY(SEDDELAY);
	
}

void
S1D13700SWMem(uint16_t caddr, size_t size, uint8_t * data)
{

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = caddr & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = caddr >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);
	
	SEDCMD = MEM_W;
	DELAY(SEDDELAY);

	while (size--)
	{
		while (SEDDAT & 0x40)
			DELAY(SEDDELAY);
		SEDDAT = *(data++);
		//DELAY(SEDDELAY);
	}
	
}

void
S1D13700WCGRam(uint16_t charLoc, uint8_t * charData, size_t dataLen)
{
	uint16_t addr = CG_BASE + (charLoc << 3);  // Generate the base address for the character

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = addr & 0xFF;	         // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = addr >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);
	
	SEDCMD = MEM_W;
	DELAY(SEDDELAY);

	while (dataLen--)
	{
		SEDDAT = *(charData++);
		//DELAY(SEDDELAY);
	}
}

void
S1D13700WCGRam_P(uint16_t charLoc, PGM_P charData, size_t dataLen)
{
	uint16_t addr = CG_BASE + (charLoc << 3);  // Generate the base address for the character

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = addr & 0xFF;	         // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = addr >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);
	
	SEDCMD = MEM_W;
	DELAY(SEDDELAY);

	while (dataLen--)
	{
		SEDDAT = __LPM(charData);
		//DELAY(SEDDELAY);
		charData++;
	}
}

void 
S1D13700TGotoXY(int8_t x, int8_t y)
{
	uint16_t caddr;
	lcdX = x % H_CHARS;
	lcdY = y % V_CHARS;
	
	caddr = lcdX + (lcdY * H_CHARS);

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = caddr & 0xFF;	             // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = caddr >> 8;	             // P2, CSRH
	//DELAY(SEDDELAY);
}

void
S1D13700TClrScr(void)
{

	int16_t size = H_CHARS * V_CHARS;

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = T_BASE;	                 // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = T_BASE >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);
	
	SEDCMD = MEM_W;
	DELAY(SEDDELAY);

	while (size--)
	{
		while (SEDDAT & 0x40)
			DELAY(SEDDELAY);
		SEDDAT = ' ';
		//DELAY(SEDDELAY);
	}
}
	
void
S1D13700GClrScr(void)
{

	int16_t size = G_MEMSIZ;

	// Execute CSRW to place cursor at caddr
	SEDCMD = CSR_W;
	DELAY(SEDDELAY);
	SEDDAT = G_BASE & 0xFF;	                 // P1, CSRL
	DELAY(SEDDELAY);
	SEDDAT = G_BASE >> 8;	             // P2, CSRH
	DELAY(SEDDELAY);
	
	SEDCMD = MEM_W;
	DELAY(SEDDELAY);

	while (size--)
	{
		//while (SEDDAT & 0x40)
			//DELAY(SEDDELAY);
		SEDDAT = 0x00;
		//DELAY(SEDDELAY);
	}
}
	
	

int 
S1D13700_putc(char data)
{
	uint16_t caddr;

	if (data == '\n')
	{
		lcdX = 0;
		lcdY = (lcdY + 1) % V_CHARS;
	
			
		caddr = lcdX + (lcdY * H_CHARS);

		// Execute CSRW to place cursor at caddr
		SEDCMD = CSR_W;
		DELAY(SEDDELAY);
		SEDDAT = caddr & 0xFF;	             // P1, CSRL
		DELAY(SEDDELAY);
		SEDDAT = caddr >> 8;	             // P2, CSRH
		//DELAY(SEDDELAY);

		return 0;
		
	}

	SEDCMD = MEM_W;
	DELAY(SEDDELAY);
	
	while (SEDDAT & 0x40)
		DELAY(SEDDELAY);
	SEDDAT = data;
	//DELAY(SEDDELAY);

	return 0;

}

void
S1D13700_printf(int8_t x, int8_t y, char * fmt, ...)
{
	va_list ap;

	if (lcdFP == NULL)
		return;

	S1D13700TGotoXY(x, y);
		
	va_start(ap, fmt);

	vfprintf(lcdFP, fmt, ap);

	va_end(ap);

}

void
S1D13700_printf_P(int8_t x, int8_t y, PGM_P fmt, ...)
{
	va_list ap;

	if (lcdFP == NULL)
		return;

	S1D13700TGotoXY(x, y);
		
	va_start(ap, fmt);

	vfprintf_P(lcdFP, fmt, ap);

	va_end(ap);

}

void
S1D13700PlotDot(uint16_t x, uint8_t y, GMode mode)
{
	uint8_t xByteLoc = x/8;
	uint8_t xBitLoc  = 0x80 >> (x % 8);
	uint8_t xBitData = 0;

	uint16_t caddr = xByteLoc + (y * H_PIXELS/8) + G_BASE;

	S1D13700RMem(caddr, &xBitData);	

	//printf("In %s(), xBitData = 0x%2.2x, xBitLoc = 0x%2.2x\n", __FUNCTION__, xBitData, xBitLoc);

	switch (mode)
	{
		case G_AND:
			S1D13700WMem(caddr, (xBitLoc & xBitData));
			break;
		case G_OR:
			S1D13700WMem(caddr, (xBitLoc | xBitData));
			break;
		case G_XOR:
			S1D13700WMem(caddr, (xBitLoc ^ xBitData));
			break;
		default:
			S1D13700WMem(caddr, xBitLoc);
	}

}

void
S1D13700PlotHLine(uint16_t x1, uint16_t x2, uint8_t y, GMode mode)
{
	uint8_t lineBegin      = 0xFF >> (x1 % 8);
	uint8_t lineEnd        = 0xFF << (7 - (x2 % 8));
	uint8_t xByteLocBegin  = x1/8;
	uint8_t xByteLocEnd    = x2/8;
	uint8_t xByteLoc;

	uint8_t xBitData = 0;

	uint16_t caddr = 0;

	caddr = xByteLocBegin + (y * H_PIXELS/8) + G_BASE;
	S1D13700RMem(caddr, &xBitData);

	switch (mode)
	{
		case G_AND:
			S1D13700WMem(caddr, (lineBegin & xBitData));
			break;
		case G_OR:
			S1D13700WMem(caddr, (lineBegin | xBitData));
			break;
		case G_XOR:
			S1D13700WMem(caddr, (lineBegin ^ xBitData));
			break;
		default:
			S1D13700WMem(caddr, lineBegin);
	}

	for (xByteLoc = xByteLocBegin+1; xByteLoc < xByteLocEnd; xByteLoc++)
	{
		caddr = xByteLoc + (y * H_PIXELS/8) + G_BASE;

		switch (mode)
		{
			case G_AND:
				S1D13700RMem(caddr, &xBitData);
				S1D13700WMem(caddr, (0xFF & xBitData));
				break;
			case G_OR:
				S1D13700WMem(caddr, 0xFF);
				break;
			case G_XOR:
				S1D13700RMem(caddr, &xBitData);
				S1D13700WMem(caddr, (0xFF ^ xBitData));
				break;
			default:
				S1D13700WMem(caddr, 0xFF);
		}
	}
	
	caddr = xByteLocEnd + (y * H_PIXELS/8) + G_BASE;
	S1D13700RMem(caddr, &xBitData);

	switch (mode)
	{
		case G_AND:
			S1D13700WMem(caddr, (lineEnd & xBitData));
			break;
		case G_OR:
			S1D13700WMem(caddr, (lineEnd | xBitData));
			break;
		case G_XOR:
			S1D13700WMem(caddr, (lineEnd ^ xBitData));
			break;
		default:
			S1D13700WMem(caddr, lineEnd);
	}

}

void
S1D13700PlotVLine(uint16_t x, uint8_t y1, uint8_t y2, GMode mode)
{
	uint8_t xByteLoc = x/8;
	uint8_t xBitLoc  = 0x80 >> (x % 8);
	uint8_t xBitData = 0;
	uint8_t yLoc;

	uint16_t caddr;
   
	for (yLoc = y1; yLoc <= y2; yLoc++)
	{
	
		caddr = xByteLoc + (yLoc * H_PIXELS/8) + G_BASE;

		S1D13700RMem(caddr, &xBitData);	

		//printf("In %s(), xBitData = 0x%2.2x, xBitLoc = 0x%2.2x\n", __FUNCTION__, xBitData, xBitLoc);

		switch (mode)
		{
			case G_AND:
				S1D13700WMem(caddr, (xBitLoc & xBitData));
				break;
			case G_OR:
				S1D13700WMem(caddr, (xBitLoc | xBitData));
				break;
			case G_XOR:
				S1D13700WMem(caddr, (xBitLoc ^ xBitData));
				break;
			default:
				S1D13700WMem(caddr, xBitLoc);
		}
	}
}

void
S1D13700PlotLine(uint16_t x1, uint8_t y1, uint16_t x2, uint8_t y2, GMode mode)
{
	int16_t i;
	int16_t pixels;
	int16_t deltaX = abs(x2 - x1);
	int16_t D;
	int16_t dInc1;
	int16_t dInc2;
	int16_t  deltaY = abs(y2 - y1);
	int8_t  xInc1;
	int8_t  xInc2;
	int8_t  yInc1;
	int8_t  yInc2;

	if (deltaX >= deltaY)
	{
		pixels = deltaX + 1;
		D      = (deltaY << 1) - deltaX;
		dInc1  = deltaY << 1;
		dInc2  = (deltaY - deltaX) << 1;
		xInc1  = 1;
		xInc2  = 1;
		yInc1  = 0;
		yInc2  = 1;
	}
	else
	{
		pixels = deltaY + 1;
		D      = (deltaX << 1) - deltaY;
		dInc1  = deltaX << 1;
		dInc2  = (deltaX - deltaY) << 1;
		xInc1  = 0;
		xInc2  = 1;
		yInc1  = 1;
		yInc2  = 1;
	}
	
	if (x1 > x2)
	{
		xInc1 = - xInc1;
		xInc2 = - xInc2;
	}
	if (y1 > y2)
	{
		yInc1 = - yInc1;
		yInc2 = - yInc2;
	}

	for (i = 0; i < pixels; i++)
	{
		S1D13700PlotDot(x1, y1, mode);
		if (D < 0)
		{
			D  += dInc1;
			x1 += xInc1;
			y1 += yInc1;
		}
		else
		{
			D  += dInc2;
			x1 += xInc2;
			y1 += yInc2;
		}
	}
}

void
S1D13700PlotCircle(uint16_t x, uint8_t y, uint8_t radius, GMode mode)
{
	int16_t xOffset = 0;
	int16_t yOffset = radius;
	int16_t d       = 3 - (radius << 1);

	for (; xOffset <= yOffset; xOffset++)
	{
#if 1
		S1D13700PlotDot(x + xOffset, y + yOffset, mode);
		S1D13700PlotDot(x + xOffset, y - yOffset, mode);
		S1D13700PlotDot(x - xOffset, y + yOffset, mode);
		S1D13700PlotDot(x - xOffset, y - yOffset, mode);
		S1D13700PlotDot(x + yOffset, y + xOffset, mode);
		S1D13700PlotDot(x + yOffset, y - xOffset, mode);
		S1D13700PlotDot(x - yOffset, y + xOffset, mode);
		S1D13700PlotDot(x - yOffset, y - xOffset, mode);
#else
		S1D13700PlotDot(x + xOffset, y + yOffset - (y/5), mode);
		S1D13700PlotDot(x + xOffset, y - yOffset + (y/5), mode);
		S1D13700PlotDot(x - xOffset, y + yOffset - (y/5), mode);
		S1D13700PlotDot(x - xOffset, y - yOffset + (y/5), mode);
		S1D13700PlotDot(x + yOffset, y + xOffset - (y/5), mode);
		S1D13700PlotDot(x + yOffset, y - xOffset + (y/5), mode);
		S1D13700PlotDot(x - yOffset, y + xOffset - (y/5), mode);
		S1D13700PlotDot(x - yOffset, y - xOffset + (y/5), mode);
#endif

		if (d < 0)
		{
			d = d + (xOffset << 2) + 6;
		}
		else
		{
			d = d + ((xOffset - yOffset) << 2) + 10;
			yOffset--;
		}
	}
}

void
S1D13700PlotBox(uint16_t x1, uint16_t x2, uint8_t y1, uint8_t y2, GMode mode)
{
	S1D13700PlotHLine(x1 + 1, x2 - 1, y1, mode);
	S1D13700PlotVLine(x1, y1, y2, mode);
	S1D13700PlotVLine(x2, y1, y2, mode);
	S1D13700PlotHLine(x1 + 1, x2 - 1, y2, mode);
}


// vim: ts=4
// vim: sw=4
