/*
  PAKBASE.C - definitions for PAK protocol
  AWC - http://www.awce.com

  NOTE: This file may require customization 
*/
#include "pakbase.h"
#include <avr/delay.h>

/*These first parts will require changes if you are 
   using another platform */

/* This function makes a delay unit * DELAYMULT * BASEDELAY 
   the _delay_loop_2 kills 4 cycles/loop */
void pakdelay(int unit)
{
  int i,j;
  for (i=0;i<unit;i++) 
    for (j=0;j<DELAYMULT;j++) _delay_loop_2(BASEDELAY);
}


/* Turn bits into outputs */
static inline void make_output(int bits)
{
  PDIR|=bits;
}

/* Turn bits into inputs */
static inline void make_input(int bits)
{
  // optional -- enable pull up
  PPORT|=bits;
  PDIR&=~bits;
  asm("nop");
}


/* Turn output bits off */
static inline void clr_bit(int bits)
{
  PPORT&=~bits;
}

/* Turn output bits on */
static inline void set_bit(int bits)
{
  PPORT|=bits;
}

/* Read entire port that contains DBIT */
static inline int read_port(void){ return PPIN;}



/* These routines should be pretty portable */

/* Reset the PAK */
void pakreset(void)
{
  make_output(DBIT | CBIT); 
  clr_bit(DBIT | CBIT);  // set everything to 0
  pakdelay(1);
  set_bit(CBIT);        // clock high
  pakdelay(1);
  set_bit(DBIT);
  pakdelay(1);
  clr_bit(CBIT|DBIT);  // back to zero
  pakdelay(1);
}

/* Send a byte to the PAK */
void paksend(int cmd)
{
  int i;
  for (i=0x80;i!=0;i>>=1) // MSB first
    {
      if (cmd&i)
        set_bit(DBIT);
      else
        clr_bit(DBIT);
      set_bit(CBIT);
      pakdelay(1);
      clr_bit(CBIT);
      pakdelay(1);
    }
}

/* Find out if PAK is ready */
int pakready(void)
{
  make_input(DBIT);
  pakdelay(1);
  return (read_port() & DBIT)?0:1;
}

/* Wait for PAK to signal ready (data=0) */
void pakwait(void)
  {
   make_input(DBIT);
  pakdelay(1);
  while (read_port() & DBIT);  // wait for ready (data=0)
  }

/* Get a byte from the PAK */
int pakrcv(void)
{
  int i;
  int rv=0;
  make_input(DBIT);
  for (i=0x80;i!=0;i>>=1)  /* MSB First */
    {
      rv|=((read_port()&DBIT)?i:0);
      set_bit(CBIT);
      pakdelay(1);
      clr_bit(CBIT);
      pakdelay(1);
    }
  make_output(DBIT);
  return rv;
}

