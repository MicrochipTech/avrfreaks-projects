/* Demo program for PAK-II floating point coprocessor
   www.awce.com
*/
#include <avr/interrupt.h>
#include <stdio.h>
#include "uart.h"
#include "pak2.h"


/* These make the UART code work */
#define XTAL_CPU 7372800
#define UART_BAUD_RATE 9600

/* Use pakdelay as a general delay */
#define delay(n) pakdelay(n)

// This routine is used for accepting input from stdin
// Problem here is that the library wants \n to end string
// but hard for us to read \r\n without prereading anything
// Could convert \r to \n and take your chances :-)
int ttyreader(void)
{
  int c;
  while (((c=uart_getc())&0xFF00));
  if (c=='\r') c='\n';
  return c;
}

// printx prints the X register using putchar
#define LDIGITS 3   // digits before decimal point
#define RDIGITS 3   // digits after decimal point
void printx(void)
{
  int i;
  putchar(pak2digit(0));  // print sign
  for (i=LDIGITS;i>=1;i--)  // print integer part
    putchar(pak2digit(i));
  putchar('.');
  for (i=0x81;i<=0x80+RDIGITS;i++)  // print fractional part
    putchar(pak2digit(i));
}

// round to 3 places
void round3(void)
{
      // round to 3 digits
      pak2floady(.0005);
      pak2add();
      // printx will chop off the other digits
}



/* Main program */
int main (void)
{
  float f;
  int n;
  pak2WaitMode=0;  // no blocking on floating point if set to 0!
  // init uart & STDIO
  uart_init(UART_BAUD_SELECT(UART_BAUD_RATE,XTAL_CPU));
  fdevopen(uart_putc,ttyreader,0);
  sei();  // UART requires interrupts

  printf("Here we go...\r\n");

  // always reset PAK first thing
  pakreset();
  // determine if PAK is connected
  if (!pak2check())
    {
      printf("Can't find PAK-II!\r\n");
      return 0;
    }
  // Set options
  pak2opts(PAK2_RND|PAK2_SAT);

  // set all the PAK I/O pins to outputs
  pak2setdir(PAK2PORTA,0xFF);
  pak2setdir(PAK2PORTB,0xFF);

  // Let's do some math
  pak2floadx(2.0);
  pak2floady(3.3);
  pak2add();
  pak2floady(9);   // automatically casts to float 
  pak2mult();
  pak2sqrt();
  // At this point we computed
  // sqrt(9*(2+3.3)) = 6.90652 (approx)
  printf("sqrt(9.0*(2.0+3.3))=");
  f=pak2freadx();
  printx();
  putchar('\r');
  putchar('\n');


#if 0
  // print from library
  // this version required more than 6650 bytes of .text space
  // You need to uncomment an LDFLAGS line in the makefile
  // if you want to use this library
  f=pak2freadx();
  printf("%f\r\n",f);
#else
  // print using digit command (printx, above)
  // This version required less than 2800 of .text space 
  // (linking without %f printf)
  // Note, I've added some code since generating these numbers
  // but the overhead is around 3K
  printx();
#endif 

  // do square/cube root table
  for (n=0;n<=100;n++)
    {
      pak2loadxint(n);  // X=n
      pak2sqrt();       // get square root
      printf("%d - ",n); // use the computing time to print
      round3();         // round
      printx();         // print
      pak2loadxint(n);  // X=n (again)
      pak2loadyint(3);  // Y=3
      pak2root();      // compute root
      putchar('\t');  // use computing time to print
      round3();       // round and print
      printx();
      putchar('\r');
      putchar('\n');  
    }

  // done, now ...
  // blink some LEDs on the ports
  while (1) 
    {
      pak2out(PAK2PORTA,4);   // bit 3
      pak2out(PAK2PORTB,0xFF); // all bits
      delay(10000);
      pak2out(PAK2PORTA,0);
      pak2out(PAK2PORTB,0);
      delay(10000);
    }
}





