/*
  PAK2.C - definitions for PAK 2 floating point coprocessor
  AWC - http://www.awce.com


*/
#include <pak2.h>

/* globals */
int pak2LastStatus = 0;
int pak2WaitMode = 1;
static int pak2Waiting=0;

/* This union lets us stuff/unstuff a float */
static union {
    float f;
    unsigned int n[2];
    unsigned char c[4];
  } pak2num;

/* This function waits for pending activity if applicable */
static void pwait(void)
{
  if (pak2Waiting)
    {
      pakwait();
      pak2LastStatus=pakrcv();
      pak2Waiting=0;
    }
}

/* Load Y from float */
void pak2floady(float f)
{
  pwait();
  paksend(4);  // swap
  pak2floadx(f);
  paksend(4);
}

/* Load X from float */
void pak2floadx(float f) 
{
  pak2num.f=f;
  pak2load(0,pak2num.n[1],pak2num.n[0]);
  paksend(9);
}

/* Read Y (float) */
float pak2fready(void)
{
  float f;
  pwait();
  paksend(4);
  f=pak2freadx();
  paksend(4);
  return f;
}


/* Read X (float) */
float pak2freadx(void)
{
  pwait();
  paksend(6);
  pak2readx(&pak2num.n[1],&pak2num.n[0]);
  paksend(9);
  return pak2num.f;
}

/* Raw load routines */
void pak2load(int yx,unsigned int fphigh,unsigned int fplow)
{
  pwait();
  paksend(1+yx);
  paksend(fphigh>>8);
  paksend(fphigh&0xFF);
  paksend(fplow>>8);
  paksend(fplow&0xFF);
}

void pak2loadx(unsigned int fphigh,unsigned int fplow)
{
  pak2load(0,fphigh,fplow);
}

void pak2loady(unsigned int fphigh,unsigned int fplow)
{
  pak2load(1,fphigh,fplow);
}

void pak2readx(unsigned int *fphigh, unsigned int *fplow)
{
  pwait();
  paksend(3);
  pakdelay(1);
  *fphigh=pakrcv()<<8;
  *fphigh|=pakrcv();
  *fplow=pakrcv()<<8;
  *fplow|=pakrcv();
}

/* Check for PAK presense */
int pak2check(void)
{
  int ck=pak2opwait(8);
  return ck==0x2b;
}

/* Get integer */
void pak2int(unsigned int *h, unsigned int *l)
{
  pak2opwait(0xb);
  pak2readx(h,l);
}

/* Signum */
int pak2sgn(void)
{
  unsigned c;
  c=pak2digit(0);
  if (c=='+') return 1;
  if (c=='-') return -1;
  return 0;
}

/* Set options */
void pak2opts(int opts)
{
  pwait();
  paksend(0x10); 
  paksend(opts);
}

/* Store to register */
void pak2sto(int reg)
{
  pwait();
  paksend(0x12);
  paksend(reg);
}

/* Recall from register *?
void pak2rcl(int reg)
{
  pwait();
  paksend(0x13);
  paksend(reg);
}

/* Set I/O direction */
void pak2setdir(int port,int dir)
{
  pwait();
  paksend(0x14+(port?0x80:0));
  paksend(dir);
}

/* Output to I/O pins */
void pak2out(int port, int out)
{ 
  pwait();
  paksend(0x16+(port?0x80:0));
  paksend(out);
}

/* Read I/O port */
int pak2read(int port)
{
  pwait();
  paksend(0x15+(port?0x80:0));
  return pakrcv();
}


/* Get digit (or sign) -- see DIGIT in manual */
int pak2digit(int n)
{
  pwait();
  paksend(5);
  paksend(n);
  pakwait();
  return pakrcv();
}

/* General operation */
int pak2op(int opcode)
{
  pwait();
  paksend(opcode);
  if (!pak2WaitMode) 
    { 
      pakready();   // switch to input
      pak2Waiting=1;
      return 0xFF;
    }
  pakwait();
  return pakrcv();
}

/* General operation -- always waits */
int pak2opwait(int opcode)
{
  pwait();
  paksend(opcode);
  pakwait();
  return pakrcv();
}

/* Load an integer to x */
void pak2loadxint(int n)
{
  pak2load(0,0,n);
  pak2opwait(7);
}


/* Load an integer to y */
void pak2loadyint(int n)
{
  pak2swap();
  pak2loadxint(n);
  pak2swap();
}
  
/* Send data to PAK -- this is like paksend but waits
   for pending operations */
void pak2send(int op)
{
  pwait();
  paksend(op);
}

