/*
  PAK2.H - definitions for PAK 2 floating point coprocessor
  AWC - http://www.awce.com


*/
#ifndef __pak2_h
#define __pak2_h
#include "pakbase.h"

extern int pak2LastStatus;  // only set in wait mode
extern int pak2WaitMode;    // set to 0 to enable nonblocking (default 1)

//raw load/read -- usually not used by user program
int pak2op(int opcode);
int pak2opwait(int opcode);
void pak2send(int opcode);
void pak2load(int yx,unsigned int fphigh, unsigned int fplow);
void pak2loadx(unsigned int fphigh, unsigned int fplow);
void pak2loady(unsigned int fphigh, unsigned int fplow);
void pak2readx(unsigned int *fphigh, unsigned int *fplow);

// gcc floating point interface
void pak2floadx(float f);  // load x with float
void pak2floady(float f);  // load y with float
void pak2loadxint(int n);  // load x with integer
void pak2loadyint(int n);  // load y with integer
float pak2freadx(void);    // read x as float
float pak2fready(void);    // read y as float

int pak2check(void);       // check if PAK is present (returns 1 if OK)

/* Options for PAK */
#define PAK2_SAT 0x80     // Saturation
#define PAK2_RND 0x40     // Rounding
void pak2opts(int opts);  // Set options


// memory
void pak2sto(int reg);
void pak2rcl(int reg);

// inline operations
static inline void pak2chs(void) { pak2send(0xa); }
static inline void pak2abs(void) { pak2send(0x11); }
static inline void pak2swap(void) { pak2send(4); }
static inline void pak2xtoy(void) { pak2send(0x17); }
static inline void pak2ytox(void) { pak2send(0x18); }
static inline int pak2add(void) { return pak2op(0xF); }
static inline int pak2mult(void) { return pak2op(0xC); }
static inline int pak2div(void) { return pak2op(0xd); }
static inline int pak2sub(void) { return pak2op(0xe); }
static inline int pak2sqrt(void) { return pak2op(0x19); }
static inline int pak2log(void) { return pak2op(0x1A); }
static inline int pak2log10(void) { return pak2op(0x1B); }
static inline int pak2exp(void) { return pak2op(0x1c); }
static inline int pak2exp10(void) { return pak2op(0x1d); }
static inline int pak2pow(void) { return pak2op(0x1e); }
static inline int pak2root(void) { return pak2op(0x1F); }
static inline int pak2recip(void) { return pak2op(0x20); }
static inline int pak2sin(void) { return pak2op(0x21); }
static inline int pak2cos(void) { return pak2op(0x22); }
static inline int pak2tan(void) { return pak2op(0x23); }
static inline int pak2asin(void) { return pak2op(0x24); }
static inline int pak2acos(void) { return pak2op(0x25); }
static inline int pak2atan(void) { return pak2op(0x26); }
static inline int pak2poly(void) { return pak2op(0x27); }



// operations
int pak2sgn(void);  // signum
void pak2int(unsigned int *h, unsigned int *l);  // read integer
int pak2digit(int n);  // get digit (see DIGIT command in manual)


// i/o
#define PAK2PORTA 0
#define PAK2PORTB 1
int pak2read(int port);  // read input
void pak2out(int port, int out);  // write output
void pak2setdir(int port, int dir);  // set direction





#endif
