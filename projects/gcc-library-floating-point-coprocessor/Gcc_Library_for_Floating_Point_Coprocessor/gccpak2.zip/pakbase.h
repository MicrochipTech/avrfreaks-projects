/*
  PAKBASE.H - definitions for PAK protocol
  AWC - http://www.awce.com

  NOTE: This file may require customization 
*/
#ifndef __pakbase_h
#define __pakbase_h
#include <avr/io.h>

// Timing parameters (you may wish to change these)
// For 7.372800MHz, BASEDELAY=10 DELAYMULT=1 works well
// To be in spec, clock must not exceed 100kHz
// If you rewrite pakdelay, you may or may not need these
#define BASEDELAY 10
#define DELAYMULT 1

// Port definitions (change as you wish)
// If you rewrite the port manipulation routines
// in pakbase.c, you may not need these
/* Output on PORTB.3,PORTB.4 */
#define DBIT 0x8
#define CBIT 0x10
#define PPORT PORTB
#define PPIN PINB
#define PDIR DDRB

/* Core function */
void pakdelay(int unit);  // delay 1/2 cycle units
void pakreset(void);      // reset PAK
void paksend(int cmd);    // send byte to PAK
void pakwait(void);       // wait for PAK to signal ready
int pakrcv(void);         // get byte from PAK
int pakready(void);       // check if PAK is ready 

#endif
