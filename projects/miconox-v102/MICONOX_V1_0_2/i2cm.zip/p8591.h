//---------------------------------------------------------------
//
// Name: pcf8591.h
// Title: Drive a PCF8591 I2C A/D and D/A converter
// Author: Mario Boller-Olfert
// Description:
//     Each PCF8591 consists of four A/D converters and one
//     D/A converter. Therefore several minor devices are
//     defined. Each device consists of 4 A/D-devices and
//     one D/A-device. the A/D-devices start from 0, the
//     D/A-devices start from 32. I.E.:
//
//     Chip-address  A/D-Port    Minor device number
//         000           0                 0
//         000           1                 1
//         000           2                 2
//         000           3                 3
//         001           0                 4
//         001           1                 5
//         001           2                 6
//         001           3                 7
//         
//     D/A-Ports:
//
//     Chip-address  Minor device number
//         000                32
//         001                33
//
//     The A/D converters may be configured in four different
//     input modes, 4 separate ports is default.
//
//     You may set auto increment, then all A/D-inputs may be
//     read in one operation using the first port of a chip. 
//     interface. The input operation gets the value that was
//     valid at the time of the last input request, the first
//     request always gives 0x80.
//
//     All settings become active on the next read or write
//     operation. So first read when you want to configure
//     the A/D ports and the next operation will use your
//     configuration!
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//
//---------------------------------------------------------------

#ifndef P8591_H
#define P8591_H

#include <inttypes.h>

// IOCTL-Commands
#define INPUT_MODE 0
#define AUTO_INCREMENT 1
 
typedef enum {
    singleEnded = 0,
    threeDifferential = 1,
    mixed = 2,
    twoDifferential = 3
} Pcf8591InputMode;

void p8591_init(void);

int8_t p8591_open(
        uint8_t minor,
        uint8_t mode);

int8_t p8591_close(
        uint8_t minor);

int p8591_read(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int p8591_write(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int8_t p8591_ioctl(
        uint8_t minor,
		uint8_t cmd,
		uint8_t arg);
#endif
