//---------------------------------------------------------------
//
// Name: pcf8591.c
// Title: Drive a PCF8591 I2C A/D and D/A converter
// Author: Mario Boller-Olfert
//
// Description:
//   Address of PCF8591 is:
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//       |  1  |  0  |  0  |  1  |  A2 |  A1 |  A0 | R/W |
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//   R/W==1 means: read operation
//
//   On each read or write operation, the control byte has to be
//   send first. It consists of the folloing bits:
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//       |  0  | AOE |    AIM    |  0  | AIF |    ADC    |
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//   AOE: Analog Output Enable
//   AIM: Analog Input Mode
//   AIF: Auto Increment Flag (not supported)
//   ADC: A/D Channel
//
// History:
//   1.0|03/17/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <inttypes.h>
#include "config.h"
#include "i2cm.h"
#include "p8591.h"

uint8_t control[PCF8591_NO_DEVICES];

inline static uint8_t p8591_idx(uint8_t piMinor)
{
	if(piMinor < 32) {
		return (piMinor >> 2);
	} else {
		return (piMinor >> 4);
	}
}

inline static uint8_t p8591_address(uint8_t piMinor)
{
	return 0x90 | p8591_idx(piMinor);
}

inline static uint8_t p8591_control(uint8_t piMinor)
{	
	return control[p8591_idx(piMinor)] | (piMinor & 0x03); 
}

//---------------------------------------------------------------
// Name: p8591_init
// Title: initialize PCF8591 device driver
// Description:
//    The control byte table is iitialized to zero.
// Return: 0=O.K.
//---------------------------------------------------------------

void p8591_init()
{
	register uint8_t i;
	
	for(i=0; i<PCF8591_NO_DEVICES; i++)
		control[i] = 0;
}

//---------------------------------------------------------------
// Name: p8591_open
// Title: Open PCF8591 communication
// Description:
//    Open the connection in a given mode. Supported are
//    O_RDONLY, O_WRONLY, O_RDWR and O_NONBLOCK
// Parameters: piMinor: device 0..7=PCF8574,8..15=PCF8574A
//             piMode: combination of modes, see fcntl
// Return: 0=O.K.
//---------------------------------------------------------------
 
int8_t p8591_open(
        uint8_t piMinor,
        uint8_t piMode)
{	
	if(piMinor & 0xF0)
		control[p8591_idx(piMinor)] |= 0x40;
		
	return 0;
}

//---------------------------------------------------------------
// Name: p8591_close
// Title: Close a PCF8574 connection.
// Description:
//     Close a RS232 connection. Interrupts are disabled.
// Parameters: piMinor: device to be closed
// Return: 0=O.K.
//---------------------------------------------------------------
 

int8_t p8591_close(
        uint8_t piMinor)
{
    if(piMinor & 0xF0)
		control[p8591_idx(piMinor)] &= 0xBF;
		
	return 0;
}

//---------------------------------------------------------------
// Name: p8591_read
// Title: read values from PCF8591 ports
// Description:
//    Read bytes from PCF8591. Multiple reads are possible. Read
//    is only possible on ports 0-31. If autoincrement is set,
//    then consecutive AD-ports are read.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for returned data
//             piCount: number of bytes that should be read
// Return: number of bytes read
//---------------------------------------------------------------

int p8591_read(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t i;
	register uint8_t j;
	register uint8_t ctrl;
	register uint8_t addr;
	
	ctrl = p8591_control(piMinor);
	addr = p8591_address(piMinor) | 1;
	
	if(piMinor > 31)
		return -1;
		
	for(i=0; i<piCount; i++) {
        i2cm_start();
        i2cm_send(addr);
        i2cm_send(ctrl);
        if(ctrl & 0x40) {
        	for(j=0;i<piCount-1 && j < 2; i++, j++)
        		ppcBuffer[i] = i2cm_receive(I2CM_CONTINUE);
        }
        ppcBuffer[i] = i2cm_receive(I2CM_QUIT);

        i2cm_stop();
    }
	
	return piCount;
}

//---------------------------------------------------------------
// Name: p8591_write
// Title: write values to PCF8591 D/A-converter.
// Description:
//    write values to PCF8591 D/A-converter. Multiple writes
//    are possible. Writes are only possible for ports 32-39.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for data to write
//             piCount: number of characters that to be written
// Return: number of bytes written
//---------------------------------------------------------------

int p8591_write(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t i;
	
	if(piMinor < 32)
		return -1;

    for(i=0; i<piCount; i++)
    {
    	i2cm_start();
    	i2cm_send(p8591_address(piMinor));
    	i2cm_send(p8591_control(piMinor));
    	i2cm_send(ppcBuffer[i]);
    	i2cm_stop();
    }
    
	return piCount;
}
        
//---------------------------------------------------------------
// Name: p8574_ioctl
// Title: control the functions of a PCF8574
// Description:
//     This function is not supported. Calls will be ignored.
// Parameters: piMinor: device to be controlled
//             piCmd: command
//             piARg: argument of the command 
// Return: 0=O.K., -1=error
//---------------------------------------------------------------

int8_t p8591_ioctl(
        uint8_t piMinor,
		uint8_t piCmd,
		uint8_t piArg)
{
	register uint8_t idx = p8591_control(piMinor);
	
	switch(piCmd) {
	case INPUT_MODE:
		control[idx] &= 0x4F;
		control[idx] |= (piArg << 4);
		break;
	case AUTO_INCREMENT:
		if(piArg)
			control[idx] |= 0x40;
		else
			control[idx] &= 0x73;
		break;
	default:
		return -1;
	}
	return 0;
}
