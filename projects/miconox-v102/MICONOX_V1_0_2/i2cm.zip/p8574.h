//---------------------------------------------------------------
//
// Name: p8574.h
// Title: header for PCF8574 IC interface
// Author: Mario Boller-Olfert
//
// Description:
//   Interface for PCF8574 I2C parallel port IC. 
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef P8574_H
#define P8574_H

#include <inttypes.h>

int8_t p8574_open(
        uint8_t minor,
        uint8_t mode);

int8_t p8574_close(
        uint8_t minor);

int p8574_read(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int p8574_write(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int8_t p8574_ioctl(
        uint8_t minor,
		uint8_t cmd,
		uint8_t arg);
		
#endif
