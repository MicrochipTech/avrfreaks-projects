//---------------------------------------------------------------
//
// Name: pcf8570.h
// Title: Drive a PCF8570 256x8-bit static low voltage RAM
// Author: Mario Boller-Olfert
// Description:
//     The PCF8570 supplies 256 words of 8 bit each of memory.
//
//     In write mode a block write mode is simulated by this
//     interface.
// History:
//   1.0|03/17/2002|MBO|First implementaion
//
//---------------------------------------------------------------

#ifndef P8570_H
#define P8570_H

#include <inttypes.h>

void p8570_init(void);

int p8570_read(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int p8570_write(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int8_t p8570_ioctl(
        uint8_t minor,
		uint8_t cmd,
		uint8_t arg);

#endif
