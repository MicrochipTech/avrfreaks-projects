//---------------------------------------------------------------
// Name: i2cm.h
// Author: Mario Boller-Olfert (Original from dinux)
// Title: Interface of the i2c master implementation
// Description:
//     Depending on the slave the call sequence should be:
//         i2c_start()
//         i2c_send(slave-address), bit0=read(1)/write(0) flag
//         i2c_send/i2c_receive with data
//         i2c_stop()
//
//      Before using this implementation, it is necessary to
//      adjust the ports and pins of the i2c lines. Also the
//      Delay has to be adjusted to the processor speed. It
//      should be sonething like processor_speed(MHz)*2.
//
//      Do not forget to supply pull up resistors to +5V
//      of about 2 kOhm to clock and data line!
//
//      You may also supply code to the i2cm_error function.
//      It will be called if the data send by you is not
//      acknowledged by the slave.
//
//      There are several define constants that may be defined
//      in the config.h file. Most of them have default values.
//
//      I2CM_SDA data pin, default=PB0
//      I2CM_SCL clock pin, default=PB1
//      I2CM_PORT_SDA data port, default=PORTB
//      I2CM_PORT_SCL clock port, default=PORTB
//      I2CM_DELAY time delay (microseconds), default=5 
//
// To be done: support of multiple i2c buses, multiple masters,
//             wait for slave
//
// History:
//     V1.0|03/17/2002|MBO|redesign of version from miconox
//---------------------------------------------------------------

#ifndef I2CM_H
#define I2CM_H

#include <inttypes.h>

// you should edit the next six defines for definition of the
// port bits of the i2c clock and data line.

//READ or WRITE operation/request (bit 0 of send address)
#define I2CM_READ    1
#define I2CM_WRITE   0

// parameter values for receive whether we want to continue
// the read operation
#define I2CM_QUIT            1
#define I2CM_CONTINUE        0

inline static void i2cm_error(void) {
    // this may be redefined by your application
}

//---------------------------------------------------------------
// Name: i2c_start
// Title: initiate an i2c request
//---------------------------------------------------------------
void i2cm_start(void);

//---------------------------------------------------------------
// Name: i2c_stop
// Title: end an i2c request
//---------------------------------------------------------------
void i2cm_stop(void);

//---------------------------------------------------------------
// Name: i2c_send
// Title: send data to i2c
// Description: This function is used to send the address and
//     data to the i2c bus
// Parameters: pData - data to be send
//---------------------------------------------------------------
void i2cm_send(uint8_t pData);

//---------------------------------------------------------------
// Name: i2c_receive
// Title: receive data from i2c
// Description: This function is used to receive data from the
// i2c bus. If more data is expected, then "CONTINUE" should be
// applied. If it should be the last byte, then "QUIT" should be
// given.
// Parameters: pEnd - continue/quit flag
//---------------------------------------------------------------
uint8_t i2cm_receive(uint8_t end);

#endif
