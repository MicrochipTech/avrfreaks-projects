//---------------------------------------------------------------
//
// Name: i2cm.c
// Title: I2C Master Simulation
// Author: Dimitar Dimitrov(dinux) modified by Mario Boller-Olfert
//
// Description:
//     Implementation of a simulation of an I2C master. The
//     data levels are realized by setting and freeing the
//     ports. If output is set, the line will become zero. If
//     output is released, then the pull up resistor will pull
//     the line to one.
//
//     The normal protocol is driven by the master. The master
//     sends a start condition, then sends an address byte with
//     4 bit device type, 3 bit chip address and one bit read-
//     flag. All else depends on the I2C slave device. At the
//     end a stop condition is send by the master.

// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <io.h>
#include <i2cm.h>
#include <delay.h>

// define default values
#ifndef I2CM_DELAY
#define I2CM_DELAY	5
#endif

#ifndef I2CM_SDA
#define I2CM_SDA		PB0
#endif

#ifndef I2CM_SCL
#define I2CM_SCL		PB1
#endif

#ifndef I2CM_PORT_SDA
#define	I2CM_PORT_SDA	PORTB
#endif

#ifndef I2CM_PORT_SCL
#define	I2CM_PORT_SCL	PORTB
#endif

#define	I2CM_DDR_SCL	I2CM_PORT_SCL-1
#define	I2CM_DDR_SDA	I2CM_PORT_SDA-1


// definition of macros for i2c atomic operations
#define DLY         delay(I2CM_DELAY);
#define	SCL_1		cbi(I2CM_DDR_SCL, I2CM_SCL);
#define	SCL_0		sbi(I2CM_DDR_SCL, I2CM_SCL);
#define	SDA_1		cbi(I2CM_DDR_SDA, I2CM_SDA);
#define	SDA_0		sbi(I2CM_DDR_SDA, I2CM_SDA);
#define	RELEASE_SDA	cbi(I2CM_DDR_SDA, I2CM_SDA);

//---------------------------------------------------------------
// Name: i2cm_start
// Title: I2C start condition
// Description:
//    In idle state data line and clock line are high as provided
//    by pull up resistors at the lines. At start of a
//    communication sequence the data line goes low while the
//    clock line is up. After that both lines are pulled low by
//    the master. (Normally the data line should no change
//    while the clock is high). 
// Parameters: none
// Return: none
//---------------------------------------------------------------

void i2cm_start()
{
    // initialize bits for safety
    cbi(I2CM_PORT_SCL, I2CM_SCL);
    cbi(I2CM_PORT_SDA, I2CM_SDA);
    
    // start condition: data changes to low while clock is high
    SDA_1
    SCL_1
    DLY
    SDA_0
    DLY
    SCL_0
    DLY
}

//---------------------------------------------------------------
// Name: i2cm_stop
// Title: I2C stop condition
// Description:
//    At end of a communication sequence a stop condition is
//    carried out. The data line goes high while the clock
//    line is high.
// Parameters: none
// Return: none
//---------------------------------------------------------------

void i2cm_stop(void)
{
	// stop condition: data changes to high while clock is high
    SDA_0
    SCL_1
    DLY
    SDA_1
    DLY
}

//---------------------------------------------------------------
// Name: i2cm_send
// Title: Send a byte on I2C
// Description:
//    One data bit after the other (Most significant bit first)
//    is set on the data line. While the bit is valid, the
//    clock line goes up and down once. At the end the clock
//    pulses once more to receive the acknowledge bit send by
//    the slave.
// Parameters: data: one byte of data
// Return: none
//---------------------------------------------------------------

void i2cm_send(uint8_t data)
{
    register uint8_t i;
    
    // for all bits of data byte
    for(i=0; i<=7; i++)
    {
    	// set data line according to bit
		if ( data & 0x80) 
	    	SDA_1
		else
	    	SDA_0
	    DLY
	    
	    // send a clock pulse
		SCL_1
		DLY
		SCL_0
		DLY
		
		// get next bit
		data = data << 1;
    }
    
    // trigger acknowledge
    RELEASE_SDA
    SCL_1
    DLY

    // test if acknowledge is received
    // (here something is missing: slave may pull
    // clock down to show he is busy)
    if( ! bit_is_clear(PIND, I2CM_SDA) )
		i2cm_error();
	
	// reset clock line	
	SCL_0
	DLY	
}

//---------------------------------------------------------------
// Name: i2cm_receive
// Title: Receive a byte from the slave
// Description:
//    We expect a byte of data to be send from the slave. We,
//    the master, send clock pulses on the clock line. On
//    each high level of the clock we expect one bit on the
//    data line.
//    If we want to get more data, we send an acknowledge bit
//    of zero at the end of the data. If we do not want anything
//    else we send a one acknowledge bit.
// Parameters: none
// Return: none
//---------------------------------------------------------------

uint8_t i2cm_receive(uint8_t end)
{
	uint8_t i,data = 0;
	
    // just to be sure
    RELEASE_SDA
    
    // for all bits
	for(i=0; i<=7; i++)
	{
	    // set clock pulse
		SCL_1
		DLY
		
		// get next data bit
		data <<= 1;
		if(bit_is_set(PIND, I2CM_SDA))
			data++;
			
		// reset clock pulse
		SCL_0
		DLY
	}

    // acknowledge if more is expected
	if(end==I2CM_CONTINUE)
		SDA_0
	else
		SDA_1
		
	// clock pulse for acknowledge
	SCL_1
	DLY
	SCL_0
	DLY

	return data;
}
