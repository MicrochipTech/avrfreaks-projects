//---------------------------------------------------------------
//
// Name: pcf8574.c
// Title: Drive a PCF8574 8-bit I/O Expander
// Author: Mario Boller-Olfert
//
// DESCRIPTION
//   Address of PCF8574 is:
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//       |  0  |  1  |  0  |  0  |  A2 |  A1 |  A0 | R/W |
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//   Address of PCF8574A is:
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//       |  0  |  1  |  1  |  1  |  A2 |  A1 |  A0 | R/W |
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//   R/W==1 means: read operation
//
//   In this Interface PCF8574 has minor addresses of 0 to
//   7 and PCF8574A has minor addresses of 8 to 15.
//
//   The data will be masked by this interface. On write
//   operations input pins will always be set to high value.
//   On input operations all output pins will be set to zero.
//
// History:
//   1.0|03/17/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <p8574.h>
#include <i2cm.h>

inline static int8_t p8574_address(int8_t minor)
{
	if(minor < 8)
		return 0x40 + (minor << 1);
	else
		return 0x70 + ((minor-8) << 1);
}

//---------------------------------------------------------------
// Name: p8574_read
// Title: read status bytes from PCF8574 ports
// Description:
//    Read bytes from PCF8574. Multiple reads are possible.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for returned data
//             piCount: number of bytes that should be read
// Return: number of bytes read
//---------------------------------------------------------------


int p8574_read(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t i;
	
    i2cm_start();
    
    i2cm_send(p8574_address(piMinor) | 1);
    
    for(i=0; i<piCount-1; i++)
    	ppcBuffer[i] = i2cm_receive(I2CM_CONTINUE);
    	
   	ppcBuffer[piCount-1] = i2cm_receive(I2CM_QUIT);
   	
    i2cm_stop();

	return piCount;
}

//---------------------------------------------------------------
// Name: p8574_write
// Title: write status bytes to PCF8574 ports.
// Description:
//    Write status bytes to PCF8574. Multiple writes are possible
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for data to write
//             piCount: number of characters that to be written
// Return: number of bytes written
//---------------------------------------------------------------

int p8574_write(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t i;
	
    i2cm_start();
    i2cm_send(p8574_address(piMinor));
    for(i=0; i<piCount; i++)
    	i2cm_send(ppcBuffer[i]);
    i2cm_stop();
    
	return 1;
}
