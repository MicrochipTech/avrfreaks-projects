//---------------------------------------------------------------
//
// Name: pcf8570.c
// Title: Drive a PCF857 256x8-bit static low voltage RAM
// Author: Mario Boller-Olfert
//
// DESCRIPTION
//   Address of PCF8570 is:
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//       |  1  |  0  |  1  |  0  |  A2 |  A1 |  A0 | R/W |
//       +-----+-----+-----+-----+-----+-----+-----+-----+
//   R/W==1 means: read operation
//
// History:
//   1.0|05/03/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <inttypes.h>
#include <config.h>
#include "i2cm.h"
#include "p8570.h"

// current addresses
uint8_t address[PCF8570_NO_DEVICES];

//---------------------------------------------------------------
// Name: Pcf8570_init
// Purpose: initialize values for PCF8591
// Parameters: pObj: pointer to object structure
//             pAddress: chip address: 0..7
//---------------------------------------------------------------
void p8570_init()
{
	register uint8_t i;
	
	for(i=0; i<PCF8570_NO_DEVICES; i++)
		address[8] = 0;
}

//---------------------------------------------------------------
// Name: p8570_read
// Title: read status bytes from PCF8574 ports
// Description:
//    Read bytes from PCF8570 memory. Writing stops at end of
//    memory. The current address is incremented by the number of
//    bytes read.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for returned data
//             piCount: number of bytes that should be read
// Return: number of bytes read
//---------------------------------------------------------------


int p8570_read(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t i;
	register uint8_t len = 0;
	
    i2cm_start();
    i2cm_send(0xA0 | (piMinor<<1));
    i2cm_send(address[piMinor]);
    i2cm_start();
    i2cm_send(0xA0 | (piMinor<<1) | 1);
    
    if(piCount > 256-address[piMinor]) {
    	len = 256-address[piMinor];
    	address[piMinor] = 255;
    } else
        len = piCount;
        
    if(len > 1)
    	for(i=0; i<len-1; i++)
    		ppcBuffer[i] = i2cm_receive(I2CM_CONTINUE);
    	
    ppcBuffer[len-1] = i2cm_receive(I2CM_QUIT);
    
    i2cm_stop();
    
	return len;
}

//---------------------------------------------------------------
// Name: p8570_write
// Title: write bytes to PCF8570 memory.
// Description:
//    Write bytes to PCF8570 memory. Writing stops at end of
//    memory. The current address is incremented by the number of
//    bytes written.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for data to write
//             piCount: number of characters that to be written
// Return: number of bytes written
//---------------------------------------------------------------

int p8570_write(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t len = 0;
	register uint8_t i;
	
    i2cm_start();
    i2cm_send(0xA0 + (piMinor<<1));
    i2cm_send(address[piMinor]);
    if(piCount > 256-address[piMinor]) {
    	len = 256-address[piMinor];
    	address[piMinor] = 255;
    } else
        len = piCount;
        
    for(i=0; i<len; i++)
    	i2cm_send(ppcBuffer[i]);
    	
	i2cm_stop();
    
	return len;
}
        
//---------------------------------------------------------------
// Name: p8570_ioctl
// Title: control the functions of a PCF8570
// Description:
//     Only one command is supported. PiCmd=0 sets the current
//     address to the address supplied in piArg.
// Parameters: piMinor: device to be controlled
//             piCmd: command
//             piARg: argument of the command 
// Return: 0=O.K., -1=error
//---------------------------------------------------------------

int8_t p8570_ioctl(
        uint8_t piMinor,
		uint8_t piCmd,
		uint8_t piArg)
{
	if(piCmd == 0)
		address[piMinor] = piArg;
	
	return 0;
}
