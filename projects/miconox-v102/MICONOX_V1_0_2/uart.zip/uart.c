//---------------------------------------------------------------
//
// Name: uart.c
// Title: uart serial device control
// Author: Mario Boller-Olfert
// Description:
//     Set parameters of serial interface, buffer input and
//     output. Operation is interrupt driven.
//     It is designed to support only one UART to avoid
//     overhead.
//     Setting of stop bits and data length is not yet
//     implemented.
// History:
//     Date       Name Version Description
//     04/28/2002 MBO    1.0   first implementation
//---------------------------------------------------------------

#include <interrupt.h>
#include <io.h>
#include <sig-avr.h>
#include <stdbool.h>

#include <config.h>
#include <fcntl.h>
#include <uart.h>

// set default values
#ifndef UART_RX_BUFSIZ
#define UART_RX_BUFSIZ 2
#endif

#ifndef UART_TX_BUFSIZ
#define UART_TX_BUFSIZ 2
#endif

#ifndef UART_RX_MASK
#define UART_RX_MASK '\x01'
#endif

#ifndef UART_TX_MASK
#define UART_TX_MASK '\x01'
#endif

// compute table of baud register values for different baud rates
static uint8_t giBaudRegisterValue[7] = {
	FCK/(16l*1200)-1,
	FCK/(16l*2400)-1,
	FCK/(16l*4800)-1,
	FCK/(16l*9600)-1,
    FCK/(16l*19200)-1,
    FCK/(16l*57600)-1,
    FCK/(16l*115200)-1
};

// receive and transmit buffers
static char msRxBuff[UART_RX_BUFSIZ];
static volatile uint8_t miRxBuffStart;
static volatile uint8_t miRxBuffEnd;

static char msTxBuff[UART_TX_BUFSIZ];
static volatile uint8_t miTxBuffStart;
static volatile uint8_t miTxBuffEnd;

// mode from open command
static uint8_t miMode;
 
//---------------------------------------------------------------
// Name: uart_init
// Title: Initialize uart interface
// Description:
//     Initialize the UART with a default baud rate of 2400 Baud
//     and mode 0 (nothing possible)
// Return: 0=O.K.
//---------------------------------------------------------------
 
int8_t uart_init() {	
	outp(giBaudRegisterValue[B2400], UBRR);
	miMode = 0;

    return 0;
}

//---------------------------------------------------------------
// Name: uart_open
// Title: Open uart connection
// Description:
//    Open the connection in a given mode. Supported are
//    O_RDONLY, O_WRONLY, O_RDWR and O_NONBLOCK
// Parameters: piMinor: device 0=UART0,1=UART1(not implemented)
//             piMode: combination of modes, see fcntl
// Return: 0=O.K.
//---------------------------------------------------------------
 
int8_t uart_open(
        uint8_t piMinor,
        uint8_t piMode)
{
    register uint8_t liMask = 0;
    
    miRxBuffStart = 0;
    miRxBuffEnd = 0;
    miTxBuffStart = 0;
    miTxBuffEnd = 0;
    
    miMode = piMode;
    
    if(miMode & O_RDONLY)
        liMask = (1<<RXEN ) | (1<<RXCIE);
    if( miMode & O_WRONLY )
    	liMask |= (1<<TXEN);
    outp( liMask, UCR );

	return 0;
}

//---------------------------------------------------------------
// Name: uart_close
// Title: Close a uart connection.
// Description:
//     Close a uart connection. Interrupts are disabled.
// Parameters: piMinor: device to be closed
// Return: 0=O.K.
//---------------------------------------------------------------
 
int8_t uart_close(
        uint8_t piMinor)
{
	outp(0, UCR);
	
	return 0;
}

//---------------------------------------------------------------
// Name: uart_read
// Title: read characters from uart into buffer
// Description:
//    Read multiple characters from connection. Depeding on
//    the mode (O_NONBLOCK) it is waited for the given
//    number of characters ore returned if no more data is
//    in the receive buffer.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for returned data
//             piCount: number of characters that should be read
// Return: number of bytes read
//---------------------------------------------------------------
 
int uart_read(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
    register uint8_t i;
    
    for(i=0; i<piCount; i++) {
    	if(miRxBuffStart == miRxBuffEnd) {
    		if(miMode & O_NONBLOCK)
    			return i;
    		else
    			while(miRxBuffStart == miRxBuffEnd);
    	}
    	cli();
    	ppcBuffer[i] = msRxBuff[miRxBuffStart];
    	miRxBuffStart = ((miRxBuffStart+1) & UART_RX_MASK);
    	sei();	
    }
    return piCount;
}

//---------------------------------------------------------------
// Name: uart_write
// Title: write characters from buffer to uart
// Description:
//    Write multiple characters to connection. Depending on
//    the mode (O_NONBLOCK) it is waited until the given
//    number of characters are written or returned if the
//    send buffer is full.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for data to write
//             piCount: number of characters that to be written
// Return: number of bytes written
//---------------------------------------------------------------
 
 
int uart_write(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	register uint8_t iIdx;
	register uint8_t iNewEnd;
	
    for(iIdx=0; iIdx<piCount; iIdx++) {
	    iNewEnd = ((miTxBuffEnd+1) & UART_TX_MASK);
    	if(iNewEnd == miTxBuffStart) {
    		if(miMode & O_NONBLOCK)
    			return iIdx;
    		while(iNewEnd == miTxBuffStart);
    	}
    	cli();
    	msTxBuff[miTxBuffEnd] = ppcBuffer[iIdx];
    	miTxBuffEnd = iNewEnd;
    	sei();
    	outp( inp(UCR) | (1<<UDRIE), UCR);
    }
    return piCount;
}	

//---------------------------------------------------------------
// Name: uart_ioctl
// Title: control the functions of a connection
// Description:
//     The functions of a connection are controlled. At the
//     moment only the baud rate and the blocking may be changed.
// Parameters: piMinor: device to be controlled
//             piCmd: command
//             piARg: argument of the command 
// Return: 0=O.K., -1=error
//---------------------------------------------------------------
 
int8_t uart_ioctl(
        uint8_t piMinor,
		uint8_t piCmd,
		uint8_t piArg) {
	switch(piCmd) {
	case IOCTL_BAUD: // baud rate
		outp(giBaudRegisterValue[piArg], UBRR);
		break;
	case IOCTL_NONBLOCK: // non blocking
		miMode &= ((piArg << 3) | 0xF7);
		break;
	}
	return 0;
}

//---------------------------------------------------------------
// Name: SIGNAL(SIG_UART_RECV)
// Title: receive interrupt
// Author: Mario Boller-Olfert
// Description:
//     Receive data from UART and store it into the receive
//     buffer. If buffer is full, then ignore the received
//     data.
//---------------------------------------------------------------
 
SIGNAL(SIG_UART_RECV) {
	register uint8_t liNewEnd;
	register uint8_t tmp;
	
	tmp = inp(UDR);
	msRxBuff[miRxBuffEnd] = tmp;
	
	liNewEnd = ((miRxBuffEnd + 1) & UART_RX_MASK);
	if(liNewEnd != miRxBuffStart) {
		miRxBuffEnd = liNewEnd;
	}
}

//---------------------------------------------------------------
// Name: SIGNAL(SIG_UART_DATA)
// Title: transmit interrupt
// Author: Mario Boller-Olfert
// Description: Send next byte in transmit buffer. If no data
//     is available, just turn off interrupt and quit.
//---------------------------------------------------------------
 
SIGNAL(SIG_UART_DATA) {
	if(miTxBuffStart != miTxBuffEnd) {
		outp(msTxBuff[miTxBuffStart], UDR);
		miTxBuffStart = ((miTxBuffStart+1) & UART_TX_MASK);
	} else {
		outp( inp(UCR) & ~ (1<<UDRIE), UCR );
	}
}
