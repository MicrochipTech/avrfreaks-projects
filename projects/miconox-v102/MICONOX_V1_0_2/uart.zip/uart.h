//---------------------------------------------------------------
//
// Name: uart.h
// Title: header for UART interface
// Author: Mario Boller-Olfert
//
// Description:
//   Interface of uart interface. This interface provides
//   buffered serial I/O without handshaking for 8 bit data
//   length, no parity and one stop bit.
//
//   The baud rate may be set at runtime, but beware: the
//   AVR UART is not accurate, so only low baud rates may work
//   if you want to communicate with other devices i.e. your
//   PC. 
//
//   The buffer may be 2, 4, 8, 16, 32, 64 or 128 characters
//   long (=BUFSIZ). The index is masked by a bit mask. This is
//   controlled by four define variables in the config.h file:
//
//   UART_RX_BUFSIZ receive buffer size, default=2
//   UART_TX_BUFSIZ transmit buffer size, default=2
//   UART_RX_MASK receive index mask, default='\x01'
//   UART_TX_MASK transmit index mask, default='\x01'
//
//   cdevsw-entry in config.c:
//   { uart_open, uart_close, uart_read, uart_write, uart_ioctl},
//
//   Call uart_init in main for initialsation
//.
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef uart_H
#define uart_H

#include <inttypes.h>

// command parameters for IOCTL call

// command         argument     description
//---------------------------------------------------------------
// IOCTL_BAUD      baudrate		set baudrate to Bxxxx
// IOCTL_NONBLOCK  non blocking 0=blocking, 1=do not wait for data

#define IOCTL_BAUD     0
#define IOCTL_NONBLOCK 1

// for baud rates following values are allowed:
// value    baud rate
// 0		1200 Baud
// 1		2400 Baud
// 2		4800 Baud
// 3		9600 Baud
// 4       19200 Baud
// 5       57600 Baud
// 6      115200 Baud

// Please note that not all values will work fine with all processors.
// Some values will lead to an overflow, others to incorrect baud rates.

#define B1200   0
#define B2400   1
#define B4800   2
#define B9600   3
#define B19200  4
#define B57600  5
#define B115200 6

int8_t uart_init(void);

int8_t uart_open(
        uint8_t minor,
        uint8_t mode);

int8_t uart_close(
        uint8_t minor);

int uart_read(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int uart_write(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int8_t uart_ioctl(
        uint8_t minor,
		uint8_t cmd,
		uint8_t arg);
		
#endif
