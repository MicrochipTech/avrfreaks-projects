//---------------------------------------------------------------
//
// Name: errno.h
// Title: definition of error numbers
// Author: Mario Boller-Olfert
//
// DESCRIPTION
//     In case of errors the global variable errno is set. If
//     you want to chack after a function call, you should set
//     it to zero before. It allways reflects the last error
//     that occured.
//
// History:
//   1.0|03/05/2002|MBO|First implementaion
//---------------------------------------------------------------
#ifndef ERRNO_H
#define ERRNO_H

#include <inttypes.h>

extern uint8_t errno;

#define EACCES      1 // permision denied
#define EBADF       2 // bad file descriptor
#define EBADMSG     3 // bad message
#define EBUSY       4 // device or resource busy
#define ECANCELED   5 // operation canceled
#define EEXIST      6 // file exists
#define EFAULT      7 // bad address
#define EFBIG       8 // file too big
#define ENFILE      9 // too many open files
#define EINTR      10 // interrupted function
#define EINVAL     11 // invalid argument
#define EIO        12 // i/o error
#define EISDIR     13 // is a directory
#define EMFILE     14 // too many open files
#define EMSGSIZE   15 // message too large
#define ENFILE     16 // too many open files in system
#define ENOBUFS    17 // no buffer space available
#define ENODEV     18 // no such device
#define ENOENT     19 // no such file or directory
#define ENOEXEC    20 // executable file format error
#define ENOMEM     21 // not enough memory space
#define ENOSPC     22 // no space left on device
#define ENOSYS     23 // function not supported
#define ENOTDIR    24 // not a directory
#define ENOTEMPTY  25 // directory not empty
#define ENOTSUP    26 // not supported
#define ENOTTY     27 // inappropriate i/o control operation
#define EOVERFLOW  28 // value too large to be stored in data type
#define EPERM      29 // operation not permitted
#define EPROTO     30 // protocol error
#define ERANGE     31 // result too large

#endif
