//---------------------------------------------------------------
//
// Name: config.c
// Title: Configuration of MICONOX
// Author: Mario Boller-Olfert
//
// DESCRIPTION
//   This file is used for configuration and initialisation of
//   MICONOX.
//
//   The file has to be adapted for the actual configuration.
//   The given implementation is just an example.
//
//   To do:
//      include header files of all used device drivers
//      define a directory entry for each minor device
//      make one line in cdev table for each device driver
//      call all initialization functions in dev_init
//
//   See also the file config.h
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <miconox.h>
#include <fcntl.h>
#include <stdlib.h>

#include <uart.h>
#include <p8570.h>
#include <p8574.h>
#include <p8591.h>
#include <lcd.h>

// initialisation of device directory
// you may save some space here by using shorter device names
struct dirs dir[NO_DIRE] = {
    { "tty" , 0, 0 }, // UART 0
    { "ram" , 1, 0 }, // PCF8570, address 0
    { "par1", 2, 0 }, // PCF8574, address 0
    { "par2", 2, 1 }, // PCF8574, address 1
    { "ad0" , 3, 0 }, // PCF8591, address 0, 1. A/D-converter
    { "ad1" , 3, 1 }, // PCF8591, address 0, 2. A/D-converter
    { "ad2" , 3, 2 }, // PCF8591, address 0, 3. A/D-converter
    { "ad3" , 3, 3 }, // PCF8591, address 0, 4. A/D-converter
    { "da0" , 3,32 }, // PCF8591, address 0, D/A-converter
    { "lcd" , 4, 0 }  // LCD display
 };

// character device table
struct cdevsw cdev[NO_CDEV] = {
	{ uart_open , uart_close , uart_read , uart_write , uart_ioctl },
	{ NULL      , NULL       , p8570_read, p8570_write, p8570_ioctl},
	{ NULL      , NULL       , p8574_read, p8574_write, NULL       },
	{ p8591_open, p8591_close, p8591_read, p8591_write, p8591_ioctl},
	{ lcd_open  , lcd_close  , NULL      , lcd_write  , lcd_ioctl  }
};

// call initialisation functions
void dev_init() {
	uart_init();
	p8570_init();
	p8591_init();
	lcd_init();
}
