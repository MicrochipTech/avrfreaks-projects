//---------------------------------------------------------------
//
// Name: fcntl.h
// Title: file control functionality of MICONOX
// Author: Mario Boller-Olfert
//
// Description:
//   Interface of file control. 
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef FCNTL_H
#define FCNTL_H

#include <inttypes.h>
#include <config.h>

// open flags (any combination is possible)
#define O_RDONLY   0x01
#define O_WRONLY   0x02
#define O_RDWR     0x03
#define O_NONBLOCK 0x04
#define O_APPEND   0x08
#define O_CREAT    0x10
#define O_TRUNC    0x20
#define O_EXCL     0x40

void fcntl_init(void);

int8_t open(
	    const char * path,
	    uint8_t mode);
	
int8_t close(
        uint8_t fd);

int read(
        uint8_t fd,
        char* buffer,
        uint8_t count);

int write(
        uint8_t fd,
        char* buffer,
        uint8_t count);

int8_t ioctl(
        uint8_t fd,
        uint8_t cmd,
        uint8_t arg);
        
struct strFiletable {
	int8_t major;
	int8_t minor;
};

// in memory directory structure (see config.c)
struct dirs {
	char *path;
	uint8_t major;
	uint8_t minor;
};

// character device switch table structure (see config.c)
struct cdevsw {
	int8_t (*pdopen)(uint8_t, uint8_t);
	int8_t (*pdclose)(uint8_t);
    int (*pdread)(uint8_t, char*, uint8_t);
    int (*pdwrite)(uint8_t, char*, uint8_t);
    int8_t (*pdioctl)(uint8_t, uint8_t, uint8_t);
};

#endif
