//---------------------------------------------------------------
//
// Name: fcntl.c
// Title: file control functionality of MICONOX
// Author: Mario Boller-Olfert
//
// Description:
//   File control provides functions for generic handling of
//   peripheral devices. At present only character devices are
//   handled. You open a device by giving the device name, then
//   you read/write/control the device and close it at the end. 
//
//   See config.c for definition of tables that drive the
//   functionality.
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <string.h>

#include <config.h>
#include <fcntl.h>
#include <errno.h>

struct strFiletable filetable[NO_MAXOPEN];
extern struct cdevsw cdev[];
extern struct dirs dir[];

//---------------------------------------------------------------
// Name: fcntl_initopen
// Title: Initialize file control
// Description:
//    The filetable is initialized to empty entries.
// Return: none
//---------------------------------------------------------------

void fcntl_init()
{
	register uint8_t i;
	for(i=0; i<NO_MAXOPEN; i++)
	    filetable[i].major = -1;
}

//---------------------------------------------------------------
// Name: open
// Title: Open a file
// Description:
//    Open a file given by a path name in the given mode.
//    A file descriptor is reurned, that should be used in
//    subsequent read/write/ioctl-calls.
// Parameters: path: path of file to be opened
//             mode: Mode (see fcntl.h)
// Return: 0..127: filedescriptor
//         ENODEV: unknown device
//         ENFILE: no mor open files available
//---------------------------------------------------------------

int8_t open(
	    const char * path,
	    uint8_t mode) {
    uint8_t i, j;
    int8_t (*pDOpen)(uint8_t, uint8_t);

    for(i=0; i<NO_MAXOPEN; i++) {
        if(filetable[i].major == -1)
        {
        	for(j=0; j<NO_DIRE; j++) {
        		if(! strcmp(path, (char*) dir[j].path) ) {
        			filetable[i].major = dir[j].major;
        			filetable[i].minor = dir[j].minor;
        			pDOpen = cdev[filetable[i].major].pdopen;
        			if(pDOpen)
        				pDOpen(filetable[i].minor, mode);
        			return i;
        		}
        	}
        	return errno = ENODEV;
        }
    }
    return errno = ENFILE;
}

//---------------------------------------------------------------
// Name: close
// Title: Close a file
// Description:
//    The file given by the filedescriptor is closed.
// Parameters: fd: filedescriptor
// Return: 0: O.K.
//---------------------------------------------------------------
	
int8_t close(
        uint8_t fd)
{
	int8_t (*pDClose) (uint8_t minor);
	pDClose = cdev[filetable[fd].major].pdclose;
	if(pDClose)
    	pDClose(filetable[fd].minor);
    filetable[fd].major = -1;
    return 0;
}

//---------------------------------------------------------------
// Name: read
// Title: Read from a file
// Description:
//    The given number of bytes are read from the file given
//    by the filedescriptor. The data is returned in the given
//    buffer. The number of bytes read is returned. There may be
//    less bytes read as given by count. Zero means nothing
//    has been read.
// Parameters: fd: filedescriptor
//             buffer: buffer where to put the read data
//             count: numbe of bytes that should be read
// Return: >0: number of bytes
//---------------------------------------------------------------
	
int read(
        uint8_t fd,
        char* buffer,
        uint8_t count)
{
	int (*pDRead) (uint8_t,char*,uint8_t);
    pDRead = cdev[filetable[fd].major].pdread;
    if(pDRead)
    	return pDRead(filetable[fd].minor, buffer, count);
    else
        return 0;
}
//---------------------------------------------------------------
// Name: write
// Title: Write to a file
// Description:
//    The given number of bytes are written to the file given
//    by the filedescriptor. The data is fetched from the given
//    buffer. The number of bytes written is returned. There may be
//    less bytes written as given by count. Zero means nothing
//    has been written.
// Parameters: fd: filedescriptor
//             buffer: buffer where to put the read data
//             count: numbe of bytes that should be read
// Return: >0: number of bytes
//---------------------------------------------------------------
	
	
int write(
        uint8_t fd,
        char* buffer,
        uint8_t count)
{
	int (*pDWrite) (uint8_t,char*,uint8_t);
    pDWrite= cdev[filetable[fd].major].pdwrite;
    if(pDWrite)
    	return pDWrite(filetable[fd].minor, buffer, count);
    else
    	return 0;
}

//---------------------------------------------------------------
// Name: fcntl
// Title: Control a file
// Description:
//    A command is send to the device given by the filedescriptor.
//    The command id and the argument are transferred to the
//    device. The action taken by calling this function depends
//    on the type of device used..
// Parameters: fd: filedescriptor
//             cmd: command to be executed
//             arg: argument for the command
// Return: depends on device
//---------------------------------------------------------------
	
int8_t fcntl(
        uint8_t fd,
        uint8_t cmd,
        uint8_t arg)
{
	int8_t (*pDIoctl) (uint8_t,uint8_t,uint8_t);

    pDIoctl = cdev[filetable[fd].major].pdioctl;
    if(pDIoctl)
    	return pDIoctl(filetable[fd].minor, cmd, arg);
    else
    	return 0;
}
