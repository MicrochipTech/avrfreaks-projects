//---------------------------------------------------------------
//
// Name: miconox.h
// Title: MICONOX central definitions
// Author: Mario Boller-Olfert
//
// Description:
//   Global definitions for MICONOX 
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------
#ifndef MICONOX_H
#define MICONOX_H

// Oops! Nothing necessary???

#endif
