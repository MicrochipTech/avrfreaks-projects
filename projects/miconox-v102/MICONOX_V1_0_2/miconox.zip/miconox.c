//---------------------------------------------------------------
//
// Name: miconox.c
// Title: main of MICONOX
// Author: Mario Boller-Olfert
//
// DESCRIPTION
//   MICONOX is an abbreviation for Microcontroller Native
//   Operation Extension. It should provide a standardized
//   interface for access of peripheral devices and other
//   operating system functions.
//
//   This file contains the main function of MICONOX. It
//   initializes the devices, turns on interrupt handling
//   and calls the application main function
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <interrupt.h>
#include <fcntl.h>
#include <miconox.h>
#include <config.h>

uint8_t errno;

int main(void);
int appl_main(void);

int main()
{
    errno = 0;
    
    // file control initialisation
    fcntl_init();
    
	// device initialisation
	dev_init();
	
	// allow interrupts
	sei();
	
	// call application
	return appl_main();
}
