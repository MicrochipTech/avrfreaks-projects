//---------------------------------------------------------------
//
// Name: config.h
// Title: configuration of MICONOX
// Author: Mario Boller-Olfert
//
// DESCRIPTION
//     You may change the values in this file in order to
//     configure the MICONOX kernel
//
// History:
//   1.0|03/05/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef CONFIG_H
#define CONFIG_H

//---------------------------------------------------------------
// fcntl: file control

// maximum number of open files
#define NO_MAXOPEN 4

// number of character devices
#define NO_CDEV 3

// number of directory entries
#define NO_DIRE 4

//---------------------------------------------------------------
// stdio: define functions that should exist

#define STDIO_DPRINTF 1
#define STDIO_DGETC 0
#define STDIO_DGETS 0
#define STDIO_DPUTC 0
#define STDIO_DPUTS 1

//---------------------------------------------------------------
// pcf8591: No of devices
#define PCF8591_NO_DEVICES 1

//---------------------------------------------------------------
// pcf8591: No of devices
#define PCF8570_NO_DEVICES 1

//---------------------------------------------------------------
// LCD display
#define LCD_NOROWS 4

//---------------------------------------------------------------
// general initialisation

// frequency of cpu clock
#define FCK 3690000
// #define FCK 8000000

// device initialization function
void dev_init(void);

#endif
