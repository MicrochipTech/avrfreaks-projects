//---------------------------------------------------------------
//
// Name: test.c
// Title: test application for MICONOX
// Author: Mario Boller-Olfert
//
// Description:
//     This application is for test and demonstration of the
//     MICONOX functionality. It should be replaced by your own
//     application.
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <fcntl.h>
#include <stdio.h>
#include <p8574.h>
#include <lcd.h>
#include <uart.h>

int appl_main(void);

//---------------------------------------------------------------
// Name: appl_main
// Title: application main function
// Description:
//     This function contains the main application code. It
//     should be implemented by you. This implementation is
//     just for test and demonstration.
// Return: you should never return.
//---------------------------------------------------------------

int appl_main() {
    uint8_t i, j, fdu, fdp, fdl, no, val;
    char buffer[1];

    fdu = open("tty", O_RDWR);
    fdp = open("par1", O_RDWR);
    fdl = open("lcd", O_RDWR);
	
    for(i=0;; i++) {
        no = read(fdu, buffer, 1);
        if( no != 0 ) {
            switch( buffer[0] ) {
                case 'i':
                    read(fdp, &val, 1);
                    break;
                case 'l':
                    dprintf( fdl, "%s %d", "value=", val);
                case 'w':
                    no = write(fdu, "write it!", 9);
                    return 0;
                case 'p':
                    dprintf( fdu, "%s %d", "value=", val);
                    break;
                case 'h':
		    dputs("hello", fdu);
		    break;
                default:
                    no = write(fdu, "what?", 5);
            }
        }
    }
}
