//---------------------------------------------------------------
//
// Name: stdio.c
// Title: standard i/o functions
// Author: Mario Boller-Olfert
//
// Description:
//     These are not so standard i/o functions for MICONOX.
//     To save program memory each function may be switched on
//     by a separate flag in the file config.h at compile time.
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#include <stdbool.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <config.h>
#include <stdio.h>
#include <fcntl.h>

//---------------------------------------------------------------
// Name: dprintf
// Title: low level formatted print
// Description:
//     Write several variables formatted by a format string to a
//     file descriptor.
//     The format string is interpreted like this:
//     any character: output as is
//     %c: interpret argument as character
//     %s: interpret argument as pointer to string
//     %d: interpret argument as decimal integer
//     %x: interpret argument as hex integer (lower case chars)
//     %X: interpret argument as hex integer (upper case chars)
//     %%: print a percent character
// Return: 0=O.K.
//---------------------------------------------------------------

#if STDIO_DPRINTF 
void dprintf( uint8_t fd, char* fmt, ... )
{
	va_list ap;
	int ival;
	unsigned int uval;
	register char *sval;
	char data;
	char buf[10];
	register uint8_t idx;
	register uint8_t temp;
	bool sign;
	
	va_start(ap, fmt);
	
	while(*fmt) {
		if(*fmt == '%') {
		    fmt++;
		    switch(*fmt) {
		    	case 'c': // character
	                data = va_arg(ap, int);
	                write(fd, &data, 1);	    		
					break;
		    	case 's': // string
		    		sval = va_arg(ap, char*);
		    		while(*sval)
		    			write(fd, sval, 1);
		    			sval++;
					break;
		    	case 'd': // signed integer
		    		ival = va_arg(ap, int);
		    		sign = false;
		    		if(ival < 0) {
		    			sign = true;
		    			ival = -ival;
		    		}
		    		idx=9;
		    		while(ival) {
		    			buf[idx] = ival % 10 + '0';
		    			idx--;
		    			ival /= 10;
		    		}
		    		if(sign) buf[idx] = '-';
		    		idx--;
		    		write(fd, &(buf[idx+1]), 9-idx);
					break;
		    	case 'x': // hexadecimal integer
		    	case 'X':
		    		uval = va_arg(ap, unsigned int);
		    		idx=9;
		    		while(uval) {
		    			temp = uval & 0x0F;
		    			buf[idx] = (temp < 10)? temp+'0':temp-10+(*fmt=='x'?'a':'A');
		    			idx--;
		    			uval >>= 4;
		    		}
		    		write(fd, &(buf[idx+1]), 9-idx);
					break;
				case '%':
					write(fd, "%", 1);
		    }
	    } else {
	    	write(fd, fmt, 1);
	    }
	    fmt++;
	}
}
#endif

//---------------------------------------------------------------
// Name: dgetc
// Title: low level get character function
// Description:
//     Returns one character as function value from the file
//     given by the file descriptor.
//
// Return: character read. errno is set to EIO if nothing read.
//---------------------------------------------------------------

#if STDIO_DGETC
uint8_t dgetc(uint8_t fd)
{
	uint8_t lc;
	uint8_t n;
	
	n = read(fd, &lc, 1);
	if(n==0) {
		errno = EIO;
		return 0;
	} else
		return lc;
}
#endif

//---------------------------------------------------------------
// Name: dgets
// Title: low level get string function
// Description:
//     Returns all characters until a new line is read. A 0 is
//     appended to the string. If an error occurs, errno is set
//     to EIO.
//
// Return: character read. errno is set to EIO if read error
//         occurs.
//---------------------------------------------------------------

#if STDIO_DGETS
void dgets(char *s, uint8_t n, uint8_t fd)
{
	uint8_t lc;
	register uint8_t i;
	
	for(i=0; i < n-1 && lc != '\n'; i++) {
		if(! read(fd, &lc, 1)) {
			errno = EIO;
			break;
		}
		s[i] = lc;
	}
	s[i] = '\0';
}
#endif

//---------------------------------------------------------------
// Name: dputc
// Title: low level put character function
// Description:
//     Writes one character.
// Return: errno is set to EIO if write error occurs.
//---------------------------------------------------------------

#if STDIO_DPUTC
void dputc(uint8_t c, uint8_t fd)
{
	uint8_t lc;
	lc = c;
	if(! write(fd, &lc, 1))
		errno = EIO;
}
#endif

//---------------------------------------------------------------
// Name: dputs
// Title: low level put string function
// Description:
//     Writes one character.
// Return: errno is set to EIO if write error occurs.
//---------------------------------------------------------------

#if STDIO_DPUTS
void dputs(char* s, uint8_t fd)
{
    uint8_t len=strlen(s);
    
    if(write(fd, s, len) < len)
    	errno = EIO;
}
#endif
