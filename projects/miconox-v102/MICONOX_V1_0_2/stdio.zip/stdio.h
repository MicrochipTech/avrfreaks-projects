//---------------------------------------------------------------
//
// Name: stdio.h
// Title: header for standard io interface
// Author: Mario Boller-Olfert
//
// Description:
//   Interface of standard io. 
//
// History:
//   1.0|04/28/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef STDIO_H
#define STDIO_H

#include <inttypes.h>
#include <config.h>

#if STDIO_DPRINTF
void dprintf(
	uint8_t fd,
	char* format,
	...);
#endif

#if STDIO_DGETC
uint8_t dgetc(
	uint8_t fd);
#endif

#if STDIO_DGETS
void dgets(
	char *s,
	uint8_t n,
	uint8_t fd);
#endif

#if STDIO_DPUTC
void dputc(
	uint8_t c,
	uint8_t fd);
#endif
	
#if STDIO_DPUTS
void dputs(
	char* s,
	uint8_t fd);
#endif

#endif
