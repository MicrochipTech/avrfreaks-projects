//=========================================================
// 
// name: time.h
// title: unix like time functions
//
// author: Mario Boller-Olfert
// date: 11.6.2002
// version: 1.0
//
// target: Atmel AT90S8515
//
// description:
//   These functions mimic the UNIX time functions. Time
//   is stored as seconds since 1st of January 1970
//   You may convert this time to and fro a structure
//   with conventional date format.
//
// hints: Only use these functions if you have plenty of
//        memory. Mathematical operations with long
//        numbers are not the strength of microcontrollers.
//
// This program is free software; you can redistribute it
// and/or modify it freely. This program is distributed in
// the hope that it will be useful, but without any
// warranty; without even the implied warranty of
// merchantibility or fitness for a particular purpose.
//
//=========================================================

#ifndef TIME_H
#define TIME_H

#include <inttypes.h>

// type for date and time in seconds since 1/1/1970 00:00:00
#define time_t long

// unix like date and time of day structure 
struct tm {
    uint8_t tm_hour;
    uint8_t tm_min;
    uint8_t tm_sec;
    uint8_t tm_mday;
    uint8_t tm_mon;
    uint8_t tm_year;
    uint8_t tm_wday;
};

// structure for actual time including milliseconds
struct timeb {
    time_t time;
    unsigned int millitm;
};

// initialize time handling
void time_init(void);

//---------------------------------------------------------
// name: ftime
// title: get current time in seconds and milliseconds
// parameter: tp - address of structure for value return
// return: 0=O.K.
//---------------------------------------------------------
int8_t ftime(struct timeb* tp);
    
//---------------------------------------------------------
// name: stime
// title: set the current time
// parameter: tp - time in seconds
// return: 0=O.K.
//---------------------------------------------------------    
int8_t stime(const time_t* tp);

//---------------------------------------------------------
// name: stime
// title: convert time given in seconds to time structure
// parameter: clock - time in seconds
// return: pointer to time structure
// hint: The returned structure is owned by the time module
//       Its weird, but its UNIX
//---------------------------------------------------------
struct tm* localtime(time_t clock);

//---------------------------------------------------------
// name: mktime
// title: convert time given in a structure to seconds
// parameter: tp - pointer to time structure
// return: time in seconds
//---------------------------------------------------------
time_t mktime(struct tm* tp);

#endif
