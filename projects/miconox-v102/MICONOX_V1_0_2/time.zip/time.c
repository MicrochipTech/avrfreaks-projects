//=========================================================
// name: time.c
// title: implementation of UNIX like time functions
//
// author: Mario Boller-Olfert
// date: 11.6.2002
// version: 1.0
//
// target: AT90S8515
//
// This program is free software; you can redistribute it
// and/or modify it freely. This program is distributed in
// the hope that it will be useful, but without any
// warranty; without even the implied warranty of
// merchantibility or fitness for a particular purpose.
//
//=========================================================

#include <inttypes.h>
#include <io.h>
#include <interrupt.h>
#include <sig-avr.h>

#include <config.h>
#include <time.h>

static struct tm gtm;

// actual time in seconds since 1st January 1970 00:00:00
time_t time;

// counter of milliseconds
unsigned long millisec;

// number of days per months
uint8_t mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};

//---------------------------------------------------------
// interrupt procedure called every millisecond
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
    // count seconds every 1000 milliseconds
    if(--millisec) {
        millisec = 1000;
        time++;
    }
}

//---------------------------------------------------------
// initialize timer
//---------------------------------------------------------
void time_init()
{
     // initialize millisecond counter
     millisec = 1000;

     // disable input capture
     outp(inp(TIFR) & ~BV(ICF1), TIFR);
     
     // disable timer output
     outp(0, TCCR1A);
     
     // reset counter on match
     outp(BV(CTC1)|BV(CS10), TCCR1B);

     // set compare register according to clock speed
     outp((FCK/1000)>>8, OCR1AH);
     outp((FCK/1000) & 0xFF, OCR1AL);

     // enable only output compare match interrupt
     outp((inp(TIMSK)|BV(OCIE1A))& ~(BV(TOIE1)|BV(TICIE1)), TIMSK);     
}

//---------------------------------------------------------
// get actual time in seconds and milliseconds
//---------------------------------------------------------
int8_t ftime(struct timeb* tp)
{
    tp->time = time;
    tp->millitm = millisec;
    return 0;
}

//---------------------------------------------------------
// set actual time to value in seconds    
//---------------------------------------------------------
int8_t stime(const time_t* tp)
{
    time = *tp;
    millisec = 0;
    return 0;
}

//---------------------------------------------------------
// convert time given in seconds to date and time structure
//---------------------------------------------------------
struct tm* localtime(time_t time)
{
    time_t temp;
    uint8_t i;
    
    // seconds 
    gtm.tm_sec = time % 60;
    temp = time / 60;
    
    // compute minutes
    gtm.tm_min = temp % 60;
    temp /= 60;
    
    // compute hours
    gtm.tm_hour = temp % 24;
    temp /= 24;
    
    // compute weekday
    gtm.tm_wday = (temp+4) % 7;
    
    // subtract number of leap days
    temp -= (temp + 364) / 1461;
    
    // compute year
    gtm.tm_year = temp / 365 + 70;
    temp = temp % 365;

    // set length of february depending on leap years
    if(gtm.tm_year % 4)
        mdays[1] = 28;
    else
        mdays[1] = 29;
        
    // subtract full months
    for(i=0; temp >= mdays[i]; i++)
    	temp -= mdays[i];
   
    // set month and day
    gtm.tm_mon = i+1;
    gtm.tm_mday = temp+1;
    
    // return pointer to structure
    return &gtm;
}

//---------------------------------------------------------
// convert date and time structure to time in seconds 
//---------------------------------------------------------
time_t mktime(struct tm* t)
{
    time_t temp;
    uint8_t i;
    
    // compute seconds for years including leap years
    temp = ((t->tm_year-70l)*1461l)/4l;
    
    // compute number of days of past month of actual year
    for(i=1;i<t->tm_mon;i++) temp+=(long)mdays[i-1];
    
    // add actual date to number of days
    temp += t->tm_mday-1;
    
    // compute number of hours for the days
    temp *= 24l;
    
    // add hour and compute minutes
    temp += t->tm_hour;
    temp *= 60l;
    
    // add minute and compute seconds
    temp += t->tm_min;
    temp *= 60l;
    
    // at last add the seconds
    temp += t->tm_sec;
    
    // return seconds
    return temp;
}
