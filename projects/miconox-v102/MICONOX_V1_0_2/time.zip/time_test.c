//=========================================================
// name: time_test.c
// title: test program for UNIX like time functions
//
// author: Mario Boller-Olfert
//
// description:
//     Test program for the UNIX like time functions. It
//     converts some dates from structured representation
//     to seconds since 1970 and back. After that a
//     counted time is displayed. You need the library
//     conio.o provided together with avrgcc.
//
// This program is free software; you can redistribute it
// and/or modify it freely. This program is distributed in
// the hope that it will be useful, but without any
// warranty; without even the implied warranty of
// merchantibility or fitness for a particular purpose.
//
//=========================================================

#include <time.h>
#include <conio.h>

//---------------------------------------------------------
// definitions
//---------------------------------------------------------
int main(void);
void put2(uint8_t x);
void puttm(struct tm* t);
void putlong(long l);

//---------------------------------------------------------
// main test function
//---------------------------------------------------------
int main() {
    time_t time;
    struct tm myTm[9] = {
        { 11, 22, 33, 20, 05, 102, 0 },
        {  0,  0,  0,  1,  1, 70, 0 },
        {  0,  0,  0,  1,  1, 71, 0 },
        {  0,  0,  0, 31, 12, 71, 0 },
        {  0,  0,  0,  1,  1, 72, 0 },
        {  0,  0,  0, 28,  2, 72, 0 },
        {  0,  0,  0, 29,  2, 72, 0 },
        { 23, 59, 59,  1,  3, 72, 0 },
        {  0,  0,  0,  1,  1, 73, 0 } };
    struct timeb myTimeb;
    struct tm *tp;
    int i;
    
    // initialize time management
    time_init();
    
    // set time to first time in table
    time = mktime(&myTm[0]); 
    stime(&time);

    // convert all time in table and display them
    for(i=0; i<9; i++) {
    
        puttm(&myTm[i]);
        putchar('|');
        
        time = mktime(&myTm[i]);
        
        putlong(time);        
        putchar('|');

        tp = localtime(time);
    
        puttm(tp);        
        putchar('\n');
    }

    // display continuous time
    while(1) {
        ftime(&myTimeb);
        tp = localtime(myTimeb.time);
        puttm(tp);
        putchar('\n');
    }

    return 0;
}

//---------------------------------------------------------
// output two digit number
//---------------------------------------------------------
void put2(uint8_t x) {
    putchar((x/10)%10+'0');
    putchar(x%10+'0');
}

//---------------------------------------------------------
// display time structure
//---------------------------------------------------------
void puttm(struct tm* t)
{
    put2(t->tm_mday);
    putchar('.');
    put2(t->tm_mon);
    putchar('.');
    put2(t->tm_year);
    putchar(' ');
    put2(t->tm_hour);
    putchar(':');
    put2(t->tm_min);
    putchar(':');
    put2(t->tm_sec);
}

//---------------------------------------------------------
// display long number
//---------------------------------------------------------
void putlong(long l)
{
    int i, j;
    char x[20];
    if(l==0) {
        putchar('0');
        return;
    }
    for(i=0; l != 0; i++)
    {
    	x[i] = l % 10 + '0';
    	l /= 10;
    }
    for(j=i; j>=0; j--)
        putchar(x[j]);
}
