//---------------------------------------------------------------
//
// Name: delay.h
// Title: header for delay function
// Author: Mario Boller-Olfert
//
// Description:
//   Wait for a specified time.
//
//   The current implementation is not very accurate to reduce
//   the cost of execution, but it takes the CPU clock frequency
//   into account. The implementation avoids to use divisions
//   ot multiplications to be more accurate. It should work for
//   up to 65 milliseconds, what should be enough for most
//   applications. Minimum clock frequency is 4 MHz.
//
//   The delay time may vary depending on the optimization level
//   of the compiler and the compiler type.
//
//   Times measured at 3.69 MHz Clock frequency on a STK500 board
//   are:
//
//   Value Time(micro-seconds)
//   -------------------------
//      1          2.5
//     10         11.2
//    100        102.0 
//   1000       1010.0
//
// History:
//   1.0|05/12/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef DELAY_H
#define DELAY_H

#include "config.h"

void delay(unsigned int uMicroSeconds);

#endif
