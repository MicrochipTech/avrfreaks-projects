//---------------------------------------------------------------
//
// Name: delay.c
// Title: wait for a time delay
// Author: Mario Boller-Olfert
// Description:
//     Wait for a given time delay given in microseconds.
// History:
//     1.0|05/12/2002|MBO|first implementation
//---------------------------------------------------------------

#include <delay.h>

#define DELAY_SHIFT FCK/8000000

void delay(unsigned int uMicroSeconds) {
	uMicroSeconds <<= DELAY_SHIFT;
	uMicroSeconds -= uMicroSeconds >> 2;
	for(;uMicroSeconds>0;uMicroSeconds--) asm("nop");
}
