//---------------------------------------------------------------
//
// Name: lcd.c
// Title: lcd device control
// Author: Mario Boller-Olfert
// Description:
//     Set parameters of lcd. Only write is supported.
// History:
//     Date       Name Version Description
//     05/09/2002 MBO    1.0   first implementation
//---------------------------------------------------------------

#include <io.h>
#include <stdbool.h>

#include <config.h>
#include <fcntl.h>
#include <lcd.h>
#include <delay.h>

#ifdef LCD_PCF8574
#include <p8574.h>
#endif

// other port registers
#define LCD_DDR LCD_PORT-1
#define LCD_PINS LCD_PORT-2

// set dafault values
#ifndef LCD_NOCOL
#define LCD_NOCOL     16
#endif
#ifndef LCD_NOROW
#define LCD_NOROW     1
#endif
#ifndef LCD_ADDR_ROW1
#define LCD_ADDR_ROW1 0x00
#endif 
#ifndef LCD_ADDR_ROW2
#define LCD_ADDR_ROW2 0x40
#endif 
#ifndef LCD_ADDR_ROW3
#define LCD_ADDR_ROW3 0x10
#endif 
#ifndef LCD_ADDR_ROW4
#define LCD_ADDR_ROW4 0x50
#endif 
#ifndef LCD_DELAY
#define LCD_DELAY     40
#endif
#ifndef LCD_DELAY_CLR
#define LCD_DELAY_CLR 1640
#endif
#ifndef LCD_USEBUSY
#define LCD_USEBUSY   0
#endif
#ifndef LCD_PORT
#define LCD_PORT      PORTA
#endif
#ifndef LCD_CMDBIT
#define LCD_CMDBIT    4
#endif
#ifndef LCD_RWBIT
#define LCD_RWBIT     6
#endif
#ifndef LCD_ENABIT
#define LCD_ENABIT    5
#endif
#ifndef LCD_HBS
#define LCD_HBS       0
#endif
#ifndef LCD_HCURPOS
#define LCD_HCURPOS   0
#endif
#ifndef LCD_HTABS
#define LCD_HTABS     0
#endif

// logical cursor position
static uint8_t iCurRow; // current cursor row (0..n)
static uint8_t iCurCol; // current corsor column (0..n)

// command for cursor and display control
static uint8_t iCmd;

// local functions
static void lcd_busy(void);
static void lcd_enable(void);
static void lcd_setcur(void);
static void lcd_send(uint8_t);
static void lcd_send_command(uint8_t);
#if LCD_USEBUSY
static uint8_t lcd_receive(void);
#endif

// data byte for connection over i2c PCF8574
#ifdef LCD_PCF8574
	uint8_t mPcfData;
#endif

void lcd_init() {
    int i;
    
	// initialize data direction bits
	outp(inp(LCD_DDR)|0x0F|1<<LCD_CMDBIT|1<<LCD_ENABIT, LCD_DDR);
#ifndef LCD_PCF8574
	
#if LCD_USEBUSY
	sbi(LCD_DDR, LCD_RWBIT);
#endif
#endif

	// wait after power on
	delay(20000);

    // initialize display
#ifdef LCD_PCF8574
    mPcfData = 0x03;
    p8574_write( LCD_PCF8574, &mPcfData, 1);
#else
    outp(((inp(LCD_PORT)&0x0F)|0x03), LCD_PORT);
#endif
    for(i=0; i<3; i++) {
    	lcd_enable();
    	delay(5000);
    }

	// switch to 4 bit mode
#ifdef LCD_PCF8574
    mPcfData = 0x02;
    p8574_write( LCD_PCF8574, &mPcfData, 1);
#else
	outp((inp(LCD_PORT)&0xF0)|0x02, LCD_PORT);
#endif
	lcd_enable();
	delay(LCD_DELAY); 

	// switch display off
	lcd_send_command(0x28);
	lcd_send_command(0x0F);
	lcd_send_command(0x06);
	lcd_send_command(0x01);
}

//---------------------------------------------------------------
// Name: lcd_open
// Title: Open lcd
// Description:
//    Open the lcd. Supported is only O_RDONLY. The lcd is
//    switched on and initialized.
// Parameters: piMinor: device 0=UART0,1=UART1(not implemented)
//             piMode: combination of modes, see fcntl
// Return: 0=O.K.
//---------------------------------------------------------------
 
int8_t lcd_open(
        uint8_t piMinor,
        uint8_t piMode)
{
	// clear display
	lcd_send_command(0x01); delay(LCD_DELAY_CLR);
	
	// switch display on
	lcd_send_command(0x0E);
	
	return 0;
}

//---------------------------------------------------------------
// Name: lcd_close
// Title: Close a lcd output.
// Description:
//     Close a lcd output. Switch off lcd.
// Parameters: piMinor: device to be closed
// Return: 0=O.K.
//---------------------------------------------------------------
 
int8_t lcd_close(
        uint8_t piMinor)
{
	// switch display off
	lcd_send_command(0x08);
	
	return 0;
}

//---------------------------------------------------------------
// Name: lcd_write
// Title: write characters from buffer to lcd
// Description:
//    Write multiple characters to lcd.
// Parameters: piMinor: device
//             ppcBuffer: address of a buffer for data to write
//             piCount: number of characters to be written
// Return: number of bytes written
//---------------------------------------------------------------
  
int lcd_write(
        uint8_t piMinor,
        char* ppcBuffer,
        uint8_t piCount)
{
	uint8_t i;
	for(i=0; i<piCount; i++) {
		if(ppcBuffer[i] == '\f') {
			lcd_send_command(0x01); delay(LCD_DELAY_CLR);
			iCurRow = 0;
			iCurCol = 0;
#if LCD_HCURPOS
		} else if(ppcBuffer[i] == '\x01') {
			iCurRow = ppcBuffer[i+1];
			iCurCol = ppcBuffer[i+2];
			i+=2;			
#endif
#if LCD_HBS
		} else if(ppcBuffer[i] == '\b') {
			if(iCurCol) {
				iCurCol--;
				lcd_setcur();
				lcd_send(' ');
			}
#endif
#if LCD_HTABS
		} else if(ppcBuffer[i] == '\t') {
			if(iCurCol+8 < LCD_NOCOL)
				iCurCol += 8;
#endif
		} else if(ppcBuffer[i] == '\n') {
			if(iCurRow < LCD_NOROW+1) { 
				iCurRow++;
			}
		} else if(ppcBuffer[i] == '\r') {
			iCurCol = 0;
		} else {
			lcd_send(ppcBuffer[i]);
			iCurCol++;
			if(iCurCol == LCD_NOCOL) {
				iCurCol = 0;
				iCurRow ++;
				if(iCurRow == LCD_NOROW) {
				    iCurRow = 0;
				    lcd_send_command(0);
				}
			}
		}
		lcd_setcur();
	}
    return piCount;
}	

//---------------------------------------------------------------
// Name: lcd_ioctl
// Title: control the functions of a lcd
// Description:
//     The functions of a lcd are controlled.
// Parameters: piMinor: device to be controlled
//             piCmd: command
//             piARg: argument of the command 
// Return: 0=O.K., -1=error
//---------------------------------------------------------------
 
int8_t lcd_ioctl(
        uint8_t piMinor,
		uint8_t piCmd,
		uint8_t piArg) {
	switch(piCmd) {
	case IOCTL_CURSOR: // enable cursor
		iCmd = (iCmd & 0x02) | ((piArg & 0x01) << 1);
		lcd_send_command(iCmd);
		break;
	case IOCTL_BLINK: // enable cursor blinking
		iCmd = (iCmd & 0x01) | (piArg & 0x01);
		lcd_send_command(iCmd);
		break;
	case IOCTL_DISPLAY: // enable display
		iCmd = (iCmd & 0x04) | ((piArg & 0x01) << 2);
		lcd_send_command(iCmd);
		break;
	case IOCTL_FONT: // use large font
		lcd_send_command(0x20 | (piArg & 0x01) << 2);
		break;
	}
	return 0;
}

//---------------------------------------------------------------
// Name: lcd_busy
// Title: wait while lcd display is busy
// Description:
//     Either it is waited for busy bit clear or a fix amount
//     of time..
// Parameters: none
// Return: none
//---------------------------------------------------------------
 
static void lcd_busy() {
#ifdef LCD_PCF8574
    delay(LCD_DELAY);
#else
#if LCD_USEBUSY
	while(lcd_receive() & 0x40) asm("nop");
#else
	delay(LCD_DELAY);
#endif
#endif	
}

//---------------------------------------------------------------
// Name: lcd_send_command
// Title: send a command to the lcd
// Description:
//     The command bit is set and the command is send to the lcd
// Parameters: command: command to be send
// Return: none
//---------------------------------------------------------------
 
static void lcd_send_command(
	uint8_t command) {
	
	// set command bit
#ifdef LCD_PCF8574
	mPcfData &= ~(1<<LCD_CMDBIT);
#else 
	cbi(LCD_PORT, LCD_CMDBIT);
#endif

	// send byte to display
	lcd_send(command);
	
#ifdef LCD_PCF8574
	mPcfData |= 1<<LCD_CMDBIT;
#else
	sbi(LCD_PORT, LCD_CMDBIT);
#endif
}

//---------------------------------------------------------------
// Name: lcd_send
// Title: send a byte to the lcd
// Description:
//     A byte is send to the lcd in two 4 bit nibbles.
// Parameters: data: data to be send
// Return: none
//---------------------------------------------------------------
 
static void lcd_send(
	uint8_t data) {

// send first half byte
#ifdef LCD_PCF8574
	mPcfData = (mPcfData & 0xF0) | ((data>>4) & 0x0F);
	p8574_write( LCD_PCF8574, &pcf_data, 1);
	
#else
	lcd_busy();
	
	outp((inp(LCD_PORT)&0xF0)|((data>>4) & 0x0F), LCD_PORT);

#if LCD_USEBUSY
	outp(inp(LCD_PORT)|1<<LCD_RWBIT, LCD_PORT);
#endif

#endif

	lcd_enable();
	
// send second half byte	
#ifdef LCD_PCF8574
	mPcfData = (mPcfData & 0xF0) | (data & 0x0F);
	p8574_write( LCD_PCF8574, mPcfData, 1);	
#else
	outp((inp(LCD_PORT)&0xF0)|(data & 0x0F), LCD_PORT);
#endif

	lcd_enable();
}

//---------------------------------------------------------------
// Name: lcd_setcur
// Title: set the cursor
// Description:
//     The cursor is set to the current logical position
// Parameters: none
// Return: none
//---------------------------------------------------------------
 
static void lcd_setcur() {
	uint8_t addr = 0;
	switch(iCurRow) {
		case 0:
			addr=LCD_ADDR_ROW1;
            break;
#if LCD_NOROW > 1
		case 1:
			addr=LCD_ADDR_ROW2;
			break;
#endif
#if LCD_NOROW > 2
		case 2:
			addr=LCD_ADDR_ROW3;
			break;
#endif
#if lCD_NOROW > 3
		case 3:
			addr=LCD_ADDR_ROW4;
			break;
#endif
	}
	addr += iCurCol;
	lcd_send_command( 0x80 | addr );
}

//---------------------------------------------------------------
// Name: lcd_enable
// Title: enable lcd data
// Description:
//     Enable the lcd to accept the current data.
// Parameters: none
// Return: none
//---------------------------------------------------------------
 
static void lcd_enable() {
#ifdef LCD_PC8574
	mPcfData |= 1<<LCD_ENABIT;
	pcf8574_write( LCD_PCF8574, &mPcfData, 1);
	mPcfData &= ~(1<<LCD_ENABIT);
	pcf8574_write( LCD_PCF8574, &mPcfData, 1);
#else
	sbi(LCD_PORT, LCD_ENABIT);
	delay(LCD_DELAY);
    cbi(LCD_PORT, LCD_ENABIT);
#endif
}

//---------------------------------------------------------------
// Name: lcd_read
// Title: read data from lcd
// Description:
//     Read data from LCD i.e. the busy flag.
// Parameters: none
// Return: none
//---------------------------------------------------------------
 
#if LCD_USEBUSY
static uint8_t lcd_read() {
	// set bits for status read
	cbi(LCD_PORT, LCD_CMDBIT);
    sbi(LCD_PORT, LCD_RWBIT);
    
    // configure data port bits for input
    outp(inp(LCD_DDR) & 0xF0, LCD_DDR);
    
    // read high byte
    outp(inp(LCD_PORT)|(1<<LCD_ENABIT), LCD_PORT);
    delay(LCD_DELAY);
    uint8_t iHigh = inp(LCD_PIN);
    outp(inp(LCD_PORT)& ~(1<<LCD_ENABIT), LCD_PORT);
    delay(LCD_DELAY);
    
    // read low byte

    sbi(LCD_PORT, LCD_ENABIT);
    delay(LCD_DELAY);
    uint8_t iLow = inp(LCD_PORT);
    cbi(LCD_PORT, LCD_ENABIT);
    delay(LCD_DELAY);
    
    // configure data port bits for output
    outp(inp(LCD_DDR) | 0x0F, LCD_DDR);

    return (iHigh<<4) | iLow;
}
#endif
