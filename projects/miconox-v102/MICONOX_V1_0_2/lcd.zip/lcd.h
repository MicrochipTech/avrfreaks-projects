//---------------------------------------------------------------
//
// Name: lcd.h
// Title: header for LCD interface
// Author: Mario Boller-Olfert
//
// Description:
//   Interface of LCD interface.
//
//   Either the busy status bit of the display or a fixed delay
//   are used to wait for the display operations. 
//   Read is only supported for internal use to read the busy
//   flag. So the code will be reduced, if the busy flag is not
//   used.
//
//   Output control is done by interpretation of special
//   characters. Most of the handling may be switched off
//   using defines to reduce the amount of code generated.
//
//   You may also connect the lcd via I2C with a PCF8574
//   ic. If an PCF8574 address is defined, then port address
//   and busy flag usage are ignored. This especially makes
//   sense if you want to connect the lcd temporary.
//
//   Displays with 2 enable bits are not supported (i.e.LCD404A).
//
// History:
//   1.0|05/09/2002|MBO|First implementaion
//---------------------------------------------------------------

#ifndef LCD_H
#define LCD_H

#include <inttypes.h>

// command parameters for IOCTL call

// command         argument     description
//---------------------------------------------------------------
// IOCTL_CURSOR    true/false   cursor on/off
// IOCTL_BLINK     true/false   blinking on/off
// IOCTL_DISPLAY   true/false   display on/off
// IOCTL_FONT      true/false   big font on/off

#define IOCTL_CURSOR  0
#define IOCTL_BLINK   1
#define IOCTL_DISPLAY 2
#define IOCTL_FONT    3

// special characters
// 0x01      cursor positioning (next 2 chars are row and column)
//           values range from 1 to LCD_NOROW or LCD_NOCOL
// 0x07 '\b' backsapce (cursor 1 char back and delete char)
// 0x09 '\t' tab (cursor column to next multiple of 8)
// 0x0A '\n' new line (cursor one line down, scroll)
// 0x0C '\f' form feed (clear screen and cursor to home)
// 0x0D '\r' carriage return (cursor to start of line)

// define constants (insert into config.h)

// LCD_NOCOL     number of visible columns, default=16
// LCD_NOROW     number of visible rows, default=1

// all row addresses are given without highest bit set
// LCD_ADDR_ROW1 start address of row 1, default=0x00
// LCD_ADDR_ROW2 start address of row 2, default=0x40
// LCD_ADDR_ROW3 start address of row 3, default=0x10
// LCD_ADDR_ROW4 start address of row 4, default=0x50
//
// Some row address values of popular displays:
// LCDxx1  0x00
// LCDxx2  0x00, 0x40 // up to 64 columns
// LCD164A 0x00, 0x40, 0x10, 0x50
// LCD204A 0x00, 0x40, 0x14, 0x54

// LCD_DELAY    used on read of busy flag or always if busy is not used
//              default=40
// port definition
// LCD_PORT      data port where LCD is connected, default=PORTA
// LCD_PCF8574   instead of a port you may define an address on I2C, 
//               default=undefined

// special bits
// LCD_CMDBIT    command enable bit, default=4
// LCD_RWBIT     read/write bit, only necessary for busy flag, default=6
// LCD_ENABIT    enable bit, default=5

// function disable=0/enable=1, disable to save program space
// LCD_USEBUSY   use busy flag (requires read bit, not used on I2C)
//               default = 0
// LCD_HBS       handle backspace, default=0
// LCD_HCURPOS   handle cursor positioning, default=0
// LCD_HTABS     handle tab characters, default=0

void lcd_init(void);

int8_t lcd_open(
        uint8_t minor,
        uint8_t mode);

int8_t lcd_close(
        uint8_t minor);

int lcd_write(
        uint8_t minor,
        char* buffer,
        uint8_t count);

int8_t lcd_ioctl(
        uint8_t minor,
		uint8_t cmd,
		uint8_t arg);
		
#endif
