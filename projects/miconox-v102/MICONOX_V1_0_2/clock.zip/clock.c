//=========================================================
// name: clock.c
// title: implementation of real time clock
//
// author: Mario Boller-Olfert
// date: 11.6.2002
// version: 1.0
//
// target: AT90S8515
//
// This program is free software; you can redistribute it
// and/or modify it freely. This program is distributed in
// the hope that it will be useful, but without any
// warranty; without even the implied warranty of
// merchantibility or fitness for a particular purpose.
//
//=========================================================

#include <inttypes.h>
#include <io.h>
#include <interrupt.h>
#include <sig-avr.h>

#include <config.h>
#include <clock.h>

static struct tm gtm;
int millisec;

uint8_t mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};

SIGNAL(SIG_OUTPUT_COMPARE1A)
{
    if(--millisec <= 0) {
        millisec = 1000;
        if(++gtm.tm_sec == 60) {
            gtm.tm_sec = 0;
            if(++gtm.tm_min == 60) {
                gtm.tm_min = 0;
                if(++gtm.tm_hour == 24) {
                    gtm.tm_hour = 0;
                    gtm.tm_wday = (++gtm.tm_wday) % 7;
                    if(++gtm.tm_mday > mdays[gtm.tm_mon-1]) {
                        gtm.tm_mday = 1;
                        if(gtm.tm_mon++ == 13) {
                            gtm.tm_mon = 1;
                            gtm.tm_year++;
                            if(gtm.tm_year % 4)
                            	mdays[1] = 28;
                            else
                            	mdays[1] = 29;
                        }
                    }
                }
            }
        }
    }
}

void clock_init()
{
     // disable input capture
     outp(inp(TIFR) & ~BV(ICF1), TIFR);
     
     // disable timer output
     outp(0, TCCR1A);
     
     // reset counter on match
     outp(BV(CTC1)|BV(CS10), TCCR1B);

     // set compare register according to clock speed
     outp((FCK/1000)>>8, OCR1AH);
     outp((FCK/1000) & 0xFF, OCR1AL);

     // enable only output compare match interrupt
     outp((inp(TIMSK)|BV(OCIE1A))& ~(BV(TOIE1)|BV(TICIE1)), TIMSK);
}

void setclock(struct tm* time)
{
    gtm = *time;
}

struct tm* getclock()
{
    return &gtm;
}
