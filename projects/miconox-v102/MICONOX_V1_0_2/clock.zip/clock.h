//=========================================================
// 
// name: clock.h
// title: real time clock functions
//
// author: Mario Boller-Olfert
// date: 11.6.2002
// version: 1.0
//
// target: Atmel AT90S8515
//
// description:
//   These functions make up a real time clock.
//
// This program is free software; you can redistribute it
// and/or modify it freely. This program is distributed in
// the hope that it will be useful, but without any
// warranty; without even the implied warranty of
// merchantibility or fitness for a particular purpose.
//
//=========================================================
#ifndef TIME_H
#define TIME_H

#include <inttypes.h>

// unix like date and time of day structure 
struct tm {
    uint8_t tm_sec;
    uint8_t tm_min;
    uint8_t tm_hour;
    uint8_t tm_mday;
    uint8_t tm_mon;
    uint8_t tm_year;
    uint8_t tm_wday;
};

//---------------------------------------------------------
// name: clock_init
// title: initialize real time clock
//---------------------------------------------------------
void clock_init(void);

//---------------------------------------------------------
// name: setclock
// title: set clock to a given time
// parameter: time - new current time
//---------------------------------------------------------
void setclock(struct tm* time);

//---------------------------------------------------------
// name: getclock
// title: get current time
// return: pointer to time structure
//---------------------------------------------------------
struct tm* getclock(void);

#endif
