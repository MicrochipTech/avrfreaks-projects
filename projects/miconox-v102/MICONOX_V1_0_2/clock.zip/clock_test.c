//=========================================================
// name: clock_test.c
// title: test program for real time clock
//
// author: Mario Boller-Olfert
//
// description:
//     Test program for real time clock. The time is
//     continuously displayed. You need the library
//     conio.o provided together with avrgcc.
//
// This program is free software; you can redistribute it
// and/or modify it freely. This program is distributed in
// the hope that it will be useful, but without any
// warranty; without even the implied warranty of
// merchantibility or fitness for a particular purpose.
//
//=========================================================

#include <clock.h>
#include <conio.h>
#include <interrupt.h>
int main(void);

//---------------------------------------------------------
// main program
//---------------------------------------------------------
int main() {
    struct tm myTm = { 58, 58, 23, 20, 05, 102, 0 };
    struct tm *tp;
    volatile int j;
    
    // initialize clock
    clock_init();
    sei();
    
    // set clock to start time
    setclock(&myTm);
    
    // display time forever
    while(1) {
        for(j=0;j<20000;++j);
        tp = getclock();
        putchar(tp->tm_mday / 10 + '0');
        putchar(tp->tm_mday % 10 + '0');
        putchar('.');
        putchar(tp->tm_mon / 10 + '0');
        putchar(tp->tm_mon % 10 + '0');
        putchar('.');
        putchar(tp->tm_year / 10 + '0');
        putchar(tp->tm_year % 10 + '0');
        putchar(' ');
        putchar(tp->tm_hour / 10 + '0');
        putchar(tp->tm_hour % 10 + '0');
        putchar(':');
        putchar(tp->tm_min / 10 + '0');
        putchar(tp->tm_min % 10 + '0');
        putchar(':');
        putchar(tp->tm_sec / 10 + '0');
        putchar(tp->tm_sec % 10 + '0');
        putchar('\n');
    }
    return 0;
}
