//rs232 routinerne til oz1ldo bus
//21-04-01
//@Kim Madsen OZ1LDO
// 
#define CMD_PLADS 3
volatile char OZ1LDOBUFFER[20];
volatile char rxpointer = 0,txpointer = 0;
volatile char RxStrengKlar = 0;
volatile char NodeAdresse = 0;
volatile char rxtimeout = 0;
volatile char txtimeout = 0;

void send();

void InitialiserOz1ldoBus()
{
	USR = 0;//reset status register
	UCR = 0xF8;//enable trans og resv samt int
	UBRR = 3;//baudrate = 57600 ved 3.68 mhz
}

interrupt [10] void rxComplete()
{               
volatile char password = 0,taeller = 0;
        rxtimeout = 2;
	if(rxpointer < 20)
		OZ1LDOBUFFER[rxpointer++]= UDR ;
	else
	{ 
		rxpointer = 0;
		rxtimeout = 0;
	}
	if(rxpointer == 20)
	{//alle char er modtaget
	//check password
		password = 0;
		rxpointer = 0;
		for(taeller = 0;taeller < 19;taeller++)
		{
			password += OZ1LDOBUFFER[taeller];
		}//end for 
		if(password == OZ1LDOBUFFER[19])
		{
			if(NodeAdresse == OZ1LDOBUFFER[0])// til denne node
			{
		        	RxStrengKlar = true;//ja g�r noget
		        }else{
			      /*	UDR =  OZ1LDOBUFFER[0]; 		 	
		        	txpointer = 1;
    	     			UCR = 0xF8;*/
    	     			send();
		        }
		}
	}
}

interrupt [11] void DataRegisterEmpty()
{       
	if(txpointer < 20)
		UDR =  OZ1LDOBUFFER[txpointer++]; 

	else
	{
	  UCR &=0xdf;//stop int
	  txpointer = 0;
	}
}

interrupt [12] void TxComplete()
{
	txpointer = 0;
}

void send()
{
	if(!txpointer)
	{
		txpointer=1;
		UDR =  OZ1LDOBUFFER[0];
		UCR = 0xF8; 
		txtimeout = 2;
	}
}

void IndsaetChecksum(char foersteledigeplads)
{
 char taeller = 0;
      OZ1LDOBUFFER[0] = OZ1LDOBUFFER[1];//retur til afsender
      OZ1LDOBUFFER[1] = NodeAdresse;
//      OZ1LDOBUFFER[2] = ??? er sat iforvejen  funktion til via server
        if(foersteledigeplads<19)
        {
         for(taeller = foersteledigeplads;taeller < 19;taeller++)
         {
         	OZ1LDOBUFFER[taeller] = 0;
         }
        }
	OZ1LDOBUFFER[19] = 0;
 	for(taeller=0;taeller < 19;taeller++)
 	{
 		OZ1LDOBUFFER[19] +=OZ1LDOBUFFER[taeller];
 	}
} 

void NytNodeNummer()
{
      struct nytnodenummerRetur* nnr;
      nnr = OZ1LDOBUFFER+CMD_PLADS;
      NodeAdresse = OZ1LDOBUFFER[CMD_PLADS+1];
      nnr->cmd = 1;//cmd
      nnr->Fabnummer = FABRIKATIONSNUMMER;
      nnr->typenummer = TYPEBETEGNELSE;
      nnr->serienummer =  SERIENUMMER;
      IndsaetChecksum(12);
      send();
}

void IndsaetKlokken()
{     
	struct nyttidspunkt* ttid;
        ttid = OZ1LDOBUFFER+CMD_PLADS;
	Ugedag = ttid->dag;
	timer = ttid->timer;
	minutter = ttid->minutter;
	sekunder = ttid->sekunder;
	IndsaetChecksum(4);//reset buffer - cmd og laengde
	send();
}

void SendKlokken()
{
	struct nyttidspunkt* ttid;
        ttid = OZ1LDOBUFFER+CMD_PLADS;
	ttid->dag = Ugedag;
	ttid->timer = timer;
	ttid->minutter = minutter;
	ttid->sekunder = sekunder;
        IndsaetChecksum(8);
        send();
}

void ModtagPrimaerData()
{            
	struct modtagprimaerdata* mpridata; 
#asm
		CLI
#endasm

		mpridata = OZ1LDOBUFFER+CMD_PLADS; 
		if(mpridata->update & 1)
		{
			Valgt_Temp =  mpridata->nyValgtTemp;
		}
		if(mpridata->update & 2)
		{
			ds1620timeoutVaerdi =  mpridata->nyDS1620TimeoutTid;
		}
		if(mpridata->update & 4)
		{
			ValgtReturTemp = mpridata->nyValgtReturTemp;
		} 
		if(mpridata->update & 8)
		{
			RumTimeoutVaerdi = mpridata->nyRumTimeoutVaerdi;
		}	
		if(mpridata->update & 16)
		{
			termo_config = mpridata->nyTermoConfig;
		}	
#asm
		SEI
#endasm         
}    

void SendPrimaerdata()
{      
	struct primaerdata* pridata;
	pridata = OZ1LDOBUFFER+CMD_PLADS;
	pridata->termoConfig = termo_config;
	pridata->converteretTemp = ConverteretTemp;
	pridata->valgtTemp = Valgt_Temp;
	pridata->ds1620timeoutTid = ds1620timeoutVaerdi;
	pridata->DS1620_fremloeb_config = DS1620_fremloeb_config;
	pridata->DS1620_retur_config = DS1620_retur_config;
	pridata->ConvFremloebTemp = ConvFremloebTemp;
	pridata->ConvReturTemp = ConvReturTemp;
	pridata->ValgtReturTemp = ValgtReturTemp; 
	IndsaetChecksum(19);
 	send();
}

void SendSekundaerdata()
{
	struct sekundaerdata* sekdata;
	sekdata = OZ1LDOBUFFER+CMD_PLADS;
	sekdata->RumTimeoutVaerdi = RumTimeoutVaerdi;
	sekdata->RumTimeout = RumTimeout;
	//ind s�t pir f�ler
	//flags = bit 0 = rummode 1; state p� termo hoved pin;
	if(RumTimeout > 0)
		sekdata->flags = 1;
	else 
		sekdata->flags = 0;
	if( VarmenTaendt != 0)
	        sekdata->flags += 2; 
	sekdata->TH = THvaerdi;
	sekdata->TL = TLvaerdi;
	sekdata->TermoFlag = 3; 
	IndsaetChecksum(14);
 	send();
} 

void ModtagEmnerTilTidsListen()
{
	struct tidsliste* liste;
	liste = OZ1LDOBUFFER+CMD_PLADS;
	if(liste->tid1 != 0xffff)
	{
		IndsaetVaerdiPaaPos(liste->tid1,liste->temp1,liste->Startplasering);
		if(liste->tid2 != 0xffff)
		{
			IndsaetVaerdiPaaPos(liste->tid2,liste->temp2,liste->Startplasering+1);
			if(liste->tid3 != 0xffff)
				IndsaetVaerdiPaaPos(liste->tid3,liste->temp3,liste->Startplasering+2);
			
		}
	}
	IndsaetChecksum(4);// send tom pakke retur
 	send();	
}

void SendEmnerFraTidsListen()
{
	struct tidsinput inputtid;
	struct sendfratidslisten* tidliste;
	unsigned char plads;
	plads = tidliste->Startplasering;
	HentvaerdiPaaPos(&inputtid,plads);
	tidliste->tid1 = inputtid.tid;
	tidliste->temp1 = inputtid.temp;
	plads ++;
	HentvaerdiPaaPos(&inputtid,plads);
	tidliste->tid2 = inputtid.tid;
	tidliste->temp2 = inputtid.temp;
	plads ++;
	HentvaerdiPaaPos(&inputtid,plads);
	tidliste->tid3 = inputtid.tid;
	tidliste->temp3 = inputtid.temp;
	IndsaetChecksum(17);
 	send();		
}

void ModtagNyOLiniePaaDisplay()
{
	struct ModtagText* TextBuffer;
	TextBuffer = OZ1LDOBUFFER+CMD_PLADS;

	IndsaetChecksum(4);// send tom pakke retur
 	send();		
}
 
void ModtagNyNLiniePaaDisplay()
{
	struct ModtagText* TextBuffer;
	TextBuffer = OZ1LDOBUFFER+CMD_PLADS;

	IndsaetChecksum(4);// send tom pakke retur
 	send();		
}

void SaetTextDisplayTimeout()
{
}
void OZ1LDOBUSData()
{
 	RxStrengKlar = false;
 	switch(OZ1LDOBUFFER[CMD_PLADS])
 	{
 		case 1:
 			NytNodeNummer();
 			break;
 		case 2:
 			IndsaetKlokken();
 			break;
 		case 3:
			ModtagPrimaerData();
 		      	SendPrimaerdata();
 			break;
 		case 4:
 			SendSekundaerdata();
 			break;
 		case 5:
 			SendKlokken();
 			break; 
 		case 6:
 	 		ModtagNyOLiniePaaDisplay();		
 			break;
 		case 7: 
 			ModtagNyNLiniePaaDisplay();
 			break;
 		case 8:// hent tastatur indput
 			SaetTextDisplayTimeout();
 			break;	
		case 10:
			ModtagEmnerTilTidsListen();
 			break;
 		case 11:
 		        SendEmnerFraTidsListen();
 			break;
 		default:
 			break;
 	}//end switch
}
