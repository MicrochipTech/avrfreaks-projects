// Keyboard communication routines

#ifndef __KB_INCLUDED
#define __KB_INCLUDED

#define ISC00 0
#define ISC01 1

char SerNumCat[28];
char CodeTypeCat[8];
char DataCat[16];
char BarCodeRcvdFlag;

void init_kb(void);
void decode(unsigned char sc);
void put_kbbuff(unsigned char c);
int getchar(void);
#endif

