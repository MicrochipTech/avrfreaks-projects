/*
 *
 * CueCat decoder
 *
 * (c) 2000 Michael Rothwell
 * rothwell@holly-springs.nc.us
 *
 * CueCat decoder section of decode_type provided by Leonid A. Broukhis, leob@mailcom.com
 * Thanks!
 *
 * Released under the GPL
 *
 * Modified for AVR microcontroller by Don Carveth, Sept.2002
 * don@botgoodies.com
 * See "notes.txt" for program description
 *
 * URLs to look stuff up at:
 * http://shop.barnesandnoble.com/booksearch/isbnInquiry.asp?isbn=0345333926
 * http://mbln.lib.ma.us/MARION?key=0395563526&ind=B
 * http://www.amazon.com/exec/obidos/ASIN/031286308X
 * http://www.dlis.dla.mil/upc/scripts/oleisapi2.dll/isapi.isapidb.normal?TARGET=CHOOSE.HTX&UPC=720642470626
 * http://www.debarcode.com/deBarcode/cgi-bin/deBarcode.cgi?type=U.P.C.%20A&barcode=720642470626
 * http://www.fluent-access.com/wtpapers/cuecat/base64.html
 *
 * The basic process works like this:
 * 
 * Generate a bar code consisting of 2 digit values, like 02 47 66 98, even 
 *     number of digits using a Cue Cat bar code generator.
 * Note that numbers 96,97,98,99 do not work.
 * Read the code - decode using this routine.
 * The returning string will look something like:
 *    .VlY8VlY8VlY8VlY8VlY8VlY8.fHmc.C3r6DhTWD3z3D3T2.
 * Strip the leading and trailing "." off of the string
 * Cut the string into it's three parts - serial num, code type, data
 * Arrange the data string in chunks of 4 characters
 * Get the "Value" of each character from the lookup
 *     table.
 * Recombine the lower 6 bits of these values into
 *    sets of 8 bits....
 *    ie: 011101 110111 010101 111011
 *                  becomes
 *        01110111 01110101 01111011
 * XOR the resulting 8 bits with a mask (&H43) and subtract 32
 * The resulting bytes represent the numeric values
 *    of the decoded data 
******************************************************* 
 */

#include <io.h>
#include <stdlib.h>
#include <string-avr.h>
#include <progmem.h>

#include "barcode.h"
#include "StdDefs.h"

// Look up table 
//  - subtract 43 from ASCII value of index (i.e. "J" = ASCII 74, less 43 = 31
//  - subtract 48 from looked up value to get ASCII value
prog_char codetable[] = 
 "n/o//defghijklm///////JKLMNOPQRSTUVWXYZ[\\]^_'abc//////0123456789:;<=>?@ABCDEFGHI";
//+/-//0123456789///////ABCDEFGHIJKLMNOPQR STUVWXYZ//////abcdefghijklmnopqrstuvwxyz
//----------1---------2---------3---------4---------5---------6---------7----

// advance 4 chars at a time through encoded sequence,
// produce base64-decoded output
char *decode_cat(char *buf, int length)
{
	CHARU 	i,j,k,l,x;
	CHARU	b[4];
	CHARU ret[MAX_CODE_LEN];
	CHARU txt[MAX_CODE_LEN];

	if (length > 0)
	{
		memset(ret,0,MAX_CODE_LEN);

		// copy source string into zeros-padded area
		memset(txt,0,MAX_CODE_LEN);
		memcpy(txt,buf,length);
		length=strlen(txt);
		l=4-((length)%4);
		j=0;
		k=0;

		while(1)
		{
			memset(b,0,4);
			x=0;
			for(i=0; i<4; i++)
			{
				x++;
				if (x>length)
				{
					//putchar('&');   //debug
					return NULL;
				};
				// skip invalid chars  -  doesn't work
				//if (((txt[j+i] < 48) | (txt[j+i] > 122)) && 
				//	(txt[j+i] != '+') && (txt[j+i] != '-')) 
				
				//{
				//	i--;
				//	putchar('c');
				//	continue;
				//};
				
				b[i] = PRG_RDB(&codetable[txt[j+i]] - 43) - 48;
				//putBCD(b[i],6,1);   // debug
				
			}
			//Debug
			//putchar('?'); putBCD(b[0],6,1); putBCD(b[1],6,1); 
			//putBCD(b[2],6,1);putBCD(b[3],6,1);
			
			// the "-32" term in these equations gives numbers same as entered
			// as 2 digit values.
			ret[k] =   (((b[0] << 2) | ((b[1]>>4) & 0x03))^67) - 32;
			ret[k+1] = (((b[1] << 4) | ((b[2]>>2) & 0x0F))^67) - 32;
			ret[k+2] = (((b[2] << 6) | (b[3] & 0x3F))^67) - 32;
			
			//Debug
			//putBCD(ret[k], 6, 1);
			//putBCD(ret[k+1], 6, 1);
			//putBCD(ret[k+2], 6, 1);
			//CRLF();
			 
			j+=4;
			k+=3;

			if(j >= length)
			{
				if (l!=4)
				{
					ret[strlen(ret)-l]=0;
				}

				if (txt !=NULL)
				{
					memcpy(txt,NULL,0);
				}
				return ret;
			}
		}
	}
	else
	{
		return NULL;
	}
}		

