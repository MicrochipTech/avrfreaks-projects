// PS/2 keyboard interface - modified for CueCat Scanner on AVR

// The decode function has a lot of code pertaining to keyboards
// that has been left in place - strip out if compact code needed.

// See "notes.txt" for program description

#include <io.h>
#include <stdlib.h>
#include <sig-avr.h>
#include <interrupt.h>
#include <progmem.h>
#include <string-avr.h>

#include "kb.h"
#include "pindefs.h"
#include "scancodes.h"
#include "StdDefs.h"

#define BUFF_SIZE 40

unsigned char edge, bitcount;                // 0 = neg.  1 = pos.

unsigned char kb_buffer[BUFF_SIZE];
unsigned char *inpt, *outpt;
unsigned char buffcnt;


void init_kb(void)
{
    inpt =  kb_buffer;                        // Initialize buffer
    outpt = kb_buffer;
    buffcnt = 0;
    BarCodeRcvdFlag = 0;

    MCUCR = 2;                                // INT0 interrupt on falling edge
    edge = 0;                                // 0 = falling edge  1 = rising edge
    bitcount = 11;
}

SIGNAL(SIG_INTERRUPT0)
{
    static unsigned char data;                // Holds the received scan code

    if (!edge)                                // Routine entered at falling edge
    {
        if(bitcount < 11 && bitcount > 2)    // Bit 3 to 10 is data. Parity bit,
        {                                    // start and stop bits are ignored.
            data = (data >> 1);
            if(PIND & 8)
                data = data | 0x80;            // Store a '1'
        }

        MCUCR = 3;                            // Set interrupt on rising edge
        edge = 1;
        
    } else {                                // Routine entered at rising edge

        MCUCR = 2;                            // Set interrupt on falling edge
        edge = 0;

        if(--bitcount == 0)                    // All bits received
        {
            decode(data);
            bitcount = 11;
        }
    }
    //    test_pin();
}


void decode(unsigned char sc)
{
    static unsigned char is_up=0, shift = 0, mode = 0;
    unsigned char i;

    if (!is_up)                // Last data received was the up-key identifier
    {
        switch (sc)
        {
          case 0xF0 :        // The up-key identifier
            is_up = 1;
            break;

          case 0x12 :        // Left SHIFT
            shift = 1;
            break;

          case 0x59 :        // Right SHIFT
            shift = 1;
            break;

          case 0x05 :        // F1
            if(mode == 0)
                mode = 1;    // Enter scan code mode
            if(mode == 2)
                mode = 3;    // Leave scan code mode
            break;

          default:
            if(mode == 0 || mode == 3)        // If ASCII mode
            {
                if(!shift)                    // If shift not pressed,
                {                            // do a table look-up
                    for(i = 0; PRG_RDB(&unshifted[i][0])!=sc && PRG_RDB(&unshifted[i][0]); i++);
                    if (PRG_RDB(&unshifted[i][0]) == sc) {
                        put_kbbuff(PRG_RDB(&unshifted[i][1]));
                    }
                } else {                    // If shift pressed
                    for(i = 0; PRG_RDB(&shifted[i][0])!=sc && PRG_RDB(&shifted[i][0]); i++);
                    if (PRG_RDB(&shifted[i][0]) == sc) {
                        put_kbbuff(PRG_RDB(&shifted[i][1]));
                    }
                }
            } else{                            // Scan code mode
                puthex(sc);            // Print scan code
                put_kbbuff(' ');
                put_kbbuff(' ');
            }
            break;
            
        }
    } else {
        is_up = 0;                            // Two 0xF0 in a row not allowed
        switch (sc)
        {
          case 0x12 :                        // Left SHIFT
            shift = 0;
            break;
            
          case 0x59 :                        // Right SHIFT
            shift = 0;
            break;

          case 0x05 :                        // F1
            if(mode == 1)
                mode = 2;
            if(mode == 3)
                mode = 0;
            break;
          case 0x06 :                        // F2
            //clr();
            break;
        } 
    }    
} 
// The first version is for a PS/2 keyboard.  The second version
// is for a CueCat bar code scanner.
void put_kbbuff(unsigned char c)
{
/*    if (buffcnt<BUFF_SIZE)                        // If buffer not full
    {
        *inpt = c;                                // Put character into buffer
        inpt++;                                    // Increment pointer

        buffcnt++;

        if (inpt >= kb_buffer + BUFF_SIZE)        // Pointer wrapping
            inpt = kb_buffer;
    }
*/
	//putchar(c); //debug
	static char dotcount = 0;
	
	if(!dotcount) 						// If first character
		{
		if(c == '.')						// If not a "." then ignore
        	dotcount = 1;	
		}
		
	else									// All characters after first
		{
		if(c == '.')
			{
			switch(dotcount)
				{
				case 1:
					*inpt = 0;
					strcpy(SerNumCat,kb_buffer);
					inpt = kb_buffer;
					dotcount = 2;
					break;
				case 2:
					*inpt = 0;
					strcpy(CodeTypeCat,kb_buffer);
					inpt = kb_buffer;
					dotcount = 3;
					break;			
				case 3:                     // Bar Code complete
					*inpt = 0;
					strcpy(DataCat,kb_buffer);
					inpt = kb_buffer;
					dotcount = 0;
					BarCodeRcvdFlag = 1;
					break;
				}									
			}
		else
			{
			*inpt = c;          // Put character into buffer
        	inpt++;             // Increment pointer
			}	
		}
}

