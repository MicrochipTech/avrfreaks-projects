// CueCat barcode scanner interface test program
// PS/2 Interface
// See "notes.txt" for program description

#include <io.h>
#include <stdlib.h>
#include <sig-avr.h>
#include <interrupt.h>
#include <string-avr.h>

#include "kb.h"
#include "barcode.h"
#include "StdDefs.h"
 
void initialize(void);

CHARU stemp[24];
INT32S xtemp;
INT16S itemp;
CHARU len1, len2;


int main(void)
{
    CHARU j;
    initialize();
    putstr("CueCat"); CRLF();

    while(1)
    {
        if(BarCodeRcvdFlag)
        	{
        	putstr(SerNumCat);
        	putstr(CodeTypeCat);
        	putstr(DataCat);
        	
        	len1 = strlen(DataCat);
        	len2 = 3 + (3 * (len1/4));
			memcpy(stemp, decode_cat(DataCat, len1),len2);
			CRLF(); 
			for(j = 0; j < (len2); j++)
				putBCD(stemp[j], 6, 1);  
        	CRLF(); 
        	
        	BarCodeRcvdFlag = 0;
        	}
        msleep(10);
        run_led(3000,3000);
    }
    return 1;
}

void initialize(void)
   {
   cli();
   
   PORTB = 0xFD;
   DDRB = 0x02;     // Port B pin 1 as test pin
   TESTPIN_OFF();

   PORTD = 0x5F;
   DDRD = 0xA0;     // All inputs with pullups.  UART will override.
                    // Pin5 - Out as RunLED, Pin7-out as RF module power

   init_kb();

   UART_CONTROL_REG = 0x18;   //Transmitter enabled, receiver enabled, no ints
   setbaud(BAUD19K);
   
   GIMSK= 0x40;        // Enable INT0 interrupt
   
   sei();
   }
   
