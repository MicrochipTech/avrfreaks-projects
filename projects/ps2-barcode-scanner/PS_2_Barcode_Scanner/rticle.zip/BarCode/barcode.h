/*
 *
 * FooCat Barcode Utilities Library
 *  version 0.1
 *
 *  (c) 2000 Michael Rothwell
 *  rothwell@holly-springs.nc.us
 *
 * Modified for AVR microcontroller by Don Carveth, Sept.2002
 * don@botgoodies.com
 * See "notes.txt" for program description
 *
 */


 
#ifndef __LIBFOOCAT_H__

#define MAX_CODE_LEN   24

extern unsigned char	__base64_codetable_initialized;
char *decode_cat(char *buf, int length);

#endif


