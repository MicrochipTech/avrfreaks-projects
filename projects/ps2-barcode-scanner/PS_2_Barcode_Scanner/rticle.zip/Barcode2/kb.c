#include <io.h>
#include <stdlib.h>
#include <sig-avr.h>
#include <interrupt.h>
#include <progmem.h>

#include "kb.h"
#include "scancodes.h"
#include "StdDefs.h"
//#include "bc2.h"

#define BUFF_SIZE 64

unsigned char edge, bitcount;                // 0 = neg.  1 = pos.

unsigned char kb_buffer[BUFF_SIZE];
unsigned char *inpt, *outpt;
unsigned char buffcnt;

void init_bc(void)
{
    inpt =  kb_buffer;                        // Initialize buffer
    outpt = kb_buffer;
    buffcnt = 0;

    MCUCR = 2;                                // INT0 interrupt on falling edge
    GIMSK= 0x40;        // Enable INT0 interrupt
    
    edge = 0;                                // 0 = falling edge  1 = rising edge
    bitcount = 11;
    
   // TCNT2 is used as a timeout timer to determine that a bar code scan
   // is complete.  Modify as required per timeout method used.
   TCCR2 = 0x00;       // Timer 2 Disabled, Clk divide by 1024
   					   // 7812 counts/second, max time = 32 ms
   OCR2 = 80;          // 80 gives about 10 ms timeout
   TIMSK = 0x80;       // Enable TCNT2 OCR match Interrupt   					   
   
   BarCodeInProgFlag = 0;
   BarCodeDoneFlag = 0;    
}

SIGNAL(SIG_INTERRUPT0)
{
    static unsigned char data;                // Holds the received scan code

    if (!edge)                                // Routine entered at falling edge
    {
        if(bitcount < 11 && bitcount > 2)    // Bit 3 to 10 is data. Parity bit,
        {                                    // start and stop bits are ignored.
            data = (data >> 1);
            if(PIND & 8)
                data = data | 0x80;            // Store a '1'
        }

        MCUCR = 3;                            // Set interrupt on rising edge
        edge = 1;
        
    } else {                                // Routine entered at rising edge

        MCUCR = 2;                            // Set interrupt on falling edge
        edge = 0;

        if(--bitcount == 0)                    // All bits received
        {
            decode(data);
            bitcount = 11;
        }
    }
    //    test_pin();   //debug
}

// Code done timeout timer ISR
SIGNAL(TO_TIMER_ISR)
	{
	BarCodeInProgFlag = 0;	
	BarCodeDoneFlag = 1;
	RESET_TO_TIMER();
	}

void decode(unsigned char sc)
{
    static unsigned char is_up=0, shift = 0, mode = 0;
    unsigned char i;

    if (!is_up)                // Last data received was the up-key identifier
    {
        switch (sc)
        {
          case 0xF0 :        // The up-key identifier
            is_up = 1;
            break;

          case 0x12 :        // Left SHIFT
            shift = 1;
            break;

          case 0x59 :        // Right SHIFT
            shift = 1;
            break;

          case 0x05 :        // F1
            if(mode == 0)
                mode = 1;    // Enter scan code mode
            if(mode == 2)
                mode = 3;    // Leave scan code mode
            break;

          default:
            if(mode == 0 || mode == 3)        // If ASCII mode
            {
                if(!shift)                    // If shift not pressed,
                {                            // do a table look-up
                    for(i = 0; PRG_RDB(&unshifted[i][0])!=sc && PRG_RDB(&unshifted[i][0]); i++);
                    if (PRG_RDB(&unshifted[i][0]) == sc) {
                        put_kbbuff(PRG_RDB(&unshifted[i][1]));
                    }
                } else {                    // If shift pressed
                    for(i = 0; PRG_RDB(&shifted[i][0])!=sc && PRG_RDB(&shifted[i][0]); i++);
                    if (PRG_RDB(&shifted[i][0]) == sc) {
                        put_kbbuff(PRG_RDB(&shifted[i][1]));
                    }
                }
            } else{                            // Scan code mode
                print_hexbyte(sc);            // Print scan code
                put_kbbuff(' ');
                put_kbbuff(' ');
            }
            break;
            
        }
    } else {
        is_up = 0;                            // Two 0xF0 in a row not allowed
        switch (sc)
        {
          case 0x12 :                        // Left SHIFT
            shift = 0;
            break;
            
          case 0x59 :                        // Right SHIFT
            shift = 0;
            break;

          case 0x05 :                        // F1
            if(mode == 1)
                mode = 2;
            if(mode == 3)
                mode = 0;
            break;
          case 0x06 :                        // F2
            //clr();
            break;
        } 
    }    
} 

void put_kbbuff(unsigned char c)
{
	
    if (buffcnt<BUFF_SIZE)                        // If buffer not full
    {
        *inpt = c;                                // Put character into buffer
        inpt++;                                    // Increment pointer

        buffcnt++;

        if (inpt >= kb_buffer + BUFF_SIZE)        // Pointer wrapping
            inpt = kb_buffer;
    }
    
    if(!BarCodeInProgFlag)                          // New code
    	{
	    BarCodeInProgFlag = 1;
	    START_TO_TIMER();
    	}
    else
    	RESTART_TO_TIMER();	
}

CHARU getchar(void)
{
    CHARU byte;
    while(buffcnt == 0) 
    {     // Wait for data
    run_led(30000, 30000);
    }
    byte = *outpt;                                // Get byte
    outpt++;                                    // Increment pointer

    if (outpt >= kb_buffer + BUFF_SIZE)            // Pointer wrapping
        outpt = kb_buffer;
    
    buffcnt--;                                    // Decrement buffer count

    return byte;
}

// Print the contents of the kb buffer and xfr the data to databuff[]
void putbuff(void)
	{
	CHARU j;
    for (j = 0; j < buffcnt; j++)
    	{
	    databuff[j] = *outpt - 0x30;        // Transfer data to databuff
	                                        // Convert from ASCII to number
        putchar(*outpt);
		outpt++;                             // Increment pointer

		if (outpt >= kb_buffer + BUFF_SIZE)  // Pointer wrapping
			outpt = kb_buffer;		        
    	}
    buffcnt = 0;		
	}

