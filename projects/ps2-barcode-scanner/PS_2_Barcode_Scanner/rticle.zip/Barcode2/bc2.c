// PS/2 Bar Code interface test program
// 
// Takes input from PS/2 Bar Code scanner that outputs ASCII
// data from scan - tested with "declawed" CueCat
// 
// Outputs raw scan in ASCII and converts and outputs 8 digit code into an
// x and y numeric value to UART (19200 8N1).

#include <io.h>
#include <stdlib.h>
#include <sig-avr.h>
#include <interrupt.h>
#include <string-avr.h>

#include "kb.h"
#include "StdDefs.h"
//#include "bc2.h"
 
void initialize(void);

INT16S x, y;

int main(void)
{
    
    initialize();
    putchar('I');

    while(1)
    {
        if(BarCodeDoneFlag)
        	{
	        putstr("Raw ASCII - ");
			putbuff();
			CRLF();
			
			x = (databuff[0] * 1000) + (databuff[1] * 100) 
				+ (databuff[2] * 10) + databuff[3];
			y = (databuff[4] * 1000) + (databuff[5] * 100) 
				+ (databuff[6] * 10) + databuff[7];
			putstr("Numeric x, y - ");
			putBCD(x, 6, 1);
			putBCD(y, 6, 1);
			CRLF();
			
	        BarCodeDoneFlag = 0;
	        BarCodeInProgFlag = 0;
	        memset(databuff, 0, SIZE_OF_DATABUFF);
        	}
        run_led(30000, 30000);
    }
    return 1;
}
 
void initialize(void)
   {
   cli();
   
   PORTB = 0xFD;
   DDRB = 0x02;     // Port B pin 1 as test pin
   TESTPIN_OFF();

   PORTD = 0x5F;
   DDRD = 0xA0;     // All inputs with pullups.  UART will override.
                    // Pin5 - Out as RunLED, Pin7-out as RF module power

   
   #if PUTCHAR_MODE == pcINTERRUPT
   	  init_uart_xmt_buff();       
   #endif   		

   UART_CONTROL_REG = 0x18;   //Transmitter enabled, receiver enabled, no ints
   setbaud(BAUD19K);
   
   init_bc();
   
   sei();
   }

