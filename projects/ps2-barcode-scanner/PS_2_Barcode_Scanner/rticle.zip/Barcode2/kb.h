// PS/2 Barcode scanner communication routines

#ifndef __KB_INCLUDED
#define __KB_INCLUDED

#define ISC00 0
#define ISC01 1


void init_bc(void);
void decode(unsigned char sc);
void put_kbbuff(unsigned char c);
unsigned char getchar(void);
void putbuff(void);
char BarCodeInProgFlag;
char BarCodeDoneFlag;

#define RESET_TO_TIMER()     TCNT2 = 0; TCCR2 = 0x00
#define START_TO_TIMER()     TCCR2 = 0x07 
#define RESTART_TO_TIMER()   TCNT2 = 0
#define TO_TIMER_ISR  SIG_OUTPUT_COMPARE2

#define SIZE_OF_DATABUFF  8
unsigned char databuff[SIZE_OF_DATABUFF];


#endif

