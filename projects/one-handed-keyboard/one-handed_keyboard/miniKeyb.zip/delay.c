// delay.c

#include "types.h"

void DELAY_long( void ){
  u08 i, j;
    for (i=0; i<255; i++)
      for(j=0; j<255;j++)
        asm("nop");
}

// 30us = 24
// 40us = 32
// 50us = 40

void DELAY_HalfClock( void ){
    u08 i;

    for (i=0; i<12; i++)
        asm("nop");
}

void DELAY_FullClock( void ){
    u08 i;

    for (i=0; i<24; i++)
        asm("nop");
}

void DELAY_25us( void ){
    u08 i;
    
    for (i=0; i<20; i++)
        asm("nop");
}

