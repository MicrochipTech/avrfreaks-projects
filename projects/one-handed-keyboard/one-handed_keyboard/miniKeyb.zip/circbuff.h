// circbuff.h

extern void CBUFF_Init( void );

char CBUFF_Store( char DataIn );
char CBUFF_Get( void );
