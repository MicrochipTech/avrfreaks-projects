// delay.h

extern void DELAY_long( void );
extern void DELAY_FullClock( void );
extern void DELAY_HalfClock( void );
extern void DELAY_25us( void );

