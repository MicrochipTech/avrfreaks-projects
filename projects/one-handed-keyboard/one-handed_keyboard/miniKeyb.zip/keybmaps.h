// keymaps.h

#ifndef __KEYMAPS_H__
#define __KEYMAPS_H__

#include "types.h"

#define MAPEND   0x0f

/*
 q-t a-g z-b

 bks-01   q-02   w-04   e-08   r-10   t-20
 spc-01   a-02   s-04   d-08   f-10   g-20
 ent-01   z-02   x-04   c-08   v-10   b-20
 num-01 shf-02 fnc-04 ctr-08 flp-10 alt-20

*
*  Alt  Flip  Ctrl                   ae=up              sd,df=space
* FN    Shft    Num          as=left ad=down af=right   qw=/
*
*                            zs=ins  zd=hom  zf=PUp
*                            zx=del  zc=end  zv=Pdn
*
*  bks q  w  e  r  t          tab p  o  i  u  y          bks  +    7& 8* 9( 0)
*  spc a  s  d  f  g          "'  ;: l  k  j  h          spc  -_   4$ 5% 6^ .>
*  ent z  x  c  v  b          \|  /? .> ,< m  n          ent  *    1! 2@ 3# =+
*
*  esc \|  F7  F8  F9  F10    .   .  .  .  .  PrSc
*  ~`  [{  F4  F5  F6  F11    .   .  .  .  .  ScLk
*  *2* ]}  F1  F2  F3  F12    *2* .  .  .  .  paus
*/

prog_char FNMap[] PROGMEM = {
  0x1b, '\\', 0xf7, 0xf8, 0xf9, 0xfa,
   '`',  '[', 0xf4, 0xf5, 0xf6, 0xfb,
  0x00,  ']', 0xf1, 0xf2, 0xf3, 0xfc
};

prog_char NumMap[] PROGMEM = {
  0x08, 0xc7,  '7',  '8',  '9',  '0',
   ' ',  '-',  '4',  '5',  '6',  '.',
  0x0d, 0xc2,  '1',  '2',  '3',  '='
};

prog_char FlipMap[] PROGMEM = {
  0x09,  'p',  'o',  'i',  'u',  'y',
  '\'',  ';',  'l',  'k',  'j',  'h',
  '\\',  '/',  '.',  ',',  'm',  'n'
};

prog_char StdMap[] PROGMEM = {
  0x08,  'q',  'w',  'e',  'r',  't',
   ' ',  'a',  's',  'd',  'f',  'g',
  0x0d,  'z',  'x',  'c',  'v',  'b'
};


prog_char ChordMap[] PROGMEM = {
  0x06, 0x00, 0x00,  '/',
  0x00, 0x0c, 0x00,  ' ',
  0x00, 0x18, 0x00,  ' ',

  0x08, 0x02, 0x00, 0xe6,	// UArrow
  0x00, 0x06, 0x00, 0xe7,	// LArrow
  0x00, 0x0a, 0x00, 0xe8,	// DArrow
  0x00, 0x12, 0x00, 0xe9,	// RArrow

  0x00, 0x04, 0x02, 0xe0,	// ins
  0x00, 0x08, 0x02, 0xe1,	// home
  0x00, 0x10, 0x02, 0xe2,	// PgUp
  0x00, 0x00, 0x06, 0xe3,	// del
  0x00, 0x00, 0x0a, 0xe4,	// end
  0x00, 0x00, 0x12, 0xe5,	// PgDn

  0x1c, 0x00, 0x00, 0xa0,   // macro1 
  MAPEND
};

prog_char FNChordMap[] PROGMEM = {
  0x20, 0x00, 0x01, 0xde,	// PrtScrn
  0x00, 0x20, 0x01, 0xc0,	// ScrLock
  0x00, 0x00, 0x01, 0xdf,	// pause
  MAPEND
};

#endif

