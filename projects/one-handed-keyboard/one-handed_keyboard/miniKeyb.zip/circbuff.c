// circbuff.cpp

char BuffStart[18];
char *BuffDataEnd, *BuffEnd, *BuffDataStart;

void CBUFF_Init( void )
{
   BuffDataStart = BuffStart;
   BuffDataEnd   = BuffStart;
   BuffEnd       = BuffStart + 16;
}


char CBUFF_Store( char DataIn )
{
   if ((BuffDataEnd + 1 == BuffDataStart)
   || ((BuffDataEnd == BuffEnd) && (BuffDataStart==BuffStart)))
     return ':';

   *(BuffDataEnd) = DataIn;

   BuffDataEnd++;
   if (BuffDataEnd > BuffEnd)
     BuffDataEnd = BuffStart;
   return DataIn;
}

char CBUFF_Get( void )
{
char DataOut;

   if (BuffDataStart == BuffDataEnd)
     return '.';

   DataOut = *(BuffDataStart);
   BuffDataStart++;
   if (BuffDataStart > BuffEnd)
     BuffDataStart = BuffStart;

   return DataOut;
}

