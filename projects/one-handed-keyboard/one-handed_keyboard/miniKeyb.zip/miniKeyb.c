// miniKeyb.c

#define __AVRCODE__
#include "types.h"

#include <io.h>
#include "uart.h"
#include "delay.h"
#include "keyb.h"
#include "ps2proto.h"
#include <interrupt.h>
#include <signal.h>

volatile u08  Timer, TimerType, TimerSave, TimerTypeSave;

void TMR0_Init( void );


int main( void )
{
    u08 data;

    UART_Init();
    TMR0_Init();
    KEYB_Init();
    PS2_Init();

    for (;;)
    {
//        data = UART_PeekByte();
//        if (data)
//            PS2_SendScan(data);

        if (KEYB_DebounceKeyboard())    // true if debounced
        {
            KEYB_ProcessControlKeys_Immediate();
            if ((data=KEYB_GetKeyToSend()))
            {
                KEYB_ProcessControlKeys_SaveLock( TRUE );
                PS2_SendScan( data );
                KEYB_ProcessControlKeys_SaveLock( FALSE );
            }
        }
        PS2_Proto();
    }
}


#define TMR0_CK_STOP	0x0
#define TMR0_CK_1	0x1
#define TMR0_CK_8	0x2
#define TMR0_CK_64	0x3
#define TMR0_CK_256     0x4
#define TMR0_CK_1024	0x5
#define TMR0_CK_EXT_FE	0x6
#define TMR0_CK_EXT_RE	0x7

void TMR0_Init( void )
{
  register u08 tmp;

  Timer=0;
  outp(0x00, TCNT0);		// clear counter of timer0
  outp(TMR0_CK_64, TCCR0);	// 64 prescale
  tmp = inp(TIMSK);		// get timer interrupt mask
  outp(tmp|BV(TOIE0), TIMSK);	// timer0 enable
}

// this routine runs every clock/(256*64)=7.3728M/16384=450Hz.
SIGNAL(SIG_OVERFLOW0)
{
  if (Timer)
    Timer--;
}

