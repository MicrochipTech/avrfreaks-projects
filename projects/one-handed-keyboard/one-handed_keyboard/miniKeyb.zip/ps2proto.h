// ps2proto.h

#ifndef __PS2PROTO_H__
#define __PS2PROTO_H__

#include "types.h"

#define KPORT PORTA
#define KPIN  PINA
#define KDDR  DDRA

// The code assumes that the KDATAIN, and KCLOCKIN bits
// are 1 bit higher than their respective KDATAOUT, and KCLOCKOUT bits

// The KDATAOUT pin is wired to the KDATAIN pin.
// The KCLOCKOUT pin is also wired to the KCLOCKIN pin.

#define KDATAOUT   0x01
#define KDATAIN    0x02
#define KCLOCKOUT  0x04
#define KCLOCKIN   0x08

#define KbitDATAOUT   0
#define KbitDATAIN    1
#define KbitCLOCKOUT  2
#define KbitCLOCKIN   3

extern void PS2_Init( void );
extern u08 PS2_SendByte( u08 abyte, u08 badParity );
extern u08 PS2_ReceiveByte( void );
extern void PS2_Proto( void );

extern u08 PS2_SendScan( u08 out );

#endif
