// test.cpp

#include "types.h"
#include <stdio.h>
#include "circbuff.h"
#include "lookup.h"

char buf[80];
int linecount = 0;
int timerdelta;

int Timer;

extern void InitBuff( void );

u08 KeysToSend, FrontReleasing,
    LastCountFrontKeys,
    CountALT, CountCTR, CountSHF, CountNUM,
    ThumbSent, ThumbLock, ThumbLast,
    TimerType;

void Init( void );
u08 getData( void );
u08 keybScan( void );
void NACS( void );
void NACSbit(u08 *count, u08 bitmask, u08 key);
void NACSbitSend(u08 tosend, u08 key);
void NACSbitP(u08 *count, u08 bitmask, u08 key, u08 isPre);
void NACS_P( u08 isPre );


int main(void)
{
   u08 out, datatype;

   Init();
   while ((datatype=getData()))
   {
       if (datatype==1)
       {
           NACS();
           if ((out=keybScan()))
           {
               NACS_P( TRUE );
               out&=0x000000ff; ////
               SendScan( out );
               printf("out=%c %2.2hx",out,out);
               NACS_P( FALSE );
           }
           printf("\n");
       }
   }
   return 0;
}


void Init( void )
{
   InitBuff( );
   KeysToSend = FALSE;
   FrontReleasing = FALSE;
   Timer = 0;
   TimerType = ttNONE;
   LastCountFrontKeys = 0;
   CountALT = 0;
   CountCTR = 0;
   CountSHF = 0;
   CountNUM = 0;
   ThumbSent = 0;
   ThumbLock = 0;
   ThumbLast = 0;
   RowSave[THUMBrow] = 0;
}


void NACS( void )
{
    u08 i,j,count;

    count=0;
    for (i=0;i<MAX_ROW;i++)
        for (j=1;j<=MAX_COL;j<<=1)
            if (RowNew[i]&j)
                count++;

    if (count==0)
    {
        Timer = INTERVAL_INITIAL;
        TimerType = ttINITIAL;
    }

    if (LastCountFrontKeys > count)
        FrontReleasing = TRUE;
    else
        FrontReleasing = FALSE;

#ifdef debug_NACS
      printf("  rs.%2.2hx tk.%2.2hx ts.%2.2hx   ",
          RowSave[THUMBrow],ThumbLock,ThumbSent);
#endif

    NACSbit(&CountALT,ALTbit,0xd5);
    NACSbit(&CountCTR,CTRbit,0xd3);
    NACSbit(&CountSHF,SHFbit,0xd1);
    NACSbit(&CountNUM,NUMbit,0);

    LastCountFrontKeys = count;
    ThumbLast = RowNew[THUMBrow];
}


void NACSbit(u08 *count, u08 bitmask, u08 key)
{
    u08 tosend;

    if (*count&1) // count is 1 or 3
    {
        if (bitmask&~RowNew[THUMBrow])
          if (bitmask&ThumbLast)
              *count = (*count)+1;
    }
    else
    {
      if (bitmask&RowNew[THUMBrow])
          if (bitmask&~ThumbLast)
              *count = (*count)+1;
    }

    if (*count>0)
        RowSave[THUMBrow] |= RowNew[THUMBrow]&bitmask;
    else
        RowSave[THUMBrow] &= ~(bitmask&~RowNew[THUMBrow]);

    if (*count>3)
    {
        *count = 0;
        ThumbLock ^= bitmask;
        RowSave[THUMBrow] &= ~bitmask;
        return;
    }

    if (!key)    // num: don't need to send anything
        return;

    tosend = (bitmask&RowNew[THUMBrow])^(bitmask&ThumbLock);
    if (tosend==(ThumbSent&bitmask))
        return;

    NACSbitSend(tosend, key);

    if (tosend)
        ThumbSent |= bitmask;
    else
        ThumbSent &= ~bitmask;
}

void NACSbitSend(u08 tosend, u08 key)
{
    if (tosend)
        SendScan( key );
    else
        SendScan( key+1 );
}


void NACSbitP(u08 *count, u08 bitmask, u08 key, u08 isPre)
{
    u08 tosend = 0;

//    tosend = (*count>0)^(bitmask&ThumbLock);
    tosend = (bitmask&RowSave[3])^(bitmask&ThumbLock);
    if (tosend==(ThumbSent&bitmask))
        return;

    if (isPre)
        NACSbitSend(tosend, key);
    else
        NACSbitSend(!tosend, key);
}


void NACS_P( u08 isPre )
{
    NACSbitP(&CountALT,ALTbit,0xd5, isPre);
    NACSbitP(&CountCTR,CTRbit,0xd3, isPre);
    NACSbitP(&CountSHF,SHFbit,0xd1, isPre);

  if (!isPre)
  {
     CountALT = 0;
     CountCTR = 0;
     CountSHF = 0;
     CountNUM = 0;
     RowSave[THUMBrow] = RowNew[THUMBrow];
  }
}


u08 keybScan( void )
{
    u08 out;

    out = 0;
    RowSave[THUMBrow] |= RowNew[THUMBrow]&(FLPbit|FNCbit);
    
    if (FrontReleasing)
    {
        if (KeysToSend)
        {
            out = doLookup();
        }
        RowSave[Qrow] = RowNew[Qrow];
        RowSave[Arow] = RowNew[Arow];
        RowSave[Zrow] = RowNew[Zrow];

        Timer = 0;
        TimerType = ttNONE;

        KeysToSend = FALSE;
    }
    else
    {
       if (( RowSave[THUMBrow] != RowNew[THUMBrow] )
       || (RowSave[Qrow] != RowNew[Qrow])
       || (RowSave[Arow] != RowNew[Arow])
       || (RowSave[Zrow] != RowNew[Zrow]))
       {
           RowSave[Qrow] |= RowNew[Qrow];
           RowSave[Arow] |= RowNew[Arow];
           RowSave[Zrow] |= RowNew[Zrow];
           if (!KeysToSend)
           {
               KeysToSend = TRUE;

               Timer = INTERVAL_INITIAL;
               TimerType = ttINITIAL;
           }
       }
       else
           if (!Timer)
           {
               if (TimerType==ttINITIAL)
                   Timer = INTERVAL_PREREPEAT;
               else
                 Timer = INTERVAL_REPEAT;

               TimerType = ttPREREPEAT;

               out = doLookup();
               KeysToSend = FALSE;
           }
   }

   RowSave[THUMBrow] &= ~(FLPbit|FNCbit);       // don't remember FLP / FNC
   RowSave[THUMBrow] |= RowNew[THUMBrow]&(FLPbit|FNCbit);

   return out;
}


u08 getData( void )
{
   if (gets(buf) != NULL)
   {
       if (buf[0]=='#')
       {
           printf("=====  %s  =====\n",buf);
           linecount = 0;
           return 2;
       }
       else
       {
           sscanf(buf," %i %i %i %i %i",
               &timerdelta, &RowNew[Qrow], &RowNew[Arow], &RowNew[Zrow], &RowNew[THUMBrow]);

           Timer -= timerdelta;
           if (Timer<0)
               Timer = 0;

           printf("%2.2i:  %2.2i %i %2.2i %2.2i %2.2i %2.2i\t",
               ++linecount, Timer, TimerType, RowNew[Qrow], RowNew[Arow], RowNew[Zrow], RowNew[THUMBrow] );
           return 1;
       }
   }
   else
        return 0;
}

//.{...{...{...{
//      if (buf[0]>='0' && buf[0]<='9'){
//
//         printf("st-%c\n\r", StoreInBuff( buf[0] ) );
//      }
//      else
//      if (buf[0]=='x')
//         printf("gb-%c\n\r", GetBuff() );
//      else
//         printf("??-%c\n\r", buf[0] );

