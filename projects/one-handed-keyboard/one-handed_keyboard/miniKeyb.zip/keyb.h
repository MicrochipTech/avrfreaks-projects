// keyb.h

#ifndef __KEYB_H__
#define __KEYB_H__

#include "types.h"
#include "uart.h"

#define TRUE     1
#define FALSE    0


#define PORTCOLS PORTC
#define DDRCOLS  DDRC

#define PORTROWS PORTA
#define PINROWS  PINA
#define DDRROWS  DDRA


#define BITrowQ  4
#define BITrowA  5
#define BITrowZ  6

#define MAX_ROW  3
#define MAX_COL  0x20


#define ALTbit   0x20
#define FLPbit   0x10
#define CTRbit   0x08
#define FNCbit   0x04
#define SHFbit   0x02
#define NUMbit   0x01

#define Qrow     0
#define Arow     1
#define Zrow     2
#define THUMBrow 3


#define INTERVAL_INITIAL   0x40
#define INTERVAL_PREREPEAT 0x30
#define INTERVAL_REPEAT    0x10

#define ttNONE             0
#define ttINITIAL          1
#define ttPREREPEAT        2
#define ttREPEAT           3

extern u08 ThumbLock;
extern u08 RowNew[4], RowSave[4];

extern void KEYB_Init( void );
extern u08 KEYB_DebounceKeyboard( void );
extern u08 KEYB_GetKeyToSend( void );

extern void KEYB_ProcessControlKeys_Immediate( void );
extern void KEYB_ProcessControlKeys_SaveLock( u08 isBefore );

#endif
