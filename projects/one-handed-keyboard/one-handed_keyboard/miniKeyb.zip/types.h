// typesAVR.h

#ifndef __TYPES_H__
#define __TYPES_H__
#define __AVRCODE__

#define TRUE 1
#define FALSE 0

#include <progmem.h>

typedef unsigned char  u08;
typedef          char  s08;
typedef unsigned short u16;
typedef          short s16;

#endif
