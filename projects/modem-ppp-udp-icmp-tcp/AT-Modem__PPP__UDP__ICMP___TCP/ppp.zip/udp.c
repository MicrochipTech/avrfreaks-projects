
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

//#ifdef CPU_eZ8
//	#pragma stkck									// enable stack checking
//#endif

#include <string.h>
#include <stdio.h>

#include "common.h"
#include "ppp.h"
#include "ip.h"
#include "udp.h"

#ifdef IncludeNTP
#include "ntp.h"
#endif

#ifdef Debug
flash char	udp_str1[]	=	"    UDPHdr: SrcPrt:";
flash char	udp_str2[]	=	" DestPrt:";
flash char	udp_str3[]	=	" Len:";
flash char	udp_str4[]	=	" Chksum:";
flash char	udp_str5[]	=	" DataBytes:";
flash char	udp_str6[]	=	" - BLOCKED\n";
flash char	udp_str7[]	=	"*** UDP chksum err\n";
#endif

#ifdef CPU_eZ8
near u16			UDP_len;
#endif
#ifdef CPU_ATmega128
u16					UDP_len;
#endif

T_UDP_Header		*UDP_Header = NULL;

//*********************************************************************************************************************

#ifdef Debug

void UDP_DisplayHeader(int HeaderIdx, int TotalBytes)
{
/*
	 0                   1                   2                   3
	 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|          Source Port          |       Destination Port        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|           Length              |         Checksum              |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
	// display the header

	if (!SendDebugRStr(udp_str1)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(UDP_Header->SourcePort));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(udp_str2)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(UDP_Header->DestPort));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(udp_str3)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(UDP_Header->Length));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(udp_str4)) return;
	sprintf((char*)ScratchPad, "%04x", ntohs(UDP_Header->Checksum));
	if (!SendDebugStr((char*)ScratchPad)) return;

	// done

	if (!SendDebugRStr(udp_str5)) return;
	sprintf((char*)ScratchPad, "%u\n", TotalBytes - (HeaderIdx + sizeof(T_UDP_Header)));
	if (!SendDebugStr((char*)ScratchPad)) return;
}

#endif

//*********************************************************************************************************************

bool UDP_StartPacket(u32 IP, u16 SourcePort, u16 DestPort)
{
	if (!IP) return false;																// no IP supplied
	if (MainBufferWr_Rx > 0) return false;												//
	if (MainBufferWr_Tx) return false;													//
																						//
	IP_StartPacket(IP_PROTO_UDP, IP);													// start the IP packet off
																						//
	UDP_len = MainBufferWr_Tx;															//
																						//
	UDP_Header = (T_UDP_Header*)(MainBuffer + MainBufferWr_Tx);							// point to the UDP header
	memset(UDP_Header, 0, sizeof(T_UDP_Header));										//
	UDP_Header->SourcePort = htons(SourcePort);											//
	UDP_Header->DestPort = htons(DestPort);												//
	MainBufferWr_Tx += sizeof(T_UDP_Header);											// update index
																						//
	return true;																		//
}

bool UDP_EndPacket(void)
{
	u16	w, w2;																			//
																						//
	w2 = MainBufferWr_Tx;																//
																						//
	UDP_len = MainBufferWr_Tx - UDP_len;												//
																						//
	IP_Header->TotalLength += UDP_len;													// update the IP header
																						//
	UDP_Header->Length = htons(UDP_len);												//
																						//
	w = IP_Checksum2((char*)UDP_Header, UDP_len);										// update the UDP header checksum
	if (!w) w = 0xffff;																	//
	UDP_Header->Checksum = htons(w);													//
																						//
	IP_EndPacket();																		//
																						//
	if (!PPP_SendPacket(false)) return false;											// send it
																						//
	#ifdef Debug																		//
		IP_DisplayProtocol(true, (int)w2);												//
		IP_DisplayHeader(4, (int)w2);													//
		UDP_DisplayHeader(4 + sizeof(T_IP_Header), (int)w2);							//
	#endif																				//
																						//
	return true;																		//
}

//*********************************************************************************************************************
// this is called when we have received a UDP packet

void UDP_In(void)
{
	u16 len, w;

	len = MainBufferWr_Rx - MainBufferRd_Rx;									// length of data left

	// *******************
	// UDP header

	UDP_Header = (T_UDP_Header*)(MainBuffer + MainBufferRd_Rx);						// point to the UDP header
																					//
	if ((!UDP_Header->Checksum) || (IP_Checksum2((char*)UDP_Header, len)))			//
	{																				// invalid checksum
		#ifdef Debug
			SendDebugRStr(udp_str7);												//
		#endif
		return;																		//
	}
																					//
	w = ntohs(UDP_Header->Length);													//
	if (w < sizeof(T_UDP_Header)) return;											// hmmmmm
	if (w > len) return;															// hmmmmm
																					//
	#ifdef Debug
		UDP_DisplayHeader((int)MainBufferRd_Rx, (int)MainBufferWr_Rx);			//
	#endif

	MainBufferRd_Rx += sizeof(T_UDP_Header);									// update index
	len = MainBufferWr_Rx - MainBufferRd_Rx;									// length of data left
																				//
	// *******************

	if (IP_FireWalled())
	{
		#ifdef Debug
			SendDebugRStr(udp_str6);
		#endif
		return;																	// firewalled
	}

	// *******************
	// data

	#ifdef IncludeNTP
	if (ntohs(UDP_Header->DestPort) == 123)
	{	// most likely an NTP reply then
		if (len >= sizeof(T_NTP)) NTP_DecodeSNTP(IP_Header->SourceIP.ip32, (T_NTP*)(MainBuffer + MainBufferRd_Rx));
		return;
	}
	#endif

	// *******************
}
// **************************************************************************
// this is called every 10ms from the IP module

void UDP_10ms_Timer(void)
{
	#ifdef IncludeNTP
	NTP_10ms_Timer();						//
	#endif
}


