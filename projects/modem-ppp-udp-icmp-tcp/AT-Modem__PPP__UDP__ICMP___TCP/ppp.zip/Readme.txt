
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

 ======================

 Right, enough of the crap ....

 It's a complete PPP/UDP/ICMP/TCP application for the Zilog Z8 Encore and the
 Atmel ATmega128 cpu's (requires the ICCAVR compiler for ATmega mode).

 ======================

 To use this code, you need to attach a second RS232 level shifter (max3232) to the
 2nd uart - due to the companies that make the dev boards can't be arsed to fit em :(

 The onboard uart port (uart-0) is the console/debug port (115200 baud), the 2nd uart
 (uart-1) is the one you connect to your ppp server, AT modem or gprs AT modem phone
 (19200 baud) or whatever.

 You also need a 7.3728MHz xtal for the ATmega128, or a 18.432MHz xtal for the z8 encore, though
 you can use a different freq xtal, just alter the MainClk define in common.h and make sure you
 update the TimerIntSpeed define to suit (10ms Timer interrupts).

 You'll find the hardware RTC/CTS pins that I used listed in the common.h file - though you
 can disable hardware handshaking if you wish.  Their's two defines in the common.h file -
 ConsoleHandShaking and ModemHandShaking.
 It's just that these little cpu's have very little internal RAM, so buffer overflows can
 occur, but the ppp side of things is all crc error checked, so if a buffer overflow does
 occur, it won't be long before the packet is sent to you again, though it's not the best idea
 to let data go adrift.

 It's been tested with windows 2K pro with a ppp server (direct connect cable), a
 Hayes AT modem onto the net (via an ISP), a nokia 6210 (with DLR3 cable) onto the net (via an ISP),
 and a nokia 6310 gprs phone (with the DLR3-P cable) on the orange and vodaphone networks, all
 appears fine - any bugs you find you'll have to fix yourself!

 To use with the different PPP connection types (AT Modem, Windows PPP etc), you need to compile
 it for the desired method - the actual PPP stuff doesn't change, it's purely how it first gets to the
 point at which it then starts the PPP.
 You'll find the compile option in the common.h near the top (WindowsPPP, ATModemPPP, GPRS_Orange
 and GPRS_VodaPhone).   Just use the define you want, but ONLY have ONE of these defines at any one time.
 This could of cause be done in software with the settings stored in eeprom, but the Zilog z8 has no
 eeprom built-in.

 NB,. Vodaphone don't seem to allow you to send outgoing ping requests via gprs, Orange
 don't seem to have this problem - just incase you you try with a gprs isp and you find you
 can't ping anyone from it.

 If you get it going from the console, just type 'help' or '?' to get a list of commands
 you can throw at it - it can ping, get ntp (unfinished), and make an outgoing tcp connect or receive
 an incoming tcp connection - on port 32932.

 It has no DNS client (for now), so stick with proper ip addies.

 Sorry for the lack of doc files, but it's a free release, and I'm not one for writing
 help/doc files anyhow, it's just a snap shot taken of some code I was writting at the time.

 ======================

 Version: 0.28
 Last updated: 5th Feb 2004

 C.Moss
