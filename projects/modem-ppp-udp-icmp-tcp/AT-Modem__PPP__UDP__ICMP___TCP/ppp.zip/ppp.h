
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef pppH
#define pppH

#include "common.h"

//***************************************************************************

#define OurRxMRU				MainBufferSize-6			// max packet size we can accept

#define PPP_Timeout				3000						// 3 second retry time - 3 seconds is the PPP standard default for speeds of 9600 and lower
#define PPP_Retries				10							// maximum number of retries - 10 is the PPP standar default
#define PPP_LCP_Echo_RetryTime	120000						// time between LCP echo tests - 120 seconds
#define PPP_DataTimeout			2000						// 2 second rx data timeout

#define	PPP_Flag				0x7E						// Start and end flag for every PPP packet
#define PPP_EscapeFlag			0x7D						// This is used if the PPPflag appears in the PPP data (byte stuffing)
#define PPP_Stuff				0x20						// bits we toggle in the byte

// PPP LCP (Link Control Packet) codes
#define	PPP_CREQ			1 								// Configure Requset
#define	PPP_CACK			2								// Configure Ack
#define	PPP_CNAK			3								// Configure Nak - rejected but can request again with different value
#define	PPP_CREJ			4								// Configure Reject - rejected, must not ask again
#define	PPP_TREQ			5								// Termination Request (LCP - close connection)
#define	PPP_TACK			6								// Terminate Ack
#define	PPP_CodeREJ			7								// Code-Reject
#define PPP_PREJ			8								// Protocol-Reject
#define PPP_EREQ			9								// Echo-Request
#define PPP_ERPY			10								// Echo-Reply
//#define PPP_DREQ			11								// Discard-Request
//#define PPP_ID				12								// Identification

// PPP LCP option types
#define LCP_MRU				1								// Maximum-Receive-Unit
#define LCP_ACCM			2								// Async-Control-Character-Map
#define LCP_AP				3								// Authentication-Protocol
#define LCP_QP				4								// Quality-Protocol
#define LCP_MN				5								// Magic-Number
#define LCP_PFC				7								// Protocol-Field-Compression
#define LCP_ACFC			8								// Address-and-Control-Field-Compression
//#define LCP_FCS_Alt			9								// FCS-Alternatives
//#define LCP_SD_PAD			10								// Self-Describing-Pad
//#define LCP_NM				11								// Numbered-Mode
//#define LCP_MLP				12								// Multi-Link-Procedure
//#define LCP_CB				13								// Callback
//#define LCP_CT				14								// Connect-Time
//#define LCP_CF				15								// Compound-Frames
//#define LCP_NDE				16								// Nominal-Data-Encapsulation
//#define LCP_MRRU			17								// Multilink-MRRU                              [RFC1717]
//#define LCP_MSSNH			18								// Multilink-Short-Sequence-Number-Header      [RFC1717]
//#define LCP_MED				19								// Multilink-Endpoint-Discriminator            [RFC1717]
//#define LCP_DCEI			21								// DCE-Identifier                            [SCHNEIDER]
//#define LCP_MLPP			22								// Multi-Link-Plus-Procedure                     [Smith]
//#define LCP_LT_BACP			23								// Link Discriminator for BACP                [Richards]

// PPP Protocols
#define	PPP_IP				0x0021							// Internet Protocol packet
#define	PPP_IPCP			0x8021							// Internet Protocol Control Protocol packet
#define	PPP_LCP				0xC021							// Link Configure Protocol packet
#define	PPP_PAP				0xC023							// username / Password Authenication Protocol packet
//#define PPP_LQR				0xC025							// Link Quality Report
//#define PPP_CBCP			0xC029							// CallBack Control Protocol
//#define PPP_CHAP			0xC223							// Cryptographic Handshake Authentication Protocol

//***************************************************************************

typedef enum TPPPStage {PPPS_None, PPPS_Start, PPPS_LCP, PPPS_LogOn, PPPS_IP_Addr, PPPS_IP, PPPS_Disc} T_PPPStage;

//***************************************************************************

typedef struct TPPPHeader1		// without ACFC and without PCF
{
	u8	AddressField;
	u8	ControlField;
	u16	Protocol;
} T_PPP_Header1;

typedef struct TPPPHeader2		// with ACFC and without PCF
{
	u16	Protocol;
} T_PPP_Header2;

typedef struct TPPPHeader3		// without ACFC and with PCF
{
	u8	AddressField;
	u8	ControlField;
	u8	Protocol;
} T_PPP_Header3;

typedef struct TPPPHeader4		// with ACFC and with PCF
{
	u8	Protocol;
} T_PPP_Header4;

typedef struct TPPP
{
	volatile u32	LCP_Echo_Timer;
	volatile u16	LastRxData;
	volatile u16	SendTick;
	u8				Retries;

	T_PPPStage		Stage;

	bool			AcceptedTheirLCPOptions;
	bool			AcceptedOurLCPOptions;
	bool			AcceptedIPOptions;

	T_IP_Addr		OUR_IP;
	T_IP_Addr		THEIR_IP;
	T_IP_Addr		DNS1_IP;
	T_IP_Addr		DNS2_IP;

	u8				OurID;
	u8				TheirID;

	u16				TxMRU;		// values to use when sending packets
	u32				TxMN;
	u32				TxACCM;

	u16				RxMRU;		// values to use when receiving packets
	u32				RxMN;
	u32				RxACCM;

	u16				AuthProtocol;

	u16				RxFCS;
	bool			RxStuff;

	u8				NAK_REJ_Count;

	char			Username[32];
	char			Password[32];

	u32				TxBytes;	// total amount of bytes sent
	u32				RxBytes;	// total amount of bytes received
} T_PPP;

typedef struct TCodeHeader
{
	u8		Code;
	u8		ID;
	u16		Len;				// MS-Byte 1st
} T_CodeHeader;

// ***********************************************************************************************

extern flash char		OurIP[4];
extern flash char		Dns1IP[4];
extern flash char		Dns2IP[4];
extern flash char		PPP_Rom_Username[];
extern flash char		PPP_Rom_Password[];
extern flash char		PPP_ModeStr[];
extern flash char		DialInit1[];
extern flash char		DialInit2[];
extern flash char		DialInit3[];
extern flash char		DialStr[];

extern T_PPP		PPP;	// PPP link details

//***************************************************************************

#ifdef Debug
extern bool PPP_DisplayStage(void);
#endif

extern bool PPP_DisplayIP(void);
extern bool PPP_SendPacket(bool MustByteStuff);
extern void PPP_StartPacket(u16 Protocol);
extern bool PPP_SendTermRequest(void);
extern bool PPP_SendConfigRequest(void);

extern void PPP_10ms_Timer(void);
extern void PPP_Process(void);

extern void PPP_Reset(char *Username, char *Password);
#ifdef CPU_eZ8
extern void PPP_Start(char rom *Username, char rom *Password);
#endif
#ifdef CPU_ATmega128
extern void PPP_Start(const char *Username, const char *Password);
#endif
extern void PPP_End(void);

// ***********************************************************************************************

#endif


