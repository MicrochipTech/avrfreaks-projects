// This program tests the ppp routine and shows how to use it

/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

 //#ifdef CPU_eZ8
//	#pragma stkck									// enable stack checking
//#endif

#include "common.h"

#ifdef CPU_eZ8
	#include <eZ8.h>
#endif

#ifdef CPU_ATmega128
	#include <iom128v.h>
	#include <macros.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
//#include <spi.h>

#include "main.h"
#include "common.h"
#include "fcs.h"
#include "at.h"
#include "ppp.h"
#include "ip.h"

#ifdef IncludeTCP
#include "tcp.h"
#endif

// *********************************************************************************

void SendDetails(void)
{
	u16	w;

	if (!SendConsoleRStr(Str3)) return;

	if (!SendConsoleRStr(VersionStr)) return;
	sprintf((char*)ScratchPad, "%u.%02x\n", Version >> 8, Version & 0xff);
	if (!SendConsoleStr((char*)ScratchPad)) return;

	if (!SendConsoleRStr(Title)) return;
	if (!SendConsoleRStr(Date)) return;

   // ************

	#ifdef CPU_ATmega128
	if (!SendConsoleStr("\nUnit ID: ")) return;
	if (Get_UnitID((char*)ScratchPad))
	{
		if (!SendConsoleStr(ScratchPad)) return;
		if (!SendConsoleStr("\n")) return;
	}
	else
	{
		if (!SendConsoleStr("Invalid\n")) return;
	}
	#endif

   // ************

	sprintf((char*)ScratchPad, "\nLast reset reason: %02X", LastResetReason);

	#ifdef CPU_eZ8
	if (LastResetReason & 0x80) strcat((char*)ScratchPad, " POR");
	if (LastResetReason & 0x40) strcat((char*)ScratchPad, " STOP");
	if (LastResetReason & 0x20) strcat((char*)ScratchPad, " WD");
	if (LastResetReason & 0x10) strcat((char*)ScratchPad, " EXT");
	#endif

	#ifdef CPU_ATmega128
	if (LastResetReason & 0x10) strcat((char*)ScratchPad, " JTAG");
	if (LastResetReason & 0x08) strcat((char*)ScratchPad, " WD");
	if (LastResetReason & 0x04) strcat((char*)ScratchPad, " BRN-OUT");
	if (LastResetReason & 0x02) strcat((char*)ScratchPad, " EXT");
	if (LastResetReason & 0x01) strcat((char*)ScratchPad, " POR");
	#endif

	strcat((char*)ScratchPad, "\n");
	if (!SendConsoleStr((char*)ScratchPad)) return;

   // ************
	// test the sram

	#ifdef CPU_ATmega128

	if (!SendConsoleStr("\nSRAM: ")) return;

	w = SRAM_Test();
	if (w == 0xffff)
	{
		if (!SendConsoleStr("OK\n")) return;
	}
	else
	{
		sprintf(ScratchPad, "%04X\n", w);
		if (!SendConsoleStr(ScratchPad)) return;
	}

	#endif

   // ************

	#ifdef Debug
		if (!SendConsoleRStr(PPP_ModeStr)) return;
	#endif
}

// *********************************************************************************
// Test button Interrupt routine

#ifdef CPU_eZ8

#pragma interrupt
void isr_C0(void)
{

}

#endif

// *********************************************************************************
// 10ms timer interrupt routine

#ifdef CPU_ATmega128
#pragma interrupt_handler timer1_compa_isr:13
void timer1_compa_isr(void)
{	// alternative more accurate timer counter option
	// compare occured TCNT1=OCR1A
}
#endif

#ifdef CPU_eZ8
#pragma interrupt
void isr_timer0(void)
#endif
#ifdef CPU_ATmega128
#pragma interrupt_handler isr_timer1_ovf:15
void isr_timer1_ovf(void)
#endif
{	// 10ms timer interrupt
	register u16	i, w;								//

	// *************************

	#ifdef CPU_ATmega128
//	w = TCNT1L;											// read the current counter low byte
//	w |= ((u16)TCNT1H) << 8;							// read the current counter low byte
	w = TCNT1;											// read the current count - depends how long it took to get here as to what we reload it with
	w += TimerIntSpeed + 3;								// update
	TCNT1 = w;											// reload counter
//	TCNT1H = (u8)(w >> 8);								// reload counter high byte
//	TCNT1L = (u8)w;										// reload counter low byte
	#endif

	// *************************

	TimerIntCounter++;									// update counter

	Random32 = UpdateFCS_32(Random32, TimerIntCounter);	// update the 32-bit random number

	// *************************
	// read the ADC if it's complete - then start the next conversion
	// this way of doing it is not exactly the fastest way (1 conversion per 20ms), but it's easy
	// and more than fast enough for monitoring battery voltage etc

	#ifdef CPU_ATmega128
	if (!(ADCSRA & (1<<ADSC)))				// conversion complete ?
	{										// yes
		if (Flags1 & (1<<Flags1_ADC))		//
		{									//
			sbi(ADCSRA, ADSC);				// Start the next conversion
			Flags1 &= ~(1<<Flags1_ADC);		// clear flag
		}									//
		else								//
		{									//
			w = (u16)ADCL;					// read LS-Byte
			w |= ((u16)ADCH) << 8;			// read MS-Byte
											//
			i = (u16)(ADMUX & 0x07);		// current ADC channel
											//
			w += ADC_Input[i];				//
			w >>= 1;						// average with previous value - helps with noise
			ADC_Input[i] = w;				// save the new value
											//
			i++;							// next ADC channel
			if (i > 1) i = 0;				// only interested in channels 0 and 1
//			if (i > 7) i = 0;				// only interested in channels 0 to 7
			ADMUX = (u8)i;					// select it
											//
			Flags1 |= (1<<Flags1_ADC);		// set flag - this tells the next timer int to start the new conversion.
											// we leave starting the next conversion to the next timer int so as to
											// allow the ADC input to settle to the newly selected input pin
		}
	}
	#endif

	// *************************

	AT_10ms_Timer();
	PPP_10ms_Timer();

	// *************************
	// Test button debounce

	if (!TestButton) button_push = 0;											// button is pressed - reset the debounce detector
	else
	{
		if (button_push < 255) button_push++;									// update the debounce counter
		if (button_push == button_debounce) Flags1 |= (1<<Flags1_ButtonPress);	// button has just been released
	}

	//**********************************
	// do stuff with the led's

	switch (AT.Stage)
	{
		case AT_Idle	:	if (TimerIntCounter & 0x20)
								RLed_On;
							else
								RLed_Off;
							break;
		case AT_PPP		:	if (TimerIntCounter & 0x50)
								RLed_On;
							else
								RLed_Off;
							break;
		default			:	if (TimerIntCounter & 0x10)
								RLed_On;
							else
								RLed_Off;
							break;
	}

	switch (PPP.Stage)
	{
		case PPPS_None	:	YLed_Off;
							break;
		case PPPS_IP	:	if (TimerIntCounter & 0x50)
								YLed_On;
							else
								YLed_Off;
							break;
		default			:	if (TimerIntCounter & 0x04)
								YLed_On;
							else
								YLed_Off;
							break;
	}

	// CTS0 state
//	if (CTS0)									//
//		GLed_Off;								//
//	else										//
//		GLed_On;								//

	// CTS1 state
//	if (CTS1)									//
//		GLed_Off;								//
//	else										//
//		GLed_On;								//

	// TCP socket state
	#ifdef IncludeTCP
	if (TCP_Socket != NULL)											//
	{																//
		switch (TCP_Socket->Stage)									//
		{															//
			case TCP_CLOSED			:	GLed_Off;					//
										break;						//
			case TCP_LISTEN			:	if (TimerIntCounter & 0x20)	//
											GLed_On;				//
										else						//
											GLed_Off;				//
										break;						//
			case TCP_ESTABLISHED	:	if (TimerIntCounter & 0x50)	//
											GLed_On;				//
										else						//
											GLed_Off;				//
										break;						//
			default					:	if (TimerIntCounter & 0x10)	//
											GLed_On;				//
										else						//
											GLed_Off;				//
										break;						//
		}															//
	}																//
	else															//
		GLed_Off;													//
	#else
		GLed_Off;													//
	#endif

	// *************************
	// keep the watchdog at bay.
	// the WatchdogCounter variable is set in the executive - this makes resetting the WD a co-op affair between the exec and this interrupt.
	// keep this code as the last thing to be done in the interrupt - incase a loop/dead-lock occurs before we get this far

	if (WatchdogCounter == 1)					//
	{											//
		Reset_WD();								// Keep the watchdog at bay
		WatchdogCounter = 0;					//
	}
}

// *********************************************************************************
// Uart-0 Rx Interrupt routine

#ifdef CPU_eZ8
	#pragma interrupt
#endif
#ifdef CPU_ATmega128
	#pragma interrupt_handler isr_uart0_rx:19
#endif
void isr_uart0_rx(void)
{
	#ifdef CPU_eZ8
	UART0_RxBuffer[UART0_RxBufferWr++] = U0D;								// save new byte into the buffer
    #endif
	#ifdef CPU_ATmega128
	UART0_RxBuffer[UART0_RxBufferWr++] = UDR0;								// save new byte into the buffer
    #endif
	if (UART0_RxBufferWr >= sizeof(UART0_RxBuffer)) UART0_RxBufferWr = 0;	// wap awound

	#ifdef ConsoleHandShaking
	HardwareFlowControl(UART0);												// tell em to hold it - if need be
	#endif
}

// *********************************************************************************
// Uart-1 Rx Interrupt routine

#ifdef CPU_eZ8
	#pragma interrupt
#endif
#ifdef CPU_ATmega128
	#pragma interrupt_handler isr_uart1_rx:31
#endif
void isr_uart1_rx(void)
{
	#ifdef CPU_eZ8
	UART1_RxBuffer[UART1_RxBufferWr++] = U1D;								// save new byte into the buffer
    #endif
	#ifdef CPU_ATmega128
	UART1_RxBuffer[UART1_RxBufferWr++] = UDR1;								// save new byte into the buffer
    #endif
	if (UART1_RxBufferWr >= sizeof(UART1_RxBuffer)) UART1_RxBufferWr = 0;	// wap awound

	#ifdef ModemHandShaking
	HardwareFlowControl(UART1);												// tell em to hold it - if need be
	#endif
}

// *********************************************************************************
/*
#ifdef CPU_ATmega128
void StackOverflowTest(u32 dw)
{
	USB_Get();								// get data from USB
	USB_Send();								// send any data that needs sending via the USB
	USB_ProcessGet();						// process the rx'ed packet from the USB

	_StackCheck();							// check for stack overflow

	if (!WatchdogCounter) WatchdogCounter++;		//

   dw++;
	StackOverflowTest(dw);
}
#endif
*/
// *********************************************************************************
// Main program here

void main(void)
{
	int		i, j;

	Disable_Ints();

	// ****************************
	// find out what caused the last reset

	#ifdef CPU_eZ8
	LastResetReason = WDTCTL;
	#endif
	#ifdef CPU_ATmega128
	LastResetReason = MCUCSR;
	MCUCSR &= 0xE0;					// clear the bits
	#endif

	// **********************
	// Define external memory mapping

	#ifdef CPU_ATmega128
	asm(	".area memory(abs)\n"
			".org 0x1100\n"
			" _SRAM:: .blkb 1\n"
			".text\n");
	#endif

	// ****************************
	// set the watchdog timeout ASAP - you'll find the timeout value in common.h
	// see page 158 of the Z8F6423 product spec's pdf
	// the file config\Z8F6423.ini for the option bit settings - changing these makes no difference :(

	#ifdef CPU_eZ8
	WDTCTL = 0x55;									// unlock the watchdog - so we can set it's time out
	WDTCTL = 0xAA;									//   "    "    "
	WDTU = (u8)((WatchdogTimeout >> 16) & 0xff);	// Set the timeout
	WDTH = (u8)((WatchdogTimeout >> 8) & 0xff);		//  "   "     "
	WDTL = (u8)(WatchdogTimeout & 0xff);			//  "   "     "
    #endif

	Reset_WD();

	#ifdef CPU_ATmega128
	WDTCR |= (1 << WDCE) | (1 << WDE);										// Enable watchdog config change
	WDTCR = (1 << WDE) | (1 << WDP2) | (1 << WDP1) | (1 << WDP0);		// Enable watchdog to 2 second time out
	#endif

	// ****************************
	// disable all interrupts as default - or should i trust that the reset condition is reliable ?

	#ifdef CPU_eZ8
	IRQ0ENH = 0;							// disable each individual interrupt
	IRQ0ENL = 0;							//
											//
	IRQ1ENH = 0;							//
	IRQ1ENL = 0;							//
											//
	IRQ2ENH = 0;							//
	IRQ2ENL = 0;							//
	#endif

	// ****************************
	// set all ports to input state as default

	#ifdef CPU_eZ8
	PADD = 0xff;	// as inputs
	PAADDR = 0;		// clear to protect sub registers
					//
	PBDD = 0xff;	// as inputs
	PBADDR = 0;		// clear to protect sub registers
					//
	PCDD = 0xff;	// as inputs
	PCADDR = 0;		// clear to protect sub registers
					//
	PDDD = 0xff;	// as inputs
	PDADDR = 0;		// clear to protect sub registers
					//
	PEDD = 0xff;	// as inputs
	PEADDR = 0;		// clear to protect sub registers
					//
	PFDD = 0xff;	// as inputs
	PFADDR = 0;		// clear to protect sub registers
					//
	PGDD = 0xff;	// as inputs
	PGADDR = 0;		// clear to protect sub registers
					//
	PHDD = 0xff;	// as inputs
	PHADDR = 0;		// clear to protect sub registers
	#endif

	#ifdef CPU_ATmega128
    PORTA = 0xff;	// enable pull-ups
    DDRA = 0x00;	// as inputs

    PORTB = 0xff;	// enable pull-ups
    DDRB = 0x00;	// as inputs

    PORTC = 0xff;	// enable pull-ups
    DDRC = 0x00;	// as inputs

    PORTD = 0xff;	// enable pull-ups
    DDRD = 0x00;	// as inputs

    PORTE = 0xff;	// enable pull-ups
    DDRE = 0x00;	// as inputs

    PORTF = 0xfc;	// enable pull-ups
    DDRF = 0x00;	// as inputs

    PORTG = 0xff;	// enable pull-ups
    DDRG = 0x00;	// as inputs
	#endif

	// ****************************
	// delay a bit - stops irratic boot-ups when programming etc

	for (i = 0; i < 25; i++)
	{
		for (j = 0; j < 32767; j++)
		{
			Reset_WD();
		}
	}

	// ****************************

	#ifdef CPU_eZ8
	RLed_ddPort &= ~(1 << RLed_Pin);		// set as output
	RLed_hdePort &= ~(1 << RLed_Pin);		// disable high drive
	RLed_addrPort = 0;						// clear to protect sub registers
	RLed_Off;								//

	YLed_ddPort &= ~(1 << YLed_Pin);		// set as output
	YLed_hdePort &= ~(1 << YLed_Pin);		// disable high drive
	YLed_addrPort = 0;						// clear to protect sub registers
	YLed_Off;								//

	GLed_ddPort &= ~(1 << GLed_Pin);		// set as output
	GLed_hdePort &= ~(1 << GLed_Pin);		// disable high drive
	GLed_addrPort = 0;						// clear to protect sub registers
	GLed_Off;								//

	RTS0_ddPort &= ~(1 << RTS0_Pin);		// set as output
	RTS0_hdePort &= ~(1 << RTS0_Pin);		// disable high drive
	RTS0_addrPort = 0;						// clear to protect sub registers
	RTS0_OK;								//

	RTS1_ddPort &= ~(1 << RTS1_Pin);		// set as output
	RTS1_hdePort &= ~(1 << RTS1_Pin);		// disable high drive
	RTS1_addrPort = 0;						// clear to protect sub registers
	RTS1_OK;								//
    #endif

	#ifdef CPU_ATmega128
	sbi(RLed_ddPort,  RLed_Pin);			// set as output
	RLed_Off;								//

	sbi(YLed_ddPort, YLed_Pin);				// set as output
	YLed_Off;								//

	sbi(GLed_ddPort, GLed_Pin);				// set as output
	GLed_Off;								//

	sbi(SS_ddPort, SS_Pin);					// set as output
	sbi(SS_oPort, SS_Pin);					// set high

	sbi(SCLK_ddPort, SCLK_Pin);				// set as output
	sbi(SCLK_oPort, SCLK_Pin);				// set high

	sbi(MOSI_ddPort, MOSI_Pin);				// set as output
	sbi(MOSI_oPort, MOSI_Pin);				// set high

	sbi(TXD0_ddPort, TXD0_Pin);				// set as output
	sbi(TXD0_oPort, TXD0_Pin);				// set high

	sbi(RTS0_ddPort, RTS0_Pin);				// set as output
	RTS0_OK;								//

	sbi(TXD1_ddPort, TXD1_Pin);				// set as output
	sbi(TXD1_oPort, TXD1_Pin);				// set high

	sbi(RTS1_ddPort, RTS1_Pin);				// set as output
	RTS1_OK;								//

	sbi(SRAM_CS_ddPort, SRAM_CS_Pin);		// set as output
	SRAM_Disable;							//
	#endif

	// ****************************

	#ifdef CPU_ATmega128
	XDIV = 0;											// xtal divider - run at xtal clock freq
	   													//
	EICRA = 0;											// no extended ext ints
	EICRB = 0;											// no extended ext ints
	EIMSK = 0;											// no external ints (INT0-INT7)
	EIFR = 0;											//
   														//
	MCUCR = (1<<SRE);									// enable external memory
	XMCRA = (1<<SRL2)|(1<<SRL0);						// lower sector = 0x1100 - 0x9fff .. no wait states
//   XMCRA = (1<<SRL2)|(1<<SRL0)|(1<<SW00);				// lower sector = 0x1100 - 0x9fff .. 1 wait state
//   XMCRA = (1<<SRL2)|(1<<SRL0)|(1<<SW01);				// lower sector = 0x1100 - 0x9fff .. 2 wait states
//   XMCRA = (1<<SRL2)|(1<<SRL0)|(1<<SW01)|(1<<SW00);	// lower sector = 0x1100 - 0x9fff .. 2 wait states during read/write, wait one cycle before driving out new address
	XMCRB = (1<<XMM0);									// leave pin PC7 free for user use
														//
	ASSR = 0;											//
														//
	TIMSK = 0;											// timer interrupt sources
	ETIMSK = 0;											// extended timer interrupt sources
	#endif

	// ****************************
	// setup a 10ms timer interrupt

	#ifdef CPU_eZ8
	// Initialize Timer-0
	SET_VECTOR(TIMER0, isr_timer0); 		// Set timer interrupt vector
 	T0H		= (u8)(TimerIntSpeed >> 8);		// Timer High
	T0L 	= (u8)(TimerIntSpeed & 0xff);	// Timer Low
	T0RH 	= (u8)(TimerIntSpeed >> 8);		// Reload Compare High
	T0RL 	= (u8)(TimerIntSpeed & 0xff);	// Reload Compare Low
	T0CTL 	= (1<<TEN)|(1<<TPOL)|(1<<PRES2)|(1<<PRES1)|(1<<PRES0)|(1<<TMODE0);			// Enabled, clk/128, Continous mode
	IRQ0ENH |= (1<<T0EN);					// Set Interrupt Priority Nominal
	IRQ0ENL &= ~(1<<T0EN);					//  "
    #endif

	#ifdef CPU_ATmega128
	// Initialize Timer-1
	TCCR1B = 0;								// stop
   											//
	TCNT1 = TimerIntSpeed;					// reload counter high value
//	TCNT1H = (u8)(TimerIntSpeed >> 8);		// reload counter high value
//	TCNT1L = (u8)(TimerIntSpeed & 0xff);	//   "
   											//
	OCR1A = 9216;							//
	OCR1B = 9216;							//
	OCR1C = 9216;							//
	ICR1 = 9216;							//
   											//
	TCCR1A = 0;								//
	TCCR1B = (1<<CS11);						// start Timer, MainClk/8
											//
	sbi(TIMSK, TOIE1);						// Enable timer overflow interupt
	#endif

	// ****************************
	// Initialize Uart-0 (Console/Debug terminal)

	InitUart(UART0, UART0_BaudRate);		// Setup uart

	#ifdef CPU_eZ8
	SET_VECTOR(UART0_RX, isr_uart0_rx);		// setup an RX interrupt
											//
	IRQ0ENH |= (1<<U0REN);					// Set Interrupt Priority normal
	IRQ0ENL &= ~(1<<U0REN);					//  "
    #endif

	// ****************************
	// Initialize Uart-1 (PPP)

	InitUart(UART1, UART1_BaudRate);		// Setup uart

	#ifdef CPU_eZ8
	SET_VECTOR(UART1_RX, isr_uart1_rx);		// setup an RX interrupt
											//
	IRQ2ENH |= (1<<U1REN);					// Set Interrupt Priority high
	IRQ2ENL |= (1<<U1REN);					//  "
    #endif

	// ****************************
	// Initialize the SPI - though we don't use it yet

	SPI_Init();

	// ****************************
	// setup the ADC

	#ifdef CPU_eZ8
	#endif

	#ifdef CPU_ATmega128
	SFIOR = 0;												//
															//
	ADCSRA = 0;												// disable adc
															//
	cbi(PORTF, 0);											// disable pull-up on ADC-0 input
	cbi(PORTF, 1);											// disable pull-up on ADC-1 input
//	cbi(PORTF, 2);											// disable pull-up on ADC-2 input
//	cbi(PORTF, 3);											// disable pull-up on ADC-3 input
//	cbi(PORTF, 4);											// disable pull-up on ADC-4 input
//	cbi(PORTF, 5);											// disable pull-up on ADC-5 input
//	cbi(PORTF, 6);											// disable pull-up on ADC-6 input
//	cbi(PORTF, 7);											// disable pull-up on ADC-7 input
															//
	ADMUX = 0;												// reference = AREF pin, Right adjusted, select adc input 0,
	ACSR = (1<<ACD);										// disable the Analogue comparator
	ADCSRA = (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);	// enable the ADC, Prescaler = 128 (Conversion time = 224uS)
	sbi(ADCSRA, ADSC);										// start a conversion
															//
	#endif

	memset((void*)ADC_Input, 0, sizeof(ADC_Input));			// clear our ADC values - the timer interrupt saves the ADC values into this buffer

	// ****************************
	// Initialize Test Button interrupt on port-C - we don't use it though as we just poll the pin in the timer interrupt

	#ifdef CPU_eZ8
//	SET_VECTOR(C0, isr_C0);							// set interrupt vector
//	IRQ2ENH |= (1<<C0EN);							// Set Interrupt Priority High
//	IRQ2ENL |= (1<<C0EN);							//  "
    #endif

    // ****************************

	WatchdogCounter = 0;							//

	CommandBuffer[0] = 0;							//

	MainBufferWr_Rx = -1;							//
	MainBufferWr_Tx = 0;							//

	AT_Stage(AT_Idle);								//
													//
	PPP.Stage = PPPS_None;							//
													//
	#ifdef IncludeTCP
		#ifdef StaticTCPSocket
			TCP_Socket = (T_TCP_Socket*)&TCP_Static_Socket;	//
			TCP_SocketStage(TCP_Socket, TCP_CLOSED);		//
		#else
			TCP_Socket = NULL;								//
		#endif
	#endif

	// ****************************
	// test to see if the button is pressed when booting up

	if (!TestButton)
	{	// the button is pressed
		RLed_On;										//
		Flags1 |= (1<<Flags1_Button);					// set flag
														//
		// wait for the button to be released - short debounce detector
		for (i = 32767; i; i--)							//
		{												//
			Reset_WD();									//
			if (!TestButton) i = 32767;					// button is still pressed
		}												//
														//
		RLed_Off;										//

		#ifdef CPU_ATmega128
		Set_UnitID("test 123456");						// reset our ID
		#endif
	}

	// ****************************
	// main loop

	#ifdef Debug
	Flags1 |= (1<<Flags1_Debug);					// enable debug as default - for now
	#endif

	Enable_Ints();									// enable global interrupts

	#ifdef Debug
		SendDetails();								//
		SendHelp();									//
	#endif

	PPP_Reset(0, 0);								//

	#ifdef CPU_ATmega128
	_StackCheck();									// check for stack overflow
	#endif

//	_StackOverflowed(0);							// test our stack overflow routine
//	StackOverflowTest(0);							// ditto

	// **************
	// main executive loop

	for (;;)
	{
		// *************
		// tell timer interrupt to keep the watchdog at bay

		if (!WatchdogCounter) WatchdogCounter++;								//

		// *************
		// do stuff when the push button is pressed

		if (Flags1 & (1<<Flags1_ButtonPress))									//
		{																		// Button has been pressed
			Flags1 &= ~(1<<Flags1_ButtonPress);									// clear the flag
																				//
			#ifdef Debug
				SendDebugRStr(Str4);											//
			#endif
																				//
			if (AT.Stage == AT_Idle)											//
				AT_Start();														// start a ppp link
			else																//
				AT_End();														// terminate the ppp link
		}																		//

		// *************
		// do stuff to keep things rolling - AT Modem, PPP, TCP etc

		ProcessMainLoop();														//

		// *************
		// deal with rx'ing and tx'ing data from/to the tcp socket

		#ifdef IncludeTCP
		if (TCP_Socket == NULL) continue;										// no tcp socket to process
		if (TCP_Socket->Stage != TCP_ESTABLISHED) continue;						// the tcp socket is not connected
																				//
		i = TCP_RxBytes(TCP_Socket);											// number of bytes the tcp socket has for us
		j = TCP_TxFree(TCP_Socket);												// number of bytes free in the tcp socket tx buffer
		if ((i <= 0) || (j <= 0)) continue;										// no data in rx buffer or no space left in tx buffer
																				//
		if (i > sizeof(ScratchPad)) i = sizeof(ScratchPad);						// limit to the temp buffer size
																				//
		if (!TCP_Socket->OutGoing)												//
		{																		// echo back - as we are in server mode
			if (i > j) i = j;													// limit the amount of data we move from tcp rx buffer back into the tcp tx buffer
			i = TCP_RxData(TCP_Socket, ScratchPad, i);							// move data from tcp rx buffer into temp buffer
			TCP_TxData(TCP_Socket, ScratchPad, i);								// move data from temp buffer into the tcp tx buffer
		}																		//
		else																	//
		{																		// don't echo back - as we are in client mode
			i = TCP_RxData(TCP_Socket, ScratchPad, i);							// move data from tcp rx buffer into temp buffer
																				//
		}																		//
		#ifdef Debug
		SendDebugAsciiDump(ScratchPad, i);										// display the buffer contents on the console
		#endif
		#endif

		// *************
	}

	// **************
}
