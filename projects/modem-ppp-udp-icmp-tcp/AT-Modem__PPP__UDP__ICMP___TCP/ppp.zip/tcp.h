
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef tcpH
#define tcpH

#include "common.h"

#define TCP_Port				32932	// port to use for incoming connections and outgoing connections - change this to whatever you like really

#define	TCP_DataTimeOut			240000	// 240 seconds .. if no data is transfered after this time, the tcp link is automatically closed
											// set it to '0' to not use this feature

#define TCP_Default_MSS			536		// default maximum segment size
#define	TCP_Retries				5		//
#define TCP_Retry_Time			4		// current RoundTripTime * this value
#define TCP_RoundTripTime		1000	// default round trip time
#define TCP_OutGoingPortLow		1024	// local port range used when making an outgoing tcp connection
#define TCP_OutGoingPortHigh	4096	//   "
#define TCP_AckDelay			200		// data ack delay - ms

typedef struct TTCPHeader
{
	// TCP header
/*
	 0                   1                   2                   3
	 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|          Source Port          |       Destination Port        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                        Sequence Number                        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                    Acknowledgment Number                      |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|  Data |           |U|A|P|R|S|F|                               |
	| Offset| Reserved  |R|C|S|S|Y|I|            Window             |
	|       |           |G|K|H|T|N|N|                               |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|           Checksum            |         Urgent Pointer        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                    Options                    |    Padding    | < optional
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|     data      ..........
	+-+-+-+-+-+-+-+-+
*/

	u16	SourcePort;
	u16	DestPort;
	u32	SequenceNum;
	u32	AckNum;
	u8  DataOffset;
	u8	ControlBits;
	u16	WindowSize;
	u16	Checksum;
	u16	UrgentPointer;
} T_TCP_Header;

#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
#define TCP_URG 0x20

typedef enum TTCPStage
{
	TCP_CLOSED,			// represents no connection state at all.
	TCP_LISTEN,			// waiting for a connection request from any remote TCP and port.
	TCP_SYN_SENT,		// waiting for a matching connection request after having sent a connection request.
	TCP_SYN_RECEIVED,	// waiting for a confirming connection request acknowledgment after having both received and sent a connection request.
	TCP_ESTABLISHED,	// an open connection, data received can be delivered to the user.  The normal state for the data transfer phase of the connection.
	TCP_FIN_WAIT_1,		// waiting for a connection termination request from the remote TCP, or an acknowledgment of the connection termination request previously sent.
	TCP_FIN_WAIT_2,		// waiting for a connection termination request from the remote TCP.
	TCP_CLOSE_WAIT,		// waiting for a connection termination request from the local user.
	TCP_CLOSING,		// waiting for a connection termination request acknowledgment from the remote TCP.
	TCP_LAST_ACK,		// waiting for an acknowledgment of the connection termination request previously sent to the remote TCP (which includes an acknowledgment of its connection termination request).
	TCP_TIME_WAIT		// represents waiting for enough time to pass to be sure the remote TCP received the acknowledgment of its connection termination request.
} T_TCP_Stage;

typedef struct TTCPSocket
{
	T_TCP_Stage		Stage;				// current socket state
										//
	volatile u32	ConnectTime;		// time since connection was initiated - ms
	volatile u32	LastRxData;			// time since last data was received - ms
										//
	volatile u16	AckDelay;			// used for delayed ack sending back - nagles algorithum
	bool			SendAck;			//
										//
	bool			OutGoing;			// true if we initiated the connection
										//
	u8				Flags;				//
										//
	u16				TheirMaxSegSize;	//
										//
	u32				TheirSequenceNum;	//
	u16				TheirWindowSize;	//
										//
	u32				OurSequenceNum;		//
	s16				OurLastBytesSent;	//
										//
	T_IP_Addr		RemoteIP;			// remote IP
	u16				RemotePort;			// remote port
	u16				LocalPort;			// local port
										//
	u16				RoundTripTime;		// average time for one of our packets to be ack'ed
	u8				Retries;			// send retries
	volatile u16	Retry_Timer;		// ms
										//
	u8				TxBuffer[512];		// holding buffer for data that needs sending - ring buffer
	s16				TxBufferRd;			//
	s16				TxBufferWr;			//
										//
	u8				RxBuffer[512];		// holding buffer for data rx'ed from tuver end - ring buffer
	s16				RxBufferRd;			//
	s16				RxBufferWr;			//
										//
	u16				len;				//
} T_TCP_Socket;

typedef struct TTCPSocketExt
{	// this ones for use with external sram - the buffers are somewhat larger ... but you can't use this yet
	T_TCP_Stage		Stage;				// current socket state
										//
	volatile u32	ConnectTime;		// time since connection was initiated - ms
	volatile u32	LastRxData;			// time since last data was received - ms
										//
	volatile u16	AckDelay;			// used for delayed ack sending back - nagles algorithum
	bool			SendAck;			//
										//
	bool			OutGoing;			// true if we initiated the connection
										//
	u8				Flags;				//
										//
	u16				TheirMaxSegSize;	//
										//
	u32				TheirSequenceNum;	//
	u16				TheirWindowSize;	//
										//
	u32				OurSequenceNum;		//
	s16				OurLastBytesSent;	//
										//
	T_IP_Addr		RemoteIP;			// remote IP
	u16				RemotePort;			// remote port
	u16				LocalPort;			// local port
										//
	u16				RoundTripTime;		// average time for one of our packets to be ack'ed
	u8				Retries;			// send retries
	volatile u16	Retry_Timer;		// ms
										//
	u8				TxBuffer[1500];		// holding buffer for data that needs sending - ring buffer
	s16				TxBufferRd;			//
	s16				TxBufferWr;			//
										//
	u8				RxBuffer[1500];		// holding buffer for data rx'ed from tuver end - ring buffer
	s16				RxBufferRd;			//
	s16				RxBufferWr;			//
										//
	u16				len;				//
} T_TCP_Socket_Ext;

#ifdef StaticTCPSocket
extern T_TCP_Socket	TCP_Static_Socket;	// the statically allocated tcp socket (only the one for now)
#endif
extern T_TCP_Socket	*TCP_Socket;		// we only have one - for now

#ifdef Debug
extern void TCP_DisplayHeader(int HeaderIdx, int TotalBytes);
extern void TCP_DisplaySocketState(T_TCP_Socket *Socket);
#endif

extern void TCP_SocketStage(T_TCP_Socket *Socket, T_TCP_Stage Stage);

extern int TCP_RxBytes(T_TCP_Socket *Socket);
extern int TCP_RxData(T_TCP_Socket *Socket, u8 *Dest, int len);

extern int TCP_TxFree(T_TCP_Socket *Socket);
extern int TCP_TxData(T_TCP_Socket *Socket, u8 *Src, int len);

extern bool TCP_CloseSocket(T_TCP_Socket *Socket);
extern T_TCP_Socket *TCP_SocketListen(u16 Port);
extern T_TCP_Socket *TCP_OpenSocket(u32 IP, u16 Port);

extern bool TCP_StartPacket(T_TCP_Socket *Socket);
extern bool TCP_EndPacket(T_TCP_Socket *Socket);
extern bool TCP_SendPacket(T_TCP_Socket *Socket, u8 ControlBits);

extern void TCP_In(void);
extern void TCP_10ms_Timer(void);
extern void TCP_Process(void);

#endif

