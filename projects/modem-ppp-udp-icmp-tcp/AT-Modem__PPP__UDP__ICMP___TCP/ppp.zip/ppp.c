
// this unit assumes the cpu is big endian (MS-Byte 1st) - for now
//
// we don't bother with Address/Control field compression - saving 2 bytes isn't worth the extra code
// we don't bother with Protocol field compression - saving 1 byte definately isn't worth the extra code

/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

//#ifdef CPU_eZ8
//	#pragma stkck									// enable stack checking
//#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "common.h"
#include "at.h"
#include "fcs.h"
#include "ppp.h"
#include "ip.h"

#ifdef IncludeTCP
#include "tcp.h"
#endif

#ifdef WindowsPPP
flash char	PPP_Rom_Username[]		=	"avr";
flash char	PPP_Rom_Password[]		=	"1234";
flash char	PPP_ModeStr[]			=	"\nPPP Mode: Windows\n";
flash char	DialInit1[]				=	"";
flash char	DialInit2[]				=	"";
flash char	DialStr[]				=	"";
flash char	PPP_WindowsStr[]		=	"CLIENTCLIENT";
flash char	OurIP[4]				=	{192, 168, 254, 9};		// fixed ip - change this to '0, 0, 0, 0' if you want the ppp server to assign you an ip - that goes for ALL the ip's listed here
flash char	Dns1IP[4]				=	{0, 0, 0, 0};			// dynamic ip
flash char	Dns2IP[4]				=	{0, 0, 0, 0};			// dynamic ip
#endif

#ifdef ATModemPPP
flash char	PPP_Rom_Username[]		=	"";
flash char	PPP_Rom_Password[]		=	"";
flash char	PPP_ModeStr[]			=	"\nPPP Mode: AT Modem\n";
flash char	DialInit1[]				=	"ATZ\n";
flash char	DialInit2[]				=	"ATV1\n";
flash char	DialInit3[]				=	"ATE0\n";
flash char	DialStr[]				=	"ATD179\n";
flash char	OurIP[4]				=	{0, 0, 0, 0};			// dynamic ip
flash char	Dns1IP[4]				=	{0, 0, 0, 0};			// dynamic ip
flash char	Dns2IP[4]				=	{0, 0, 0, 0};			// dynamic ip
#endif

#ifdef GPRS_Orange
flash char	PPP_Rom_Username[]		=	"";
flash char	PPP_Rom_Password[]		=	"";
flash char	PPP_ModeStr[]			=	"\nPPP Mode: GPRS Orange\n";
flash char	DialInit1[]				=	"ATV1\n";
flash char	DialInit2[]				=	"ATE0\n";
flash char	DialInit3[]				=	"AT+CGDCONT=1,\"IP\",\"orangeinternet\"\n";		// oranges Access Point Name
//flash char	DialStr[]				=	"ATD*99#\n";
flash char	DialStr[]				=	"ATD*99***1#\n";
flash char	OurIP[4]				=	{0, 0, 0, 0};			// dynamic ip
flash char	Dns1IP[4]				=	{193, 35, 131, 194};	// fixed ip
flash char	Dns2IP[4]				=	{193, 35, 131, 195};	// fixed ip
#endif

#ifdef GPRS_VodaPhone
flash char	PPP_Rom_Username[]		=	"web";
flash char	PPP_Rom_Password[]		=	"web";
flash char	PPP_ModeStr[]			=	"\nPPP Mode: GPRS VodaPhone\n";
flash char	DialInit1[]				=	"ATV1\n";
flash char	DialInit2[]				=	"ATE0\n";
flash char	DialInit3[]				=	"AT+CGDCONT=1,\"IP\",\"pp.vodafone.co.uk\"\n";	// vodaphones Access Point Name
//flash char	DialStr[]				=	"ATD*99#\n";
flash char	DialStr[]				=	"ATD*99***1#\n";
flash char	OurIP[4]				=	{0, 0, 0, 0};			// dynamic ip
flash char	Dns1IP[4]				=	{0, 0, 0, 0};			// dynamic ip
flash char	Dns2IP[4]				=	{0, 0, 0, 0};			// dynamic ip
#endif

#ifdef Debug
flash char	ppp_str1[]				=	"    accepted:";
flash char	ppp_str2[]				=	"    n-rejected:";
flash char	ppp_str3[]				=	"    rejected:";

flash char	LoopBackStr[]			=	"loop-back mode - disconnecting\n";
flash char	Str2[]					=	"TX: PPP IP REPLY\n";
flash char	UnknownProtocolStr[]	=	"    rejected unknown prot\n";
flash char	PPPStageStr1[]			=	"\n*** PPP Stage: ";
flash char	PPPStageStr2[]			=	"None\n";
flash char	PPPStageStr3[]			=	"Starting\n";
flash char	PPPStageStr4[]			=	"LCP Options\n";
flash char	PPPStageStr5[]			=	"Auth'ing\n";
flash char	PPPStageStr6[]			=	"Sorting IP's\n";
flash char	PPPStageStr7[]			=	"IP\n";
flash char	PPPStageStr8[]			=	"Disconnecting\n";
flash char	PPPStageStr9[]			=	"Unknown\n";
flash char	CodeStr[]				=	"    Code:";
flash char	CREQStr[]				=	"CREQ";
flash char	CACKStr[]				=	"CACK";
flash char	CREJStr[]				=	"CREJ";
flash char	CNAKStr[]				=	"CNAK";
flash char	TREQStr[]				=	"TREQ";
flash char	TACKStr[]				=	"TACK";
flash char	CodeREJStr[]			=	"CodeREJ";
flash char	PREJStr[]				=	"PREJ";
flash char	EREQStr[]				=	"EREQ";
flash char	ERPYStr[]				=	"ERPY";
flash char	UnknownCodeStr[]		=	"F00kKnows";
flash char	LCPStr[]				=	"PPP_LCP";
flash char	IPCPStr[]				=	"PPP_IPCP";
flash char	PAPStr[]				=	"PPP_PAP";
flash char	IPStr[]					=	"PPP_IP";
flash char	AuthAcceptedStr[]		=	"\n  They accepted our Auth'\n";
flash char	AuthNoNeedStr[]			=	"\n  No Auth' required it seems\n";
flash char	AuthRejectedStr[]		=	"\n  They rejected our Auth'\n";
flash char	WeAreInStr[]			=	"\n *** WE'RE IN ***\n";
flash char	UnknownCodeStr2[]		=	"    rejected unknown code\n";
flash char	PPPRetryFailStr[]		=	"*** PPP retry failure\n";
flash char	TxBytesStr[]			=	"Tx-Bytes:";
flash char	RxBytesStr[]			=	"  Rx-Bytes:";
#endif

flash char	OurIPStr[]				=	"  Our IP: ";
flash char	TheirIPStr[]			=	"\nTheir IP: ";
flash char	DNS1IPStr[]				=	"\nDNS-1 IP: ";
flash char	DNS2IPStr[]				=	"\nDNS-2 IP: ";

T_PPP			PPP;							// PPP link details

T_PPP_Header1	*PPPHeader = NULL;
T_CodeHeader	*CodeHeader = NULL;

//****************************************************************************

bool PPP_DisplayIP(void)
{	// display our IP's
	if (!SendConsoleRStr(OurIPStr)) return false;
	IP_Str((char*)ScratchPad, PPP.OUR_IP.ip32);
	if (!SendConsoleStr((char*)ScratchPad)) return false;

	if (!SendConsoleRStr(TheirIPStr)) return false;
	IP_Str((char*)ScratchPad, PPP.THEIR_IP.ip32);
	if (!SendConsoleStr((char*)ScratchPad)) return false;

	if (!SendConsoleRStr(DNS1IPStr)) return false;
	IP_Str((char*)ScratchPad, PPP.DNS1_IP.ip32);
	if (!SendConsoleStr((char*)ScratchPad)) return false;

	if (!SendConsoleRStr(DNS2IPStr)) return false;
	IP_Str((char*)ScratchPad, PPP.DNS2_IP.ip32);
	if (!SendConsoleStr((char*)ScratchPad)) return false;

	if (!SendConsoleByte('\r')) return false;
	return SendConsoleByte('\n');
}

#ifdef Debug

bool PPP_WeAcceptedStr(u8 type)
{
	if (!SendDebugRStr(ppp_str1)) return false;
	sprintf((char*)ScratchPad, "%u\n", type);
	return SendDebugStr((char*)ScratchPad);
}

bool PPP_WeNRejectedStr(u8 type)
{
	if (!SendDebugRStr(ppp_str2)) return false;
	sprintf((char*)ScratchPad, "%u\n", type);
	return SendDebugStr((char*)ScratchPad);
}

bool PPP_WeRejectedStr(u8 type)
{
	if (!SendDebugRStr(ppp_str3)) return false;
	sprintf((char*)ScratchPad, "%u\n", type);
	return SendDebugStr((char*)ScratchPad);
}

bool PPP_DisplayPacket(bool Tx, u16 Bytes)
{
	u8				type, len;
	u16				i, j, Protocol;
	u32				dw;
	T_CodeHeader	*CodeHeader;

	i = 0;
	j = ntohs(*(u16*)(MainBuffer + i));				//
	if (j == 0xff03) i += 2;						// the address/control fields are present (no ACFC)
													//
	if (MainBuffer[i] & 0x01)						//
		Protocol = (u16)MainBuffer[i++];			// the protocol field has been compressed
	else											//
	{												//
		Protocol = ntohs(*(u16*)(MainBuffer + i));	// no PFC
		i += 2;										//
	}												//
													//
	if (Protocol == PPP_IP) return true;			// let the IP routine display the packet

	// ********************
	// display the protocol

	if (Tx)
		strcpy((char*)ScratchPad, "\nT");
	else
		strcpy((char*)ScratchPad, "\nR");
	strcat((char*)ScratchPad, "X: Protocol: ");
	switch (Protocol)
	{
		case PPP_LCP	:	rstrcpy((char*)ScratchPad + strlen((char*)ScratchPad), LCPStr);
							break;
		case PPP_IPCP	:	rstrcpy((char*)ScratchPad + strlen((char*)ScratchPad), IPCPStr);
							break;
		case PPP_PAP	:	rstrcpy((char*)ScratchPad + strlen((char*)ScratchPad), PAPStr);
							break;
		default			:	sprintf((char*)ScratchPad + strlen((char*)ScratchPad), "%04x\n", Protocol);
							return SendDebugStr((char*)ScratchPad);
	}
	sprintf((char*)ScratchPad + strlen((char*)ScratchPad), " [%04x]", Protocol);
	if (!SendDebugStr((char*)ScratchPad)) return false;

	// ********************
	// display the code header

	CodeHeader = (T_CodeHeader *)(MainBuffer + i);
	i += sizeof(T_CodeHeader);

	if (!SendDebugRStr(CodeStr)) return false;
	switch (CodeHeader->Code)
	{
		case PPP_CREQ	:	rstrcpy((char*)ScratchPad, CREQStr);
							break;
		case PPP_CACK	:	rstrcpy((char*)ScratchPad, CACKStr);
							break;
		case PPP_CNAK	:	rstrcpy((char*)ScratchPad, CNAKStr);
							break;
		case PPP_CREJ	:	rstrcpy((char*)ScratchPad, CREJStr);
							break;
		case PPP_TREQ	:	rstrcpy((char*)ScratchPad, TREQStr);
							break;
		case PPP_TACK	:	rstrcpy((char*)ScratchPad, TACKStr);
							break;
		case PPP_CodeREJ:	rstrcpy((char*)ScratchPad, CodeREJStr);
							break;
		case PPP_PREJ	:	rstrcpy((char*)ScratchPad, PREJStr);
							break;
		case PPP_EREQ	:	rstrcpy((char*)ScratchPad, EREQStr);
							break;
		case PPP_ERPY	:	rstrcpy((char*)ScratchPad, ERPYStr);
							break;
		default			:	rstrcpy((char*)ScratchPad, UnknownCodeStr);
							break;
	}
	sprintf((char*)ScratchPad + strlen((char*)ScratchPad), " [%u]  ID:%u   Len:%u\n",  CodeHeader->Code, CodeHeader->ID, ntohs(CodeHeader->Len));
	if (!SendDebugStr((char*)ScratchPad)) return false;

	// ********************
	// display the options (if any)

	if ((Protocol == PPP_LCP) || (Protocol == PPP_IPCP))
	{
		if ((CodeHeader->Code == PPP_CREQ) || (CodeHeader->Code == PPP_CACK) || (CodeHeader->Code == PPP_CNAK) || (CodeHeader->Code == PPP_CREJ))
		{
			while ((i + 2) <= Bytes)
			{
				type = MainBuffer[i + 0];
				len = MainBuffer[i + 1];
				if (len < 2) len = 2;
				sprintf((char*)ScratchPad, "    type:%u     len:%u", type, len);
				if (Protocol == PPP_IPCP)
				{
					if (type == 2)
					{
						if (len >= 2)
						{
							strcat((char*)ScratchPad, "   comp-prot: ");
							j = ntohs(*(u16*)(MainBuffer + i + 2));
							sprintf((char*)ScratchPad + strlen((char*)ScratchPad), "%04X", j);
						}
					}
					else
					if ((type == 3) || (type == 129) || (type == 130) || (type == 131) || (type == 132))
					{
						if (len >= 4)
						{
							strcat((char*)ScratchPad, "   ip: ");
							dw = *(u32*)(MainBuffer + i + 2);
							IP_Str((char*)ScratchPad + strlen((char*)ScratchPad), dw);
						}
					}
				}
				else
				if (Protocol == PPP_LCP)
				{
					switch (type)
					{
						case LCP_MRU	:	strcat((char*)ScratchPad, "   MRU: ");
											j = ntohs(*(u16*)(MainBuffer + i + 2));
											sprintf((char*)ScratchPad + strlen((char*)ScratchPad), "%u", j);
											break;
						case LCP_ACCM	:	strcat((char*)ScratchPad, "  ACCM: ");
											dw = ntohl(*(u32*)(MainBuffer + i + 2));
											bin2bstr(ScratchPad + strlen((char*)ScratchPad), dw, 32);
											break;
						case LCP_AP		:	strcat((char*)ScratchPad, "    AP: ");
											j = ntohs(*(u16*)(MainBuffer + i + 2));
											sprintf((char*)ScratchPad + strlen((char*)ScratchPad), "%02X", j);
											break;
						case LCP_MN		:	strcat((char*)ScratchPad, "    MN: ");
											dw = ntohl(*(u32*)(MainBuffer + i + 2));
											sprintf((char*)ScratchPad + strlen((char*)ScratchPad), "%lu", dw);
											break;
						case LCP_PFC	:	strcat((char*)ScratchPad, "  PFC");
											break;
						case LCP_ACFC	:	strcat((char*)ScratchPad, "  ACFC");
											break;
						default			:	strcat((char*)ScratchPad, " .. ");
											for (j = 2; j < len; j++) sprintf((char*)ScratchPad + strlen((char*)ScratchPad), "%02X ", (u16)((u8)MainBuffer[i + j]));
											break;
					}
				}
				strcat((char*)ScratchPad, "\n");
				if (!SendDebugStr((char*)ScratchPad)) return false;
				i += len;
			}
		}
	}

	// ********************

	return true;
}

bool PPP_DisplayStage(void)
{
	if(!SendDebugRStr(PPPStageStr1)) return false;
	switch (PPP.Stage)
	{
		case PPPS_None		:	return SendDebugRStr(PPPStageStr2);
		case PPPS_Start		:	return SendDebugRStr(PPPStageStr3);
		case PPPS_LCP		:	return SendDebugRStr(PPPStageStr4);
		case PPPS_LogOn		:	return SendDebugRStr(PPPStageStr5);
		case PPPS_IP_Addr	:	return SendDebugRStr(PPPStageStr6);
		case PPPS_IP		:	return SendDebugRStr(PPPStageStr7);
		case PPPS_Disc		:	return SendDebugRStr(PPPStageStr8);
		default				:	return SendDebugRStr(PPPStageStr9);
	}
}

#endif

//****************************************************************************

void PPP_Stage(T_PPPStage Stage)
{
	if (PPP.Stage == Stage) return;			// no change
											//
	#ifdef Debug
		PPP_DisplayStage();					// display current stage
	#endif
											//
	PPP.Stage = Stage;						// set the new PPP stage/state
	PPP.Retries = 0;						// reset the send retry counter
	u16_Put(&PPP.SendTick, PPP_Timeout);	// send next packet asap
	PPP.NAK_REJ_Count = 0;					// reset the rejection counter

	#ifdef Debug
		PPP_DisplayStage();
	#endif
}

//****************************************************************************
// send the PPP buffer to the server.
//
// This is where we add the byte stuffing and also calculate the fcs on the fly.
//
// Byte stuffing is used to make sure the start/stop flag (a single byte) never
// appears in the packet data - so ensuring we can 100% reliably detect the packet boundries from
// one packet to the next.

bool PPP_SendByte(u8 c)
{
	PPP.TxBytes++;														// update byte counter
	return SendModemByte(c);											// send byte
}


bool PPP_TxByte(u8 c, bool MustByteStuff)
{	// send byte with byte stuffing
	if (!WatchdogCounter) WatchdogCounter++;							//
																		//
	if (c == PPP_Flag) goto Stuff;										// stuff the byte
	if (c == PPP_EscapeFlag) goto Stuff;								// stuff the byte
	if (c > 31) goto NoStuff;											// no need to stuff the byte
	if (MustByteStuff) goto Stuff;										// must use byte stuffing - for now
	if (!(PPP.TxACCM & (1 << c))) goto NoStuff;							// no need to stuff the byte
Stuff:
	if (!PPP_SendByte(PPP_EscapeFlag)) return false;					// send byte
	c ^= PPP_Stuff;														// modify the byte
NoStuff:
	return PPP_SendByte(c);												// send byte
}

bool PPP_SendPacket(bool MustByteStuff)
{
	u8		c;
	u16		fcs;
	u8		*Buffer;
	u16		Len;

	Buffer = MainBuffer;												//
	Len = MainBufferWr_Tx;												//

	if (Len == 0) return true;											// no data to send

	fcs = HDLC_PPP_INIT_FCS_16;											// init the fcs

	if (!PPP_SendByte(PPP_Flag)) return false;							// start flag

	for (; Len; Len--)
	{
		c = *Buffer++;													// byte to send
		fcs = UpdateFCS_16(fcs, c);										// update the FCS
		if (!PPP_TxByte(c, MustByteStuff)) return false;				// data
	}

	fcs = ~fcs;															// finalize the fcs

	if (!PPP_TxByte((u8)(fcs & 0xff), MustByteStuff)) return false;			// fcs LS-Byte
	if (!PPP_TxByte((u8)((fcs >> 8) & 0xff), MustByteStuff)) return false;	// fcs MS-Byte

	MainBufferWr_Tx = 0;												//

	return PPP_SendByte(PPP_Flag);										// stop flag
}

//****************************************************************************

void PPP_StartPacket(u16 Protocol)
{	// start a PPP packet off
	MainBufferWr_Tx = 0;											//
	PPPHeader = (T_PPP_Header1*)(MainBuffer + MainBufferWr_Tx);	// get address of the ppp header in the packet
	PPPHeader->AddressField = 0xff;									//
	PPPHeader->ControlField = 0x03;									//
	PPPHeader->Protocol = htons(Protocol);							//
	MainBufferWr_Tx += sizeof(T_PPP_Header1);						// update index
}

int PPP_AddCodeHeader(u8 Code)
{	// add the code header into the PPP packet
	CodeHeader = (T_CodeHeader*)(MainBuffer + MainBufferWr_Tx);	// get address of the code header in the packet
	CodeHeader->Code = Code;										// code
	CodeHeader->ID = PPP.OurID;										// ID
	CodeHeader->Len = sizeof(T_CodeHeader);							// length - update this as data is added to the packet
	MainBufferWr_Tx += sizeof(T_CodeHeader);						// update index
	return CodeHeader->Len;											// size of data we have added
}

void PPP_Add8(u8 b)
{	// add a byte into the PPP packet
	MainBuffer[MainBufferWr_Tx++] = b;								// 8-bit
	CodeHeader->Len++;												// update length
}

void PPP_Add16(u16 w)
{	// add a 16-bit value into the PPP packet
	*(u16*)(MainBuffer + MainBufferWr_Tx) = htons(w);				// 16-bit
	MainBufferWr_Tx += 2;											// update index
	CodeHeader->Len += 2;											// update length
}

void PPP_Add32(u32 dw)
{	// add a 32-bit value into the PPP packet
	*(u32*)(MainBuffer + MainBufferWr_Tx) = htonl(dw);				// 32-bit
	MainBufferWr_Tx += 4;											// update index
	CodeHeader->Len += 4;											// update length
}

int PPP_AddText(char *s)
{	// add text into the PPP packet
	u16	i = (u16)strlen(s);											// length of text
	MainBuffer[MainBufferWr_Tx++] = (char)i;						// length
	strcpy((char*)MainBuffer + MainBufferWr_Tx, s);					// text
	MainBufferWr_Tx += i;											// update index
	CodeHeader->Len += 1 + i;										// update length
	return 1 + i;													// size of data we have added
}

int PPP_Add_IPCP_Option(u8 Code)
{	// add an IP option into the PPP packet
	u32		ip;

	if (Code == 3) ip = PPP.OUR_IP.ip32;							// point to our ip
	else															//
	if (Code == 129) ip = PPP.DNS1_IP.ip32;							// point to primary dns ip
	else															//
	if (Code == 131) ip = PPP.DNS2_IP.ip32;							// point to secondary dns ip
	else															//
	return 0;														//
																	//
	PPP_Add8(Code);													// type
	PPP_Add8(6);													// length
	PPP_Add32(ntohl(ip));											// ip address
																	//
	return 6;														// size of option we have added
}

int PPP_AddACCM(u32 ACCM)
{	// add an ACCM option into the packet
	PPP_Add8(LCP_ACCM);												// type
	PPP_Add8(6);													// length
	PPP_Add32(ACCM);												// data
	return 6;														// size of option we have added
}

int PPP_AddMN(u32 MN)
{	// add a magic number option into the packet
	PPP_Add8(LCP_MN);												// type
	PPP_Add8(6);													// length
	PPP_Add32(MN);													// data
	return 6;														// size of option we have added
}

int PPP_AddMRU(u16 MRU)
{	// add an MRU option into the packet
	PPP_Add8(LCP_MRU);												// type
	PPP_Add8(4);													// length
	PPP_Add16(MRU);													// data
	return 4;														// size of option we have added
}

int PPP_AddPAP(void)
{
	PPP_Add8(LCP_AP);												// type
	PPP_Add8(4);													// length
	PPP_Add16(PPP_PAP);												// the auth protocol we can do
	return 4;														// size of option we have added
}

//****************************************************************************

bool PPP_SendEchoRequest(void)
{	// Send an LCP Echo request packet
	u16 w;

	PPP_StartPacket(PPP_LCP);										//
	PPP_AddCodeHeader(PPP_EREQ);									//
	PPP_Add32(PPP.TxMN);											// magic number
	   																//
	CodeHeader->Len = htons(CodeHeader->Len);						// correct byte order
																	//
	u16_Put(&PPP.SendTick, 0);										// reset the send retry timer
	PPP.Retries++;													// update the send retry counter
																	//
	w = MainBufferWr_Tx;											//
																	//
	if (!PPP_SendPacket(true)) return false;						// send the packet
																	//
	#ifdef Debug
		PPP_DisplayPacket(true, w);									//
	#endif

	return true;													//
}

bool PPP_SendIPRequest(void)
{	// Send a IPCP packet requesting the ip's (our's and the dns ip's)
	u16 w;

	PPP_StartPacket(PPP_IPCP);										//
	PPP_AddCodeHeader(PPP_CREQ);									//
																	//
	if (PPP.OUR_IP.ip32 != 0xffffffff) PPP_Add_IPCP_Option(3);		// add our ip to the packet
	if (PPP.DNS1_IP.ip32 != 0xffffffff) PPP_Add_IPCP_Option(129);	// add the primary DNS ip
	if (PPP.DNS2_IP.ip32 != 0xffffffff) PPP_Add_IPCP_Option(131);	// add the secondary DNS ip
																	//
	CodeHeader->Len = htons(CodeHeader->Len);						// correct byte order
   																	//
	u16_Put(&PPP.SendTick, 0);										// reset the send retry timer
	PPP.Retries++;													// update the send retry counter
																	//
	w = MainBufferWr_Tx;											// remember how many bytes their are
																	//
	if (!PPP_SendPacket(false)) return false;						// send the packet
																	//
	#ifdef Debug
		PPP_DisplayPacket(true, w);									//
	#endif

	return true;													//
}

bool PPP_SendPap(void)
{	// Send an LCP PAP login packet
	u16 w;

	PPP_StartPacket(PPP_PAP);										//
  	PPP_AddCodeHeader(PPP_CREQ);									//
	PPP_AddText(PPP.Username);										//
	PPP_AddText(PPP.Password);										//
																	//
	CodeHeader->Len = htons(CodeHeader->Len);						// correct byte order
   																	//
	u16_Put(&PPP.SendTick, 0);										// reset the send retry timer
	PPP.Retries++;													// update the send retry counter
																	//
	w = MainBufferWr_Tx;											// remember how many bytes their are
																	//
	if (!PPP_SendPacket(false)) return false;						// send the packet

	#ifdef Debug
		PPP_DisplayPacket(true, w);									//
	#endif

	return true;													//
}

bool PPP_SendTermRequest(void)
{	// Send an LCP Terminate Request packet
	u16 w;

	PPP_StartPacket(PPP_LCP);										//
	PPP_AddCodeHeader(PPP_TREQ);									//
																	//
  	u16_Put(&PPP.SendTick, 0);										// reset the send retry timer
	PPP.Retries++;													// update the send retry counter
																	//
	CodeHeader->Len = htons(CodeHeader->Len);						// correct byte order
																	//
	w = MainBufferWr_Tx;											// remember how many bytes their are
																	//
	if (!PPP_SendPacket(true)) return false;						// send the packet

	#ifdef Debug
		PPP_DisplayPacket(true, w);									//
	#endif

	return true;													//
}

bool PPP_SendConfigRequest(void)
{
	u16 w;

	// *****************
	// PPP into a windows server

	#ifdef WindowsPPP
		if (PPP.Stage == PPPS_Start)
		{	// this is needed to log onto a windows PPP server
			if (!SendModemRStr(PPP_WindowsStr)) return false;				//
																			//
			if (!WatchdogCounter) WatchdogCounter++;						// tell timer interrupt to reset the watchdog
																			//
			u16_Put(&PPP.SendTick, 0);										//
			for (; u16_Get(&PPP.SendTick) < 500; );							// wait for 500ms
																			//
			if (!WatchdogCounter) WatchdogCounter++;						// tell timer interrupt to reset the watchdog
		}
	#endif

	// *****************
	// Send an LCP CREQ packet - requesting the desired PPP options

	if (PPP.Stage != PPPS_LCP) PPP_Stage(PPPS_LCP);							//
																			//
	PPP.AcceptedOurLCPOptions = false;										// will be true when they accept all our options
																			//
	PPP_StartPacket(PPP_LCP);												//
	PPP_AddCodeHeader(PPP_CREQ);											//
	if (PPP.TxMRU) PPP_AddMRU(PPP.TxMRU);									//
	if (PPP.TxACCM != 0xffffffff) PPP_AddACCM(PPP.TxACCM);					//
	if (PPP.TxMN) PPP_AddMN(PPP.TxMN);										//
																			//
	CodeHeader->Len = htons(CodeHeader->Len);								// correct byte order
																			//
	u16_Put(&PPP.SendTick, 0);												// reset the send retry timer
	PPP.Retries++;															// update the send retry counter
																			//
	w = MainBufferWr_Tx;													// purly for debugging
																			//
	if (!PPP_SendPacket(true)) return false;								// send the packet
																			//
	#ifdef Debug
		PPP_DisplayPacket(true, w);											// purly for debugging
	#endif

	return true;													//
}

// **************************************************************************
// Save the incoming byte into the packet buffer.
// return false if the packet did not complete, else return true

bool PPP_AddNewRxByte(u8 c)
{
	int				i;
	u8				type, len;
	u16				InformationIndex, w, w2, Len, Protocol;
	u32				dw;
	u32				*p;
	bool			MustByteStuff, Terminate;

	CodeHeader = 0;															//
	MustByteStuff = true;													//
	Terminate = false;														//
	MainBufferWr_Tx = 0;													// write index
																			//
	PPP.RxBytes++;															// update byte counter
	u16_Put(&PPP.LastRxData, 0);											// reset timer

	// ***********************
	// save the incoming data into the main buffer.
	// this is where we detect packet start/stops and do any byte de-stuffing.
	// we also update the fcs here - as each byte comes in

	if (c != PPP_Flag)
	{	// packet data
		if (MainBufferWr_Rx < 0) return false;								// still waiting for the start of a packet
																			//
		if (MainBufferWr_Rx >= sizeof(MainBuffer))							//
		{																	// buffer overflow - drop packet and wait for next one
			MainBufferWr_Rx = -1;											// wait for start of packet (PPP Flag)
			return false;													//
		}																	//
																			//
		if (c == PPP_EscapeFlag)											//
		{																	// start de-stuffing
			PPP.RxStuff = true;												//
			return false;													//
		}																	//
																			//
		if (PPP.RxStuff)													//
		{																	// previous byte was an Escape flag byte (byte stuffing)
			PPP.RxStuff = false;											//
			c ^= PPP_Stuff;													// recover the byte from it's stuffing
		}																	//
																			//
		if ((!MainBufferWr_Rx) && (c != 0xff)) return false;				// this isn't really needed but every little helps
																			//
		MainBuffer[MainBufferWr_Rx++] = c;									// save the new byte into our PPP buffer
																			//
		if (MainBufferWr_Rx >= 3)											//
		{																	//
			c = (u8)MainBuffer[MainBufferWr_Rx - 3];						// get byte from 3 bytes ago - to avoid pulling the fcs in
			PPP.RxFCS = UpdateFCS_16(PPP.RxFCS, c);							// update the fcs
		}																	//
																			//
		return false;														//
	}																		//
																			//
	if (MainBufferWr_Rx < 6) goto ppp_end1;									// not enough bytes to the ppp packet - need at least 6 bytes - drop the packet
																			//
	PPP.RxFCS = ~PPP.RxFCS;													// finalize the fcs
																			//
	type = MainBuffer[--MainBufferWr_Rx];									//
	w = (u16)type;															// get fcs from packet
	w <<= 8;																// LS-Byte 1st
	type = MainBuffer[--MainBufferWr_Rx];									//
	w |= (u16)type;															// get fcs from packet
																			//
	if (PPP.RxFCS != w)														// same as our calculated fcs ?
	{																		// nope
		#ifdef Debug
			SendDebugStr("\n ");											//
			SendDebugDataDump(MainBuffer, MainBufferWr_Rx + 2);				//
			sprintf((char*)ScratchPad, "\nFCS Error ... Len:%u  OurFCS:%04X  TheirFCS:%04X\n", 2 + MainBufferWr_Rx, PPP.RxFCS, w);
			SendDebugStr((char*)ScratchPad);
		#endif
		goto ppp_end1;														// fcs error - drop the packet
	}

	// *********************************************
	// w00t, valid PPP packet !! ... process it

	#ifdef Debug
		PPP_DisplayPacket(false, MainBufferWr_Rx);									// display the ppp packet on the console
	#endif

	MainBufferRd_Rx = 0;															// reset read index
																					//
	PPPHeader = (T_PPP_Header1*)(MainBuffer + MainBufferRd_Rx);					// point to the PPP header
	if (PPPHeader->AddressField != 0xff) goto ppp_end1;								// bah
	if (PPPHeader->ControlField != 0x03) goto ppp_end1;								// moo
	MainBufferRd_Rx += sizeof(T_PPP_Header1);										// update read index
																					//
	InformationIndex = MainBufferRd_Rx;												// remember the current index
																					//
	Protocol = ntohs(PPPHeader->Protocol);											// fix byte order - to make things easier

	// ***********************
	// send a protocol reject packet back if the protocol is unknown to us

	if	((Protocol != PPP_LCP) &&													//
		 (Protocol != PPP_PAP) &&													//
		 (Protocol != PPP_IPCP) &&													//
		 (Protocol != PPP_IP)) goto ppp_Unknown;									// unknown protocol

	// ***********************
	// Internet Protocol (IP)

	if (Protocol == PPP_IP)
	{
		if ((PPP.Stage != PPPS_IP) && (PPP.Stage != PPPS_Disc)) goto ppp_end1;						// ignore it, we aint PPP'ed online yet
																									//
		if (u32_Get(&PPP.LCP_Echo_Timer) < PPP_LCP_Echo_RetryTime) u32_Put(&PPP.LCP_Echo_Timer, 0);	// don't think theirs a need to do echo tests while we still seem to be getting packets
																									//
		MustByteStuff = false;																		//
		IP_dec();																					// pass the packet onto the IP layer
																									//
		goto ppp_end1;																				//
	}

	// ****************

	CodeHeader = (T_CodeHeader *)(MainBuffer + MainBufferRd_Rx);					// point to the code header
	MainBufferRd_Rx += sizeof(T_CodeHeader);										// update read index
	Len = sizeof(T_CodeHeader);														// Len will be used if we need to send a packet back

	// ****************
	// Link Configure Protocol (LCP)

	if (Protocol == PPP_LCP)
	{
		// *******************************************************
		// terminate request

		if (CodeHeader->Code == PPP_TREQ)					//
		{													//
			CodeHeader->Code = PPP_TACK;					// turn the rx'ed packet into an ACK
			MainBufferWr_Tx = MainBufferWr_Rx;				// send the whole thing back
															//
			Terminate = true;								// tell the bit at the end of this function to close the link
			goto ppp_end1;									//
		}													//

		// *******************************************************
		// terminate ack

		if (CodeHeader->Code == PPP_TACK)					//
		{													//
			Terminate = true;								// tell the bit at the end of this function to close the link
			goto ppp_end1;									//
		}													//

		// *******************************************************
		// protocol reject

		if (CodeHeader->Code == PPP_PREJ)					//
		{													//
			w = ntohs(*(u16*)&MainBuffer[MainBufferRd_Rx]);	// Rejected Protocol
															//
			#ifdef Debug
				sprintf((char*)ScratchPad, "     they rejected protocol:%04X\n", w);
				SendDebugStr((char*)ScratchPad);
			#endif

			// this prolly means things have gone wrong as we are only using the most basic of protocols

			PPP_End();										// terminate the link
  			goto ppp_end1;									//
		}

		// *******************************************************
		// Code reject

		if (CodeHeader->Code == PPP_CodeREJ)				//
		{													//
			w = (u16)MainBuffer[MainBufferRd_Rx++];			// Rejected code

			#ifdef Debug
				sprintf((char*)ScratchPad, "     they rejected code:%u\n", w);
				SendDebugStr((char*)ScratchPad);
			#endif

			// this will prolly mean things have gone wrong

			PPP_End();										// terminate the link
  			goto ppp_end1;									//
		}

		// *******************************************************
		// Echo request - we MUST send back an echo reply - it's the rules!

		if (CodeHeader->Code == PPP_EREQ)								//
		{																//
			dw = ntohl(*(u32*)(MainBuffer + MainBufferRd_Rx));		// magic number - MS-Byte 1st

			if ((dw) && (dw == PPP.TxMN))
			{	// seems we are in loopback mode - well, more than likely !
				#ifdef Debug
					SendDebugRStr(LoopBackStr);
				#endif
				Terminate = true;
				goto ppp_end1;
			}

			dw = 0;
			if (PPP.AcceptedOurLCPOptions) dw = PPP.TxMN;			// replace the Magic number with ours
			*(u32*)(MainBuffer + MainBufferRd_Rx) = htonl(dw);		// magic number
																	//
			CodeHeader->Code = PPP_ERPY;							// change the packet into a reply packet
			MainBufferWr_Tx = MainBufferWr_Rx;						// number of bytes to send back

  			goto ppp_end1;											// send it back
		}

		if (CodeHeader->Code == PPP_ERPY)
		{
			dw = ntohl(*(u32*)(MainBuffer + MainBufferRd_Rx));		// magic number - MS-Byte 1st

			if ((dw) && (dw == PPP.TxMN))
			{	// seems we are in loopback mode
				#ifdef Debug
					SendDebugRStr(LoopBackStr);
				#endif
				Terminate = true;
				goto ppp_end1;
			}

			if (dw == PPP.RxMN)
			{	// it's for us
				u32_Put(&PPP.LCP_Echo_Timer, 0);			// reset echo timer
				PPP.Retries = 0;							// reset the send retry counter
				u16_Put(&PPP.SendTick, PPP_Timeout);		// send next packet asap
			}

			goto ppp_end1;
		}

		// *******************************************************
		// don't go any further if we are not sorting/sorted things out or are disconnecting

		if ((PPP.Stage == PPPS_None) || (PPP.Stage == PPPS_Start) || (PPP.Stage == PPPS_Disc)) goto ppp_end1;

		// *******************************************************
		// They are requesting LCP options

		if (CodeHeader->Code == PPP_CREQ)
		{
			// *************************************
			// first do a NAK test - to see if we could accept any of the options but with different values

			i = MainBufferRd_Rx;
			while ((i + 2) <= MainBufferWr_Rx)
			{	// go thru each option
				type = MainBuffer[i++];
				len = MainBuffer[i++];
				if (len < 2) len = 2;
				switch (type)
				{
					case LCP_MN		:	// check to see if their magic number is the same as ours - if it is, then nak a suggested one back to them for them to use
										// it could be that we are in loop back mode - in which case, give up with the PPP link
										dw = ntohl(*(u32*)(MainBuffer + i));							// fetch the Magic number
										if ((dw) && (dw != PPP.TxMN)) break;							// their MN seems ok to us
																										//
										while (dw == PPP.TxMN) dw = Random32;							//
																										//
										if (MainBufferWr_Tx == 0) MainBufferWr_Tx = MainBufferRd_Rx;	// number bytes to send back - so far
										Len += PPP_AddMN(dw);											//

										#ifdef Debug
											PPP_WeNRejectedStr(type);
										#endif

										break;
					case LCP_MRU	:	// Maximum Receive Unit - limit it to our max rx MRU
										w = ntohs(*(u16*)(MainBuffer + i));								// fetch the MRU they want to use when sending to us
										if (w < 128) w = 128;											// set a minimum MRU to use
										else
										if (w > PPP.RxMRU) w = PPP.RxMRU;								// set a max MRU we can accept
										else
											break;														// it's within limits

										// copy the option back into the packet with a suggestion we can accept
										if (MainBufferWr_Tx == 0) MainBufferWr_Tx = MainBufferRd_Rx;	// number bytes to send back - so far
										Len += PPP_AddMRU(w);											//

										#ifdef Debug
											PPP_WeNRejectedStr(type);
										#endif
										break;
					case LCP_AP		:	// authentication protocol
										w = ntohs(*(u16*)(MainBuffer + i));								// authentication protocol they are requesting us to use
										if (w == PPP_PAP) break;										// they are requesting the one we can do

										// add the auth option we CAN accept
										if (MainBufferWr_Tx == 0) MainBufferWr_Tx = MainBufferRd_Rx;	// number bytes to send back - so far
										Len += PPP_AddPAP();											//

										#ifdef Debug
											sprintf((char*)ScratchPad, "     we n-rejected auth-prot:%04X .. asking for PAP instead\n", w);
											SendDebugStr((char*)ScratchPad);
										#endif
										break;
				}
				i += len - 2;
			}
			if (MainBufferWr_Tx > 0)
			{	// we have n-rejected some options - send them back
				CodeHeader->Code = PPP_CNAK;							// update the header we are sending back
				CodeHeader->Len = htons(Len);							// update the header we are sending back
				PPP.NAK_REJ_Count++;									// update counter
				goto ppp_end1;												// send the packet back
			}

			// *************************************
			// now see if their are any options we must reject

			i = MainBufferRd_Rx;
			while ((i + 2) <= MainBufferWr_Rx)
			{	// go thru each option
				type = MainBuffer[i + 0];
				len = MainBuffer[i + 1];
				if (len < 2) len = 2;
				switch (type)
				{
					case LCP_MRU	:
					case LCP_ACCM	:
					case LCP_MN		:	break;
					case LCP_AP		:	break;	//if ((PPP.Username[0]) || (PPP.Password[0])) break;				// we are going to try to log on
					default			:	// found an option we must reject as we don't use it
										if (MainBufferWr_Tx == 0) MainBufferWr_Tx = MainBufferRd_Rx;	// number bytes to send back - so far
										// copy the option back into the packet for sending back
										if (i != MainBufferWr_Tx) memmove(MainBuffer + MainBufferWr_Tx, MainBuffer + i, len);
										MainBufferWr_Tx += len;
										Len += len;
										#ifdef Debug
											PPP_WeRejectedStr(type);
										#endif
										break;
				}
				i += len;
			}
			if (MainBufferWr_Tx > 0)
			{	// we have rejected some options - send them back
				CodeHeader->Code = PPP_CREJ;							// update the header we are sending back
				CodeHeader->Len = htons(Len);							// update the header we are sending back
				PPP.NAK_REJ_Count++;									// update counter
				goto ppp_end1;												// send the packet back
			}

			// *************************************
			// Accept all of their options - we only get this far if we didunt reject any of their options

			i = MainBufferRd_Rx;										//
			while ((i + 2) <= MainBufferWr_Rx)							//
			{															// go thru each option
				type = MainBuffer[i++];									//
				len = MainBuffer[i++];									//
				if (len < 2) len = 2;									//
				switch (type)											//
				{														//
					case LCP_MRU	:	PPP.RxMRU = ntohs(*(u16*)(MainBuffer + i));
										break;
					case LCP_ACCM	:	PPP.RxACCM = ntohl(*(u32*)(MainBuffer + i));
										break;
					case LCP_MN		:	PPP.RxMN = ntohl(*(u32*)(MainBuffer + i));
										break;
					case LCP_AP		:	PPP.AuthProtocol = ntohs(*(u16*)(MainBuffer + i));
										break;
				}														//
				#ifdef Debug
					PPP_WeAcceptedStr(type);
				#endif
				i += len - 2;											//
			}															//
			CodeHeader->Code = PPP_CACK;								//
			MainBufferWr_Tx = MainBufferWr_Rx;							//
																		//
			PPP.AcceptedTheirLCPOptions = true;							// we have accepted their options
																		//
			u16_Put(&PPP.SendTick, PPP_Timeout);						// send next packet asap
  			goto ppp_end1;												// send ACK packet back
		}																//

		// *******************************************************
		// they have accepted our options

		if (CodeHeader->Code == PPP_CACK)								//
	    {																//
/*			i = MainBufferRd_Rx;										//
			while ((i + 2) <= MainBufferWr_Rx)							//
			{															// go thru each option
				type = MainBuffer[i++];									//
				len = MainBuffer[i++];									//
				if (len < 2) len = 2;									//
				switch (type)											//
				{														//
					case LCP_MRU	:
										break;							//
					case LCP_MN		:
										break;							//
					case LCP_ACCM	:
										break;							//
				}														//
				i += len - 2;											//
			}															//
*/
			PPP.AcceptedOurLCPOptions = true;							// they have accepted our options
																		//
			u16_Put(&PPP.SendTick, PPP_Timeout);						// send next packet asap
  			goto ppp_end1;													//
		}																//

		// *******************************************************
		// they have rejected at least one of our options

		if ((CodeHeader->Code == PPP_CNAK) || (CodeHeader->Code == PPP_CREJ))
		{
			i = MainBufferRd_Rx;										//
			while ((i + 2) <= MainBufferWr_Rx)							//
			{															// go thru each option
				type = MainBuffer[i++];									//
				len = MainBuffer[i++];									//
				if (len < 2) len = 2;									//
				switch (type)											//
				{														//
					case LCP_MRU	:	PPP.TxMRU = 0;																	// don't ask again - assum the default of 1500
										if (CodeHeader->Code == PPP_CNAK) PPP.TxMRU = ntohs(*(u16*)(MainBuffer + i));	// no wait - use their suggestion instead
										break;																			//
					case LCP_MN		:	PPP.TxMN = 0;																	// don't ask again
										if (CodeHeader->Code == PPP_CNAK) PPP.TxMN = ntohl(*(u32*)(MainBuffer + i));	// no wait - use their suggestion instead
										break;																			//
					case LCP_ACCM	:	PPP.TxACCM = 0xffffffff;														// wtf else can we do if they send a REJ
										if (CodeHeader->Code == PPP_CNAK) PPP.TxACCM = ntohl(*(u32*)(MainBuffer + i));	// no wait - use their suggestion instead
										break;																			//
				}														//
				i += len - 2;											//
			}															//
																		//
			PPP.AcceptedOurLCPOptions = false;							//
																		//
			u16_Put(&PPP.SendTick, PPP_Timeout);						// send next packet asap
			goto ppp_end1;													//
		}

		// *******************************************************
		// unknown lcp code - send the packet back as a code reject

		goto ppp_CodeReject;
	}

	// ****************
	// it's not a LCP packet

	if ((PPP.Stage == PPPS_None) || (PPP.Stage == PPPS_Start) || (PPP.Stage == PPPS_LCP) || (PPP.Stage == PPPS_Disc)) goto ppp_end1;

	if ((Protocol != PPP_PAP) && (Protocol != PPP_IPCP)) goto ppp_Unknown;	// pffft

	MustByteStuff = false;										// only force byte stuffing with LCP packets

	// ****************
	// Password Authenication Protocol (PAP)

	if (Protocol == PPP_PAP)
	{
		if (PPP.Stage != PPPS_LogOn) goto ppp_end1;

       #ifdef Debug
		ScratchPad[0] = 0;
		if (Len > sizeof(T_CodeHeader))
		{
			len = MainBuffer[MainBufferRd_Rx++];			// message length
			if (len > 0)
			{	// they have sent an ascii message back
				strcpy((char*)ScratchPad, " msg: ");
				memcpy(ScratchPad + strlen((char*)ScratchPad), &MainBuffer[MainBufferRd_Rx], len);
				ScratchPad[len++] = '\n';
				ScratchPad[len] = 0;
			}
		}
		#endif

		if (CodeHeader->Code == PPP_CACK)
		{	// Authenticate-Ack - w00t! ... we have logged on
			#ifdef Debug
				if (SendDebugRStr(AuthAcceptedStr))
				{
					if (ScratchPad[0] != 0) SendDebugStr((char*)ScratchPad);
				}
			#endif

			PPP_Stage(PPPS_IP_Addr);							// onto next stage
			goto ppp_end1;
		}

		if ((CodeHeader->Code == PPP_CREJ) || (CodeHeader->Code == PPP_CNAK))
		{	// hmmmmmmmm
			#ifdef Debug
				if (SendDebugRStr(AuthRejectedStr))
				{
					if (ScratchPad[0] != 0) SendDebugStr((char*)ScratchPad);
				}
			#endif

			PPP_End();										// terminate the link
			goto ppp_end1;
		}

		goto ppp_CodeReject;									// unknown code
	}

	// ****************
	// Internet Protocol Control Protocol (IPCP)

	if (Protocol == PPP_IPCP)
	{
		if ((PPP.Stage != PPPS_IP_Addr) && (PPP.Stage != PPPS_IP)) goto ppp_end1;

		// **********************************************************
		// CREQ

		if (CodeHeader->Code == PPP_CREQ)
		{
			// **********************************************************
			// first check to see if theirs any options we need to reject

			i = MainBufferRd_Rx;
			while ((i + 2) <= MainBufferWr_Rx)
			{
				type = MainBuffer[i + 0];
				len = MainBuffer[i + 1];
				if (len < 2) len = 2;
				if ((type != 3) && (type != 129) && (type != 131))
				{	// reject the option
					// copy the option back into the packet for sending back
					if (MainBufferWr_Tx == 0) MainBufferWr_Tx = MainBufferRd_Rx;		// number bytes to send back - so far
					if (i != MainBufferWr_Tx) memmove(&MainBuffer[MainBufferWr_Tx], &MainBuffer[i], len);
					MainBufferWr_Tx += len;
					Len += len;
					#ifdef Debug
						PPP_WeRejectedStr(type);
					#endif
				}
				i += len;
			}
			if (MainBufferWr_Tx > 0)
			{	// we have rejected some options - send them back
				CodeHeader->Code = PPP_CREJ;							// update the header we are sending back
				CodeHeader->Len = htons(Len);							// update the header we are sending back
				PPP.NAK_REJ_Count++;									// update counter
				goto ppp_end1;											// send the packet back
			}

			// **********************************************************
			// accept all the options - we only get this far if we didunt reject any

			i = MainBufferRd_Rx;
			while ((i + 2) <= MainBufferWr_Rx)
			{
				type = MainBuffer[i++];
				len = MainBuffer[i++];
				if (len < 2) len = 2;
				p = 0;
				if (type == 3) p = &PPP.THEIR_IP.ip32;		// Their ip address
				else
				if (type == 129) p = &PPP.DNS1_IP.ip32;		// primary dns ip address
				else
				if (type == 131) p = &PPP.DNS2_IP.ip32;		// secondary dns ip address
				if (p) memmove(p, MainBuffer + i, 4);		// save the ip address
				#ifdef Debug
					PPP_WeAcceptedStr(type);
				#endif
				i += len - 2;
			}
			CodeHeader->Code = PPP_CACK;
			MainBufferWr_Tx = MainBufferWr_Rx;
			goto ppp_end1;
		}

		// **********************************************************
		// CREJ

		if (CodeHeader->Code == PPP_CREJ)
		{
			i = MainBufferRd_Rx;
			while ((i + 2) <= MainBufferWr_Rx)
			{
				type = MainBuffer[i++];
				len = MainBuffer[i++];
				if (len < 2) len = 2;
				dw = *(u32*)(MainBuffer + i);									// get the ip they rejected
				switch (type)
				{
					case 3		:	// oh dear
									if (dw && (dw != 0xffffffff))
										PPP.OUR_IP.ip32 = 0;					// try requesting a new ip then
									else
									{
										PPP.OUR_IP.ip32 = 0xffffffff;			//
										PPP_End();								// terminate the link
										goto ppp_end1;
									}
									break;
					case 129	:	if (dw && (dw != 0xffffffff))
										PPP.DNS1_IP.ip32 = 0;					// try requesting a new ip then
									else
										PPP.DNS1_IP.ip32 = 0xffffffff;			// their is no primary DNS ip .. don't ask again
									break;
					case 131	:	if (dw && (dw != 0xffffffff))
										PPP.DNS2_IP.ip32 = 0;					// try requesting a new ip then
									else
										PPP.DNS2_IP.ip32 = 0xffffffff;			// their is no secondary DNS ip .. don't ask again
									break;
				}
				i += len - 2;
			}
			u16_Put(&PPP.SendTick, PPP_Timeout);								// send next packet asap
			goto ppp_end1;
		}

		// **********************************************************

		if ((CodeHeader->Code == PPP_CNAK) || (CodeHeader->Code == PPP_CACK))
		{
			i = MainBufferRd_Rx;
			while ((i + 2) <= MainBufferWr_Rx)
			{
				type = MainBuffer[i++];
				len = MainBuffer[i++];
				if (len < 2) len = 2;
				p = 0;
				if (type == 3) p = &PPP.OUR_IP.ip32;				// they are giving us our ip address
				else
				if (type == 129) p = &PPP.DNS1_IP.ip32;				// they are giving us the primary dns ip address
				else
				if (type == 131) p = &PPP.DNS2_IP.ip32;				// they are giving us the secondary dns ip address
				if (p) memmove(p, MainBuffer + i, 4);				// get ip address
				i += len - 2;
			}
			if (CodeHeader->Code == PPP_CACK) PPP.AcceptedIPOptions = true;
			u16_Put(&PPP.SendTick, PPP_Timeout);					// send next packet asap
			goto ppp_end1;
		}

		// **********************************************************

		goto ppp_CodeReject;	// should never get here
	}

	// ****************
	// unknown protocol - reject it and send it back

ppp_Unknown:
	#ifdef Debug
		SendDebugRStr(UnknownProtocolStr);
	#endif

	w = PPP_PREJ;
	w2 = InformationIndex - 2;
	len = (MainBufferWr_Rx - InformationIndex) + 2;

	goto ppp_end2;

	// ****************
	// unknown code - reject it and send it back

ppp_CodeReject:
	#ifdef Debug
		SendDebugRStr(UnknownCodeStr2);
	#endif

	w = PPP_CodeREJ;
	w2 = InformationIndex;
	len = MainBufferWr_Rx - InformationIndex;

	// ***********************
	// add the rejected packet - ready for sending back

ppp_end2:
	MustByteStuff = true;

	memmove(&MainBuffer[sizeof(T_PPP_Header1) + sizeof(T_CodeHeader)], &MainBuffer[w2], len);

	PPP_StartPacket(PPP_LCP);
	CodeHeader = (T_CodeHeader *)&MainBuffer[MainBufferWr_Tx];
	PPP_AddCodeHeader(w);

	MainBufferWr_Tx += len;									// we previously moved the rejected packet into place
	CodeHeader->Len += len;
	CodeHeader->Len = htons(CodeHeader->Len);				// correct byte order

	PPP.OurID++;

	// ***********************
	// Send a tx packet back if we have one to send

ppp_end1:
	if (MainBufferWr_Tx)
	{	// if we have compiled a packet to send back, send it now
		w = MainBufferWr_Tx;

		if (PPP_SendPacket(MustByteStuff))		// send it
		{
			#ifdef Debug
				PPP_DisplayPacket(true, w);		//
			#endif
		}
	}

	MainBufferWr_Tx = 0;						//

	// **********************************
	// reset ppp rx ready for next packet

	PPP.RxStuff = false;						// reset Rx stuff flag
	PPP.RxFCS = HDLC_PPP_INIT_FCS_16;			// init the Rx fcs
	MainBufferWr_Rx = 0;						// reset Rx buffer index

	// **********************************
	// terminate the ppp link if we have ben told too

	if (Terminate) PPP_Reset(0, 0);				// link is now closed

	// **********************************

	return true;								// their was a packet
}

//**************************************************************************************
// call this from the main executive loop - as often as you can ... it'll take care of ALL the PPP stuff for you
// do NOT call this from an interrupt !!

void PPP_Process(void)
{
	u8	c;

	if (PPP.Stage == PPPS_None) return;										// we haven't got a PPP conection going

	// **********************************
	// get any new data from the PPP uart

	if (!MainBufferWr_Tx)
	{
		while (UART1_RxBufferRd != UART1_RxBufferWr)
		{
			c = (u8)UART1_RxBuffer[UART1_RxBufferRd++];
			if (UART1_RxBufferRd >= sizeof(UART1_RxBuffer)) UART1_RxBufferRd -= sizeof(UART1_RxBuffer);	// wap awound
			if (PPP_AddNewRxByte(c)) break;									// pass the byte onto the PPP RX routine
		}
	}

	#ifdef ModemHandShaking
	HardwareFlowControl(ModemUart);											// tell em to stop sending data if our buffer is full
	#endif

	// **********************************
	// take of sending PPP org packets (all the acks, naks, rejs are sent in rx routine)

	if (PPP.NAK_REJ_Count >= PPP_Retries) goto ppp_end;		// oh no !

	if (u16_Get(&PPP.LastRxData) >= PPP_DataTimeout)		//
	{														//
		MainBufferWr_Rx = -1;								//
	}														//

	if (MainBufferWr_Rx > 0) return;						// we have data coming in - wait for it to be processed before using the buffer for sending a packet

	if (u16_Get(&PPP.SendTick) < PPP_Timeout) return;					// not time to retry
	if ((PPP.Stage != PPPS_IP) && (PPP.Retries >= PPP_Retries))			//
	{
		#ifdef Debug
			SendDebugRStr(PPPRetryFailStr);
		#endif

		switch (PPP.Stage)
		{
			case PPPS_None		:	break;
			case PPPS_Start		:	PPP_Stage(PPPS_None);
									break;
			case PPPS_LCP		:	PPP_Reset(0, 0);
									break;
			case PPPS_LogOn		:
			case PPPS_IP_Addr	:
			case PPPS_IP		:	PPP_Stage(PPPS_Disc);
									break;
			case PPPS_Disc		:
			default				:	PPP_Reset(0, 0);
									break;
		}
		return;
	}

	switch (PPP.Stage)													//
	{																	//
		case PPPS_Start		:	PPP_SendConfigRequest();				// request LCP options
								break;									//
		case PPPS_LCP		:	if ((PPP.AcceptedTheirLCPOptions) && (PPP.AcceptedOurLCPOptions))
									PPP_Stage(PPPS_LogOn);			// onto next stage
								else									//
								if (!PPP.AcceptedOurLCPOptions)			//
									PPP_SendConfigRequest();			// request LCP options
								break;									//
		case PPPS_LogOn		:	if (PPP.AuthProtocol == PPP_PAP)		//
									PPP_SendPap();						// send our username/password
								else									//
								{										//
									#ifdef Debug						//
										SendDebugRStr(AuthNoNeedStr);	//
									#endif								//
									PPP_Stage(PPPS_IP_Addr);			// onto next stage - without logging on
								}										//
								break;									//
		case PPPS_IP_Addr	:	if (!PPP.AcceptedIPOptions)				//
								{
									PPP_SendIPRequest();				// ask for ip addresses
									break;
								}

								#ifdef Debug
									sprintf((char*)ScratchPad, "\n  Tx Magic Num: %lu\n", PPP.TxMN);
									SendDebugStr((char*)ScratchPad);
									sprintf((char*)ScratchPad, "  Rx Magic Num: %lu\n", PPP.RxMN);
									SendDebugStr((char*)ScratchPad);

									strcpy((char*)ScratchPad, "\n       Tx ACCM: ");
									bin2bstr(ScratchPad + strlen((char*)ScratchPad), PPP.TxACCM, 32);
									strcat((char*)ScratchPad, "\n       Rx ACCM: ");
									bin2bstr(ScratchPad + strlen((char*)ScratchPad), PPP.RxACCM, 32);
									strcat((char*)ScratchPad, "\n");
									SendDebugStr((char*)ScratchPad);

									sprintf((char*)ScratchPad, "\n        Tx MRU: %u\n", PPP.TxMRU);
									SendDebugStr((char*)ScratchPad);
									sprintf((char*)ScratchPad, "        Rx MRU: %u\n\n", PPP.RxMRU);
									SendDebugStr((char*)ScratchPad);

									if (Flags1 & (1<<Flags1_Debug)) PPP_DisplayIP();
								#endif

								IP_ID = rand();								//
								PPP_Stage(PPPS_IP);							// onto next stage
																			//
								#ifdef Debug
									SendDebugRStr(WeAreInStr);
								#endif

								#ifdef IncludeTCP
								TCP_Socket = TCP_SocketListen(TCP_Port);			// open a tcp listening socket
								#endif
								break;												//
		case PPPS_IP		:	IP_Process();												//
																							//
								if (u32_Get(&PPP.LCP_Echo_Timer) >= PPP_LCP_Echo_RetryTime)	//
								{															//
									PPP_SendEchoRequest();									// send an echo request
								}															//
								break;														//
		case PPPS_Disc		:	IP_Process();												//
								#ifdef IncludeTCP
								if (TCP_CloseSocket(TCP_Socket)) PPP_SendTermRequest();	// teminate the link
								#else
								PPP_SendTermRequest();
								#endif

								break;										//
		default				:	PPP_Stage(PPPS_None);						// fix it
								break;										//
	}																		//

	return;

ppp_end:
	PPP_End();		// give up
}

//**************************************************************************************
// call this every 10ms - from a timer interrupt say

void PPP_10ms_Timer(void)
{
	if (PPP.Stage == PPPS_None) return;

	if (PPP.LastRxData < 65000) PPP.LastRxData += 10;
	if (PPP.SendTick < 65000) PPP.SendTick += 10;

	if (PPP.Stage == PPPS_IP)
	{
		if (PPP.LCP_Echo_Timer < PPP_LCP_Echo_RetryTime) PPP.LCP_Echo_Timer += 10;
	}

	if ((PPP.Stage == PPPS_IP) || (PPP.Stage == PPPS_Disc))
	{
		IP_10ms_Timer();
	}
}

//**************************************************************************************
// call this to reset/clear the PPP details ready for connecting

void PPP_Reset(char *Username, char *Password)
{
	int	i;
	u32	TxBytes, RxBytes;

	TxBytes = PPP.TxBytes;
	RxBytes = PPP.RxBytes;

	#ifdef Debug
		if ((PPP.TxBytes) || (PPP.RxBytes))
		{
			SendDebugRStr(TxBytesStr);
			sprintf((char*)ScratchPad, "%lu  ", PPP.TxBytes);
			SendDebugStr((char*)ScratchPad);

			SendDebugRStr(RxBytesStr);
			sprintf((char*)ScratchPad, "%lu\n", PPP.RxBytes);
			SendDebugStr((char*)ScratchPad);
		}
	#endif

	if (PPP.Stage != PPPS_None) PPP_Stage(PPPS_None);

	memset(&PPP, 0, sizeof(T_PPP));

	PPP.TxBytes = TxBytes;
	PPP.RxBytes = RxBytes;

	if (Username)
	{	// save the username to log on with
		i = sizeof(PPP.Username);
		if (strlen(Username) >= i)
			strncpy((char*)PPP.Username, Username, i - 1);
		else
			strcpy((char*)PPP.Username, Username);
	}

	if (Password)
	{
		i = sizeof(PPP.Password);
		if (strlen(Password) >= i)
			strncpy((char*)PPP.Password, Password, i - 1);
		else
			strcpy((char*)PPP.Password, Password);
	}

	PPP.Stage = PPPS_None;							//
	u16_Put(&PPP.SendTick, PPP_Timeout);			// send next packet asap
	u16_Put(&PPP.LastRxData, 0);					//
	u32_Put(&PPP.LCP_Echo_Timer, 0);				//

	PPP.TxMRU = 1500;								// max size of packet we will send
	PPP.RxMRU = OurRxMRU;							// max size of packet we can accept

	PPP.TxMN = Random32;							// get a random 32-bit value

	rmemcpy((char*)&PPP.OUR_IP.ip32, OurIP, 4);		// set the ip's
	rmemcpy((char*)&PPP.DNS1_IP.ip32, Dns1IP, 4);	//
	rmemcpy((char*)&PPP.DNS2_IP.ip32, Dns2IP, 4);	//

	#ifdef IncludeTCP
		#ifndef StaticTCPSocket
			if (TCP_Socket != NULL)
			{
				realloc(TCP_Socket, 0);
				TCP_Socket = NULL;
			}
		#endif
	#endif

	MainBufferWr_Rx = -1;
	MainBufferWr_Tx = 0;
	UART1_RxBufferRd = 0;
	UART1_RxBufferWr = 0;
}

//**************************************************************************************
// call this when you want to start a PPP session

#ifdef CPU_eZ8
void PPP_Start(char rom *Username, char rom *Password)
#endif
#ifdef CPU_ATmega128
void PPP_Start(const char *Username, const char *Password)
#endif
{
	char	un[32] = {""};
	char	pw[32] = {""};

	if (PPP.Stage != PPPS_None) return;		// PPP is already busy
											//
	if (Username) rstrcpy(un, Username);	// copy the text into ram
	if (Password) rstrcpy(pw, Password);	// copy the text into ram
											//
	PPP_Reset(un, pw);						//
											//
	PPP_Stage(PPPS_Start);					// start a PPP log on
}

//**************************************************************************************
// call this to end a PPP session

void PPP_End(void)
{
	switch (PPP.Stage)
	{
		case PPPS_None		:	break;
		case PPPS_Start		:	PPP_Stage(PPPS_None);
								break;
		case PPPS_LCP		:
		case PPPS_LogOn		:
		case PPPS_IP_Addr	:
		case PPPS_IP		:	PPP_Stage(PPPS_Disc);
								break;
		case PPPS_Disc		:	break;
		default				:	PPP_Reset(0, 0);
								break;
	}
}

//***********************************************************

