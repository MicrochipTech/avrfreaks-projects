
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

//#ifdef CPU_eZ8
//	#pragma stkck									// enable stack checking
//#endif

#include <string.h>
#include <stdio.h>
//#include <math.h>

#include "common.h"
#include "ppp.h"
#include "ip.h"
#include "udp.h"
#include "ntp.h"

#define HoursPerDay		24
#define MinsPerDay		(HoursPerDay * 60)
#define SecsPerDay		(MinsPerDay * 60)
#define MSecsPerDay		(SecsPerDay * 1000)

#ifdef CPU_eZ8
volatile near u16			NTP_Timer;
volatile near T_IP_Addr		NTP_IP;
#endif
#ifdef CPU_ATmega128
volatile u16				NTP_Timer;
volatile T_IP_Addr			NTP_IP;
#endif

//*********************************************************************************************************************
// request the date & time using SNTP

bool NTP_RequestSNTP(u32 IP)
{
	T_NTP	*NTP;

	if (!UDP_StartPacket(IP, 123, 123)) return false;									//
																						//
	NTP = (T_NTP*)(MainBuffer + MainBufferWr_Tx);										//
	memset(NTP, 0, sizeof(T_NTP));														//
	NTP->mode = 0x1b;																	//
	MainBufferWr_Tx += sizeof(T_NTP);													// update index
																						//
	u16_Put(&NTP_Timer, 0);																// reset the timer
	u32_Put(&NTP_IP.ip32, IP);															// remember the ip we are getting the ntp from
																						//
	return UDP_EndPacket();																//
}

//*********************************************************************************************************************
// decode an SNTP reply (UDP packet on port 123 normally)

void NTP_DecodeSNTP(u32 IP, T_NTP *NTP)
{
//	TDateTime		FNTPTime;
//	double			Nsec, Nfrac;
	u32				dw;
	u16				hour, min, sec, lag;

	if (!NTP) return;								//
													//
	NTP->Xmit1 = ntohl(NTP->Xmit1);					//
	NTP->Xmit2 = ntohl(NTP->Xmit2);					//
													//
	#ifdef Debug
		sprintf((char*)ScratchPad, "\nXmit1:%lu\nXmit2:%lu\n", NTP->Xmit1, NTP->Xmit2);
		SendDebugStr((char*)ScratchPad);
	#endif

//	Nsec = (double)NTP->Xmit1;						// MS-Byte 1st ... shit ... the zilog s32 to double is inaccurate :( .. unless it's the sprintf function that is bad
//	Nfrac = (double)NTP->Xmit2;						// as above
//	Nfrac /= 4294967295.0;							//
//	FNTPTime = Nsec;								//
//	FNTPTime += Nfrac;								//
//	FNTPTime /= SecsPerDay;							//
//	FNTPTime += 2;									// add 2 days
													//
	lag = u16_Get(&NTP_Timer);						// how long it took to get the reply back (ms)
	lag >>= 1;										//
	dw = (u32)(lag / 1000);							// now in seconds
	NTP->Xmit1 += dw;								// take the network lag/response time into account
													//
													// NTP->Xmit1 is the number of seconds since "1st Jan 1900 00:00:00" .. NTP->Xmit2 is the fractional part
	dw = NTP->Xmit1 % SecsPerDay;					// dw = seconds thru the current day
	NTP->Xmit1 /= SecsPerDay;						// now left with the number of days since "1st Jan 1900 00:00:00"
													//
	sec = dw % 60;									//
	dw /= 60;										//
	min = dw % 60;									//
	dw /= 60;										//
	hour = dw;										//

	#ifdef Debug
		sprintf((char*)ScratchPad, "%02u:%02u:%02u ... lag:%ums\n", hour, min, sec, lag);
		SendDebugStr((char*)ScratchPad);
	#endif

	if (IP != u32_Get(&NTP_IP.ip32)) return;		//
   													//
	#ifdef Debug
		SendDebugStr("Time set\n");					//
   #endif
													//
	u32_Put(&NTP_IP.ip32, 0);						//
}

//*********************************************************************************************************************
// this is called every 10ms from the UDP module

void NTP_10ms_Timer(void)
{
	if (NTP_Timer < 5000)										//
		NTP_Timer += 10;										// update the timer
	else														//
		NTP_IP.ip32 = 0;										// ignore any ntp replies after 5 seconds
}

