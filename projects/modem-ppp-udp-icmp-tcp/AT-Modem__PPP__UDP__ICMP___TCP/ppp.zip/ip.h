
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef ipH
#define ipH

#include "common.h"

//**************************************************************************************************

// IP Protocols
#define IP_PROTO_ICMP		1
#define IP_PROTO_TCP		6
#define IP_PROTO_UDP		17

// ICMP types
#define ICMP_ECHO_REPLY		0
#define ICMP_ECHO_REQUEST	8

// IP stuff
#define IP_DONT_FRAGMENT 	0x4000	// Don't Fragment Flag
#define IP_MORE_FRAGMENTs 	0x2000	// More fragments to follow flag
#define IP_FRAGMENT_OFFSET	0x1fff	// Fragment offset mask
#define IP_FRAGMENTED		0x3fff	//

//**************************************************************************************************
// tcp socket etc

//**************************************************************************************************

typedef struct TIPHeader
{
	// IP header
/*
	 0                   1                   2                   3
	 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|Ver= 4 |IHL= 5 |Type of Service|        Total Length = 21      |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|      Identification = 111     |Flg=0|   Fragment Offset = 0   |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|   Time = 123  |  Protocol = 1 |        header checksum        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                         source address                        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                      destination address                      |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                    Options                    |    Padding    | < optional
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|     data      ..........
	+-+-+-+-+-+-+-+-+
*/

	u8			VerLen;
	u8			TOS;
	u16			TotalLength;
	u16			ID;
	u16			Fragment;
	u8			TTL;
	u8			Protocol;
	u16			Checksum;
	T_IP_Addr	SourceIP;
	T_IP_Addr	DestIP;
} T_IP_Header;

//**************************************************************************************************

#ifdef CPU_eZ8
extern near u16		IP_ID;
#endif
#ifdef CPU_ATmega128
extern u16			IP_ID;
#endif

extern T_IP_Header	*IP_Header;

#ifdef Debug
extern void IP_DisplayProtocol(bool Tx, int TotalBytes);
extern void IP_DisplayHeader(int HeaderIdx, int TotalBytes);
#endif

extern bool IP_FireWalled(void);

extern u32 IP_Checksum(char *p, u16 len);
extern u16 IP_ChecksumFinalize(u32 checksum);
extern u16 IP_Checksum1(char *p, u16 len);
extern u16 IP_Checksum2(char *p, u16 len);

extern void IP_StartPacket(u8 Protocol, u32 IP);
extern void IP_EndPacket(void);

extern void IP_dec(void);

extern void IP_10ms_Timer(void);
extern void IP_Process(void);

#endif


