
//      TCP A                                                 TCP B
//  1.  CLOSED                                                LISTEN
//
//  2.  SYN-SENT    --> <SEQ=100><CTL=SYN>                --> SYN-RECEIVED
//  3.  ESTABLISHED <-- <SEQ=300><ACK=101><CTL=SYN,ACK>   <-- SYN-RECEIVED
//  4.  ESTABLISHED --> <SEQ=101><ACK=301><CTL=ACK>       --> ESTABLISHED
//
//  5.  ESTABLISHED --> <SEQ=101><ACK=301><CTL=ACK><DATA> --> ESTABLISHED
//  6.    etc
//
//
//
//  7.  FIN-WAIT-1  --> <SEQ=100><ACK=300><CTL=FIN,ACK>   --> CLOSE-WAIT
//  8.  FIN-WAIT-2  <-- <SEQ=300><ACK=101><CTL=ACK>       <-- CLOSE-WAIT
//  9.  TIME-WAIT   <-- <SEQ=300><ACK=101><CTL=FIN,ACK>   <-- LAST-ACK
// 10.  TIME-WAIT   --> <SEQ=101><ACK=301><CTL=ACK>       --> CLOSED
// 11.  (2 MSL)
//      CLOSED

/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

//#ifdef CPU_eZ8
//	#pragma stkck									// enable stack checking
//#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "common.h"
#include "ppp.h"
#include "ip.h"
#include "tcp.h"

#ifdef Debug
flash char	tcp_str1[]	=	"    TCPHdr: SrcPrt:";
flash char	tcp_str2[]	=	" DestPrt:";
flash char	tcp_str3[]	=	" SeqNum:";
flash char	tcp_str4[]	=	" AckNum:";
flash char	tcp_str5[]	=	" DataOfs:";
flash char	tcp_str6[]	=	" CBits:";
flash char	tcp_str7[]	=	"-URG";
flash char	tcp_str8[]	=	"-ACK";
flash char	tcp_str9[]	=	"-PSH";
flash char	tcp_str10[]	=	"-RST";
flash char	tcp_str11[]	=	"-SYN";
flash char	tcp_str12[]	=	"-FIN";
flash char	tcp_str13[]	=	" WinSize:";
flash char	tcp_str14[]	=	" Chksum:";
flash char	tcp_str15[]	=	" UrgPtr:";
flash char	tcp_str16[]	=	"    option:";
flash char	tcp_str17[]	=	"    DataBytes:";
flash char	tcp_str18[]	=	" Conn RESET\n";
flash char	tcp_str19[]	=	" Conn ACCEPTED\n";
flash char	tcp_str20[]	=	" Conn ESTABLISHED\n";
flash char	tcp_str21[]	=	" - BLOCKED\n";

flash char	tcp_str22[]	=	"TCP Skt State: ";
flash char	tcp_str23[]	=	"CLOSED\n";
flash char	tcp_str24[]	=	"LISTEN\n";
flash char	tcp_str25[]	=	"SYN_SENT\n";
flash char	tcp_str26[]	=	"SYN_RECEIVED\n";
flash char	tcp_str27[]	=	"ESTABLISHED\n";
flash char	tcp_str28[]	=	"FIN_WAIT_1\n";
flash char	tcp_str29[]	=	"FIN_WAIT_2\n";
flash char	tcp_str30[]	=	"CLOSE_WAIT\n";
flash char	tcp_str31[]	=	"CLOSING\n";
flash char	tcp_str32[]	=	"LAST_ACK\n";
flash char	tcp_str33[]	=	"TIME_WAIT\n";
flash char	tcp_str34[]	=	"UNKNOWN\n";

flash char	tcp_Str35[]	=	"*** failed to get mem for socket\n";

flash char	tcp_str40[]	=	"*** TCP chksum err\n";

flash char	TCP_Str50[]	=	"      Connect Time: ";
flash char	TCP_Str51[]	=	"      Last Rx Data: ";
flash char	TCP_Str52[]	=	"Their Max Seg Size: ";
flash char	TCP_Str53[]	=	"     Their Seq Num: ";
flash char	TCP_Str54[]	=	"       Our Seq Num: ";
flash char	TCP_Str55[]	=	"    Their Win Size: ";
flash char	TCP_Str56[]	=	"   Last Bytes Sent: ";
flash char	TCP_Str57[]	=	"          Their IP: ";
flash char	TCP_Str58[]	=	"       Remote Port: ";
flash char	TCP_Str59[]	=	"        Local Port: ";
flash char	TCP_Str60[]	=	"   Round Trip Time: ";
flash char	TCP_Str61[]	=	"           Retries: ";
flash char	TCP_Str62[]	=	"       Retry Timer: ";
flash char	TCP_Str63[]	=	"        TxBufferRd: ";
flash char	TCP_Str64[]	=	"        TxBufferWr: ";
flash char	TCP_Str65[]	=	"        RxBufferRd: ";
flash char	TCP_Str66[]	=	"        RxBufferWr: ";
#endif

#ifdef CPU_eZ8
near u16		TCP_TmpPort = 0;									// this is usedfor deciding what source port to use when making out going tcp connections
#endif
#ifdef CPU_ATmega128
u16			TCP_TmpPort = 0;										//  "
#endif

#ifdef StaticTCPSocket
T_TCP_Socket	TCP_Static_Socket;									// static socket
T_TCP_Socket	*TCP_Socket = (T_TCP_Socket*)&TCP_Static_Socket;	// set the pointer to point to it
#else
T_TCP_Socket	*TCP_Socket = NULL;									// it'll be dynamically allocated
#endif

T_TCP_Header	*TCP_Header = NULL;									// points to the tcp header in a tx or rx packet

//*****************************************************************************************************

#ifdef Debug

void TCP_DisplayHeader(int HeaderIdx, int TotalBytes)
{	// display the tcp header details
	u8	b, type, len;
	int	i, j;
	u16	w;
	u32	dw;

/*
	 0                   1                   2                   3
	 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|          Source Port          |       Destination Port        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                        Sequence Number                        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                    Acknowledgment Number                      |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|  Data |           |U|A|P|R|S|F|                               |
	| Offset| Reserved  |R|C|S|S|Y|I|            Window             |
	|       |           |G|K|H|T|N|N|                               |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|           Checksum            |         Urgent Pointer        |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                    Options                    |    Padding    | < optional
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

	// display the header

	if (!SendDebugRStr(tcp_str1)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(TCP_Header->SourcePort));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(tcp_str2)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(TCP_Header->DestPort));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(tcp_str3)) return;
	dw = ntohl(TCP_Header->SequenceNum);
	sprintf((char*)ScratchPad, "%lu", dw);
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(tcp_str4)) return;
	dw = ntohl(TCP_Header->AckNum);
	sprintf((char*)ScratchPad, "%lu", dw);
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(tcp_str5)) return;
	sprintf((char*)ScratchPad, "%u", TCP_Header->DataOffset >> 4);
	if (!SendDebugStr((char*)ScratchPad)) return;

	b = TCP_Header->ControlBits;
	if (!SendDebugRStr(tcp_str6)) return;
	if (b & TCP_SYN) SendDebugRStr(tcp_str11);
	if (b & TCP_FIN) SendDebugRStr(tcp_str12);
	if (b & TCP_RST) SendDebugRStr(tcp_str10);
	if (b & TCP_URG) SendDebugRStr(tcp_str7);
	if (b & TCP_ACK) SendDebugRStr(tcp_str8);
	if (b & TCP_PSH) SendDebugRStr(tcp_str9);

	if (!SendDebugRStr(tcp_str13)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(TCP_Header->WindowSize));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(tcp_str14)) return;
	sprintf((char*)ScratchPad, "%04x", ntohs(TCP_Header->Checksum));
	if (!SendDebugStr((char*)ScratchPad)) return;

	if (!SendDebugRStr(tcp_str15)) return;
	sprintf((char*)ScratchPad, "%u", ntohs(TCP_Header->UrgentPointer));
	if (!SendDebugStr((char*)ScratchPad)) return;

	// display the options - if any

	i = HeaderIdx;																//
	j = (int)(TCP_Header->DataOffset >> 4);										// header length in 32-bit dwords
	j <<= 2;																	//  ... and now in bytes
	j += i;																		// point to data (immediately follows the TCP header)
	i += sizeof(T_TCP_Header);													//
	while (i < j)																//
	{																			// go thru each IP header option
		if (!SendDebugStr("\n")) return;										//
																				//
		type = MainBuffer[i++];													// option type
		len = 0;																//
		if (type >= 2) len = MainBuffer[i++];									//
																				//
		if (!SendDebugRStr(tcp_str16)) return;									//
																				//
		switch (type)															//
		{																		//
			case 0	:															//
			case 1	:	sprintf((char*)ScratchPad, "%u", type);							//
						break;															//
			case 2	:	w = ntohs(*(u16*)(MainBuffer + i));								// max segment size
						sprintf((char*)ScratchPad, "%u  len:%u   %u", type, len, w);	//
						if (!SendDebugStr((char*)ScratchPad)) return;					//
						break;															//
			default	:	sprintf((char*)ScratchPad, "%u  len:%u", type, len);			//
						if (!SendDebugStr((char*)ScratchPad)) return;					//
						break;															//
		}																		//

		if (type == 0) break;													// end of options
		if (type == 1) continue;												// no length byte
																				//
		if (len < 2) len = 2;													//

		i += (len - 2);															// point to next option
	}																			//
	i = j;

	if (!SendDebugStr("\n")) return;											//

	// done

	if (!SendDebugRStr(tcp_str17)) return;
	sprintf((char*)ScratchPad, "%u\n", TotalBytes - i);
	if (!SendDebugStr((char*)ScratchPad)) return;
}

void TCP_DisplaySocketStage(T_TCP_Socket *Socket)
{	// display the tcp socket stage
	if (Socket == NULL) return;

	if (!SendDebugRStr(tcp_str22)) return;
	switch (Socket->Stage)
	{
		case TCP_CLOSED			:	SendDebugRStr(tcp_str23);
									break;
		case TCP_LISTEN			:	SendDebugRStr(tcp_str24);
									break;
		case TCP_SYN_SENT		:	SendDebugRStr(tcp_str25);
									break;
		case TCP_SYN_RECEIVED	:	SendDebugRStr(tcp_str26);
									break;
		case TCP_ESTABLISHED	:	SendDebugRStr(tcp_str27);
									break;
		case TCP_FIN_WAIT_1		:	SendDebugRStr(tcp_str28);
									break;
		case TCP_FIN_WAIT_2		:	SendDebugRStr(tcp_str29);
									break;
		case TCP_CLOSE_WAIT		:	SendDebugRStr(tcp_str30);
									break;
		case TCP_CLOSING		:	SendDebugRStr(tcp_str31);
									break;
		case TCP_LAST_ACK		:	SendDebugRStr(tcp_str32);
									break;
		case TCP_TIME_WAIT		:	SendDebugRStr(tcp_str33);
									break;
		default					:	SendDebugRStr(tcp_str34);
									break;
	}
}

void TCP_DisplaySocketState(T_TCP_Socket *Socket)
{
	if (Socket == NULL) return;

	TCP_DisplaySocketStage(Socket);

	SendDebugStr("\n");

	SendDebugRStr(TCP_Str50);
	sprintf((char*)ScratchPad, "%lums\n", u32_Get(&Socket->ConnectTime));
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str51);
	sprintf((char*)ScratchPad, "%lums\n", u32_Get(&Socket->LastRxData));
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str52);
	sprintf((char*)ScratchPad, "%u\n", Socket->TheirMaxSegSize);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str53);
	sprintf((char*)ScratchPad, "%lu\n", Socket->TheirSequenceNum);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str54);
	sprintf((char*)ScratchPad, "%lu\n", Socket->OurSequenceNum);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str55);
	sprintf((char*)ScratchPad, "%u\n", Socket->TheirWindowSize);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str56);
	sprintf((char*)ScratchPad, "%d\n", Socket->OurLastBytesSent);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str57);
	IP_Str((char*)ScratchPad, Socket->RemoteIP.ip32);
	strcat((char*)ScratchPad, "\n");
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str58);
	sprintf((char*)ScratchPad, "%u\n", Socket->RemotePort);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str59);
	sprintf((char*)ScratchPad, "%u\n", Socket->LocalPort);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str60);
	sprintf((char*)ScratchPad, "%ums\n", Socket->RoundTripTime);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str61);
	sprintf((char*)ScratchPad, "%u\n", Socket->Retries);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str62);
	sprintf((char*)ScratchPad, "%ums\n", u16_Get(&Socket->Retry_Timer));
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str63);
	sprintf((char*)ScratchPad, "%d\n", Socket->TxBufferRd);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str64);
	sprintf((char*)ScratchPad, "%d\n", Socket->TxBufferWr);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str65);
	sprintf((char*)ScratchPad, "%d\n", Socket->RxBufferRd);
	SendDebugStr((char*)ScratchPad);

	SendDebugRStr(TCP_Str66);
	sprintf((char*)ScratchPad, "%d\n", Socket->RxBufferWr);
	SendDebugStr((char*)ScratchPad);
}

#endif

// ******************************************************************************************
// set the socket stage

void TCP_SocketStage(T_TCP_Socket *Socket, T_TCP_Stage Stage)
{
	if (Socket == NULL) return;													//
																				//
	Socket->Stage = Stage;														// set the socket stage
	Socket->Retries = 0;														//
	u16_Put(&Socket->Retry_Timer, Socket->RoundTripTime * TCP_Retry_Time);		// send next packet asap

	#ifdef Debug
		TCP_DisplaySocketStage(Socket);
	#endif
}

// ******************************************************************************************

void TCP_UpdateRoundTripTime(T_TCP_Socket *Socket, u16 Time)
{
	// update our record of roughtly how long it takes for the total round trip time for tcp data.
	// we the value to work out how long we should wait for tx retries

	if (Socket == NULL) return;											//
																		//
	if (Socket->RoundTripTime < Time)									//
		Socket->RoundTripTime = Time;									// bump straight up
	else																//
	{																	//
		Socket->RoundTripTime += Time;									// average round trip time
		Socket->RoundTripTime >>= 1;									//    "
	}																	//
																		//
	if (Socket->RoundTripTime < 100) Socket->RoundTripTime = 100;		// no lower than 100ms
	else																//
	if (Socket->RoundTripTime > 6000) Socket->RoundTripTime = 6000;		// no higher than 6000ms
}

// ******************************************************************************************

bool TCP_CloseSocket(T_TCP_Socket *Socket)
{	// close the tcp socket
	if (Socket == NULL) return true;				// socket is closed

	switch (Socket->Stage)
	{
		case TCP_CLOSED			:
		case TCP_LISTEN			:	break;			// close the socket
		case TCP_SYN_SENT		:	TCP_SocketStage(Socket, TCP_CLOSED);
									TCP_SendPacket(Socket, TCP_RST);
									return false;
		case TCP_SYN_RECEIVED	:
		case TCP_ESTABLISHED	:	TCP_SocketStage(Socket, TCP_FIN_WAIT_1);
									TCP_SendPacket(Socket, TCP_FIN | TCP_ACK);
		default					:	return false;
	}

	TCP_SocketStage(Socket, TCP_CLOSED);			//
													//
	return true;									// socket is closed
}

T_TCP_Socket *TCP_SocketListen(u16 Port)
{	// create a new tcp socket and set it to listen mode
	T_TCP_Socket	*Socket;													//
																				//
	#ifdef StaticTCPSocket
		Socket = TCP_Socket;													// static socket
	#else
		Socket = malloc(sizeof(T_TCP_Socket));									// allocate memory for a tcp socket
		if (Socket == NULL)														//
		{																		//
			#ifdef Debug
	       	SendDebugRStr(tcp_Str35);											//
	    	#endif
			return NULL;														// failed to get a socket
		}																		//
	#endif
																				//
	memset(Socket, 0, sizeof(T_TCP_Socket));									//
	Socket->LocalPort = Port;													// select the port we are gona listen on
	Socket->OurSequenceNum = Random32;											// our sequence number
	Socket->RoundTripTime = TCP_RoundTripTime;									// default average round trip time - ms
	Socket->TheirMaxSegSize = TCP_Default_MSS;									//
	Socket->OutGoing = false;													//
	Socket->AckDelay = 65000;													//
																				//
	TCP_SocketStage(Socket, TCP_LISTEN);										// open a tcp listening socket
																				//
	return Socket;																// success
}

T_TCP_Socket *TCP_OpenSocket(u32 IP, u16 Port)
{	// create a tcp socket and initiate an out going connection
	T_TCP_Socket	*Socket;													//
																				//
	if ((!IP) || (!Port)) return NULL;											//
																				//
	#ifdef StaticTCPSocket
		Socket = TCP_Socket;													// static socket
	#else
		Socket = malloc(sizeof(T_TCP_Socket));									// allocate memory for a tcp socket
		if (Socket == NULL)														//
		{																		//
			#ifdef Debug
	       	SendDebugRStr(tcp_Str35);											//
	    	#endif
			return NULL;														// failed to get a socket
		}																		//
	#endif
																				//
	memset(Socket, 0, sizeof(T_TCP_Socket));									//
																				//
	if (TCP_TmpPort < TCP_OutGoingPortLow) TCP_TmpPort = TCP_OutGoingPortLow;	//
	else																		//
	if (TCP_TmpPort >= TCP_OutGoingPortHigh) TCP_TmpPort = TCP_OutGoingPortHigh;//
																				//
	Socket->LocalPort = TCP_TmpPort++;											// select the port we are gona listen on
	Socket->RemotePort = Port;													// select the port we are gona listen on
	Socket->RemoteIP.ip32 = IP;													// select the port we are gona listen on
	Socket->OurSequenceNum = Random32;											// our sequence number
	Socket->TheirMaxSegSize = TCP_Default_MSS;									//
	Socket->RoundTripTime = TCP_RoundTripTime;									// default average round trip time - ms
	Socket->OutGoing = true;													//
	Socket->AckDelay = 65000;													//
																				//
	TCP_SocketStage(Socket, TCP_SYN_SENT);										// start a an outgoing connection
	u16_Put(&Socket->Retry_Timer, Socket->RoundTripTime * TCP_Retry_Time);		// next packet asap
																				//
	return Socket;																// success
}

// ******************************************************************************************

int TCP_RxSaveData(T_TCP_Socket *Socket, u8 *Src, int len)
{	// save the received tcp data into the sockets rx ring buffer - the executive reads the dat back from this buffer
	int	i;

	if ((Socket == NULL) || (!Src) || (len <= 0)) return 0;													//
																											//
	i = RingBufBytesFree(sizeof(Socket->RxBuffer), Socket->RxBufferRd, Socket->RxBufferWr);					// number of bytes free in our buffer
	if (len > i) len = i;																					//
																											//
	i = CopyToRingBuffer(Socket->RxBuffer, Src, Socket->RxBufferWr, sizeof(Socket->RxBuffer), len);			//
	Socket->RxBufferWr += i;																				//
	while (Socket->RxBufferWr >= sizeof(Socket->RxBuffer)) Socket->RxBufferWr -= sizeof(Socket->RxBuffer);	//
																											//
	u32_Put(&Socket->LastRxData, 0);																		// reset timer
	Socket->TheirSequenceNum += (u32)i;																		// the next sequence number we will be expecting
	Socket->AckDelay = 0;																					// delayed ack send back
//	Socket->Flags |= TCP_ACK;																				// we need to ACK the data they sent us
																											//
	#ifdef Debug
		sprintf((char*)ScratchPad, "RxBufferRd:%d  RxBufferWr:%d\n", Socket->RxBufferRd, Socket->RxBufferWr);
		SendDebugStr((char*)ScratchPad);
	#endif
																								//
	return i;																					//
}

int TCP_RxBytes(T_TCP_Socket *Socket)
{	// return how many tcp Rx bytes are in the sockets rx ring buffer
	if (Socket == NULL) return 0;																//
	return RingBufBytes(sizeof(Socket->RxBuffer), Socket->RxBufferRd, Socket->RxBufferWr);		// number of bytes in our buffer
}

int TCP_RxData(T_TCP_Socket *Socket, u8 *Dest, int len)
{	// get a number of bytes from the tcp rx ring buffer - this is called from the executive
	int	i;

	if ((Socket == NULL) || (!Dest) || (len <= 0)) return 0;												//
																											//
	i = TCP_RxBytes(Socket);																				// number of bytes waiting for them to collect
	if (i <= 0) return 0;																					// none
	if (len > i) len = i;																					// limit number of bytes their gona get
																											//
	i = CopyFromRingBuffer(Dest, Socket->RxBuffer, Socket->RxBufferRd, sizeof(Socket->RxBuffer), len);		//
	Socket->RxBufferRd += i;																				//
	while (Socket->RxBufferRd >= sizeof(Socket->RxBuffer)) Socket->RxBufferRd -= sizeof(Socket->RxBuffer);	//
																											//
	return i;																								//
}

int TCP_TxFree(T_TCP_Socket *Socket)
{	// return how much space we have in the sockets tx ring buffer
	if (Socket == NULL) return 0;
	return RingBufBytesFree(sizeof(Socket->TxBuffer), Socket->TxBufferRd, Socket->TxBufferWr);
}

int TCP_TxData(T_TCP_Socket *Socket, u8 *Src, int len)
{	// save data into the sockets tx ring buffer - this will get sent down the tcp link
	int	i;

	if ((Socket == NULL) || (!Src) || (len <= 0) || (Socket->Stage != TCP_ESTABLISHED)) return 0;			//
																											//
	i = TCP_TxFree(Socket);																					// number of bytes free in our buffer
	if (len > i) len = i;																					// limit number of bytes we will send
	if (len > Socket->TheirMaxSegSize) len = Socket->TheirMaxSegSize;										// they can only acept a certain amount
	i = CopyToRingBuffer(Socket->TxBuffer, Src, Socket->TxBufferWr, sizeof(Socket->TxBuffer), len);			// copy the bytes into the tcp tx buffer
	Socket->TxBufferWr += i;																				//
	while (Socket->TxBufferWr >= sizeof(Socket->TxBuffer)) Socket->TxBufferWr -= sizeof(Socket->TxBuffer);	//
																											//
	return i;																								// number of bytes saved into the buffer
}

// ******************************************************************************************

bool TCP_StartPacket(T_TCP_Socket *Socket)
{	// start constructing a tcp packet for tranmission
	if (MainBufferWr_Tx > 0) return false;											// the buffer is in use
																					//
	if (Socket == NULL) return false;												//
																					//
	IP_StartPacket(IP_PROTO_TCP, Socket->RemoteIP.ip32);							// start the IP packet off
																					//
	Socket->len = MainBufferWr_Tx;													//
																					//
	TCP_Header = (T_TCP_Header*)(MainBuffer + MainBufferWr_Tx);						// point to the TCP header
	memset(TCP_Header, 0, sizeof(T_TCP_Header));									// clear it
	TCP_Header->DataOffset = sizeof(T_TCP_Header);									//
	TCP_Header->WindowSize = (u16)RingBufBytesFree(sizeof(Socket->RxBuffer), Socket->RxBufferRd, Socket->RxBufferWr);		// number of bytes we have free in our rx buffer
																					//
	MainBufferWr_Tx += sizeof(T_TCP_Header);										// update index
																					//
	return true;																	//
}

bool TCP_EndPacket(T_TCP_Socket *Socket)
{	// end constructing a tcp packet for tranmission and send it
	u16 w, w2;

	if (Socket == NULL) return false;												//
																					//
	if (TCP_Header->ControlBits & (TCP_SYN|TCP_FIN|TCP_PSH|TCP_RST))				//
	{																				//
		u16_Put(&Socket->Retry_Timer, 0);											//
		Socket->Retries++;															//
	}																				//
																					//
	TCP_Header->SourcePort = htons(Socket->LocalPort);								//
	TCP_Header->DestPort = htons(Socket->RemotePort);								//
	TCP_Header->SequenceNum = htonl(Socket->OurSequenceNum);						//
	TCP_Header->AckNum = htonl(Socket->TheirSequenceNum);							//
	TCP_Header->WindowSize = htons(TCP_Header->WindowSize);							//
	TCP_Header->UrgentPointer = htons(TCP_Header->UrgentPointer);					//
	TCP_Header->DataOffset >>= 2;													//
	TCP_Header->DataOffset <<= 4;													//
																					//
	Socket->len = MainBufferWr_Tx - Socket->len;									//
																					//
	w2 = MainBufferWr_Tx;															//
																					//
	IP_Header->TotalLength += Socket->len;											// update the IP header
																					//
	w = IP_Checksum2((char*)TCP_Header, Socket->len);								// update the TCP header checksum
//	if (!w) w = 0xffff;																//
	TCP_Header->Checksum = htons(w);												//
																					//
	IP_EndPacket();																	//
																					//
	if (!PPP_SendPacket(false)) return false;										// send it

	#ifdef Debug
		IP_DisplayProtocol(true, (int)w2);											//
		IP_DisplayHeader(4, (int)w2);												//
		TCP_DisplayHeader(4 + sizeof(T_IP_Header), (int)w2);						//
																					//
		sprintf((char*)ScratchPad, "TxBufferRd:%d  TxBufferWr:%d\n", Socket->TxBufferRd, Socket->TxBufferWr);	//
		SendDebugStr((char*)ScratchPad);																		//
	#endif
																					//
	return true;																	//
}

bool TCP_SendPacket(T_TCP_Socket *Socket, u8 ControlBits)
{	// construct a tcp packet and send it
	int	i, j;

	if (!TCP_StartPacket(Socket)) return false;										//
																					//
	if (ControlBits & TCP_SYN)														//
	{																				//
		i = sizeof(MainBuffer);														//
		if (i > sizeof(Socket->RxBuffer)) i = sizeof(Socket->RxBuffer);				//
		i -= 50;																	// allow for headers etc
		MainBuffer[MainBufferWr_Tx++] = 2;											// type ... max segment size option
		MainBuffer[MainBufferWr_Tx++] = 4;											// length
		*(u16*)(MainBuffer + MainBufferWr_Tx) = htons(i);							// max seg size
		MainBufferWr_Tx += 2;														//
		TCP_Header->DataOffset += 4;												// Update TCP header
																					//
		if ((Socket->Stage == TCP_CLOSED) || (Socket->Stage == TCP_LISTEN))			//
		{																			//
			TCP_SocketStage(Socket, TCP_SYN_SENT);									//
		}																			//
	}																				//
	else																			//
	if (Socket->Stage == TCP_ESTABLISHED)														//
	{																							//
		if ((ControlBits & TCP_ACK) && (Socket->TxBufferRd != Socket->TxBufferWr))				//
		{																						// send some data with the packet
			i = RingBufBytes(sizeof(Socket->TxBuffer), Socket->TxBufferRd, Socket->TxBufferWr);	// number of bytes waiting to go
			if (i > Socket->TheirWindowSize) i = Socket->TheirWindowSize;						//
																								//
			j = sizeof(MainBuffer) - MainBufferWr_Tx;											//
			if (i > j) i = j;																	//
																								//
			j = CopyFromRingBuffer(MainBuffer + MainBufferWr_Tx, Socket->TxBuffer, Socket->TxBufferRd, sizeof(Socket->TxBuffer), i);	// move data from the tx buffer into the tx packet
																								//
			if (j > 0)																			//
			{																					//
				MainBufferWr_Tx += j;															//
				ControlBits |= TCP_PSH;															//
				Socket->OurLastBytesSent = j;													//
			}																					//
		}																						//
	}																							//
																								//
	TCP_Header->ControlBits = ControlBits;														// set the tx packet control bits
																								//
	if (ControlBits & TCP_ACK)																	//
	{																							//
		u16_Put(&Socket->AckDelay, TCP_AckDelay);												//
		Socket->SendAck = false;																// ack has been sent
	}																							//
																								//
	return TCP_EndPacket(Socket);																//
}

//*****************************************************************************************************

void TCP_In(void)
{	// this is called when we have rx'ed a tcp packet
	u8				type;
	int				i;
	u16				len;
	u32				dw;
	u16				MaxSegSize = 0;
	T_TCP_Socket	*Socket = NULL;

	len = MainBufferWr_Rx - MainBufferRd_Rx;									// length of data left

	// *******************
	// TCP header

	TCP_Header = (T_TCP_Header*)(MainBuffer + MainBufferRd_Rx);					// point to the TCP header

	#ifdef Debug
		TCP_DisplayHeader(MainBufferRd_Rx, MainBufferWr_Rx);					//
	#endif

	i = TCP_Header->DataOffset >> 4;											// header length in 32-bit dwords
	i <<= 2;																	// header length in bytes
	if (i < sizeof(T_TCP_Header)) return;										// hmmmmm
	if (i > len) return;														//   "
																				//
	if ((!TCP_Header->Checksum) || (IP_Checksum2((char*)TCP_Header, len)))		//
	{																			// invalid checksum
		#ifdef Debug															//
			SendDebugRStr(tcp_str40);											//
		#endif																	//
		return;																	//
	}																			//
																				//
	// *******************
	// go thru the header options

	i += MainBufferRd_Rx;														// point to data (immediately follows the TCP header)
	MainBufferRd_Rx += sizeof(T_TCP_Header);									// update index - now pointing to TCP options (if any)
	while (MainBufferRd_Rx < i)													//
	{																			// go thru each IP header option
		type = MainBuffer[MainBufferRd_Rx++];									// option type
		if (type == 0) break;													// end of options
		if (type == 1) continue;												// no length byte
																				//
		len = (u16)MainBuffer[MainBufferRd_Rx++];								// option length
		if (len < 2) len = 2;													//
		if (type == 2)															//
		{																		//
			MaxSegSize = ntohs(*(u16*)(MainBuffer + MainBufferRd_Rx));		// maximum segment size
		}																		//
		else																	//
		{	// unknown option													//
		}																		//
		MainBufferRd_Rx += (len - 2);											// point to next option
	}																			//
	MainBufferRd_Rx = i;														//
																				//
	len = MainBufferWr_Rx - MainBufferRd_Rx;									// number of data bytes in the tcp packet

	// *******************
	// only let the packet past this point if it's from the station we have a link too
	// - or if we are in listen mode

	if (IP_Header->DestIP.ip32 != PPP.OUR_IP.ip32) return;									// ignore it, it's not for us
																							//
	Socket = TCP_Socket;																	// we only have one at the moment
	if (Socket == NULL) return;																//
																							//
	if (!Socket->LocalPort) return;															//
	if (ntohs(TCP_Header->DestPort) != Socket->LocalPort) return;						// wrong port, drop it
																							//
	if (Socket->Stage == TCP_CLOSED) goto RefuseConnection;									// we aint expecting any packets, shuv off!
																							//
	if (Socket->Stage == TCP_LISTEN)														//
	{																						//
//		if (IP_FireWalled())																//
//		{																					//
//			#ifdef Debug																	//
//				SendDebugRStr(tcp_str21);													//
//			#endif																			//
//			return;																			// firewalled
//		}																					//
								 															//
		if (Socket->RemoteIP.ip32)															//
		{																					// waiting for a particular ip to connect
			if (IP_Header->SourceIP.ip32 != Socket->RemoteIP.ip32) goto RefuseConnection;	// ignore it
		}																					//
																							//
		if (Socket->RemotePort)																//
		{																					// only a particular source port is allowed
			if (ntohs(TCP_Header->SourcePort) != Socket->RemotePort) goto RefuseConnection;	// wrong port, drop it
		}																					//
	}																						//
	else																					//
	{																						//
		if (IP_Header->SourceIP.ip32 != Socket->RemoteIP.ip32) goto RefuseConnection;		// wrong ip, sod em
		if (ntohs(TCP_Header->SourcePort) != Socket->RemotePort) goto RefuseConnection;		// wrong port, drop it
	}																						//
																							//
	Socket->Flags = 0;																		// this will be altered if a packet needs sending back

	// *******************
	// connection reset

	if (TCP_Header->ControlBits & TCP_RST)
	{
		if (Socket->Stage != TCP_LISTEN) TCP_SocketStage(Socket, TCP_CLOSED);
		return;
	}

	// *******************
	// check to see if it's a connect request

	if (TCP_Header->ControlBits & TCP_SYN)
	{
		if (TCP_Header->ControlBits & (TCP_RST | TCP_FIN))
		{	// wot they trying to do ?
			TCP_SocketStage(Socket, TCP_CLOSED);
			return;
		}

		switch (Socket->Stage)
		{
			case TCP_LISTEN			:	Socket->Flags |= TCP_SYN;
			case TCP_SYN_SENT		:	TCP_SocketStage(Socket, TCP_SYN_RECEIVED);
										break;
			case TCP_SYN_RECEIVED	:	break;
			case TCP_ESTABLISHED	:	// hmmmm - something is wrong
										TCP_SendPacket(Socket, TCP_ACK);		// send a packet back
										return;
			default					:	return;	// ignore it - for now

		}

		// accept the incoming connection request

		Socket->RemoteIP.ip32 = IP_Header->SourceIP.ip32;						// their IP
		Socket->RemotePort = ntohs(TCP_Header->SourcePort);						// their port
		Socket->TheirWindowSize = ntohs(TCP_Header->WindowSize);				// their window size (how much data we can tx)
		Socket->TheirSequenceNum = ntohl(TCP_Header->SequenceNum) + 1;			// their sequence number
		Socket->TxBufferRd = 0;													//
		Socket->TxBufferWr = 0;													//
		Socket->RxBufferRd = 0;													//
		Socket->RxBufferWr = 0;													//
		if (MaxSegSize) Socket->TheirMaxSegSize = MaxSegSize;					//
																				//
		Socket->Flags |= TCP_ACK;												// we need to send an ACK back
	}

	// *******************
	// disconnect request

	if (TCP_Header->ControlBits & TCP_FIN)
	{
		if (TCP_Header->ControlBits & (TCP_SYN | TCP_RST))
		{	// wot they trying to do ?
			TCP_SocketStage(Socket, TCP_CLOSED);
			return;
		}

		switch (Socket->Stage)
		{
			case TCP_LISTEN			:	return;
			case TCP_SYN_SENT		:	Socket->Flags |= TCP_FIN;
			case TCP_SYN_RECEIVED	:	TCP_SocketStage(Socket, TCP_CLOSE_WAIT);
										break;
			case TCP_ESTABLISHED	:	TCP_SocketStage(Socket, TCP_CLOSE_WAIT);
										break;
			case TCP_FIN_WAIT_1		:	TCP_SocketStage(Socket, TCP_FIN_WAIT_2);
										break;
			case TCP_FIN_WAIT_2		:	TCP_SocketStage(Socket, TCP_TIME_WAIT);
										u16_Put(&Socket->Retry_Timer, 0);
										break;
			case TCP_CLOSE_WAIT		:
			case TCP_CLOSING		:
			case TCP_LAST_ACK		:
			case TCP_TIME_WAIT		:	TCP_SocketStage(Socket, TCP_TIME_WAIT);
										break;
			default					:	TCP_SocketStage(Socket, TCP_CLOSED);
										return;
		}

		Socket->TheirSequenceNum = ntohl(TCP_Header->SequenceNum) + 1;				// their sequence number
		Socket->Flags |= TCP_ACK;													// we need to send an ACK back
	}

	// *******************
	// ack

	if (TCP_Header->ControlBits & TCP_ACK)
	{	// ACK
		switch (Socket->Stage)
		{
			case TCP_LISTEN			:	return;
			case TCP_SYN_SENT		:	TCP_SendPacket(Socket, TCP_RST);		// send a packet back
										TCP_SocketStage(Socket, TCP_CLOSED);
										return;
			case TCP_SYN_RECEIVED	:	// we were waiting for the ack
										TCP_UpdateRoundTripTime(Socket, u16_Get(&Socket->Retry_Timer));

										Socket->OurSequenceNum++;
										TCP_SocketStage(Socket, TCP_ESTABLISHED);

										if (!Socket->OutGoing)
										{
											strcpy(ScratchPad, "z8 Tcp server\r\n--------------\r\n");
											TCP_TxData(Socket, ScratchPad, strlen((char*)ScratchPad));	// send them some text
										}
										break;
			case TCP_ESTABLISHED	:	if (Socket->OurSequenceNum != ntohl(TCP_Header->AckNum))
										{	// ack to some data we have sent
											TCP_UpdateRoundTripTime(Socket, u16_Get(&Socket->Retry_Timer));

											dw = ntohl(TCP_Header->AckNum);
											if (dw < Socket->OurSequenceNum)
												dw += 1 + (0xffffffff - Socket->OurSequenceNum);	// 32-bit unsigned rap-around number
											else
												dw -= Socket->OurSequenceNum;
											if (dw > Socket->OurLastBytesSent) dw = Socket->OurLastBytesSent;	// hmmm

											Socket->TxBufferRd += (s16)dw;
											while (Socket->TxBufferRd >= sizeof(Socket->TxBuffer)) Socket->TxBufferRd -= sizeof(Socket->TxBuffer);

											Socket->OurSequenceNum += dw;
											Socket->OurLastBytesSent = 0;

											Socket->Retries = 0;
											u16_Put(&Socket->Retry_Timer, Socket->RoundTripTime * TCP_Retry_Time);	// next packet asap
										}
										break;
			case TCP_FIN_WAIT_1		:	TCP_UpdateRoundTripTime(Socket, u16_Get(&Socket->Retry_Timer));

										TCP_SocketStage(Socket, TCP_FIN_WAIT_2);				// we got an ack back for the FIN we sent
										break;
			case TCP_FIN_WAIT_2		:	TCP_SocketStage(Socket, TCP_TIME_WAIT);
										break;
			case TCP_CLOSE_WAIT		:	break;
			case TCP_CLOSING		:	TCP_SocketStage(Socket, TCP_TIME_WAIT);
										break;
			case TCP_LAST_ACK		:	TCP_SocketStage(Socket, TCP_CLOSED);
			case TCP_TIME_WAIT		:	break;
			default					:	break;
		}

		if (TCP_Header->ControlBits & TCP_URG)											//
		{																				//
		    if (TCP_Header->UrgentPointer)												//
		    {																			//
//				dw = ntohl(TCP_Header->SequenceNum);									//
//            	dw += (u32)ntohs(TCP_Header->UrgentPointer);							// dw = the sequence number of this data
				Socket->Flags |= TCP_ACK;												// send an ACK back
   				goto SendNow;															// we don't yet deal with urgent pointers :(
 			}																			//
	    }																				//
																						//
		if (ntohl(TCP_Header->SequenceNum) == Socket->TheirSequenceNum)						//
		{																						//
			if (len) i = TCP_RxSaveData(Socket, MainBuffer + MainBufferRd_Rx, (int)len);		// save the data sent in the packet into our rx buffer and sent ask back
		}																						//
		else																					//
			Socket->Flags |= TCP_ACK;															// tell them seq-num we were expecting
	}

	// *******************
	// Send any packets back that need sending

SendNow:
	if (Socket->Flags)
	{
		TCP_SendPacket(Socket, Socket->Flags);											// send a packet back
	}

	return;

	// *******************
	// reject the packet completely

RefuseConnection:																			//
//		if (IP_FireWalled())																//
//		{																					//
//			#ifdef Debug																	//
//				SendDebugRStr(tcp_str21);													//
//			#endif																			//
//			return;																			// firewalled - just don't bother with them
//		}																					//

	if (TCP_Header->ControlBits & TCP_RST) return;											// we don't send RST in responce to RST rx'ed
    																						//																							//
	// swap the packet round and send it back												//
																							//
	dw = IP_Header->DestIP.ip32;															//
	IP_Header->DestIP.ip32 = IP_Header->SourceIP.ip32;										//
	IP_Header->SourceIP.ip32 = dw;															//
																							//
	len = TCP_Header->SourcePort;															//
	TCP_Header->SourcePort = TCP_Header->DestPort;											//
	TCP_Header->DestPort = len;																//
																							//
	dw = TCP_Header->SequenceNum;															//
	TCP_Header->SequenceNum = TCP_Header->AckNum;											//
	TCP_Header->AckNum = dw;																//
																							//
	TCP_Header->DataOffset = sizeof(T_TCP_Header) >> 2;										//
	TCP_Header->DataOffset <<= 4;															//
																							//
	TCP_Header->ControlBits = TCP_RST | TCP_ACK;											// set the tx packet control bits
																							//
	TCP_Header->Checksum = 0;																//
	TCP_Header->WindowSize = 0;																//
	TCP_Header->UrgentPointer = 0;															//
																							//
	MainBufferWr_Tx = sizeof(T_PPP_Header1) + sizeof(T_IP_Header) + sizeof(T_TCP_Header);	// update index
																							//
	len = IP_Checksum2((char*)TCP_Header, sizeof(T_TCP_Header));							// update the TCP header checksum
//	if (!len) len = 0xffff;																	//
	TCP_Header->Checksum = htons(len);														//
																							//
	IP_Header->ID = htons(IP_ID++);															//
	IP_Header->Checksum = 0;																// update the IP header
	IP_Header->TotalLength = sizeof(T_IP_Header) + sizeof(T_TCP_Header);					// update the IP header
	IP_Header->TotalLength = htons(IP_Header->TotalLength);									//
																							//
	len = (u16)(IP_Header->VerLen & 0x0f);													// number of 32-bit words to the ip header
	len <<= 2;																				// now number of bytes
	len = IP_Checksum1((char*)IP_Header, len);												// update the IP header checksum
//	if (!len) len = 0xffff;																	//
	IP_Header->Checksum = htons(len);														//
																							//
	len = MainBufferWr_Tx;																	//
																							//
	if (!PPP_SendPacket(false)) return;														// send it

	#ifdef Debug
		IP_DisplayProtocol(true, (int)len);													//
		IP_DisplayHeader(sizeof(T_PPP_Header1), (int)len);									//
		TCP_DisplayHeader(sizeof(T_PPP_Header1) + sizeof(T_IP_Header), (int)len);			//
	#endif

	return;
}

// ******************************************************************************************
// this is called from the ip module - every 10ms

void TCP_10ms_Timer(void)
{
	u16				w;
	T_TCP_Socket	*Socket;

	Socket = TCP_Socket;														// we only have the one - for now
	if (Socket == NULL) return;													// no socket to update
																				//
	if (Socket->Stage == TCP_ESTABLISHED)										//
	{																			//
		if (Socket->ConnectTime < 4294967195) Socket->ConnectTime += 10;		//
		if (Socket->LastRxData < 4294967195) Socket->LastRxData += 10;		//
																				//
		if (Socket->AckDelay < 65000)											//
		{																		//
			w = Socket->AckDelay + 10;											//
			if ((Socket->AckDelay < TCP_AckDelay) && (w >= TCP_AckDelay)) Socket->SendAck = true;	// time to send ack back
			Socket->AckDelay = w;												//
		}																		//
	}																			//
																				//
	if ((Socket->Stage == TCP_CLOSED) || (Socket->Stage == TCP_LISTEN)) return;	//
																				//
	if (Socket->Retry_Timer < 65000) Socket->Retry_Timer += 10;					// ms since last packet sent
}

// ******************************************************************************************
// this is called from the ip module
// - it takes care of the TCP link for you

void TCP_Process(void)
{
	T_TCP_Socket	*Socket;

	Socket = TCP_Socket;								// we only have the one - for now
	if (Socket == NULL) return;							// no socket to update
														//
	if (Socket->Stage == TCP_CLOSED)					//
	{													//
		#ifndef StaticTCPSocket
			realloc(Socket, 0);							// free the socket memory
			Socket = 0;									//
		#endif

		Socket = TCP_SocketListen(TCP_Port);			// re-open it for listening
		return;											//
	}													//

	if (Socket->Stage == TCP_LISTEN) return;			// waiting for an incoming connection

	if (Socket->Stage == TCP_ESTABLISHED)											//
	{																				//
		if ((TCP_DataTimeOut) && (u32_Get(&Socket->LastRxData) >= TCP_DataTimeOut))	// tcp no-data timeout
		{																			// disconnect
			TCP_CloseSocket(Socket);												//
			return;																	//
		}																			//
	}																				//

	if (u16_Get(&Socket->Retry_Timer) < (Socket->RoundTripTime * TCP_Retry_Time)) return;	// not time to retry a packet send

	if (Socket->Retries >= TCP_Retries)					//
	{													// give up with the link
		TCP_SocketStage(Socket, TCP_CLOSED);			//
		TCP_SendPacket(Socket, TCP_ACK | TCP_RST);		//
		return;											//
	}													//
														//
	if (MainBufferWr_Rx > 0) return;					// something else is using the buffer atm
	if (MainBufferWr_Tx > 0) return;					//   "

	switch (Socket->Stage)
	{
		case TCP_CLOSED			:	break;
		case TCP_LISTEN			:	break;
		case TCP_SYN_SENT		:
		case TCP_SYN_RECEIVED	:	TCP_SendPacket(Socket, TCP_SYN);
									break;
		case TCP_ESTABLISHED	:	// send any data that needs sending
									if (Socket->TxBufferRd != Socket->TxBufferWr) TCP_SendPacket(Socket, TCP_ACK | TCP_PSH);	// send some data
									else																						//
									if (Socket->SendAck) TCP_SendPacket(Socket, TCP_ACK);										// send ack back
									break;
		case TCP_FIN_WAIT_1		:	TCP_SendPacket(Socket, TCP_FIN | TCP_ACK);
									break;
		case TCP_FIN_WAIT_2		:	// waiting for their FIN packet
									break;
		case TCP_CLOSE_WAIT		:	TCP_SendPacket(Socket, TCP_FIN | TCP_ACK);
									TCP_SocketStage(Socket, TCP_LAST_ACK);
									u16_Put(&Socket->Retry_Timer, 0);
									break;
		case TCP_CLOSING		:
									break;
		case TCP_LAST_ACK		:	TCP_SendPacket(Socket, TCP_FIN | TCP_ACK);
									break;
		case TCP_TIME_WAIT		:	TCP_SocketStage(Socket, TCP_CLOSED);
									break;
		default					:	TCP_SocketStage(Socket, TCP_CLOSED);
									break;
	}
}

// ******************************************************************************************

