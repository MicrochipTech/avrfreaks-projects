
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef commonH
#define commonH

// *********************************************************************************
// compile options

#if defined(__IMAGECRAFT__)
#define CPU_ATmega128
#else
//#if defined(_Z8F640) || defined(_Z8F642)
#define CPU_eZ8
//#endif
#endif

#define Debug										// comment this out to compile without the debug info (debug text sent to the console)

#define ConsoleHandShaking							// comment this out if you don't want console uart hardware handshaking (RTS/CTS)
#define ModemHandShaking							// comment this out if you don't want ppp uart hardware handshaking (RTS/CTS)

// PPP mode to use - ONLY one of these must be used
#define WindowsPPP									//
//#define ATModemPPP									//
//#define GPRS_Orange									//
//#define GPRS_VodaPhone								//

#define IncludeICMP										// include the ICMP code
//#define IncludeUDP										// include the UDP code
//#define IncludeNTP										// include the NTP code
#define IncludeTCP										// include the TCP code

#define StaticTCPSocket								// if this is defined, we use a static TCP socket in memory - ie, not allocated from the heap

// *********************************************************************************

#ifdef CPU_eZ8
	#include <eZ8.h>

    #define flash rom
#endif

#ifdef CPU_ATmega128
	#include <iom128v.h>
	#include <macros.h>

    #define flash const
#endif

// *********************************************************************************
// basic data types

#define true					1
#define false					0

typedef unsigned char			bool;		// 1-byte
typedef unsigned char			u8;			// 1-byte 0..255
typedef signed char			s8;			// 1-byte -128..127

#ifdef CPU_eZ8
typedef unsigned short			u16;		// 2-bytes 0..65535
typedef signed short			s16;		// 2-bytes -32768..32767
typedef unsigned long			u32;		// 4-bytes 0..4294967295
typedef signed long			s32;		// 4-bytes -2147483648..2147483647
#endif

#ifdef CPU_ATmega128
typedef unsigned short			u16;
typedef short					s16;
typedef unsigned long			u32;
typedef long					s32;
//typedef long long				s64;
//typedef unsigned long long		u64;
#endif

// *********************************************************************************
// various defines

#define MainBufferSize	512			//

#define WatchdogTimeout	100000		// 20us increments - 100,000 = 2000ms seconds

#ifdef CPU_eZ8
#define MainClk			18432000	// xtal osc freq
#endif
#ifdef CPU_ATmega128
#define MainClk			7372800		// xtal osc freq
#endif

#define UART0			0
#define UART1			1

#define UART0_BaudRate	115200
#define UART1_BaudRate	19200

#define ConsoleUart		UART0
#define ModemUart		UART1

#ifdef CPU_eZ8
#define TimerIntSpeed	1440		// 10ms timer interrupt ((MainClk / 128) / 1440) = 100 ints per second
#endif
#ifdef CPU_ATmega128
#define TimerIntSpeed	0xdc00		// 10ms timer interrupt ((MainClk / 8) / 9216) = 100 ints per second ... 0xdc00 = -9216
#endif

#define button_debounce	8			// 80ms push button debounce

#define	MPH_2_KNOTS		1.1507771555
#define	KNOTS_2_MPH		0.868978

#define	KNOTS_2_KM		2.478322
#define	KM_2_KNOTS		0.4034988

#define	MPH_2_KM		1.609344
#define	KM_2_MPH		0.6213711

// *********************************************************************************
// Macros

#ifdef CPU_eZ8
#define Disable_Ints()	DI()						// disable global interrupts
#endif
#ifdef CPU_ATmega128
#define Disable_Ints()	CLI()						// disable global interrupts
#endif

#ifdef CPU_eZ8
#define Enable_Ints()	EI()						// Enable global Interrupts
#endif
#ifdef CPU_ATmega128
#define Enable_Ints()	SEI()						// enable global interrupts
#endif

#define ByteSwap2(val)				\
    (((val & 0xff) << 8) |			\
     ((val & 0xff00) >> 8))

#define ByteSwap4(val)				\
    (((val & 0xff) << 24) |			\
     ((val & 0xff00) << 8) |		\
     ((val & 0xff0000) >> 8) |		\
     ((val & 0xff000000) >> 24))

#ifdef CPU_eZ8
//#define	Reset_WD()	WDT;									// reset the watchdog - the zilog compiler ignores this
#define	Reset_WD()	asm("WDT");								// so do it our selves
#endif
#ifdef CPU_ATmega128
#define	Reset_WD()	WDR()
#endif

#ifdef CPU_eZ8
#define RomChar	char rom
#endif
#ifdef CPU_ATmega128
#define RomChar	const char
#endif

// *********************************************************************************
// pins

#ifdef CPU_eZ8

#define RLed_addrPort		PAADDR	// address
#define RLed_oPort			PAOUT	// output
#define RLed_afPort			PAAF	// alternate function
#define RLed_ocPort			PAOC	// output control
#define RLed_ddPort			PADD	// direction
#define RLed_hdePort		PAHDE	// high drive
#define RLed_iPort			PAIN	// input
#define RLed_Pin			0		// bit

#define YLed_addrPort		PAADDR	// address
#define YLed_oPort			PAOUT	// output
#define YLed_afPort			PAAF	// alternate function
#define YLed_ocPort			PAOC	// output control
#define YLed_ddPort			PADD	// direction
#define YLed_hdePort		PAHDE	// high drive
#define YLed_iPort			PAIN	// input
#define YLed_Pin			1		// bit

#define GLed_addrPort		PAADDR	// address
#define GLed_oPort			PAOUT	// output
#define GLed_afPort			PAAF	// alternate function
#define GLed_ocPort			PAOC	// output control
#define GLed_ddPort			PADD	// direction
#define GLed_hdePort		PAHDE	// high drive
#define GLed_iPort			PAIN	// input
#define GLed_Pin			2		// bit

#define TestBut_addrPort	PCADDR	// address
#define TestBut_oPort		PCOUT	// output
#define TestBut_afPort		PCAF	// alternate function
#define TestBut_ocPort		PCOC	// output control
#define TestBut_ddPort		PCDD	// direction
#define TestBut_hdePort		PCHDE	// high drive
#define TestBut_iPort		PCIN	// input
#define TestBut_Pin			0		// bit

#define SS_addrPort			PCADDR	// address
#define SS_oPort			PCOUT	// output
#define SS_afPort			PCAF	// alternate function
#define SS_ocPort			PCOC	// output control
#define SS_ddPort			PCDD	// direction
#define SS_hdePort			PCHDE	// high drive
#define SS_iPort			PCIN	// input
#define SS_Pin				2		// bit

#define SCLK_addrPort		PCADDR	// address
#define SCLK_oPort			PCOUT	// output
#define SCLK_afPort			PCAF	// alternate function
#define SCLK_ocPort			PCOC	// output control
#define SCLK_ddPort			PCDD	// direction
#define SCLK_hdePort		PCHDE	// high drive
#define SCLK_iPort			PCIN	// input
#define SCLK_Pin			3		// bit

#define MOSI_addrPort		PCADDR	// address
#define MOSI_oPort			PCOUT	// output
#define MOSI_afPort			PCAF	// alternate function
#define MOSI_ocPort			PCOC	// output control
#define MOSI_ddPort			PCDD	// direction
#define MOSI_hdePort		PCHDE	// high drive
#define MOSI_iPort			PCIN	// input
#define MOSI_Pin			4		// bit

#define MISO_addrPort		PCADDR	// address
#define MISO_oPort			PCOUT	// output
#define MISO_afPort			PCAF	// alternate function
#define MISO_ocPort			PCOC	// output control
#define MISO_ddPort			PCDD	// direction
#define MISO_hdePort		PCHDE	// high drive
#define MISO_iPort			PCIN	// input
#define MISO_Pin			5		// bit

#define CTS0_addrPort		PAADDR	// address
#define CTS0_oPort			PAOUT	// output
#define CTS0_afPort			PAAF	// alternate function
#define CTS0_ocPort			PAOC	// output control
#define CTS0_ddPort			PADD	// direction
#define CTS0_hdePort		PAHDE	// high drive
#define CTS0_iPort			PAIN	// input
#define CTS0_Pin			3		// bit

#define RTS0_addrPort		PDADDR	// address
#define RTS0_oPort			PDOUT	// output
#define RTS0_afPort			PDAF	// alternate function
#define RTS0_ocPort			PDOC	// output control
#define RTS0_ddPort			PDDD	// direction
#define RTS0_hdePort		PDHDE	// high drive
#define RTS0_iPort			PDIN	// input
#define RTS0_Pin			1		// bit

#define TXD0_addrPort		PAADDR	// address
#define TXD0_oPort			PAOUT	// output
#define TXD0_afPort			PAAF	// alternate function
#define TXD0_ocPort			PAOC	// output control
#define TXD0_ddPort			PADD	// direction
#define TXD0_hdePort		PAHDE	// high drive
#define TXD0_iPort			PAIN	// input
#define TXD0_Pin			5		// bit

#define CTS1_addrPort		PDADDR	// address
#define CTS1_oPort			PDOUT	// output
#define CTS1_afPort			PDAF	// alternate function
#define CTS1_ocPort			PDOC	// output control
#define CTS1_ddPort			PDDD	// direction
#define CTS1_hdePort		PDHDE	// high drive
#define CTS1_iPort			PDIN	// input
#define CTS1_Pin			6		// bit

#define RTS1_addrPort		PDADDR	// address
#define RTS1_oPort			PDOUT	// output
#define RTS1_afPort			PDAF	// alternate function
#define RTS1_ocPort			PDOC	// output control
#define RTS1_ddPort			PDDD	// direction
#define RTS1_hdePort		PDHDE	// high drive
#define RTS1_iPort			PDIN	// input
#define RTS1_Pin			0		// bit

#define TXD1_addrPort		PDADDR	// address
#define TXD1_oPort			PDOUT	// output
#define TXD1_afPort			PDAF	// alternate function
#define TXD1_ocPort			PDOC	// output control
#define TXD1_ddPort			PDDD	// direction
#define TXD1_hdePort		PDHDE	// high drive
#define TXD1_iPort			PDIN	// input
#define TXD1_Pin			5		// bit

#endif

#ifdef CPU_ATmega128

#define RLed_iPort			PINB	// input
#define RLed_oPort			PORTB	// output
#define RLed_ddPort			DDRB	// data direction
#define RLed_Pin			5		//

#define YLed_iPort			PINB	// input
#define YLed_oPort			PORTB	// output
#define YLed_ddPort			DDRB	// data direction
#define YLed_Pin			6		//

#define GLed_iPort			PINB	// input
#define GLed_oPort			PORTB	// output
#define GLed_ddPort			DDRB	// data direction
#define GLed_Pin			7		//

#define TestBut_iPort		PIND	// input
#define TestBut_oPort		PORTD	// output
#define TestBut_ddPort		DDRD	// data direction
#define TestBut_Pin			0		//

#define SS_iPort			PINB	// input
#define SS_oPort			PORTB	// output
#define SS_ddPort			DDRB	// data direction
#define SS_Pin				0		//

#define SCLK_iPort			PINB	// input
#define SCLK_oPort			PORTB	// output
#define SCLK_ddPort			DDRB	// data direction
#define SCLK_Pin			1		//

#define MOSI_iPort			PINB	// input
#define MOSI_oPort			PORTB	// output
#define MOSI_ddPort			DDRB	// data direction
#define MOSI_Pin			2		//

#define MISO_iPort			PINB	// input
#define MISO_oPort			PORTB	// output
#define MISO_ddPort			DDRB	// data direction
#define MISO_Pin			3		//

#define TXD0_iPort			PINE	// input
#define TXD0_oPort			PORTE	// output
#define TXD0_ddPort			DDRE	// data direction
#define TXD0_Pin			1		//

#define CTS0_iPort			PINE	// input
#define CTS0_oPort			PORTE	// output
#define CTS0_ddPort			DDRE	// data direction
#define CTS0_Pin			2		//

#define RTS0_iPort			PINE	// input
#define RTS0_oPort			PORTE	// output
#define RTS0_ddPort		DDRE	// data direction
#define RTS0_Pin			3		//

#define TXD1_iPort			PIND	// input
#define TXD1_oPort			PORTD	// output
#define TXD1_ddPort		DDRD	// data direction
#define TXD1_Pin			3		//

#define CTS1_iPort			PIND	// input
#define CTS1_oPort			PORTD	// output
#define CTS1_ddPort		DDRD	// data direction
#define CTS1_Pin			4		//

#define RTS1_iPort			PIND	// input
#define RTS1_oPort			PORTD	// output
#define RTS1_ddPort		DDRD	// data direction
#define RTS1_Pin			5		//

#define SRAM_CS_oPort		PORTC	// output ................ Atmel STK300 board
#define SRAM_CS_ddPort		DDRC	// data direction ........ Atmel STK300 board
#define SRAM_CS_Pin		7		// pin ................... Atmel STK300 board

#endif

// *********************************************************************************
// TxCTL bits

#ifdef CPU_eZ8

#define TEN					7
#define TPOL				6
#define PRES2				5
#define PRES1				4
#define PRES0				3
#define TMODE2				2
#define TMODE1				1
#define TMODE0				0

#endif

// *********************************************************************************
// IRQ bits

#ifdef CPU_eZ8

// IRQ0
#define T2I					7
#define T1I					6
#define T0I					5
#define U0RXI				4
#define U0TXI				3
#define I2CI				2
#define SPII				1
#define ADCI				0

// IRQ0ENH/L
#define T2EN				7
#define T1EN				6
#define T0EN				5
#define U0REN				4
#define U0TEN				3
#define I2CEN				2
#define SPIEN				1
#define ADCEN				0

// IRQ1
#define PAD7I				7
#define PAD6I				6
#define PAD5I				5
#define PAD4I				4
#define PAD3I				3
#define PAD2I				2
#define PAD1I				1
#define PAD0I				0

// IRQ1ENH/L
#define PAD7EN				7
#define PAD6EN				6
#define PAD5EN				5
#define PAD4EN				4
#define PAD3EN				3
#define PAD2EN				2
#define PAD1EN				1
#define PAD0EN				0

// IRQ2
#define T3I					7
#define U1RXI				6
#define U1TXI				5
#define DMAI				4
#define PC3I				3
#define PC2I				2
#define PC1I				1
#define PC0I				0

// IRQ2ENH/L
#define T3EN				7
#define U1REN				6
#define U1TEN				5
#define DMAEN				4
#define C3EN				3
#define C2EN				2
#define C1EN				1
#define C0EN				0

// IRQES
#define IES7				7
#define IES6				6
#define IES5				5
#define IES4				4
#define IES3				3
#define IES2				2
#define IES1				1
#define IES0				0

// IRQPS
#define PAD7S				7
#define PAD6S				6
#define PAD5S				5
#define PAD4S				4
#define PAD3S				3
#define PAD2S				2
#define PAD1S				1
#define PAD0S				0

// IRQCTL
#define IRQE				7

#endif

// *********************************************************************************
// mower macros

#ifdef CPU_ATmega128

#define outp(val, reg)			(reg = val)
#define inp(reg)				(reg)

#define cbi(reg, bit)			(reg &= ~BIT(bit))
#define sbi(reg, bit)			(reg |= BIT(bit))

#define cbr(reg, mask)			(reg &= ~mask)
#define sbr(reg, mask)			(reg |= mask)

#define bit_is_set(reg, bit)	(reg & (1 << bit))
#define bit_is_clr(reg, bit)	(!(reg & (1 << bit)))

#endif

#define RLed_On		(RLed_oPort &= ~(1 << RLed_Pin))			//
#define RLed_Off	(RLed_oPort |= (1 << RLed_Pin))				//
#define RLed_Toggle	(RLed_oPort ^= (1 << RLed_Pin))				//

#define YLed_On		(YLed_oPort &= ~(1 << YLed_Pin))			//
#define YLed_Off	(YLed_oPort |= (1 << YLed_Pin))				//
#define YLed_Toggle	(YLed_oPort ^= (1 << YLed_Pin))				//

#define GLed_On		(GLed_oPort &= ~(1 << GLed_Pin))			//
#define GLed_Off	(GLed_oPort |= (1 << GLed_Pin))				//
#define GLed_Toggle	(GLed_oPort ^= (1 << GLed_Pin))				//

#define RTS0_OK		(RTS0_oPort &= ~(1 << RTS0_Pin))			// set low - allows the other end to send data
#define RTS0_STOP	(RTS0_oPort |= (1 << RTS0_Pin))				// set high - tells other end to stop sending
#define CTS0		(CTS0_iPort & (1 << CTS0_Pin))				//

#define RTS1_OK		(RTS1_oPort &= ~(1 << RTS1_Pin))			// set low - allows the other end to send data
#define RTS1_STOP	(RTS1_oPort |= (1 << RTS1_Pin))				// set high - tells other end to stop sending
#define CTS1		(CTS1_iPort & (1 << CTS1_Pin))				//

#define TestButton	(TestBut_iPort & (1 << TestBut_Pin))		//

#define SRAM_Enable	(SRAM_CS_oPort &= ~(1 << SRAM_CS_Pin))
#define SRAM_Disable	(SRAM_CS_oPort |= (1 << SRAM_CS_Pin))

// *********************************************************************************
// flags

#define Flags1_USB_Stuff		0	//
#define Flags1_USB_RxPacket		1	//
#define Flags1_ButtonPress		2	//
#define Flags1_UpdatingClock	3	//
#define Flags1_PPP_RxStuff		4	//
#define Flags1_Button			5	// set if the button was held pressed when booting up
#define Flags1_ADC				6	//
#define Flags1_Debug			7	// set if to send debug info to the console

#define Flags2_gga				0
#define Flags2_rmc				1
#define Flags2_gsv				2
#define Flags2_gsa				3
#define Flags2_rtc				4

// *********************************************************************************

typedef union TIPAddr
{
	u8				ip8[4];	// access the ip as either 4 seperate bytes
	u32				ip32;	// ... or as a single 32-bit dword
} T_IP_Addr;

#define TCP_MaxSockets	8
/*
typedef struct TSRAM
{
	#ifdef IncludeTCP
	T_TCP_Socket_Ext	*TCP_Socket[TCP_MaxSockets];
	#endif

} T_SRAM;
*/
// *********************************************************************************
// constants in flash rom

extern flash u16		Version;
extern flash char		VersionStr[];

extern flash char		Title[];
extern flash char		Date[];

#ifdef CPU_ATmega128
//extern char			UnitID[32];	// located in eeprom
#endif

extern flash char		Str3[];

extern flash char		HelpStr[];

#ifdef Debug
extern flash char		Str4[];
#endif

// *********************************************************************************

#ifdef CPU_eZ8

extern near u8				LastResetReason;

extern volatile near u8		WatchdogCounter;

extern volatile near u8		Flags1;
extern volatile near u8		Flags2;

extern volatile near u8		TimerIntCounter;

extern volatile near u8		button_push;

extern volatile near u32	Random32;

extern near u16				MainBufferRd_Rx;
extern near s16				MainBufferWr_Rx;
extern near u16				MainBufferWr_Tx;

extern volatile near u8		UART0_RxBuffer[32];		// UART-0 ring buffer
extern volatile near u8		UART0_RxBufferWr;
extern volatile near u8		UART0_RxBufferRd;

extern volatile near u8		UART1_RxBuffer[96];		// UART-1 ring buffer
extern volatile near u8		UART1_RxBufferWr;
extern volatile near u8		UART1_RxBufferRd;

#endif

#ifdef CPU_ATmega128

extern u8				SRAM;					// external memory

extern u8				LastResetReason;

extern volatile u8		WatchdogCounter;

extern volatile u8		Flags1;
extern volatile u8		Flags2;

extern volatile u8		TimerIntCounter;

extern volatile u8		button_push;

extern volatile u32		Random32;

extern u16				MainBufferRd_Rx;
extern s16				MainBufferWr_Rx;
extern u16				MainBufferWr_Tx;

extern volatile u8		UART0_RxBuffer[32];			// UART-0 ring buffer
extern volatile u8		UART0_RxBufferWr;
extern volatile u8		UART0_RxBufferRd;

extern volatile u8		UART1_RxBuffer[96];			// UART-1 ring buffer
extern volatile u8		UART1_RxBufferWr;
extern volatile u8		UART1_RxBufferRd;

#endif

extern volatile u16		ADC_Input[8];			// this is where the ADC samples are saved too

extern u8				CommandBuffer[32];			// typed console commands end up in here
extern u8				ScratchPad[256];			// for misc use
extern u8				MainBuffer[MainBufferSize];	// the main ppp/udp/tcp etc input and output buffer - yes it's shared

// *********************************************************************************

#ifdef CPU_ATmega128
extern void _StackOverflowed(char c);

extern void EPROMWrite(u16 Addr, u8 Data);
extern u8 EPROMRead(u16 Addr);
extern void EPROMWrite_Data(u16 Addr, u8 *src, u16 len);
extern bool EPROMRead_Data(u16 Addr, u8 *dest, u16 len);

extern void Set_UnitID(char *s);
extern bool Get_UnitID(char *buf);
extern u16 SRAM_Test(void);
#endif

void u16_Put(volatile u16 *pnter, u16 w);
u16 u16_Get(volatile u16 *pnter);
s16 s16_Get(volatile s16 *pnter);
void u32_Put(volatile u32 *pnter, u32 dw);
u32 u32_Get(volatile u32 *pnter);

extern u32 htonl(u32 hostlong);
extern u16 htons(u16 hostshort);
extern u32 ntohl(u32 netlong);
extern u16 ntohs(u16 netshort);

extern int RingBufBytesFree(int BufSize, int Rd, int Wr);
extern int RingBufBytes(int BufSize, int Rd, int Wr);

extern int IP_Str(char *buf, u32 IP);

extern int rstrlen(RomChar *s);
extern void rstrcpy(char *dest, RomChar *src);
extern void rmemcpy(char *dest, RomChar *src, int len);

extern void SPI_Init(void);
extern u8 SPI_TxRxByte(u8 o);

extern void InitUart(char port, unsigned long baud);
extern void HardwareFlowControl(char Uart);
extern bool SendUartByte(char c, char Uart);
extern bool SendUartStr(char *s, char Uart);
extern bool SendUartRStr(RomChar *s, char Uart);
extern bool SendUartData(char *s, u16 len, char Uart);

extern bool SendConsoleByte(char c);
extern bool SendConsoleStr(char *s);
extern bool SendConsoleRStr(RomChar *s);
extern bool SendConsoleData(char *d, u16 len);

#ifdef Debug
extern bool SendDebugByte(char c);
extern bool SendDebugStr(char *s);
extern bool SendDebugRStr(RomChar *s);
extern bool SendDebugData(char *d, u16 len);
#endif

extern bool SendModemByte(char c);
extern bool SendModemRStr(RomChar *s);
extern bool SendModemStr(char *s);

#ifdef Debug
extern void SendDebugDataDump(u8 *Buf, int len);
extern void SendDebugAsciiDump(u8 *Buf, int len);
#endif

extern bool SendHelp(void);

extern int str2ipport(char *buf, u8 *ip, u16 *port);

extern void ProcessUART0(void);

extern int bin2bstr(u8 *Buffer, u32 num, int digits);
extern void strtrim(u8 *s, u8 c);
extern u8 *GetNextParam(u8 *out, u8 *in, u8 delimiter);
extern u8 HexChar2Bin(u8 ascii);

extern int CopyToRingBuffer(u8 *Dest, u8 *Src, int idx, int BufSize, int Bytes);
extern int CopyFromRingBuffer(u8 *Dest, u8 *Src, int idx, int BufSize, int Bytes);

extern void ProcessMainLoop(void);

// *********************************************************************************

#endif

