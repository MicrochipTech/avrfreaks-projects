
/*
 * Copyright (C) 2003-2004 by Clive Moss All rights reserved.
 *
 * Help & Contributions from D.J.Armstrong

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY CLIVE MOSS 'AS IS' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL CLIVE MOSS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL,SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

//#ifdef CPU_eZ8
//	#pragma stkck									// enable stack checking
//#endif

#ifdef CPU_eZ8
	#include <eZ8.h>
#endif

#ifdef CPU_ATmega128
	#include <iom128v.h>
	#include <macros.h>
#endif

#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include "common.h"
#include "fcs.h"
#include "at.h"
#include "ppp.h"
#include "ip.h"

#ifdef IncludeTCP
#include "tcp.h"
#endif

#ifdef IncludeICMP
#include "icmp.h"
#endif

#ifdef IncludeUDP
#include "udp.h"
#endif

#ifdef IncludeNTP
#include "ntp.h"
#endif

// *********************************************************************************
// Flash constants

flash char	Str3[]					=	"\n#####\nRebooted .....\n\n";

flash u16	Version					=	0x0028;				// version (BCD)
flash char	VersionStr[]			=	"Ver: v";

flash char	Title[]					=	"AT/PPP/ICMP/UDP/TCP by C.Moss\n";
flash char	Date[]					=	"5th Feb 2004\n";

flash char	HelpStr[]				=	"\n"
										"  help or ? ........ guess\n"
										"  ipconfig ......... display ip addresses\n"
										"  dial ............. connect\n"
										"  disc ............. disconnect\n"
										#ifdef Debug
										"  debug off ........ debug messages off\n"
										"  debug on ......... debug messages on\n"
										#endif
										#ifdef IncludeICMP
										"  ping <ip> ........ ping\n"
										#endif
										#ifdef IncludeTCP
										"  tcp <ip>[:port] .. tcp into a server\n"
										"  tcp down ......... tcp disconnect\n"
										#endif
										#ifdef IncludeNTP
										"  ntp <ip> ......... sync clock to ntp server\n"
										#endif
										#ifndef WindowsPPP
										"  at<modem cmd> .... gets sent to modem\n"
										#endif
										"  reboot ........... reboot!\n";

#ifdef Debug
flash char	DebugMessagesStr1[]		=	"\n*** Debug Msgs: ";
flash char	DebugMessagesStr2[]		=	"off\n";
flash char	DebugMessagesStr3[]		=	"on\n";
#endif

flash char	RebootingStr[]			=	"\nRebooting ..\n";

#ifdef Debug
flash char	Str4[]					=	"\nButton\n";
#endif

// *********************************************************************************
// EEPROM locations - 4096 bytes
//
// every entry must have it's own crc.
// This means we don't loose the whole lot due to a single byte corruption - which would be
// the case if we just crc error checked the entire eeprom in one go.

#ifdef CPU_ATmega128

#define Unit_ID_Len			32
#define MaxPhoneNumLen		32

#pragma data:eeprom

char			Unit_ID[Unit_ID_Len]			= {""};												// Unit ID
u16				Unit_ID_crc						= 0xffff;

T_IP_Addr		ServerIP1						= {0, 0, 0, 0};										// primary server ip
u16				ServerIP1_crc					= 0xffff;

T_IP_Addr		ServerIP2						= {0, 0, 0, 0};										// seconday server ip
u16				ServerIP2_crc					= 0xffff;

char			ServerPhoneNum1[MaxPhoneNumLen]	= {""};												// primary server phone number
u16				ServerPhoneNum1_crc				= 0xffff;

char			ServerPhoneNum2[MaxPhoneNumLen]	= {""};												// secondary server phone number
u16				ServerPhoneNum2_crc				= 0xffff;

#pragma data:data

#endif

// *********************************************************************************

#ifdef CPU_eZ8

near u8				LastResetReason = 0;

volatile near u8	WatchdogCounter = 0;

volatile near u8	Flags1 = 0;
volatile near u8	Flags2 = 0;

volatile near u8	TimerIntCounter = 0;

volatile near u8	button_push = 255;

volatile near u32	Random32;

near u16			MainBufferRd_Rx = 0;
near s16			MainBufferWr_Rx = -1;
near u16			MainBufferWr_Tx = 0;

volatile near u8	UART0_RxBuffer[32];			// UART-0 ring buffer
volatile near u8	UART0_RxBufferWr = 0;
volatile near u8	UART0_RxBufferRd = 0;

volatile near u8	UART1_RxBuffer[96];			// UART-1 ring buffer
volatile near u8	UART1_RxBufferWr = 0;
volatile near u8	UART1_RxBufferRd = 0;

#endif

#ifdef CPU_ATmega128

u8				LastResetReason = 0;

volatile u8		WatchdogCounter = 0;

volatile u8		Flags1 = 0;
volatile u8		Flags2 = 0;

volatile u8		TimerIntCounter = 0;

volatile u8		button_push = 255;

volatile u32	Random32;

u16				MainBufferRd_Rx = 0;
s16				MainBufferWr_Rx = -1;
u16				MainBufferWr_Tx = 0;

volatile u8		UART0_RxBuffer[32];			// UART-0 ring buffer
volatile u8		UART0_RxBufferWr = 0;
volatile u8		UART0_RxBufferRd = 0;

volatile u8		UART1_RxBuffer[96];			// UART-1 ring buffer
volatile u8		UART1_RxBufferWr = 0;
volatile u8		UART1_RxBufferRd = 0;

#endif

volatile u16	ADC_Input[8];				// this is where the ADC input values are stored

u8				CommandBuffer[32];			// console command buffer
u8				ScratchPad[256];			// general usage buffer for strings etc

//u8				MainBuffer[1550];			// must be big enough for the 1500 ppp/udp/tcp packets
u8				MainBuffer[MainBufferSize];	// - sod that, we just aint got the ram

// *********************************************************************************
// macros

#define BRG(freq, baud) ((unsigned long)(freq) / ((unsigned long)(baud) * 16))

// *********************************************************************************

#ifdef CPU_ATmega128

void _StackOverflowed(char c)
{	// we end up here if a stack overflow occured - this replaces iccavr's routine

	Disable_Ints();
	Reset_WD();

// c = 0 ... software stack overflow
// c = 1 ... hardware stack overflow

	#ifdef Debug
   	SendDebugStr("\n\n*** Stack Overflow\n");	// doubt if this will work - the stack is messed up :(
	#endif

	for (;;);						// infinate loop - let the watch dog reset us
}

#endif

// **************************************************************************
// saftly read multi-byte values from the executive that are modified by an interrupt.
// at the moment, I'm just disabling global ints while I read/set the value - maybe not be the best way to go about this

void u16_Put(volatile u16 *pnter, u16 w)
{
	#ifdef CPU_eZ8
	*pnter = w;									// read the value
	#endif

	#ifdef CPU_ATmega128
	u8 savedSREG = SREG;						// keep interrupt setting
	Disable_Ints();								//
	*pnter = w;									// set the value
	SREG = savedSREG;							// restore interrupt setting
	#endif
}

u16 u16_Get(volatile u16 *pnter)
{
	#ifdef CPU_eZ8
	return *pnter;								// read the value
	#endif

	#ifdef CPU_ATmega128
	u16	w;
	u8 savedSREG = SREG;						// keep interrupt setting
	Disable_Ints();								//
	w = *pnter;									// read the value
	SREG = savedSREG;							// restore interrupt setting
	return w;									//
	#endif
}

s16 s16_Get(volatile s16 *pnter)
{
	#ifdef CPU_eZ8
	return *pnter;								// read the value
	#endif

	#ifdef CPU_ATmega128
	s16	i;
	u8 savedSREG = SREG;						// keep interrupt setting
	Disable_Ints();								//
	i = *pnter;									// read the value
	SREG = savedSREG;							// restore interrupt setting
	return i;									//
	#endif
}

void u32_Put(volatile u32 *pnter, u32 dw)
{
	#ifdef CPU_eZ8
	*pnter = dw;								// set the value
	#endif

	#ifdef CPU_ATmega128
	u8 savedSREG = SREG;						// keep interrupt setting
	Disable_Ints();								//
	*pnter = dw;								// set the value
	SREG = savedSREG;							// restore interrupt setting
	#endif
}

u32 u32_Get(volatile u32 *pnter)
{
	#ifdef CPU_eZ8
	return *pnter;								// read the value
	#endif

	#ifdef CPU_ATmega128
	u32	dw;
	u8 savedSREG = SREG;						// keep interrupt setting
	Disable_Ints();								//
	dw = *pnter;								// read the value
	SREG = savedSREG;							// restore interrupt setting
	return dw;									//
	#endif
}

// **************************************************************************

#ifdef CPU_ATmega128

void EPROMWrite(u16 Addr, u8 Data)
{
	u8 savedSREG;

	savedSREG = SREG;							// keep setting so the interrupt setting can be restored
	Disable_Ints();								//
												//
	for (; bit_is_set(EECR, EEWE); );			// wait for previous write to finish
	EEAR = Addr;								// set address
	EEDR = Data;								// set data
	sbi(EECR, EEMWE);							// set "write enable" bit
	sbi(EECR, EEWE);							// set "write" bit
												//
	SREG = savedSREG;							// restore SREG - ie, the CLI/SEI state
	EEAR = 0;									//
}

u8 EPROMRead(u16 Addr)
{
	for (; bit_is_set(EECR, EEWE); );			// wait for previous write to finish
	EEAR = Addr;								// set address
	sbi(EECR, EERE);							// set "read enable" bit
	EEAR = 0;									//
	return (u8)EEDR;							// return the EEPROM byte
}

void EPROMWrite_Data(u16 Addr, u8 *src, u16 len)
{
	u8	c;
	u16	crc;

	if (!src)											//
	{													// fill with '0'
		for (; len; len--) EPROMWrite(Addr++, 0);		// data
		EPROMWrite(Addr++, 0xff);						// crc LS-Byte
		EPROMWrite(Addr, 0xff);							// crc MS-Byte
		return;											//
	}

	crc = 0xffff;										// init crc
	crc = UpdateFCS_16(crc, 10);						// update crc
	crc = UpdateFCS_16(crc, (u8)(len & 0xff));			// update crc
	crc = UpdateFCS_16(crc, (u8)(len >> 8));			// update crc
	for (; len; len--)									//
	{													//
		c = *src++;										// get byte
		crc = UpdateFCS_16(crc, c);						// update crc
		EPROMWrite(Addr++, c);							// save it into the eeprom
	}													//
	crc = ~crc;											// finalize the crc
	EPROMWrite(Addr++, (u8)(crc & 0xff));				// save LS-Byte of crc
	EPROMWrite(Addr++, (u8)(crc >> 8));					// save MS-Byte of crc
}

bool EPROMRead_Data(u16 Addr, u8 *dest, u16 len)
{
	u8	c;
	u16	i, j;
	u16	crc1, crc2;

	if (!dest) return false;

	// first check the data is valid
	crc1 = 0xffff;										// init crc
	crc1 = UpdateFCS_16(crc1, 10);						// update crc
	crc1 = UpdateFCS_16(crc1, (u8)(len & 0xff));		// update crc
	crc1 = UpdateFCS_16(crc1, (u8)(len >> 8));			// update crc
	i = Addr;											// eeprom address to read from
	for (j = len; j; j--)								//
	{													//
		c = EPROMRead(i++);								// read byte from eeprom
		crc1 = UpdateFCS_16(crc1, c);					// update crc
	}													//
	crc1 = ~crc1;										// finalize the crc
	crc2 = (u16)EPROMRead(i++);							// read LS-Byte of crc
	crc2 |= ((u16)EPROMRead(i)) << 8;					// read MS-Byte of crc
	if (crc1 != crc2)									//
	{													//
		memset(dest, 0, len);							//
		return false;									// data is invalid
	}													//

	// go get the data from the eeprom
	for (; len; len--) *dest++ = EPROMRead(Addr++);		// read byte from eeprom
														//
	return true;										// data is valid
}

#endif

// *********************************************************************************
// set/get the unit id

#ifdef CPU_ATmega128

void Set_UnitID(char *s)
{
	int i;

	char	UnitID[Unit_ID_Len];

	if (!s)															//
	{																//
		EPROMWrite_Data((u16)&Unit_ID, 0, Unit_ID_Len);				//
		return;														//
	}																//

	memset(UnitID, 0, Unit_ID_Len);									//
	i = strlen(s);													//
	if (i >= Unit_ID_Len) i = Unit_ID_Len - 1;						//
	strncpy(UnitID, s, i);											//
	EPROMWrite_Data((u16)&Unit_ID, (u8*)UnitID, Unit_ID_Len);		// write it to eeprom
}

bool Get_UnitID(char *buf)
{
	return EPROMRead_Data((u16)&Unit_ID, (u8*)buf, Unit_ID_Len);	//
}

#endif

// *********************************************************************************
// test the 32K SRAM

#ifdef CPU_ATmega128

u16 SRAM_Test(void)
{
	u8				j;
	register u16	i;
	register u8		b;
	register u8		*p;

   for (j = 0; j < 8; j++)	// do it 16 times
   {
		Reset_WD();

		// fill the ram up with data
		p = &SRAM;
		b = j;
		SRAM_Enable;
		for (i = 0; i < 32768; i++) *p++ = b--;
		SRAM_Disable;

		Reset_WD();

		// now see if the data is as should be
		p = &SRAM;
		b = j;
		SRAM_Enable;
		for (i = 0; i < 32768; i++)
		{
			if (*p++ != b--)
			{
				SRAM_Disable;
				Reset_WD();
				return i;		// return the bad address
			}
		}
		SRAM_Disable;

		Reset_WD();
	}

   return 0xffff;			// past it's test
}

#endif

// *********************************************************************************

u32 htonl(u32 hostlong)
{
	#ifdef CPU_ATmega128
		return ByteSwap4(hostlong);
	#else
		return hostlong;
	#endif
}

u16 htons(u16 hostshort)
{
	#ifdef CPU_ATmega128
		return ByteSwap2(hostshort);
	#else
		return hostshort;
	#endif
}

u32 ntohl(u32 netlong)
{
	return htonl(netlong);
}

u16 ntohs(u16 netshort)
{
	return htons(netshort);
}

// *********************************************************************************
// convert an IP into a string

int IP_Str(char *buf, u32 IP)
{
	T_IP_Addr	ip;

	if (!buf) return 0;

	ip.ip32 = IP;

	return sprintf(buf, "%u.%u.%u.%u", ip.ip8[0], ip.ip8[1], ip.ip8[2], ip.ip8[3]);
}

// *********************************************************************************
// Work out how many bytes are free in a RING BUFFER.
// We must always leave 1 free byte for a ring buffer to work

int RingBufBytesFree(int BufSize, int Rd, int Wr)
{
	if (BufSize <= 0) return 0;				// doh!
	while (Rd >= BufSize) Rd -= BufSize;	// rap around
	while (Wr >= BufSize) Wr -= BufSize;	//  "     "
	if (Wr == Rd) return BufSize - 1;		// buffer is empty
	while (Wr > Rd) Wr -= BufSize;			//
	return (Rd - Wr) - 1;					// number of bytes free
}

// *********************************************************************************
// Work out how many bytes are present in a RING BUFFER.

int RingBufBytes(int BufSize, int Rd, int Wr)
{
	if (BufSize <= 0) return 0;				// doh!
	while (Rd >= BufSize) Rd -= BufSize;	// rap around
	while (Wr >= BufSize) Wr -= BufSize;	//  "     "
	if (Wr == Rd) return 0;					// buffer is empty
	while (Wr < Rd) Wr += BufSize;			//
	return Wr - Rd;							// number of bytes present
}

// *********************************************************************************
// flash (rom) stuff

int rstrlen(RomChar *s)
{	// return the length of a string in rom
	int len = 0;
	if (s)
	{
		for (; *s; s++) len++;
	}
	return len;
}

void rstrcpy(char *dest, RomChar *src)
{	// copy a flash (rom) string into data memory
	if (!dest) return;	// tut tut
	if (src)
	{
		for (; *src; ) *dest++ = *src++;
	}
	*dest = 0;	// null terminate it
}

void rmemcpy(char *dest, RomChar *src, int len)
{	// copy a block of data from flash (rom) into data memory
	if (!dest) return;
	if (!src) return;
	for (; len; len--) *dest++ = *src++;
}

// *********************************************************************************
// SPI stuff

void SPI_Init(void)
{	// setup the spi

	#ifdef CPU_eZ8
//	PCAF = 0x3c;									// Enable Port C for SPI functions
//	PCADDR = 0;										// protect sub registers

//	SPICTL = PHASE_ONE | MMEN_MASTER | SPI_ENABLE; 	// SCK Phase One, SPI Master, SPI enable,
  													// CLK Polarity=0->falling edge for internal strobe
//	SPIMODE = SSIO_OUTPUT; 							// SS pin select as an output, SS pin low
//	SPIBRH = 0x00; 									// BRG High
//	SPIBRL = 0x9c; 									// BRG Low
	asm("nop");
    #endif

	#ifdef CPU_ATmega128
	// SPI initialisation
	// clock rate: 3686400hz (with 7.3728Mhz xtal)

	SPCR = 0;									// disable SPI
	SPSR = (1 << SPI2X);						// 2X
	SPCR = (1 << SPE) | (1 << MSTR);			// enable SPI ... no interrupt, SPI enable, MSB 1st, Master mode, Fosc/2

//	SPDR = 0x55;								// sends a 0x55 byte out the spi
//	while (bit_is_clr(SPSR, SPIF));				// wait for transmission to finish
//	c = SPDR;									// this is needed

//	SPDR = 0;									// write a dummy byte - this is to generate the SCK for reading
//	while (bit_is_clr(SPSR, SPIF));				// wait for rx byte to arrive
//	c = SPDR;									// reads a rx'ed byte
	#endif

}

u8 SPI_TxRxByte(u8 o)
{	// send and receive bytes to/from the spi
	u8 i;							//

	#ifdef CPU_eZ8
	i = 0;
	#endif

	#ifdef CPU_ATmega128
	SPDR = o;						// send byte down spi
	while (!(SPSR & (1<<SPIF)));	// wait for byte to go
	i = SPDR;						// get byte from spi
	#endif

	return i;						// return byte got
}

// *********************************************************************************
// uart stuff

#ifdef CPU_eZ8
void InitUart(char port, unsigned long baud)
{
    unsigned long	brg;

	// calculate the divider value
    brg = MainClk / (baud * 16);

    switch (port)
    {
        case UART0	:	// set the baud-rate generater
			            U0BRH = brg >> 8;
			            U0BRL = brg & 0xFF;

			            // configure GPIO for alternate function
			            PAAF |= 0x30;				// enable the UART0 Rx/Tx with the AF register
			            PAADDR = 0;					// clear to protect sub-regiters

			            // configure UART control register 1
			            U0CTL1 = 0x00;				// clear for normal non-Multiprocessor operation

			            // configure UART control register 1
			            U0CTL0 = 0xc0;				// Transmit enable, Receive Enable, No Parity, 1 Stop
			            break;
        case UART1	:	// set the baud-rate generater
			            U1BRH = brg >> 8;
			            U1BRL = brg & 0xFF;

			            // configure GPIO for alternate function
			            PDAF |= 0x30;				// enable the UART1 Rx/Tx with the AF register
			            PDADDR = 0;					// clear to protect sub-regiters

			            // configure UART control register 1
			            U1CTL1 = 0x00;				// clear for normal non-Multiprocessor operation

			            // configure UART control register 1
			            U1CTL0 = 0xc0;				// Transmit enable, Receive Enable, No Parity, 1 Stop
			            break;
    }
}

#endif

#ifdef CPU_ATmega128

void InitUart(char port, unsigned long baud)
{
    u16		brg;

	// calculate the divider value
    brg = (MainClk / (baud * 8)) - 1;	// double speed formula

    switch (port)
    {
        case UART0	:	// 8-bit 1-stop no-parity async ... 7 = 115200 baud
						UCSR0B = 0;											// disable while setting it up

						UBRR0H = (u8)(brg >> 8);							// set baud rate hi
						UBRR0L = (u8)(brg & 0xff);							// set baud rate lo

						UCSR0A = (1<<U2X0);									// double speed
						UCSR0C = (1<<UCSZ00)|(1<<UCSZ01)|(1<<UCSZ00);		// 8-bit 1-stop
						UCSR0B = (1<<RXCIE0)|(1<<RXEN0)|(1<<TXEN0);			// enable Tx/Rx

			            break;
        case UART1	:	// 8-bit 1-stop no-parity async .. 47 = 19200 baud
				        UCSR1B = 0;											// disable while setting baud rate

						UBRR1H = (u8)(brg >> 8);							//set baud rate hi
						UBRR1L = (u8)(brg & 0xff);							//set baud rate lo

						UCSR1A = (1<<U2X1);									// double speed
						UCSR1C = (1<<UCSZ10)|(1<<UCSZ11)|(1<<UCSZ10);		// 8-bit 1-stop
						UCSR1B = (1<<RXCIE1)|(1<<RXEN1)|(1<<TXEN1);			// enable Tx/Rx
			            break;
    }
}

#endif

bool SendUartByte(char c, char Uart)
{	// send a byte down a uart
	u16	UART_TimeOut = 10000;

	switch (Uart)
 	{
    	case UART0	:	while (true)
						{
							UART_TimeOut--;
							if (!UART_TimeOut) return false;				// timed out

							#ifdef ConsoleHandShaking
							if (CTS0) continue;								// other end not yet ready
							#endif

							#ifdef CPU_eZ8
							if (U0STAT0 & 0x04) break;						// clear to send another byte
                            #endif

							#ifdef CPU_ATmega128
							if (UCSR0A & (1 << UDRE0)) break;				// clear to send another byte
                            #endif
						}
						#ifdef CPU_eZ8
						U0D = c;											// Send byte
						#endif
						#ifdef CPU_ATmega128
						UDR0 = c;											// Send byte
                        #endif
						break;
    	case UART1	:	while (true)
						{
							UART_TimeOut--;
							if (!UART_TimeOut) return false;				// timed out

							#ifdef ModemHandShaking
							if (CTS1) continue;								// other end not yet ready
							#endif

							#ifdef CPU_eZ8
							if (U1STAT0 & 0x04) break;						// clear to send another byte
                            #endif

							#ifdef CPU_ATmega128
							if (UCSR1A & (1 << UDRE1)) break;				// clear to send another byte
                            #endif
						}
						#ifdef CPU_eZ8
						U1D = c;											// Send byte
						#endif
						#ifdef CPU_ATmega128
						UDR1 = c;											// Send byte
                        #endif
						break;
		default		:	return false;										//
	}

	return true;
}

void HardwareFlowControl(char Uart)
{	// do some hardware flow control - ie, set their CTS line accordingly
	int	i;

	switch (Uart)
	{
		case UART0	:	i = RingBufBytesFree(sizeof(UART0_RxBuffer), UART0_RxBufferRd, UART0_RxBufferWr);		// work out how many bytes we have free in our buffer
						if (i > 18)																				// this value seems to have to be at least as big as the fifo buffer on the pc's uart
							RTS0_OK;																			// we're ok to rx more data
						else																					//
							RTS0_STOP;																			// tell em to stop sending data
						break;																					//
		case UART1	:	i = RingBufBytesFree(sizeof(UART1_RxBuffer), UART1_RxBufferRd, UART1_RxBufferWr);		// work out how many bytes we have free in our buffer
						if (i > 18)																				// this value seems to have to be at least as big as the fifo buffer on the pc's uart
							RTS1_OK;																			// we're ok to rx more data
						else																					//
							RTS1_STOP;																			// tell em to stop sending data
						break;
	}
}

bool SendUartStr(char *s, char Uart)
{	// Send a string down a uart
	char	c;

	if (!s) return true;

	for (;*s;)
	{
		c = *s++;
		if (c == '\n')
	 	{	// insert a CR (\r) before the LF (\n)
  			if (!SendUartByte('\r', Uart)) return false;			// Send byte
		}
		if (!SendUartByte(c, Uart)) return false;					// Send byte
	}

	return true;
}

bool SendUartRStr(RomChar *s, char Uart)
{	// send a string from rom
	char	c;

	if (!s) return true;

	for (;*s;)
	{
		c = *s++;
		if (c == '\n')
	 	{	// insert a CR (\r) before the LF (\n)
  			if (!SendUartByte('\r', Uart)) return false;				// Send byte
		}
		if (!SendUartByte(c, Uart)) return false;						// Send byte
	}

	return true;
}

bool SendUartData(char *s, u16 len, char Uart)
{	// Send data down a uart
	char	c;

	if (!s) return true;

	for (; len; len--)
	{
		c = *s++;
		if (!SendUartByte(c, Uart)) return false;					// Send byte
	}

	return true;
}

bool SendConsoleByte(char c)
{	// send a byte
	return SendUartByte(c, ConsoleUart);
}

bool SendConsoleStr(char *s)
{	// send a string from ram
	return SendUartStr(s, ConsoleUart);
}

bool SendConsoleRStr(RomChar *s)
{	// send a string from rom
	return SendUartRStr(s, ConsoleUart);
}

bool SendConsoleData(char *d, u16 len)
{	// send data from ram
	return SendUartData(d, len, ConsoleUart);
}

#ifdef Debug

bool SendDebugByte(char c)
{	// send a byte
	if (!(Flags1 & (1<<Flags1_Debug))) return true;					// don't bother with debug unless the debug flag is set
	return SendUartByte(c, ConsoleUart);
}

bool SendDebugStr(char *s)
{	// send a string from ram
	if (!(Flags1 & (1<<Flags1_Debug))) return true;					// don't bother with debug unless the debug flag is set
	return SendUartStr(s, ConsoleUart);
}

bool SendDebugRStr(RomChar *s)
{	// send a string from rom
	if (!(Flags1 & (1<<Flags1_Debug))) return true;					// don't bother with debug unless the debug flag is set
	return SendUartRStr(s, ConsoleUart);
}

bool SendDebugData(char *d, u16 len)
{	// send data from ram
	if (!(Flags1 & (1<<Flags1_Debug))) return true;					// don't bother with debug unless the debug flag is set
	return SendUartData(d, len, ConsoleUart);
}

bool SendDebugState(void)
{
	if (!SendConsoleRStr(DebugMessagesStr1)) return false;
	if (Flags1 & (1<<Flags1_Debug))
		return SendConsoleRStr(DebugMessagesStr3);
	else
		return SendConsoleRStr(DebugMessagesStr2);
}
#endif

bool SendModemByte(char c)
{
	return SendUartByte(c, ModemUart);
}

bool SendModemRStr(RomChar *s)
{
	return SendUartRStr(s, ModemUart);
}

bool SendModemStr(char *s)
{
	return SendUartStr(s, ModemUart);
}

#ifdef Debug

void SendDebugDataDump(u8 *Buf, int len)
{	// send a hex dump
	int		i;									//
	u8		b;									//
	char	buffer[8];							//
												//
	if (!Buf) return;							//
												//
	for (i = 0; i < len; i++)					//
	{											//
		b = *Buf++;								//
		sprintf(buffer, " %02X", b);			//
		if (!SendDebugStr(buffer)) return;		//
	}											//
	SendDebugStr("\n");							//
}

void SendDebugAsciiDump(u8 *Buf, int len)
{	// send a text dump
	int		i;										//
	u8		b;										//
	char	buffer[8];								//
													//
	if (!Buf) return;								//
													//
	for (i = 0; i < len; i++)						//
	{												//
		b = *Buf++;									//
		if ((b < 32) || (b > 127))					//
		{											//
			sprintf(buffer, " %02X", b);			//
			if (!SendDebugStr(buffer)) return;		//
		}											//
		else										//
		{											//
			if (!SendDebugByte(b)) return;			//
		}											//
	}												//
	SendDebugStr("\n");								//
}

bool SendADCInputs(void)
{
	int i;														//
	s16	j;														//
	for (i = 0; i < 8; i++)										//
	{															//
		j = s16_Get((s16*)&ADC_Input[i]);						//
		sprintf((char*)ScratchPad, "ADC-%d: %u\n", i, j);		//
		if (!SendDebugStr((char*)ScratchPad)) return false;		//
	}															//
	return true;												//
}

#endif

bool SendHelp(void)
{
	if (!SendConsoleRStr(HelpStr)) return false;

	#ifdef Debug
		if (!SendDebugState()) return false;
		if (!SendADCInputs()) return false;
		if (!AT_DisplayStage()) return false;
		if (!PPP_DisplayStage()) return false;

		sprintf((char*)ScratchPad, "\nMainBufferWr_Rx: %d\n", MainBufferWr_Rx);
		SendDebugStr((char*)ScratchPad);
		sprintf((char*)ScratchPad, "MainBufferWr_Tx: %d\n", MainBufferWr_Tx);
		SendDebugStr((char*)ScratchPad);

		#ifdef IncludeTCP
		TCP_DisplaySocketState(TCP_Socket);
		#endif
	#endif

	return true;
}

// **************************************************************************

int bin2bstr(u8 *Buffer, u32 num, int digits)
{
	register u8		*p = Buffer;		// buffer to save the text into
	register u32	i;					// bit mask
										//
	if (digits-- <= 0) return 0;		// no digits
	if (!p) return 0;					// no buffer
										//
	i = 1;								//
	i <<= digits;						// bit mask
	while (i)							//
	{									//
		if (num & i)					//
			*p++ = '1';					//
		else							//
			*p++ = '0';					//
		i >>= 1;						//
	}									//
	*p = 0;								//
										//
	return strlen(Buffer);				// return number of characters
}

// **************************************************************************
// trim a string of it's leading and trailing characters

void strtrim(u8 *s, u8 c)
{
	u8		i, j, *p1, *p2;

	if (s == 0) return;

	// delete the trailing characters
	if (*s == 0) return;
	j = strlen(s);
	p1 = s + j;
	for (i = 0; i < j; i++)
	{
	   	p1--;
	   	if (*p1 != c) break;
	}
	if (i < j) p1++;
	*p1 = 0;	// null terminate the undesired trailing characters

	// delete the leading characters
  	p1 = s;
	if (*p1 == 0) return;
	for (i = 0; *p1++ == c; i++);
	if (i > 0)
	{
		p2 = s;
	 	p1--;
		for (; *p1 != 0;) *p2++ = *p1++;
		*p2 = 0;
	}
}

// **************************************************************************
/*
u8 *GetNextParam(u8 *out, u8 *in, u8 delimiter)
{
	if (in == 0) return 0;
	if (out == 0) return 0;
	*out = 0;
	if (*in == 0) return 0;

	// extract the parameter
	for (; ((*in != delimiter) && *in);) *out++ = *in++;
	*out = 0;
	strtrim(out, ' ');									// delete leading and trailing spaces

	if ((*in == delimiter) && (*in != 0)) *in++ = 0; // null term current param and skip the delimiter

	strtrim(out, '(');									// delete leading and trailing '('
	strtrim(out, ')');									// delete leading and trailing ')'
	strtrim(out, '\"');									// delete leading and trailing '"'

	return in;
}
*/
// **************************************************************************
// convert a hex character into a 4-bit binary value
/*
u8 HexChar2Bin(u8 ascii)
{
	if ((ascii >= '0') && (ascii <= '9')) return (ascii - '0');
	if ((ascii >= 'A') && (ascii <= 'F')) return ((ascii - 'A') + 10);
	if ((ascii >= 'a') && (ascii <= 'f')) return ((ascii - 'a') + 10);
	return 0;
}
*/

// **************************************************************************

int str2ipport(char *buf, u8 *ip, u16 *port)
{	// convert an ip:port string into a binary values
	int	i;
	u16	_ip[4], _port;

	_port = 0;
	memset(_ip, 0, sizeof(_ip));

	strtrim((u8*)buf, ' ');

	i = sscanf(buf, "%u.%u.%u.%u:%u", &_ip[0], &_ip[1], &_ip[2], &_ip[3], &_port);

	*(u8*)(ip + 0) = (u8)_ip[0];
	*(u8*)(ip + 1) = (u8)_ip[1];
	*(u8*)(ip + 2) = (u8)_ip[2];
	*(u8*)(ip + 3) = (u8)_ip[3];
	*port = _port;

	return i;
}

void ProcessUART0(void)
{	// process received uart0 data (console text commands)
	u8				ip[4];
	u16				w;
	char			c;
	int				i;
	#ifdef IncludeTCP
	T_TCP_Socket	*Socket = NULL;
	#endif

	if (UART0_RxBufferRd == UART0_RxBufferWr) return;							// no new bytes rx'ed
	c = UART0_RxBuffer[UART0_RxBufferRd++];										// get byte
	if (UART0_RxBufferRd >= sizeof(UART0_RxBuffer)) UART0_RxBufferRd = 0;	// wap awound

	#ifdef ConsoleHandShaking
	HardwareFlowControl(ConsoleUart);											// tell em to stop sending data if our buffer is full
	#endif

	i = strlen((char*)CommandBuffer);
	if (i >= (sizeof(CommandBuffer) - 1)) goto end;								// drop the buffer contents - buffer overflow

	if (c != 13)
	{	// add new byte into command buffer
		if (c >= 32)
		{	// ascii character
			CommandBuffer[i++] = tolower(c);
			CommandBuffer[i] = 0;
		}
		return;
	}

	// process the new command

	strtrim(CommandBuffer, ' ');
	if (CommandBuffer[0] == 0) goto end;

	if ((strcmp((char*)CommandBuffer, "help") == 0) || (strcmp((char*)CommandBuffer, "?") == 0))
	{	// send them help
		SendHelp();
		goto end;
	}

	if (strcmp((char*)CommandBuffer, "ipconfig") == 0)
	{	// send them all the ip addresses
		PPP_DisplayIP();
		goto end;
	}

	if (strcmp((char*)CommandBuffer, "dial") == 0)
	{	// connect
		if (AT.Stage != AT_Idle) goto end;
		AT_Start();
 		goto end;
	}

	if (strcmp((char*)CommandBuffer, "disc") == 0)
	{	// disconnect
		AT_End();
		goto end;
	}

	#ifdef Debug

	if (strcmp((char*)CommandBuffer, "debug off") == 0)
	{	// disable the debug messages
		Flags1 &= ~(1<<Flags1_Debug);				// clear flag
		SendDebugState();
		goto end;
	}

	if (strcmp((char*)CommandBuffer, "debug on") == 0)
	{	// enable the debug messages
		Flags1 |= (1<<Flags1_Debug);				// set flag
		SendDebugState();
		goto end;
	}

	#endif

	#ifdef IncludeTCP
	if (strcmp((char*)CommandBuffer, "tcp down") == 0)
	{	// disconnect the tcp link
		TCP_CloseSocket(TCP_Socket);
		goto end;
	}
	#endif

	if (strcmp((char*)CommandBuffer, "reboot") == 0)
	{
		AT_End();									// close the network links
		while (AT.Stage != AT_Idle)					//
		{											//
			ProcessMainLoop();						// let the tcp/ppp link close gracefully
		}											//
													//
		SendConsoleRStr(RebootingStr);				//

		Disable_Ints();								// disable global interrupts

		RLed_On;									// Red led on
		YLed_On;									// Yellow led on
		GLed_On;									// Green led on

		#ifdef CPU_eZ8
		WDTCTL = 0x55;								// unock the watchdog - so we set it's time out
		WDTCTL = 0xAA;								//   "    "    "
		WDTU = 0;									// Set the timeout to a very short value
		WDTH = 0;									//  "   "     "
		WDTL = 10;									//  "   "     "
		Reset_WD();									//
		#endif

		for (;;);									// let the watchdog reset us
	}

	#ifdef IncludeICMP
	if ((strlen((char*)CommandBuffer) >= 4) && (strncmp((char*)CommandBuffer, "ping", 4) == 0))
	{
		i = str2ipport((char*)CommandBuffer + 4, ip, &w);
		if (i < 4) goto end;
		ICMP_Out(*(u32*)ip);
		goto end;
	}
	#endif

	#ifdef IncludeNTP
	if ((strlen((char*)CommandBuffer) >= 3) && (strncmp((char*)CommandBuffer, "ntp", 3) == 0))
	{
		i = str2ipport((char*)CommandBuffer + 3, ip, &w);
		if (i < 4) goto end;
		NTP_RequestSNTP(*(u32*)ip);
		goto end;
	}
	#endif

	#ifdef IncludeTCP
	if ((strlen((char*)CommandBuffer) >= 3) && (strncmp((char*)CommandBuffer, "tcp", 3) == 0))
	{
		i = str2ipport((char*)CommandBuffer + 3, ip, &w);
		if (i < 4) goto end;
		if (i <= 4) w = TCP_Port;
		if (TCP_Socket != NULL)
		{
			if ((TCP_Socket->Stage != TCP_LISTEN) && (TCP_Socket->Stage != TCP_CLOSED)) goto end;		// socket is already in use
		}
		TCP_Socket = TCP_OpenSocket(*(u32*)ip, w);
		goto end;
	}
	#endif

	#ifndef WindowsPPP
	if ((strlen((char*)CommandBuffer) >= 2) && (strncmp((char*)CommandBuffer, "at", 2) == 0))
	{	// modem command
		strcat((char*)CommandBuffer, "\n");				// add a CR
		SendModemStr(CommandBuffer);
		goto end;
	}
	#endif

end:
	memset(CommandBuffer, 0, sizeof(CommandBuffer));
}

// **************************************************************************

int CopyToRingBuffer(u8 *Dest, u8 *Src, int idx, int BufSize, int Bytes)
{	// move data from a linear buffer into a ring buffer
	int	i, j, k;

	if ((!Dest) || (!Src) || (Bytes <= 0) || (BufSize <= 0)) return 0;	//
																		//
	j = Bytes;															//
	for (; Bytes > 0; )													//
	{																	//
		i = Bytes;														//
		k = BufSize - idx;												//
		if (i > k) i = k;												//
		memcpy(Dest + idx, Src, i);										// add the bytes to the ring buffer
		Src += i;														//
		idx += i;														//
		while (idx >= BufSize) idx -= BufSize;							// rap around
		Bytes -= i;														//
	}																	//
																		//
	return j;															//
}

int CopyFromRingBuffer(u8 *Dest, u8 *Src, int idx, int BufSize, int Bytes)
{	// move data from a ring buffer into a linear buffer
	int	i, j, k;

	if ((!Dest) || (!Src) || (Bytes <= 0) || (BufSize <= 0)) return 0;	//
																		//
	j = Bytes;															//
	for (; Bytes > 0; )													//
	{																	//
		i = Bytes;														//
		k = BufSize - idx;												//
		if (i > k) i = k;												//
		memcpy(Dest, Src + idx, i);										// add the bytes to the linear buffer
		Dest += i;														//
		idx += i;														//
		while (idx >= BufSize) idx -= BufSize;							// rap around
		Bytes -= i;														//
	}																	//
																		//
	return j;															//
}

// *********************************************************************************

void ProcessMainLoop(void)
{
	ProcessUART0();					//
	AT_Process();					//
	PPP_Process();					//
}

// **************************************************************************

