#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
 int  M,N,E,I,D ;

    while (1)
   {    
           printf("\n Bresenham's algorithm - equaly distribute N in M ");
           printf("\n ");
           printf("\n Enter M: ");
           scanf("%d",&M);
           printf(" Enter N: ");
           scanf("%d",&N);
           printf("\n ");
           
           E= 2*N - M;
            
            for(I=0 ; I<M ; I++)
             {
                if (E>=0)
                 {
                  E=E + 2*(N-M);
                  printf("1 "); 
                  }
                 else
                  {
                   E=E + 2*N;
                   printf("0 ");    
                  } 
              } 
             printf("\n "); 
             
        
                  
             
}
 //  system("PAUSE");	
  return 0;
}
