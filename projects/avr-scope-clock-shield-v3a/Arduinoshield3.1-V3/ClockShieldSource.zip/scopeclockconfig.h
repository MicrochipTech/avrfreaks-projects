; ScopeClockConfig.h - included source for Dutchtronix Oscilloscope Clock
;
;  Copyright � 2008 Johannes P.M. de Rie
;
;  All Rights Reserved
;
;  This file is part of the Dutchtronix Oscilloscope Clock Distribution.
;  Use, modification, and re-distribution is permitted subject to the
;  terms in the file named "LICENSE.TXT", which contains the full text
;  of the legal notices and should always accompany this Distribution.
;
;  This software is provided "AS IS" with NO WARRANTY OF ANY KIND.
;
;  This notice (including the copyright and warranty disclaimer)
;  must be included in all copies or derivations of this software.
;
; Firmware for Dutchtronix AVR Oscilloscope Clock
;
#if Mega168
;
; 8 bit parallel data (7..0) is mapped to PC3..PC0 PB3..PB0 for Hardware 3.0 and up.
; DACA/DACB select is mapped to PD3 (low is A)
; WR (active low) is mapped to PD4
; LED (active high) or NET input is mapped to PD6
; Hardware 3.0 and up:
;	LDAC is mapped to PD5
;	Z control is mapped to PD7
; Hardware 3.1 and up:
;	Tactile Switch 1 is mapped to PB4
;	Tactile Switch 2 is mapped to PB5
;
#define	LED_DDR DDRD
#define	LED_PORT PORTD
#define	LED_PIN PIND
#define	LED_BIT 6
#define	PPS_IN PORTD,2
#define DACSELECT	PORTD,3
#define DACWR PORTD,4
#define DACCTLDDR DDRD

#define DACHIDATA PORTC
#define DACLODATA PORTB
#define	DACHIDDR  DDRC
#define	DACLODDR  DDRB
#define DACLDAC PORTD,5
#define DACZX PORTD,7
#define	DACZXDDR  DDRD,7
;
; use PB4 and PB5 as input lines
;
#define	SW_DDR DDRB
#define	SW_PORT PORTB
#define	SW_PIN PINB
#define	SW_BIT 4
#define	SW2_BIT 5
;
.EQU	PORT_RTC  =  PORTC
.EQU	DDR_RTC   =  DDRC
.EQU	PIN_RTC   =  PINC
.EQU	BIT_SDA   =  4
.EQU	BIT_SCL   =  5

#elif Mega32
#define	LED_DDR DDRC
#define	LED_PORT PORTC
#define	LED_PIN PINC
#define	LED_BIT 0
#define	LED2_BIT 1
;
; Note that the code relies on the fact that PORTD, pin 3 is the INT1 interrupt
;
#define	SW_DDR DDRD
#define	SW_PORT PORTD
#define	SW_PIN PIND
#define	SW_BIT 3
#define	PPS_IN PORTD,2
;
; 8 bit parallel data (7..0) is mapped to PA7..PA0
; DACA/DACB select is mapped to PD3 (low is A)
; WR (active low) is mapped to PD4
;
#define DACDATA PORTA
#define DACSELECT	PORTB,3
#define DACWR PORTB,4
#define DACZX PORTB,5
#define	DACDATADDR  DDRA
#define DACCTLDDR DDRB
;
.EQU	PORT_RTC  =  PORTB
.EQU	DDR_RTC   =  DDRB
.EQU	PIN_RTC   =  PINB
.EQU	BIT_SDA   =  0
.EQU	BIT_SCL   =  1
#endif

