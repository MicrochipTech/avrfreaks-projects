//
//  AVR Oscilloscope Clock Display Tables Generator, originally written 
//	 by Sascha Ittner ((c) 2004 GPL).
//
// Updated for Dutchtronix AVR Oscilloscope clock by Jan de Rie 2007-2008
//
// X,Y coordinates start in lower left corner (0,0)
//
// Make sure that the ESCAPE char is never generated in the vector tables
// 
#include <stdio.h>
#include <math.h>

#define INVERT(x) (256 - (x))
#define M_PI 3.14159265358979323846

void MakeScale(char *name, float r, float len1, float len2, float len3);
void MakeSimplePtr(char *name, float r1);
void MakeTriangPtr(char *name, float r1, float r2);
void MakeNum(char *name, int x, int y, int height, int width, int val, int term, int force, int fEnabled);
void MakeNum3(char *name, int x, int y, int val, int term, int force, int fEnabled);
void MakeRomanLetter(char *name, int x, int y, int val, int term, int force, int fEnabled);

int NumCount = 0;	// force even number of bytes per line

int main(void) {
  float r = 105.0, a;
  int dig, x1, y1;

  printf(";\n");
  printf("; Data for Dutchtronix Oscilloscope Clock	\n");
  printf(";\n");
  printf("\n");

  MakeScale("DialData:",126,5,10,12);
  printf("\n");
//
// Regular Dial Numbers
//
  for(dig=0; dig<60; dig += 5) {
    a=((float)(dig*6))/180*M_PI;
    x1=(int)(128+sin(a)*r);
	y1=(int)(128-cos(a)*r);
	switch (dig) {
		case 0:  MakeNum3("DialDigits:",x1-6, INVERT(30), 1,0, 0, 1);
				 MakeNum3(NULL         ,x1+6, INVERT(30), 2,0, 0, 1);
				 break;
		case 5:  MakeNum3(NULL		 , x1+1, INVERT(y1),  (dig / 5),0, 1, 1);
				 break;
		case 10: MakeNum3(NULL		 , x1-2, INVERT(y1),  (dig / 5),0, 1, 1); break;
		case 15: MakeNum3(NULL        ,   x1, INVERT(y1) , 3,0, 0, 1);
				 break;
		case 20: MakeNum3(NULL		 ,   x1, INVERT(y1),  (dig / 5),0, 1, 1); break;
		case 25: MakeNum3(NULL		 , x1-2, INVERT(y1-2),  (dig / 5),0, 1, 1); break;
		case 30: MakeNum3(NULL        ,   x1, INVERT(y1)+3 , 6,0, 0, 1);
				 break;
		case 35: MakeNum3(NULL		 , x1+2, INVERT(y1-2),  (dig / 5),0, 1, 1); break;
		case 40: MakeNum3(NULL		 ,  x1,  INVERT(y1) , (dig / 5),0, 1, 1); break;
		case 45: MakeNum3(NULL        ,   x1, INVERT(y1) , 9,0, 1, 1);
				 break;
		case 50: MakeNum3(NULL		 , x1-4, INVERT(y1) ,            1,0, 1, 1); 
				 MakeNum3(NULL		 , x1+8, INVERT(y1) , 		   0,0, 1, 1); break;
		case 55: MakeNum3(NULL		 , x1-2, INVERT(y1) , 		   1,0, 1, 1);
				 MakeNum3(NULL		 , x1+8, INVERT(y1) , 		   1,0xff, 1, 1); break;
	}
  }
//
// 24 Hrs format Dial Numbers
//
  for(dig=0; dig<60; dig += 5) {
    a=((float)(dig*6))/180*M_PI;
    x1=(int)(128+sin(a)*r);
	y1=INVERT((int)(128-cos(a)*r));
	switch (dig) {
		case 0:  MakeNum("DialDigits24:",x1-7, y1,   3,3, 2,0, 0, 1);
				 MakeNum(NULL           ,x1+7, y1,   3,3, 4,0, 0, 1); break;
		case 5:  MakeNum(NULL		    ,x1-10, y1-2,3,3, 1,0, 1, 1);
				 MakeNum(NULL		    ,x1+2, y1-2, 3,3, 3,0, 1, 1);break;
		case 10: MakeNum(NULL		    ,x1-10, y1-2,3,3, 1,0, 1, 1);
				 MakeNum(NULL		    ,x1+2, y1-2, 3,3, 4,0, 1, 1); break;
		case 15: MakeNum(NULL           ,x1-12,y1,   3,3, 1,0, 0, 1);
				 MakeNum(NULL           ,x1, y1,     3,3, 5,0, 0, 1); break;
		case 20: MakeNum(NULL		    ,x1-10, y1,  3,3, 1,0, 1, 1);
				 MakeNum(NULL		    ,x1+2, y1,   3,3, 6,0, 1, 1); break;
		case 25: MakeNum(NULL		    ,x1-10,y1-2, 3,3, 1,0, 1, 1);
				 MakeNum(NULL		    ,x1+2, y1-2, 3,3, 7,0, 1, 1); break;
		case 30: MakeNum(NULL           ,x1-4, y1,   3,3, 1,0, 0, 1);
				 MakeNum(NULL           ,x1+7, y1,   3,3, 8,0, 0, 1); break;
		case 35: MakeNum(NULL		    ,x1-2,  y1,  3,3, 1,0, 1, 1);
				 MakeNum(NULL		    ,x1+10, y1,  3,3, 9,0, 1, 1); break;
		case 40: MakeNum(NULL		    ,x1-1,  y1,  3,3, 2,0, 1, 1);
				 MakeNum(NULL		    ,x1+16, y1,  3,3, 0,0, 1, 1); break;
		case 45: MakeNum(NULL           ,x1   , y1,  3,3, 2,0, 1, 1);
				 MakeNum(NULL           ,x1+12, y1,  3,3, 1,0, 1, 1); break;
		case 50: MakeNum(NULL		    ,x1-1,  y1,  3,3, 2,0, 1, 1); 
				 MakeNum(NULL		    ,x1+16, y1,  3,3, 2,0, 1, 1); break;
		case 55: MakeNum(NULL		    ,x1-5, y1-4, 3,3, 2,0, 1, 1);
				 MakeNum(NULL		    ,x1+12,y1-4, 3,3, 3,0xff, 1, 1); break;
	}
  }
  printf("\n");
//
// Roman Numerals Dial
//
  for(dig=0; dig<60; dig += 5) {
    a=((float)(dig*6))/180*M_PI;
    x1=(int)(128+sin(a)*r);
	y1=(int)(128-cos(a)*r);
	switch (dig) {
		case 0:  MakeRomanLetter("DialDigitsRoman:",x1,INVERT(y1 /* 30 */), 12 ,0, 1, 1);		//XII
				 break;
		case 5:  MakeRomanLetter(NULL		 , x1-3, INVERT(y1),  (dig / 5),0, 1, 1);
				 break;
		case 10: MakeRomanLetter(NULL		 , x1-2, INVERT(y1),  (dig / 5),0, 1, 1); break;
		case 15: MakeRomanLetter(NULL        , x1-3, INVERT(y1) , 3,0, 0, 1);
				 break;
		case 20: MakeRomanLetter(NULL		 , x1-6, INVERT(y1),  (dig / 5),0, 1, 1); break;
		case 25: MakeRomanLetter(NULL		 , x1-3, INVERT(y1)+6,  (dig / 5),0, 1, 1); break;
		case 30: MakeRomanLetter(NULL        ,   x1, INVERT(y1)+6 , 6,0, 0, 1);
				 break;
		case 35: MakeRomanLetter(NULL		 , x1+3, INVERT(y1)+6,  (dig / 5),0, 1, 1); break;
		case 40: MakeRomanLetter(NULL		 , x1+6,  INVERT(y1) , (dig / 5),0, 1, 1); break;
		case 45: MakeRomanLetter(NULL        , x1+3, INVERT(y1) , (dig / 5),0, 1, 1); break;
		case 50: MakeRomanLetter(NULL		 , x1+6, INVERT(y1) , (dig / 5),0, 1, 1); break;
		case 55: MakeRomanLetter(NULL		 , x1+6, INVERT(y1) , (dig / 5),0xff, 1, 1); break;
	}
  }
//
// Minimal Dial
//
	for(dig=0; dig<60; dig += 5) {
	    a=((float)(dig*6))/180*M_PI;
		x1=(int)(128+sin(a)*r);
		y1=(int)(128-cos(a)*r);
		switch (dig) {
			case 0:  MakeNum3("DialDigitsMin:	",x1-6, INVERT(30), 1,0, 0, 1);
					 MakeNum3(NULL       ,x1+6, INVERT(30), 2,0, 0, 1);
					 break;
			case 15: MakeNum3(NULL       ,x1, INVERT(y1) , 3,0, 0, 1);
					 break;
			case 30: MakeNum3(NULL       ,x1, INVERT(y1)+3 , 6,0, 0, 1);
					 break;
			case 45: MakeNum3(NULL       ,x1, INVERT(y1) , 9,0xff, 1, 1);
					 break;
		}
	}
  printf("\n");
 
  MakeSimplePtr("SecPtrData:",108);
  MakeTriangPtr("MinPtrData:",102,2);
  MakeTriangPtr("HrPtrData:",60,2);
}

void MakeScale(char *name, float r, float len1, float len2, float len3) {
  int min;
  float r2;
  float a;
  int x1;
  int y1;
  int x2;
  int y2;
  int i;

  i=0;
  for(min=0; min<60; min=min+1) {
    a=((float)(min*6))/180*M_PI;

    r2=r;
    if ((min % 15) == 0) {
      r2=r2-len3;
    } else if ((min % 5) == 0) {
      r2=r2-len2;
    } else {
      r2=r2-len1;
    }

    x1=(int)(128+sin(a)*r);
    y1=INVERT((int)(128-cos(a)*r));
    x2=(int)(128+sin(a)*r2);
    y2=INVERT((int)(128-cos(a)*r2));

    if (i == 0) {
      if ((min == 0) && (name != NULL)) {
        printf("%-15s .db ",name);
      } else {
        printf("                .db ");
      }
    } else {
      printf(",");
    }

    printf("0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x",x1,y1,x2,y2);
    if (min == 59) {
      printf(",0xff");
    } else {
      printf(",0x00");
    }

    if ((i++) == 3) {
      printf("\n");
      i=0;
    }
  }
  printf("\n");
}

void MakeSimplePtr(char *name, float r1) {
  int sec;
//  int len;
  float a;
  int x;
  int y;
  int i;

  i=0;
  for(sec=0; sec<60; sec++) {


    a=((float)(sec*6))/180*M_PI;
    x=(int)(128+sin(a)*r1);
    y=256 - (int)(128-cos(a)*r1);
	//
	// make sure pointer for 0, 15, 30,45 is straight
	//
	switch (sec) {
		case 0:
		case 30: x = 0x80; break;
		case 15:
		case 45: y = 0x80; break;
	}
    if (i == 0) {
      if ((sec == 0) && (name != NULL)) {
        printf("%-15s .db ",name);
      } else {
        printf("                .db ");
      }
    } else {
      printf(",");
    }
    printf("0x%2.2x,0x%2.2x,0x80,0x80,0xff",x,y);
    if ((i++) == 3) {
      printf("\n");
      i=0;
    }
  }
  printf("\n");
}

void MakeTriangPtr(char *name, float r1, float r2) {
  int min;
  float a;
  int x1;
  int y1;
  int x2;
  int y2;
  int x3;
  int y3;
  int i;

  i=0;
  for(min=0; min<60; min=min+1) {

    a=((float)(min*6))/180*M_PI;

    x1=(int)(128+sin(a+(M_PI/2))*r2);
    y1=INVERT((int)(128-cos(a+(M_PI/2))*r2));
    x2=(int)(128+sin(a)*r1);
    y2=INVERT((int)(128-cos(a)*r1));
    x3=(int)(128+sin(a-(M_PI/2))*r2);
    y3=INVERT((int)(128-cos(a-(M_PI/2))*r2));

    if (i == 0) {
      if ((min == 0) && (name != NULL)) {
        printf("%-15s .db ",name);
      } else {
        printf("                .db ");
      }
    } else {
      printf(",");
    }

	printf("0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,0xff",x1,y1,x2,y2,x3,y3,x1,y1);
    if ((i++) == 1) {
      printf("\n");
      i=0;
    }
  }
  printf("\n");
}

void MakeNum(char *name, int x, int y, int height, int width, int val, int term, int force, int fEnabled) {
  int i;
  int n;
  int c1[]={0,3,0,-3,255};		// 1
  int c2[]={-2,2,-1,3,1,3,2,2,2,1,-2,-3,2,-3,255};
  int c3[]={-2,2,-1,3,1,3,2,2,2,1,1,0,2,-1,2,-2,1,-3,-1,-3,-2,-2,-255,-1,0,1,0,255};
  int c4[]={2,0,-2,0,1,3,1,-3,255};
  int c5[]={2,3,-2,3,-2,0,1,0,2,-1,2,-2,1,-3,-1,-3,-2,-2,255};
  int c6[]={2, 2,1, 3,-1, 3,-2, 2,-2,-2,-1,-3,1,-3,2,-2,2,-1,1,0,-1,0,-2,-1,255};
  int c7[]={-2,3, 2,3, 2,2, 1,1, 0,-1, 0,-3,255};
  int c8[]={-1,0,-2,1,-2,2,-1,3,1,3,2,2,2,1,1,0,-1,0,-2,-1,-2,-2,-1,-3,1,-3,2,-2,2,-1,1,0,255};
  int c9[]={2,1,1,0,1,0,-1,0,-2,1,-2,2,-1,3,1,3,2,2,2,-2,1,-3,-1,-3,-2,-2,255};
  int c0[]={-2,2,-1,3,1,3,2,2,2,-2,1,-3,-1,-3,-2,-2,-2,2,255};
  int *c[]={c0,c1,c2,c3,c4,c5,c6,c7,c8,c9};
  int cx;
  int cy;

  if (val>9) return;

  if (name != NULL) {
    printf("%-15s .db ",name);
  } else {
		if ((NumCount % 2) == 0) {
			printf("                .db ");
		}
  }

  i=0;
  n=0;
  while ((cx = c[val][i]) != 255) {
    i++;
    if (cx == -255) {
      printf("0x00");
	  NumCount++;
      n=n+1;
    } else {
      cy=c[val][i];
      i++;

      cx=(cx*width)+x;
      if (cx<1)
		  cx=1;
      if (cx>254) cx=254;
      cy=(cy*height)+y;
      if (cy<1)   cy=1;
      if (cy>254) cy=254;

      printf("0x%2.2x,0x%2.2x",cx,cy);
	  NumCount += 2;
	  n=n+2;
    }
      printf(",");
  }
  printf("0x%2.2x",term);
  NumCount++;
  if (force || ((NumCount % 2) == 0)) {
	  if (force && ((NumCount %2) == 1)) {
		  printf(",0x00");
	  }
	  printf("\n");
	  NumCount = 0;
	} else {
	printf(",");
  }

}

void MakeNum3(char *name, int x, int y, int val, int term, int force, int fEnabled) {
  int i;
  int n;
  int c1[]={0,9,0,-9,255};		// 1
  int c2[]={-6,6,-3,9,3,9,6,6,6,3,-6,-9,6,-9,255};
  int c3[]={-6,6,-3,9,3,9,6,6,6,3,3,0,6,-3,6,-6,3,-9,-3,-9,-6,-6,-255,-3,0,3,0,255};
  int c4[]={6,0,-6,0,3,9,3,-9,255};
  int c5[]={6,9,-6,9,-6,0,3,0,6,-3,6,-6,3,-9,-3,-9,-6,-6,255};
  int c6[]={6, 6,3, 9,-3, 9,-6, 6,-6,-6,-3,-9,3,-9,6,-6,6,-3,3,0,-3,0,-6,-3,255};
  int c7[]={-6,9, 6,9, 6,6, 3,3, 0,-3, 0,-9,255};
  int c8[]={-3,0,-6,3,-6,6,-3,9,3,9,6,6,6,3,3,0,-3,0,-6,-3,-6,-6,-3,-9,3,-9,6,-6,6,-3,3,0,255};
  int c9[]={6,3,3,0,3,0,-3,0,-6,3,-6,6,-3,9,3,9,6,6,6,-6,3,-9,-3,-9,-6,-6,255};
  int c0[]={-6,6,-3,9,3,9,6,6,6,-6,3,-9,-3,-9,-6,-6,-6,6,255};
  int *c[]={c0,c1,c2,c3,c4,c5,c6,c7,c8,c9};
  int cx;
  int cy;

  if (val>9) return;

  if (name != NULL) {
    printf("%-15s .db ",name);
  } else {
		if ((NumCount % 2) == 0) {
			printf("                .db ");
		}
  }

  i=0;
  n=0;
  while ((cx = c[val][i]) != 255) {
    i++;
    if (cx == -255) {
      printf("0x00");
	  NumCount++;
      n=n+1;
    } else {
      cy=c[val][i];
      i++;

      cx=(cx)+x;
      if (cx<1)
		  cx=1;
      if (cx>254) cx=254;
      cy=(cy)+y;
      if (cy<1)   cy=1;
      if (cy>254) cy=254;

      printf("0x%2.2x,0x%2.2x",cx,cy);
	  NumCount += 2;
	  n=n+2;
    }
      printf(",");
  }
  printf("0x%2.2x",term);
  NumCount++;
  if (force || ((NumCount % 2) == 0)) {
	  if (force && ((NumCount %2) == 1)) {
		  printf(",0x00");
	  }
	  printf("\n");
	  NumCount = 0;
	} else {
	printf(",");
  }

}

void MakeRomanLetter(char *name, int x, int y, int val, int term, int force, int fEnabled)
{
	int i;
	int n;
	int c0[]={255};
	int	c1[]={-4,-10,4,-10,-255, 0,-10, 0,10, -255, -4,10, 4,10,255};	// I
	int	c2[]={-6,-10,6,-10,-255, -2,-10, -2,10, -255, 2,-10, 2,10, -255, -6,10, 6,10, 255};	// II
	int	c3[]={-9,-10,9,-10,-255, -5,-10, -5,10, -255, 0,-10,0,10,-255, 5,-10, 5,10, -255, -9,10, 9,10, 255};	// III
	int	c4[]={-10,-10,10,-10,-255, -6,-10,-6,10,-255, -1,10, 3,-10,7,10,-255, -10,10,10,10, 255};	// IV
	int	c5[]={-8,-10,8,-10,-255, -4,10,0,-10,4,10,-255, -8,10,8,10, 255};	// V
	int	c6[]={-10,-10,10,-10,-255, -6,10,-2,-10,2,10,-255, 6,-10,6,10,-255, -10,10,10,10, 255};	// VI
	int	c7[]={-11,-10,11,-10,-255, -8,10, -4,-10,0,10,-255, 3,-10,3,10,-255, 7,-10,7,10,-255, -11,10,11,10, 255};	// VII
	int	c8[]={-14,-10,14,-10,-255, -9,10,-5,-10,-1,10,-255, 3,-10,3,10,-255, 7,-10,7,10,-255,
														11,-10,11,10,-255, -14,10,14,10, 255};	// VIII
	int	c9[]={-9,-10,9,-10,-255, -6,-10,-6,10,-255, -2,-10,6,10,-255, -2,10,6,-10,-255, -9,10,9,10,255};		// IX
	int	c10[]={-7,-10,7,-10,-255, -4,-10,4,10,-255, -4,10,4,-10,-255, -7,10,7,10,255};		// X
	int	c11[]={-9,-10,9,-10,-255, -6,-10,2,10,-255, -6,10,2,-10,-255, 5,-10,5,10,-255, -9,10,9,10,255};		// XI
	int	c12[]={-10,-10,10,-10,-255, -7,-10,0,10,-255, -7,10,0,-10,-255, 3,-10,3,10,-255, 7,10,7,-10,-255, -10,10,10,10,255};		// XII
//			     I  II III IV V  VI VII VIII IX X   XI  XII
	int *c[]={c0,c1,c2,c3, c4,c5,c6,c7, c8,  c9,c10,c11,c12};
	int cx;
	int cy;

  if (val>12) return;

  if (name != NULL) {
    printf("%-15s .db ",name);
  } else {
		if ((NumCount % 2) == 0) {
			printf("                .db ");
		}
  }

  i=0;
  n=0;
  while ((cx = c[val][i]) != 255) {
    i++;
    if (cx == -255) {
      printf("0x00");
	  NumCount++;
      n=n+1;
    } else {
      cy=c[val][i];
      i++;

      cx=(cx)+x;
      if (cx<1)   cx=1;
      if (cx>254) cx=254;
      cy=(cy)+y;
      if (cy<1)   cy=1;
      if (cy>254) cy=254;

      printf("0x%2.2x,0x%2.2x",cx,cy);
	  NumCount += 2;
	  n=n+2;
    }
    printf(",");
  }
  printf("0x%2.2x",term);
  NumCount++;
  if (force || ((NumCount % 2) == 0)) {
	  if (force && ((NumCount %2) == 1)) {
		  printf(",0x00");
	  }
	  printf("\n");
	  NumCount = 0;
	} else {
	printf(",");
  }
}

