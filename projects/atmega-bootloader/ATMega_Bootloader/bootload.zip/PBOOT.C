/************************************************************************/
/*									*/
/*			Bootloader Programmer				*/
/*		Author: Peter Dannegger, danni@specs.de			*/
/*									*/
/************************************************************************/

#include <stdio.h>
#include <dos.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <alloc.h>
#include <time.h>

#include "readargs.inc"


#define KEY_ENTER		0x0D
#define COMMAND_CONTINUE	'c'
#define COMMAND_FAIL		'f'
#define COMMAND_DONE		'a'

#define TIMEOUT		8

int ComPort = 0;
unsigned long Baud = 57600L;
char Flash[81] = "";
char * Eeprom = "";


void connect( void );
int empfang( int te );
void helptext( void );
void initsio( void );
void program( char *fname, int EEPROM );
int readhex( FILE *fp, unsigned int *addr, unsigned char *data);
void senden(unsigned char c);
void sendstring(char *text);
void splitname( void );
void txdone( void );


void main( void )
{
  helptext();
  connect();					// connect ATMega
  if( readargs( ASTRING, 'p', &Flash ) ){       // Prgramming
    splitname();
    if( Flash[0] )
      program( Flash, 0 );
    if( Eeprom[0] )
      program( Eeprom, 1 );
  }
  sendstring( "\nReset" );			// disconnect ATMega
  printf( "\n" );
}


void connect( void ){
  int COM[] = { 0x3f8, 0x2f8, 0x3e8, 0x2e8 };
  char WAITSTRING[] = { '|', '/', '-', '\\' };
  unsigned int i = 1;

  readargs( ALONG, 'b', &Baud );
  if( Baud < 2 )
    Baud = 2;
  if( Baud > 115200 )
    Baud = 115200;
  readargs( AINT, 'c', &i );		// serial port
  if( --i > 3 )
    i = 0;
  printf("COM %d at %ld Baud:  ", i+1, Baud );
  if( readargs( ABOOL, 'd', &i ) == 0 )
    ComPort = COM[i];			// Convert port number to io-address
  initsio();

  for(;;){
    printf( "\b%c", WAITSTRING[++i&3] );
    if( kbhit() ){
      getch();
      printf("\nAborted\n");
      exit( 254 );
    }
    sendstring( "\370\360\340\200\374" );
    if( empfang( 0 ) == COMMAND_DONE ){
      printf("\bConnected\n");
      empfang( 2 );			// clear rx buffer
      return;
    }
  }
}


int empfang( int te )
{
  clock_t t = clock();

  if( !ComPort )
    return COMMAND_DONE;
  while( (inportb(ComPort+5) & 0x1) == 0 )	// wait until receive done
    if( (clock() - t ) >= te )			// timeout
      return -1;
  return( inportb(ComPort) );
}


void helptext( void )
{
  int i;
  if( readargs( ABOOL, '?', &i ) ){
    printf( "/?\t\t Get this help message\n"
	  "/Bnnnn\t\t Define baud rate\n"
	  "/Cn\t\t Define serial port n = 1..4\n"
	  "/PFname,Ename\t Perform Program\n"
//	  "/VFname,Ename\t Perform Verify\n"
//	  "/RFname,Ename\t Perform Read\n"
	  "/D\t\t Debug Mode\n"
	  "Press any Key ! " );
    getch();
    printf("\n");
    exit( 255 );
  }
}


void initsio( void )
{
  if( !ComPort )
    return;
  while( (inportb(ComPort+5) & 0x60) != 0x60 );	// Senden beenden
  while( (inportb(ComPort+5) & 1) == 1 )
    inportb(ComPort);				// Empfangspuffer leeren
  outportb(ComPort+3, 0x87); 			// Einlesen Baudrate
  outportb(ComPort, (115200 / Baud) & 0xFF );	// Baudrate low
  outportb(ComPort+1, 450 / Baud );		// Baudrate high
  outportb(ComPort+3, 0x03);			// N, 1, 8
  outportb(ComPort+1, 0x00);			// Interruptsperre
  outportb(ComPort+4, 0); 			// DTR = RTS = 0
}


void program( char *fname, int EEPROM )
{
  FILE *fp;
  unsigned int firstaddr = 65536;
  unsigned int lastaddr = 0;
  unsigned int addr;
  int i;
  unsigned char far *data;
  unsigned char s[255];
  unsigned char d1;

  data = farmalloc( 65536L );
  if( data == NULL ){
    puts("Memory allocation error !" );
    return;
  }
  _fmemset( data, 0xFF, 65536L );

  if( NULL == ( fp = fopen( fname, "rb" ) ) ){
    printf("File %s open failed !\n", fname);
    return;
  }

  while( (i = readhex( fp, &addr, s )) >= 0 ){
    if( i ){
      _fmemcpy( data + addr, s, i );
      if( firstaddr > addr )
	firstaddr = addr;
      addr += i;
      if( lastaddr < addr-1 )
	lastaddr = addr-1;
      addr++;
    }
  }
  fclose( fp );

  printf( "Program %s: %04X - %04X", fname, firstaddr, firstaddr);
  if( EEPROM )
    sendstring( "DEM8" );
  else
    sendstring( "DM8" );
  txdone();
  if( empfang( TIMEOUT ) != COMMAND_DONE ){
    printf( "Programmer Error 1\n" );
  }else{
    sprintf( s, "FPR%04X", firstaddr );
    sendstring( s );
    for( addr = firstaddr;; addr++ ){
      d1 = data[addr];
      senden( d1 );
      if( d1 == 0xA5 )
	senden( 0xA5 );			// send A5 two times
      if( (addr & 0xF) == 0xF ){
	txdone();
	printf( "\b\b\b\b%04X", addr + 1 );
	if( empfang( TIMEOUT ) != COMMAND_CONTINUE ){
	  printf( "\nProgrammer Error 2\n" );
	  break;
	}
      }
      if( addr == lastaddr ){
	senden(0xA5);
	senden(0x00);
	txdone();
	printf( "\b\b\b\b%04X\n", addr );
	if( empfang( TIMEOUT ) == COMMAND_DONE ){
	  printf( "Programming successful" );
	}else{
	  printf( "Programmer Error 3\n" );
	}
	break;
      }
    }
  }
  farfree( data );
  printf("\n");
}


int sscanhex( unsigned char *str, unsigned int *hexout, int n )
{
  unsigned int hex = 0, x = 0;
  for(; n; n--){
    x = *str;
    if( x >= 'a' )
      x += 10 - 'a';
    else if( x >= 'A' )
      x += 10 - 'A';
    else
      x -= '0';
    if( x >= 16 )
      break;
    hex = hex * 16 + x;
    str++;
  }
  *hexout = hex;
  return n;					// 0 if all digits read
}


int readhex( FILE *fp, unsigned int *addr, unsigned char *data){
  /* Return value: 1..255	number of bytes
			0	end or segment record
		       -1	file end
		       -2	error or no HEX-File */
  char hexline[524];				// intel hex: max 255 byte
  char * hp = hexline;
  unsigned int byte;
  int i;
  unsigned int num;

  if( fgets( hexline, 524, fp ) == NULL )
    return -1;					// end of file
  if( *hp++ != ':' )
    return -2;                                  // no hex record
  if( sscanhex( hp, &num, 2 ))
    return -2;					// no hex number
  hp += 2;
  if( sscanhex( hp, addr, 4 ))
    return -2;
  hp += 4;
  if( sscanhex( hp, &byte, 2 ))
    return -2;
  if( byte != 0 )				// end or segment record
    return 0;
  for( i = num; i--; ){
    hp += 2;
    if( sscanhex( hp, &byte, 2 ))
      return -2;
    *data++ = byte;
  }
  return num;
}


void senden(unsigned char c)
{
  if( !ComPort )
    return;
  while( (inportb(ComPort+5) & 0x20) == 0);	/* Test Sendepuffer leer */
  outportb(ComPort, c );
}


void sendstring(char *text){
  while( *text )
    senden( *text++ );
  senden( KEY_ENTER );			// command end
}


void splitname( void )
{
  char * s;
  Eeprom = "";
  s = strchr( Flash, ',' );	       // comma separated files: Flash,Eeprom
  if( s ){
    *s = 0;
    Eeprom = s + 1;
  }
}


void txdone( void )
{
  while( (inportb(ComPort+5) & 0x60) != 0x60 );	/* Senden beenden */
}

