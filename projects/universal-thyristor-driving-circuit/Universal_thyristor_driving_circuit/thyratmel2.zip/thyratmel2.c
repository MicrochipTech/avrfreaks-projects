/****************************************************************************

Description : 	UNIVERSAL THYRISTOR CONTROL

Device :	ATMega163

Author : 	Philippe MISSIRLIU
		Lycee Newton-ENREA
		92110 Clichy
		France

Compiler : 	AVR-GCC and Avredit

Version :       2.0

Date :          11/28/2002


******************************************************************************/

#include <sig-avr.h>
#include <interrupt.h>
#include <iom163.h>
#include <pgmspace.h>
#include "prg_rdw.h"

/****************************************************************************
*
*         		Global variables
*
******************************************************************************/

unsigned int sync_time;		// value of Timer1 on the rising edge of synchro
unsigned int alpha=1180;	// firing angle, relative value (initial value = 170�)
unsigned int alpha_n;		// firing angle, absolute value
unsigned char thn;		// value to be written on port C
extern prog_int  arcos[];	// look up table used to linearize the output mean voltage
extern prog_int  scaleadc[];	// look up table to scale the adc output from 0->1024 to 0->1250
unsigned char dc_ac;		// state of the dc/ac pin after initialization
unsigned char dir_rev;		// state of the dir/rev pin after initialization
#define synchro	6		// synchronization input

/************************************************************************************
*
*		Wait for a stable main
*
************************************************************************************/
void	wait_stable_main (void)
{
char i=0;
while (i<50)		// wait for 50 main cycles
	{
	loop_until_bit_is_set(PIND,synchro);
	loop_until_bit_is_clear(PIND,synchro);
	i++;
  	}
}
/****************************************************************************
*    			Compute the next firing angle
*
*	This routine is executed at each compare interrupt. It computes the  value
*	of the compare register for the next compare interrupt.
* 		Parameters :
* 		- val_PORTC : value of  PORTC at the next interrupt
* 		- shift : value to be added to the current firing angle to obtain
*	alpha
*
****************************************************************************/
void next_angle(unsigned char val_PORTC,unsigned int shift)
{
thn=val_PORTC;			 	// value of port C for the next time
alpha_n=sync_time+alpha+shift;		// compute alpha for next time
OCR1A=alpha_n;			// set the new value of the compare register
}

/****************************************************************************
*
*         		Rectifier with direct main
*
*****************************************************************************/
void rect_direct(void)
{
switch(thn)
	{
	case 0x9:
	sync_time=ICR1;	// store the value of timer 1 on the rising edge of synchro
	next_angle(0x21,625);	// prepare the next compare interrupt
	break;

	case 0x21:
	next_angle(0x24,1042);
	break;

	case 0x24:
	next_angle(0x6,1458);
	break;

	case 0x6:
	next_angle(0x12,1875);
	break;

	case 0x12:
	next_angle(0x18,2292);
	break;

	case 0x18:
	next_angle(0x9,2708);
	break;
        }
}
/****************************************************************************
*
*         		Rectifier with reverse main
*
*****************************************************************************/
void rect_reverse(void)
{
switch(thn)
	{
	case 0x21:
	sync_time=ICR1;	// store the value of timer 1 on the rising edge of synchro
	next_angle(0x9,625);	// prepare the next compare interrupt
	break;

	case 0x9:
	next_angle(0x18,1042);
	break;

	case 0x18:
	next_angle(0x12,1458);
	break;

	case 0x12:
	next_angle(0x6,1875);
	break;

	case 0x6:
	next_angle(0x24,2292);
	break;

	case 0x24:
	next_angle(0x21,2708);
	break;
        }
}
/****************************************************************************
*
*         		AC controller with direct main
*
*****************************************************************************/
void accontrol_direct(void)
{
switch(thn)
	{
	case 0x19:
	sync_time=ICR1;	// store the value of timer 1 on the rising edge of synchro
	next_angle(0x29,417);	// prepare the next compare interrupt
	break;

	case 0x29:
	next_angle(0x25,833);
	break;

	case 0x25:
	next_angle(0x26,1250);
	break;

	case 0x26:
	next_angle(0x16,1667);
	break;

	case 0x16:
	next_angle(0x1A,2083);
	break;

	case 0x1A:
	next_angle(0x19,2500);
	break;
        }
}
/****************************************************************************
*
*         		Rectifier with reverse main
*
*****************************************************************************/
void accontrol_reverse(void)
{
switch(thn)
	{
	case 0x25:
	sync_time=ICR1;	// store the value of timer 1 on the rising edge of synchro
	next_angle(0x29,417);	// prepare the next compare interrupt
	break;

	case 0x29:
	next_angle(0x19,833);
	break;

	case 0x19:
	next_angle(0x1A,1250);
	break;

	case 0x1A:
	next_angle(0x16,1667);
	break;

	case 0x16:
	next_angle(0x26,2083);
	break;

	case 0x26:
	next_angle(0x25,2500);
	break;
        }
}

/****************************************************************************
*
*         		Input capture interrupt
*
*	Executed on each rising edge of the synchro input
*
*****************************************************************************/
SIGNAL(SIG_INPUT_CAPTURE1)
{
char x=PORTC&0x3F;
if (dc_ac)
	{
	if((x!=0x24)&&(x!=0x6)&&(x!=0x12)&&(x!=0x18))
		{			// on first time or on error
		PORTC=0x0;
		sync_time=ICR1;	// store the value of timer 1 on the rising edge of synchro
		if(dir_rev)
			next_angle(0x21,625);// prepare the next interrupt
		else
			next_angle(0x9,625);// prepare the next interrupt
		sbi(TIMSK,OCIE1A);   	// enable the compare A interrupt
		}
}
else
	{
	if((x!=0x26)&&(x!=0x16)&&(x!=0x1A))
		{			// on first time or on error
		PORTC=0x0;
		sync_time=ICR1;	// store the value of timer 1 on the rising edge of synchro
		next_angle(0x29,417);// prepare the next interrupt
		sbi(TIMSK,OCIE1A);   	// enable the compare A interrupt
		}
	}
}



/****************************************************************************
*
*         		COMPARE A INTERRUPT
*	This routine is executed each time the value of timer1 is equal
*	to the value of the compare register OCR1A. The topology (rectifier or
*	AC controller) and the main (direct or reverse) is tested then the suitable
*	routine is launched.
*
*****************************************************************************/
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
PORTC=thn;		// write new value on port C

if(dc_ac)		// test the type of circuit
	{
	if(dir_rev)      // test the sense of the 3 phase main
		rect_direct();
	else
		rect_reverse();
	}
else
	{
	if(dir_rev)      // test the sense of the 3 phase main
		accontrol_direct();
	else
		accontrol_reverse();
	}

sbi(ADCSR,ADSC);			// start conversion
}

/****************************************************************************
*
*         		ADC INTERRUPT
*
*****************************************************************************/
SIGNAL(SIG_ADC)
{
unsigned int x;
if (dc_ac)
	{
	x=PRG_RDW(&arcos[ADCW]);
	if ((alpha>420)&&(x<alpha)&&((alpha-x)>400))
		alpha=alpha-380;
	else
		alpha=x;
	}
else
	{
	x=PRG_RDW(&scaleadc[ADCW]);
	if ((alpha>420)&&(x<alpha)&&((alpha-x)>400))
		alpha=alpha-380;
	else
		alpha=x;
	}

}

/****************************************************************************
*
*         		MAIN
*
*****************************************************************************/
void main(void)
{
// Port B : PB0 , PB1 as input with pull up
PORTB=0x03;
DDRB=0x0;


// Port C : PC0 ... PC5 as output, initial value = 0
DDRC=0x3F;
PORTC=0x0;

// Port D : PD7 as output
PORTD=0x0;
DDRD=0x80;

// Timer1 as couter	clock = 125kHz	Input Capture on Rising Edge
TCCR1B=0x43;
TCNT1L=0x10;
sbi(TIMSK,TICIE1);   	// enable the compare A interrupt

// Timer 2 as PWM 	freq = 16.2 kHz 		duty cycle = 0.5
TCCR2=0x61;
OCR2=0x80;

// ADC initialized	read ADC0	interrupt enabled
ADMUX=0x0;
ADCSR=0x8E;

wait_stable_main();	// wait for 50 main cycles
dir_rev=bit_is_set(PINB,0);	// store the value of the direct/inverse input
dc_ac=bit_is_set(PINB,1);	// store the value of the dc/ac input
sei();			// global enable interrupts

while (1);		// infinite loop
}


