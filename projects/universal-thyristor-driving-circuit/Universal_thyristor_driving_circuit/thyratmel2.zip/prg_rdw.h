/******************************************************************

I needed to read a table of integers stored in ROM.

I searched the AVRfreaks forum and found this macro written by Jiri Pinchal.

Thank you Jiri.

********************************************************************/




#define PRG_RDW(addr) ({\
unsigned short __addr16 = (unsigned short)(addr);\
unsigned int __result;\
__asm__ __volatile__ (\
"lpm" "\n\t"\
"mov %A0, r0" "\n\t"\
"adiw r30, 1" "\n\t"\
"lpm" "\n\t"\
"mov %B0, r0"\
: "=r" (__result)\
: "z" (__addr16)\
: "r0"\
);\
__result;\
})
