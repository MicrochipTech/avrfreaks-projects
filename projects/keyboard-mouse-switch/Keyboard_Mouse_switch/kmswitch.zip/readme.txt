see
http://www.arune.se/~arune/km-switch/