//this stuff must be defined here and/or in the main program
#define	CE		PORTB.0
#define	RESET		PORTB.1
#define	WR		PORTB.2
#define	CD		PORTB.3
#define	BACKLIGHT	PORTB.4
#define	RD		PORTB.5

#define	HIGH		1
#define	LOW		0

#define	GRAPHICS_HOME3	0x200 
#define	GRAPHICS_HOME2	0x980
#define	GRAPHICS_HOME1	0x1100
#define	GRAPHICS_HOME0	0x1880
#define	GRAPHICS_WIDTH	30  
#define	GRAPHICS_LINES	64
#define	TEXT_HOME0	0x00  
#define	TEXT_HOME1	0xF0
#define	TEXT_WIDTH	30
#define	TEXT_LINES	8     

void write_command(unsigned char data)
{
	while (read_status()!=0x03){};
	DDRC=0b11111111;     
 	PORTC=data;     
	WR=LOW;
	CE=LOW;
	CE=HIGH;
	WR=HIGH;
	return;
}

void write_data(unsigned char data)
{
	while (read_status()!=0x03){}; 
	DDRC=0b11111111;
	CD=LOW;
	PORTC=data;
	WR=LOW;
	CE=LOW;
	CE=HIGH;
	WR=HIGH;
	CD=HIGH;
	return;
}

void init_display(void)
{
	CE=HIGH;
	WR=HIGH;
	CD=HIGH;
	RD=HIGH;     
	
	RESET=LOW;
	delay_ms(100);  
	RESET=HIGH;
	delay_ms(100);
	
	write_command(0xB2);		//automode reset

	set_graphic_window(GRAPHICS_HOME0);
	
	write_data(GRAPHICS_WIDTH);     //low byte
	write_data(0x00);       	//high byte
	write_command(0x43);	      	//set graphics line length 
	
	set_text_window(TEXT_HOME0);

	write_data(TEXT_WIDTH);         //low byte
	write_data(0x00);            	//high byte
	write_command(0x41);          	//text line length
	
	write_command(0b10000001);  	//mode set 
	
	write_command(0b10011100);	//display mode
	
	write_command(0xA3);		//cursor pattern select
	
	write_command(0x01);
	write_command(0x00);
	write_command(0x21);		//cursor position set
	return;
}            

void set_graphic_window(unsigned int address)
{
	unsigned char data;
	
	data=address&0xFF;	
	write_data(data);		//low byte
	data=(address>>8)&0xFF;
	write_data(data);		//high byte
	write_command(0x42);		//set graphics home address
	return;
}           

void set_text_window(unsigned int address)
{
	unsigned char data;  
	
	data=address&0xFF;
	write_data(data);            	//low byte
	data=(address>>8)&0xFF;
	write_data(data);             	//high byte
	write_command(0x40);           	//Text home address 
	return;
}	   

void copy_display_memory(unsigned int source, unsigned int destination, unsigned int length)
{	
	unsigned int i;
	unsigned char data;
	
	for(i=0;i<length;i++)
	{
		set_address(source+i);
		data=read_data();
		set_address(destination+i);
		write_data(data);
		write_command(0xC0);
	}
	
	return;
}
		

unsigned char read_data(void)
{
	unsigned char data=0;
	
	DDRC=0b00000000;		//set PORTC to inputs   
	PORTC=0b11111111;
	write_command(0xC1);		//read then increase address pointer
	while (read_status()!=0x03){};	//busy check
	CD=LOW;
	RD=LOW;
	CE=LOW;
	delay_us(5);			//5uS marginal, 10uS maybe better
	data=PINC;
	CE=HIGH;
	RD=HIGH;
	CD=HIGH;
	DDRC=0b11111111;		//set PORTC to outputs
	return data;
}		

unsigned char read_status (void)
{
	unsigned char data; 
        CE=1;
	PORTC=0xFF;    		//set all pull ups
	DDRC=0b00000000;	//set port to inputs
  	CE=LOW;
	RD=LOW;
	#asm("NOP")
	data=PINC&0b00000011;
  	RD=HIGH;
 	CE=HIGH;  	
	DDRC=0b11111111; 	//set port to outputs
	return data; 
} 

void clear_text(void)
{
	unsigned char i=0;
	set_address(TEXT_HOME0);
	
	for (i=0;i<TEXT_WIDTH*TEXT_LINES;i++)
	{
		write_data(0);
		write_command(0xC0);
	}
	 
	return;
}     

void clear_graphics(void)
{
	Blank(0,0,GRAPHICS_WIDTH,GRAPHICS_LINES);
	return;
}

void set_address(unsigned int address)
{
	write_data(address&0xFF);
	write_data(address>>8&0xFF);
	write_command(0x24);		
	return;
}

void pixel(unsigned char x,unsigned char y, unsigned char data)
{
	unsigned char bit_pos;
	bit_pos=x%8;
	x/=8;
	set_address(GRAPHICS_HOME0+((unsigned int)y*GRAPHICS_WIDTH)+x);
	write_command(0xF0|data<<3|(7-bit_pos));
	return;
}

void write_string(unsigned char x, unsigned char y,  char* ptr)
{
	set_address(TEXT_HOME0+((unsigned int)y*TEXT_WIDTH)+x);
	
	while (*ptr)
	{
 		write_data(*ptr-0x20);
 		write_command(0xC0);       	
		ptr++;                 
	}
	return;
}

void backlight(unsigned char backlight_command)
{
	if(backlight_command)
		BACKLIGHT=0;	//PNP-turn backlight on by sinking
	else
		BACKLIGHT=1;	//turn off backlight
	
	return;
}  

void DrawBitmap(unsigned char flash* bitmap, unsigned char x, unsigned char y)
{
	unsigned char w;
	unsigned char h;
	unsigned int i;
	unsigned char xi; 
	unsigned int address;

	address=GRAPHICS_HOME0+(unsigned int)y*GRAPHICS_WIDTH+x;
	
	set_address(address); 
	
	i=0;
	w=bitmap[i++];
	h=bitmap[i++]; 

	while(h--)
	{
		xi=w;
		while(xi--)
		{    
			write_data(bitmap[i++]);
			write_command(0xC0);
		}
		
		address+=GRAPHICS_WIDTH;				
		set_address(address);
	}
	
	return;
} 

void Blank(unsigned char x, unsigned char y, unsigned char w, unsigned char h)
{
	unsigned char xi; 
	unsigned int address;

	address=GRAPHICS_HOME0+(unsigned int)y*GRAPHICS_WIDTH+x;
	
	set_address(address); 

	while(h--)
	{
		xi=w;
		while(xi--)
		{    
			write_data(0);
			write_command(0xC0);
		}
		
		address+=GRAPHICS_WIDTH;				
		set_address(address);
	}
	
	return;  
}     