/*********************************************
This program was produced by the
CodeWizardAVR V1.0.2.1b Standard
Automatic Program Generator
� Copyright 1998-2001
Pavel Haiduc, HP InfoTech S.R.L.
http://infotech.ir.ro
e-mail:dhptechn@ir.ro , hpinfotech@xnet.ro

Project : 
Version : 
Date    : 1/29/2002
Author  : John Sorensen                   
Company : StrangeLab     
Comments: 


Chip type           : AT90LS8535
Clock frequency     : 4.000000 MHz
Memory model        : Small
Internal SRAM size  : 512
External SRAM size  : 0
Data Stack size     : 128
*********************************************/
#define	FALSE		0
#define	TRUE		1 

#include <90s8535.h>
#include <delay.h>   
#include <stdio.h>   
#include <stdlib.h> 

#define DEBUG	FALSE                             
                     
//***************** T6963C definitions *******************

#define	GRAPHICS_HOME3	0x200 
#define	GRAPHICS_HOME2	0x980
#define	GRAPHICS_HOME1	0x1100
#define	GRAPHICS_HOME0	0x1880
#define	GRAPHICS_WIDTH	30  
#define	GRAPHICS_LINES	64
#define	TEXT_HOME0	0x00  
#define	TEXT_HOME1	0xF0
#define	TEXT_WIDTH	30
#define	TEXT_LINES	8 
#include "T6963C.h"             

#define	RANDOM		PIND.0
#define	SET_SEED	PIND.2	//int0

#include "bitmaps.c"
                      
#define	BACKLIGHT_PB	PINB.6

struct complex_number
{
	float real;
	float imag;
};

#define	XSIZE	224
#define	YSIZE	64       
#define	BITS_IN_QUADRANT	XSIZE*YSIZE/4                   

#define ADC_VREF_TYPE 0x00   

// Read the ADC conversion result
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input|ADC_VREF_TYPE;
ADCSR|=0x40;
while ((ADCSR&0x10)==0);
ADCSR|=0x10;
return ADCW;
}

// Declare your global variables here 
unsigned char string[30];
unsigned char ten_ms;
unsigned char sec;
unsigned char minute;
unsigned char hour;   

unsigned char iterate(struct complex_number c, unsigned char iterations); 
unsigned char bits_per_byte (unsigned int address);

interrupt [EXT_INT0] void ext_int0(void)
{
	srand(TCNT2);	//seed the random number generator
}

interrupt [TIM1_COMPA] void tim1_compa(void)
{
	backlight(0);
}

interrupt [TIM2_COMP] void tim2_comp(void)
{
	ten_ms++;
	if(ten_ms==100)
	{
		sec++;
		ten_ms=0;
	}
	if(sec==60)
	{
		minute++;
		sec=0;
	}
	if(minute>=60)
	{
		hour++;
		minute=0;
	}
	if(hour==24)
	{
		hour=0;
	}   
}     

void main(void)
{
// Declare your local variables here 
unsigned char i;      
unsigned char j;    
unsigned char iterations;     
unsigned char chTemp;      
unsigned char zooms;

#if DEBUG
	unsigned int percent_done; 
#endif

unsigned int nTemp;
unsigned int bits_in_quadrant[4];  

struct complex_number z;

float left;
float right;
float top;
float bottom;  



DDRA=0b00000000;
PORTA=0b11111110;

DDRB=0b00111111;
PORTB=0b11111111;

DDRC=0b00000000;
PORTC=0b11111111;

DDRD=0b00000000;
PORTD=0b11111111;

TCCR0=0x00;
TCNT0=0x00;

TCCR1A=0x00;
TCCR1B=0b00001101;	//enable clear timer on compare match, 1024 prescaler
TCNT1H=0x00;
TCNT1L=0x00;
OCR1AH=0x98;
OCR1AL=0x96;   
OCR1BH=0x00;
OCR1BL=0x00;

TCCR2=0b00001110;	//enable clear timer on compare match, 256 prescaler
ASSR=0x00;
TCNT2=0x00;
OCR2=0x9C;

GIMSK=0b01000000;	//enable INT0, for seeding random number generator
MCUCR=0b00000010;	//falling edge of int0 should cause interrupt

//TIMSK=0b10010000;
TIMSK=0b00000000;	//disable timer interrupts

ACSR=0x80;

ADCSR=0x87;   

UCR=0b00000010;
UBRR=25;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End of Initialization ~~~~~~~~~~~~~~~~~~~~~~~~ 
ten_ms=0;
sec=0;
minute=0;
hour=0;          

init_display();

clear_text();
clear_graphics();

#asm("sei");   

iterations=10;	//number of iterations for the first zoom level

left=-2.0;  	//starting frame
right=1.0;
top=1.0;
bottom=-1.0;  
                    
zooms=0;

DrawBitmap(strangelab,8,24);     

set_graphic_window(GRAPHICS_HOME0);

while (1)
{
	iterations+=(zooms*5);	//number of iterations depends on zoom level 
	
	if(zooms==10)
	{
		iterations=10;	//number of iterations for the first zoom level

		left=-2.0;  	//starting frame
		right=1.0;
		top=1.0;
		bottom=-1.0;  
                    
		zooms=0;
	}      
	
	zooms++;		
	
	#if DEBUG		 	//display number of zooms
		sprintf(string,"zooms %03i",zooms);
		write_string(0,7,string); 
	#endif
	
	#if DEBUG		       	//display number of iterations
		sprintf(string,"iters %03i",iterations);
		write_string(0,0,string);   
	#endif
	
	for(j=0;j<YSIZE;j++)            //perform the calulations  
	{
		for(i=0;i<XSIZE;i++)
		{
       			#if DEBUG		 	//display number of zooms  
				percent_done=((unsigned int)j*XSIZE+i)/(XSIZE*YSIZE*0.01);
				sprintf(string,"Percent %03i",percent_done);
				write_string(15,7,string); 
			#endif		       
			
			z.real = left + i * (right - left) / XSIZE;	//determine real and imag
            		z.imag = top + j * (bottom - top) / YSIZE;	//coordinates
                        
			if(iterate(z,iterations))			//is in set?
				pixel(i,j,1);                   	//yes, set pixel
			else                                   	
				pixel(i,j,0);           		//no, reset pixel   
			
		}  
		
		//update "progress"
		if(j>1&&j<62)
		{       
			set_address(GRAPHICS_HOME1+(unsigned int)(63-j)*GRAPHICS_WIDTH+(GRAPHICS_WIDTH-1));
			write_data(0b10111101);
			write_command(0xC0);
		}
			
	}


	//draw "progress bar"	
	set_address(GRAPHICS_HOME0+GRAPHICS_WIDTH-1);
	write_data(0xFF);
	write_command(0xC0);
	set_address(GRAPHICS_HOME0+GRAPHICS_WIDTH*(GRAPHICS_LINES-1)+GRAPHICS_WIDTH-1);
	write_data(0xFF);
	write_command(0xC0);	                                   
	
	for(chTemp=1;chTemp<GRAPHICS_LINES-1;chTemp++)
	{
		set_address(GRAPHICS_HOME0+(unsigned int)chTemp*GRAPHICS_WIDTH+(GRAPHICS_WIDTH-1));
		write_data(0b10000001);
		write_command(0xC0);
	}		

	//transfer the new screen to the display screen		
	copy_display_memory(GRAPHICS_HOME0, GRAPHICS_HOME1, GRAPHICS_LINES*GRAPHICS_WIDTH);
	
	//set graphic home to the display screen
	set_graphic_window(GRAPHICS_HOME1);      
	
	backlight(1);

	for (chTemp=0;chTemp<4;chTemp++)  	//reset the number of pixels set in quadrant				
		bits_in_quadrant[chTemp]=0;  	//counters
		
	for(j=0;j<YSIZE;j++) 		//determine the number of pixels set in each
	{
		for(i=0;i<(XSIZE/8);i++) 	//quadrant   
		{
			chTemp=bits_per_byte(GRAPHICS_HOME0+(unsigned int)j*GRAPHICS_WIDTH+i); 
			bits_in_quadrant[i/((XSIZE/8)/2)+(j/(YSIZE/2))*2]+=chTemp;

			#if DEBUG		//display status
				sprintf(string,"i=%03i j=%03i bib=%03i quad=%1i ",i,j,chTemp,i/((XSIZE/8)/2)+(j/(YSIZE/2))*2);
				write_string(0,1,string);  
			#endif
			
			#if DEBUG       	//display pixels in each quadrant
				for (chTemp=0;chTemp<4;chTemp++)
				{
					sprintf(string,"%04i",bits_in_quadrant[chTemp]);
					write_string(0,2+chTemp,string); 	
				}			
			#endif
	
		} 
	}
	
	for (chTemp=0;chTemp<4;chTemp++)//calc distance from 50% pixels on
	{
		if(bits_in_quadrant[chTemp]>=(BITS_IN_QUADRANT*0.50))
			bits_in_quadrant[chTemp]=bits_in_quadrant[chTemp]-(BITS_IN_QUADRANT*0.50);
		else
			bits_in_quadrant[chTemp]=(BITS_IN_QUADRANT*0.50)-bits_in_quadrant[chTemp];
	}  
		
	#if DEBUG			//display distance from 50% pixels on
		for (chTemp=0;chTemp<4;chTemp++)
		{
			sprintf(string,"%04i",bits_in_quadrant[chTemp]);
			write_string(0,2+chTemp,string); 	
		}                         
	#endif
	
	chTemp=0;

	nTemp=bits_in_quadrant[0];

	for (i=1;i<4;i++)		//determine quadrant closest to having 50% pixels on
	{
		if(bits_in_quadrant[i]<nTemp)
		{
			chTemp=i;
			nTemp=bits_in_quadrant[i];
		}
	}
	
	nTemp=0;

	if(!RANDOM)	//if the random pin is grounded the 50% calculation is overriden
		do
		{
			chTemp=(unsigned char)(rand()%4);
			nTemp++;
		}while((bits_in_quadrant[chTemp]>((BITS_IN_QUADRANT/2)*0.80))&&(nTemp<20));//make sure there is something to look at

	#if DEBUG  			//display the selected quadrant
	 	sprintf(string,"50 quad %1i",chTemp);
		write_string(0,6,string);  
	#endif 

	switch (chTemp)     		//calculate new boundaries
	{
		case 0:
			bottom=top-(top-bottom)/2;
			right=left+(right-left)/2;
			break;
		case 1:
			bottom=top-(top-bottom)/2;
			left=right-((right-left)/2);
			break;
		case 2:
			top=bottom-((bottom-top)/2);
			right=left+(right-left)/2;
			break;
		case 3:	      
			top=bottom-((bottom-top)/2);
			left=right-((right-left)/2);
			break;
	}
	
	backlight(0);   
}; 
}

unsigned char iterate(struct complex_number c, unsigned char iterations)
{
	struct complex_number z;
	float zr2;			//z.real squared
	float zi2;			//z.imaginary squared         
	float magnitude2;   		//magnitude squared
	unsigned char i;
	
	unsigned char is_in_set;    	//is in set?
	is_in_set=1;                 	//assume yes to begin

	z.real=0.0;     		//initialize z to zero
	z.imag=0.0;
	
	for(i=0;i<iterations;i++)
	{
		zr2=z.real*z.real;		//complex number calculations, mandelbrot set
		zi2=z.imag*z.imag;     		//square z
		z.imag=2*z.real*z.imag+c.imag;	//and add c
		z.real=zr2-zi2+c.real;
		magnitude2=zr2+zi2;    
		
		if(magnitude2>4.0)
		{
			is_in_set=0;
			break;
		}
	}
	
	return is_in_set;
}

unsigned char bits_per_byte (unsigned int address)
{
	unsigned char bits;
	unsigned char i;
	unsigned char data;
	
	bits=0;
	
	set_address(address);
	data=read_data();  
	
	#if DEBUG
		set_address(address);
		write_data(~data);
		write_command(0xC0);
	#endif
	
	for (i=0;i<8;i++)
		if(data&1<<i)
			bits++;
			
	#if DEBUG
		set_address(address);
		write_data(data);
		write_command(0xC0);
	#endif
	
	return bits;
		
}