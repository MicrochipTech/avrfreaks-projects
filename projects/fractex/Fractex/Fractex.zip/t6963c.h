//HIGH LEVEL COMMANDS
void init_display(void);
void set_graphic_window(unsigned int address);  
void set_text_window(unsigned int address);
void copy_display_memory(unsigned int source, unsigned int destination, unsigned int length);
void clear_text(void);
void clear_graphics(void);
void pixel(unsigned char x,unsigned char y, unsigned char data); 
void write_string(unsigned char x, unsigned char y,  char* ptr);
void backlight(unsigned char backlight_command); 
void DrawBitmap(unsigned char flash* bitmap, unsigned char x, unsigned char y);
void Blank(unsigned char x, unsigned char y, unsigned char w, unsigned char h);


//LOW LEVEL COMMANDS
void write_command(unsigned char data);
void write_data(unsigned char data);
unsigned char read_data(void);
unsigned char read_status (void);  
void set_address(unsigned int address);
