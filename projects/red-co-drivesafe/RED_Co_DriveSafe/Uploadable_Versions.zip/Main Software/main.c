/*
R.E.D. Co. DrifeSafe main code, uses the Salvo RTOS.

This project was for the Shad Cup of 2003. As a member of
Team University of New Brunswick (Team UNB) we decided to
create a buisness called RED Co, with this DriveSafe product.

Visit the RED Co site at http://redco.kewima.com

Visit Colin O'Flynn (that's me) website at http://www.newae.com

E-mail: coflynn@newae.com or c_oflynn@yahoo.com

*/

/* Includes */
#include <salvo.h>
#include <avr/io.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>
#include "uart.h"
#include "edm.h"
#include <stdlib.h>
#include <string.h>
#include <avr/eeprom.h>



/* ------------------ Prototypes ------------------------- */
void									TaskFailSafe
	(
	void
	);
	
void									TaskMeasureForce
	(
	void
	);
	
void									TaskWarnDriver
	(
	void
	);
	
void									TaskMakeNoise
	(
	void
	);
	
void									TaskKillEngine
	(
	void
	);
	
void									send_string
	(
	char					string[]
	);

unsigned char							post
	(
	void
	);

/* ------------------ Salvo RTOS Defines ------------------ */
/* Tasks */
#define TASK_FAILSAFE_P      OSTCBP(1) 	/* task #1, the failsafe pulse*/
#define TASK_MEASUREFORCE_P  OSTCBP(2) 	/* task #2, Measure the acceleration*/
#define TASK_WARNDRIVER_P	 OSTCBP(3)  /* task #3, warns driver about bad driving */
#define TASK_MAKENOISE_P	 OSTCBP(4)  /* task #4, makes some noise */
#define TASK_KILLENGINE_P	 OSTCBP(5) /* task #5, kills the engine off */

/* Task Priorities */
#define PRIO_FAILSAFE       10        	/* This has lowest priority, makes sure it will be first to fail */

#define PRIO_MEASUREFORCE   2        	/* This is an important task */

#define PRIO_WARNDRIVER		4			/* This task can be delayed for a few seconds safely */

#define PRIO_MAKENOISE		5			/* This is reasonably important, don't want to blast drivers ears out */

#define PRIO_KILLENGINE		4			/* Same priority as the driver warning */

/* Messages */
#define MSG_MAKENOISE_P			OSECBP(1)
#define MSG_DRIVER_ERRATIC_P 	OSECBP(2)
#define MSG_KILL_ENGINE_P		OSECBP(3)


/* Labels */									   
_OSLabel(TaskFailSafe1)
_OSLabel(TaskMeasureForce1)
_OSLabel(TaskWarnDriver1)
_OSLabel(TaskMakeNoise1)
_OSLabel(TaskKillEngine1)


/* ------------------ System Settings -------------------- */



/* Factory Defaults */
#define DEFAULT_HORN_ENABLED 	TRUE
#define DEFAULT_FUELCUT_ENABLED	TRUE
#define DEFAULT_HAZARDS_ENABLED	TRUE
#define DEFAULT_BUZZER_ENABLED	TRUE
#define DEFAULT_PASSWORD		"drivesafe"

#define PASSWORD_LENGTH			9
/* Where user settings are stored */
#define ADDR_HORN_ENABLED		((unsigned char)(E2END-1))
#define ADDR_FUELCUT_ENABLED	((unsigned char)(E2END-2))
#define ADDR_HAZARDS_ENABLED	((unsigned char)(E2END-3))
#define ADDR_BUZZER_ENABLED		((unsigned char)(E2END-4))
#define ADDR_PASSWORD_END		((unsigned char)(ADDR_BUZZER_ENABLED - PASSWORD_LENGTH - 2))
#define ADDR_CRC8				((unsigned char)(ADDR_PASSWORD_END-1))

#define E2PROM_BACKUP_OFFSET	((unsigned short)0x004F);

/* Where the settings are stored in RAM */

unsigned char	horn_enabled;
unsigned char	fuelcut_enabled;
unsigned char	hazards_enabled;
unsigned char	buzzer_enabled;
unsigned char	password[PASSWORD_LENGTH+1];

/* ------------------ Defines for the FailSafe logic ------ */
#define DDR_FAILSAFE		DDRB
#define PORTREG_FAILSAFE	PORTB
#define PIN_FAILSAFE		0
//this will toggle the pin by XORing a mask with the value of the port register
#define toggle_failsafe()	PORTREG_FAILSAFE = (1<<PIN_FAILSAFE) ^ PORTREG_FAILSAFE	

/* ------------------ Defines for reading ADX311 ---------- */
/* Sleep Macro */
#define SLEEP()				asm volatile("SLEEP"::)

/* ADC Channel Select Macro */
#define ADChannel(channel)	(ADMUX = (ADMUX & 0xF0) | channel)

/* Which ADC channel is which axis connected to on ADXL311 */
#define ADXL311_X			1
#define ADXL311_Y			0

/* ------------------ Various Macros and Defines ----------*/
/* Check which mode to run in macro */
#define MODE()				(PINC & (1<<5))
#define RUNMODE				(1<<5)

/* Simulate erratic driving macro */
#define SIM_ERRATIC()		(PINC & (1<<4))
#define ERRATIC				0x00

/* Generate sound macros */
#define STOP				0
#define LOW					0xFF
#define MEDIUM				0x10
#define HIGH				0x0F
#define SOUND(x)			(OCR2 = x)

/* Warning light macro */
#define ON					1
#define OFF					0
#define WARNING_LIGHT(x)	if (x==ON){PORTD |= 1<<7;} else {PORTD &= ~(1<<7);}

/* Power source macro */
#define ACC					0
#define ALWAYS_ON			1
#define POWER_SOURCE(x)		if (x==ACC){PORTD &= ~(1<<5);} else {PORTD |= 1<<5;}

/* Fuel pump macro */
#define	FUEL_PUMP(x)		if (x==ON){PORTD &= ~(1<<6);} else {PORTD |= 1<<6;}

/* Hazard light macros */
#define TOGGLE_HAZARDS()	(PORTD ^= 1<<3)
#define HAZARDS(OFF)		(PORTD &= ~(1<<3))

/* Reset button */
#define RESET_BUTTON()		(PIND & (1<<2))

unsigned char				timer;


int										main
	(
	void
	)
	{
	
	/* Start the Power On Self Test */
	post();
	
	
	/* Enable Timer1 to be at 10mS intervals */
	TCCR1B = 0x00; /* Stop Timer1 */
    TCNT1H = 0x00; /* Clear Timer1 */ 
    OCR1AH = 0x00; /* Set Compare A to 39 */ 
    OCR1AL = 0x24; /* ((3.6864MHz/1024)/36) = 10ms timer */
    TIMSK  = 1<<OCIE1A; /* Compare A Interrupt enable */ 
    TCCR1B = 0x0D; /* Start Timer1 with clk/1024 */ 
	
	/* Set Ports up */
	//set ADCs to inputs
	DDRC = 0x00;
	//need pull-ups on switch lines
	PORTC = (1<<5) | (1<<4);
	//PORTB, PORTD are outputs, except for PIND.2
	DDRB = 0xff;
	DDRD = ~(1<<2);
	//pull-ups on push button line
	PORTD = 1<<2;
	
	
	/* Init UART */
	init_uart0();
	
	OSInit();
    
	/* Create the tasks */
    OSCreateTask(TaskFailSafe, TASK_FAILSAFE_P, PRIO_FAILSAFE);
    OSCreateTask(TaskMeasureForce, TASK_MEASUREFORCE_P, PRIO_MEASUREFORCE);
    OSCreateTask(TaskWarnDriver, TASK_WARNDRIVER_P, PRIO_WARNDRIVER);
	OSCreateTask(TaskMakeNoise, TASK_MAKENOISE_P, PRIO_MAKENOISE);
	OSCreateTask(TaskKillEngine, TASK_KILLENGINE_P, PRIO_KILLENGINE);
	

	/* Create the semaphores */
	OSCreateBinSem(MSG_MAKENOISE_P, 0);
	OSCreateBinSem(MSG_DRIVER_ERRATIC_P, 0);
	OSCreateBinSem(MSG_KILL_ENGINE_P, 0);

	
    OSEi(); 
	
    while (1==1)
		{
        OSSched();	
		}
		
	return 1;
	}
	
void									TaskFailSafe
	(
	void
	)
	{
	
	DDR_FAILSAFE |= 1<<PIN_FAILSAFE;
	
	while (1==1)
	{
	/* Wait 10 OS ticks, each tick is 10mS */
	OS_Delay(10, TaskFailSafe1);	
	
	/* Toggle the failsafe pin */
	toggle_failsafe();
	}
	
	}

void									TaskMeasureForce
	(
	void
	)
	{
	/* Local variables */
	unsigned int			Y_acceleration;
	unsigned int			X_acceleration;
	char					string[10];
	

	/* ADC Enabled, ADC Prescale set to 64, ADC interrupt enabled */
	ADCSRA =  (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADIE) ;
	
	/* ADC is set to external voltage ref */
	ADMUX = 0x00;
	
	/* SLEEP instruction actually goes to ADC Low Noise Mode */
	MCUCR |= (1<<SE) | (1<<SM0);
	
	while (1==1)
	{
	// Select Y Axis
	ADChannel(ADXL311_Y);
	
	// Take Measurement
	SLEEP();
	Y_acceleration = ADC;
	
	// Select X Axis
	ADChannel(ADXL311_X);
	
	// Take Measurement
	SLEEP();
	X_acceleration = ADC;


	if (MODE() == RUNMODE)
	/* In Run mode, so perform normally */
		{
		if (SIM_ERRATIC() == ERRATIC)
			{
			OSSignalBinSem(MSG_DRIVER_ERRATIC_P);
			}
		}
	/* In Datalogging mode, so just send out current data to serial port
	   which will be picked up by USB chip */
	else
		{

		/*Data packet looks like this:
		  X[X Data]Y[Y Data][crc8 of packet]
		  [X data] and [Y Data] are both two bytes long. */

		string[0] = 'X';
		string[1] = (unsigned char)X_acceleration;
		string[2] = (unsigned char)(X_acceleration >> 8);
		string[3] = 'Y';
		string[4] = (unsigned char)Y_acceleration;
		string[5] = (unsigned char)(Y_acceleration >> 8);
		string[6] = crc8(string, 6);
		string[7] = '\0';
		send_string(string);	

		}

	
	/* Wait 500mS */
	OS_Delay(50, TaskMeasureForce1);
	}
	
	}

/* Warns the driver about the erratic driving */
void									TaskWarnDriver
	(
	void
	)
	{
	
	while (1==1)
	{
	/* Wait for MSG_DRIVER_ERRATIC_P to be set to 1 */
	OS_WaitSem(MSG_DRIVER_ERRATIC_P, OSNO_TIMEOUT, TaskWarnDriver1);

	//we are in warning mode, so switch over to always-on power so user can't
	//deactivate unit by turning off car
	POWER_SOURCE(ALWAYS_ON);

	//Wait, sounding noise and lights still if needed
	timer = 0;
	while (timer < 4) 
		{
		OS_Delay(100, TaskWarnDriver1);
		OSSignalBinSem(MSG_MAKENOISE_P);
		timer++;
		}

	//clear binary semaphore
	OSTryBinSem(MSG_DRIVER_ERRATIC_P);
	
	
	//wait 1 second or so
	OS_Delay(150, TaskWarnDriver1);

	//check if driver is still erratic
	if (OSTryBinSem(MSG_DRIVER_ERRATIC_P) != 0)
		{
		OSSignalBinSem(MSG_KILL_ENGINE_P);
		}
	else
		{
		//phew, driver started acting normally
		POWER_SOURCE(ACC);
		}
			
	}
	
	}

/* Makes a beep beep sound and flashes the warning light on the dash */
void									TaskMakeNoise
	(
	void
	)
	{
	
	/* Set Timer2 up to CTC mode, OCR2 output, with a prescale of 32 from CLK */
	TCCR2 = (1<<WGM21) | (1<<COM20) | (1<<CS21) | (1<<CS20);

	SOUND(STOP);

	while (1==1)
	{
	/* Wait to be told to make some noise */
	OS_WaitBinSem(MSG_MAKENOISE_P, OSNO_TIMEOUT, TaskMakeNoise1);
	
	/* Put out low sound, wait 1/2 second, put out high sound, wait
	   1/2 second. Also flash the warning light at the same time */
	SOUND(LOW);
	WARNING_LIGHT(ON);
	OS_Delay(50, TaskMakeNoise1);
	
	SOUND(MEDIUM);
	WARNING_LIGHT(OFF);
	OS_Delay(50, TaskMakeNoise1);

	SOUND(STOP);
	
	}
	
	return;
	}
	
void									TaskKillEngine
	(
	void
	)
	{
	
	FUEL_PUMP(ON);
	
	while (1 == 1)
	{
	OS_WaitBinSem(MSG_KILL_ENGINE_P, OSNO_TIMEOUT, TaskKillEngine1);
	
	/* We can now turn off most other tasks */
	OSStopTask(TASK_MAKENOISE_P);
	OSStopTask(TASK_WARNDRIVER_P);
	OSStopTask(TASK_MEASUREFORCE_P);
	
	
	WARNING_LIGHT(ON);
	FUEL_PUMP(OFF);
	
	/* Wait for 5 minuites */
	timer = 0;
	while (timer < 118)
		{
		TOGGLE_HAZARDS();
		OS_Delay(255, TaskKillEngine1);
		timer++;
		}
		
	/* Turn off warning light, user can re-enable car now */
	WARNING_LIGHT(OFF);
	
	/* Wait for user to press the button */
	
	while (RESET_BUTTON() == OFF)
		{
		TOGGLE_HAZARDS();
		OS_Delay(255, TaskKillEngine1);
		}
		
	HAZARDS(OFF);
	FUEL_PUMP(ON);
	OSStartTask(TASK_MAKENOISE_P);
	OSStartTask(TASK_WARNDRIVER_P);
	OSStartTask(TASK_MEASUREFORCE_P);
	
	}
	}

/* Timer1 10mS Timer */
SIGNAL(SIG_OUTPUT_COMPARE1A)
	{	
    OSTimer(); 
	}

/* ADC Done interrupt, doesn't actually do anything just brings AVR out of sleep mode */
SIGNAL(SIG_ADC)
	{
	return;
	}

/* Sends a string off the UART */
void									send_string
	(
	char					string[]
	)
	{
	unsigned char			counter = 0;
	
	while (string[counter] != '\0')
		{
		output_ch_0(string[counter]);
		counter++;
		}
		
	return;
	}
	
/* Power On Self Test */
unsigned char							post
	(
	void
	)
	{
	/* Test the warning light */
	WARNING_LIGHT(ON);
	
	
	return 0;
	}
	
//NOT ENABLED YET
#if 1==0
/* Stores the ram-based variables to E2PROM */
unsigned char							store_settings
	(
	unsigned char			offset
	)
	{
	unsigned char			data[4 + PASSWORD_LENGTH + 1];
	unsigned char			counter;
	unsigned char			addr;
	
	addr = ADDR_HORN_ENABLED - offset;
	data[0] = horn_enabled;
	eeprom_write_byte(&addr, data[0]);

	addr = ADDR_FUELCUT_ENABLED - offset;
	data[1] = fuelcut_enabled;
	eeprom_write_byte(&addr, data[1]);
	
	addr = ADDR_HAZARDS_ENABLED - offset;
	data[2] = hazards_enabled;
	eeprom_write_byte(&addr, data[2]);
	
	addr = ADDR_BUZZER_ENABLED - offset;
	data[3] = buzzer_enabled;
	eeprom_write_byte(&addr, data[3]);
	
	addr = ADDR_PASSWORD_END - offset;
	data[4] = password[0];
	eeprom_write_byte(&addr, data[4]);

	counter = 1;
	while (counter < PASSWORD_LENGTH)
		{
		addr++;
		data[counter + 4] = password[counter];
		eeprom_write_byte(addr, password[counter]);
		counter++;
		}
		
	data[counter + 4] = crc8(data, data[counter + 4]);
	eeprom_write_byte(addr, data[counter + 4)];
		
	return;
	}
#endif		
	
	