/*                                                          */
/*  Salvo LE & Pro library build                            */
/*                                                          */
#if defined(MAKE_WITH_STD_LIB)
#define OSUSE_LIBRARY				TRUE
#define OSLIBRARY_TYPE				OSL
#define OSLIBRARY_CONFIG 			OSA
#define OSEVENTS                    2 
#define OSEVENT_FLAGS               0
#define OSMESSAGE_QUEUES            0
#define OSTASKS                     7
#endif

