/*

Watchdog timer module for loading onto small microcontroller

Watches PB1, and if it doesn't pulse fast enough then the chip resets, which
means that PB4 will not be pulled high anymore. 

There must be one rising edge at least every 800 mS on the INT0 pin (which is PB1).

*/


#include <avr\io.h>
#include <avr\signal.h>
#include <avr\interrupt.h>

/* The pin that will go low or floating when there is a problem */
#define PIN_DOG_MOUTH 	4
/* The port pin INT0 is connected to */
#define PIN_INT0		1

int							main
	(
	void
	)
	{
	
	/* Portb.4 is output and LOW, rest are inputs */
	DDRB = 1 << PIN_DOG_MOUTH;
	
	/* INT0 has pull-up resistor enabled so it never floats */
	PORTB = 1<<PIN_INT0;
	
	/* Enable WatchDog Timer (WDT) with approx 0.97s timeout  */
	WDTCR = (1<<WDP2) | (1<<WDP1) | (1<<WDE);
	
	/* Set INT0 to a rising edge interrupt */
	MCUCR |= 1<<ISC00;
	GIMSK |= 1<<INT0;
	sei();
	
	/* Let the interrupts do their magic */
	while (1==1)
		{
		continue;
		}
		
	return 1;
	}
	
SIGNAL(SIG_INTERRUPT0)
	{
	/* Clear the watchdog */
	asm volatile("wdr"::);
	
	/* Make sure the dog isn't barking */
	PORTB |= 1<<PIN_DOG_MOUTH;
	}
	
