;    
;    PMDEmu SMALL - AVR based emulator of Czechoslovak microcomputer PMD-85 originally based on I8080
;    Copyright (C) 2003  Peter Chrenko <peto@kmit.sk>, J.Matusku 2178/21, 955 01 Topolcany, Slovakia
	
;
;    This program is free software; you can redistribute it and/or modify
;    it under the terms of the GNU General Public License as published by
;    the Free Software Foundation; either version 2 of the License, or
;    (at your option) any later version.
;
;    This program is distributed in the hope that it will be useful,
;    but WITHOUT ANY WARRANTY; without even the implied warranty of
;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;    GNU General Public License for more details.
;
;    You should have received a copy of the GNU General Public License
;    along with this program; if not, write to the Free Software
;    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
;

; PMD.PHP

 	 .include 	"m8515def.inc"
	 .listmac 
  	 .include       "macro.asm" 

<?        //configuration
	$f	= 20000000;  // XTAL frequency (range 18.432 MHz .... 20.000 MHz)
        $turbo 	= false; //true; 

	
function T($microsecound)
{
  global $f;
  
  $rv = round($f*$microsecound*1e-6);	
  
  echo $rv;
}
?>

	 .def	video_SREG	=	r0	
     	 .def	video_DDRA	=	r1	
	 .def	video_PORTA	=	r2	; pair (kbd.asm uses movw)
         .def	video_PORTB	=	r3
	 .def	video_PORTC	=	r4	; pair (kbd.asm uses movw)
	 .def	video_PORTD	=	r5
     	 .def	video_PORTE	=	r6 	
 	 .def	mask_register	=	r7
	 .def	video_ptr_h	=	r8
	 .def	video_ptr_l	=	r9		
	 .def	_zero		=	r10
	 .def	_255		=	r11
         .def   _last_result  	=	r12
	 .def	A		=	r13
	 .def	L		=	r14	  
     	 .def	H		=	r15   

     
		
    	.def	m64		=	r16
	.def	PSW		=	r17
	.def	video_tmp	= 	r18 
        .def	video_state	=	r19
		.def	video_tmp2	=	r20	; video.php
		.def	kbd_reg		=	r20	;kbd.asm
		.def	kbd_flags_reg	=	r21	;kbd.asm

	.def	C		=	r20	  ; pair register - musnt  use ADDIW	    
	.def	B		=	r21

	.def	E		=	r22	  ; pair register - musnt  use ADDIW
	.def	D		=	r23    
    
	
	.def	_SPL	=	r24	  ; may use addiw _SPL,1
    	.def	_SPH	=	r25
	
	; X je temp address(16bit register)
	; Z is used by IJMP & LPM
	
	.def	_PCL	=	r28   ; Y
	.def	_PCH	=	r29


.dseg
kb_cols:	.byte   16  	; PMD's keyboard has 16 columns selected by 74154
m64:		.byte	1
blink_counter:	.byte	1
kbd_ports:	.byte   4	; keyboard 8255 state
kbd_portC:	.byte	1
mgf_pointer: 	.byte	3	; 3 bytes counter
_rom:		.byte	4	; external ROM modul 8255 state	


kbd_flags:	.byte	1	 ; flags for KBD module
					    ; 7 = F0
					    ; 6 = STOP
					    ; 5 = SHIFT
					    ; 4 = ALT
					    ; 3 = 
					    ; 2 =
					    ; 1 =
    					    ; 0 =
.equ	F0_bit		= 7
.equ	STOP_bit	= 6
.equ	SHIFT_bit	= 5
.equ	ALT_bit		= 4

.cseg



 		.org	0
 		rjmp 	after_reset

		.org	OC1Aaddr
		<? require	"video.php" ?>		
		


after_reset:
				clr		_zero			; _zero := 0	
				ldi		r30,255
				mov		_255,r30
				

				
				; PD0 = KBD_DATA(RXD)(IN)
				; PD1 = A18 (OUT)
				; PD2 = A17 (OUT)
				; PD3 = SRAM/FLASH SELECT(OUT)
				; PD4 = KBD_CLK(IN)
				; PD5 = BUZZER(OUT)
				; PD6 = WR(OUT)
				; PD7 = RD(OUT)
				
				; PE0 = VIDEO
				; PE1 = A16
				; PE2 = VIDEO_SYNC
				
				ldi		r30, ~((1 << DDD4)|(1 << DDD0)) ;
				out		DDRD,r30
				out		PORTD,_255	 	 ; control bus = idle state	
			
				out		DDRB,_255		 ; portB vystup (address)
				out		DDRC,_255		 ; PORTC output (address)
				out		DDRE,_255		 ; PORTE output (address,video,sync)
				out		PORTE,_zero		 ; BLACK level on video

				; ---------- inicialize PS/2 keyboard ---------------------------------------------
				ldi		r30,(1<<RXEN)
				out		UCSRB,r30
						
				ldi		r30,0b11100110 ; synchro mode enable
				out		UCSRC,r30
				; ---------- end of inicializing PS/2 keyboard ---------------------------------------------

				;------------ load look-up parity table
				ldi	XH,high(parity_table)
				ldi	XL,low(parity_table)
calculate_new_byte_parity:				
				mov 	r0,XL
				swap 	r0
				eor 	r0,XL
				mov	r1,r0
				lsr	r1	
				lsr	r1
				eor	r0,r1
				mov	r1,r0
				lsr	r1
				eor	r0,r1
				com	r0	
				
				
				st	X+,r0
				cp	XL,_zero
				brne	calculate_new_byte_parity

				;------------------- rewind tape				
				ldi	XL,byte1(C_games_start)
				sts	mgf_pointer+0,XL
				ldi	XL,byte2(C_games_start)
				sts	mgf_pointer+1,XL
				ldi	XL,byte3(C_games_start)
				sts	mgf_pointer+2,XL
				
				ldi	XL,1
				sts	last_count,XL
				
				;---------------- inicialize video subsystem -------------------------------
				
				ldi		r30,0b00011001		; divide 1; FAST PWM mode; ICR1 = TOP; mode = 14
				out		TCCR1B,r30
				ldi		r30,0b00100010		; inverted PWM, mode = 14
				out		TCCR1A,r30
				
				ldi		r30,high(<? T(64) ?>)		; ICR1 = TOP = 64 us
				out		ICR1H,r30
				ldi		r30,low(<? T(64) ?>)	
				out		ICR1L,r30


				ldi		r30,high(<? T(64-4.7) ?>)	; when sync goes low 
				out		OCR1BH,r30
				ldi		r30,low(<? T(64-4.7) ?>)	
				out		OCR1BL,r30

				ldi		r30,high(<? T($tt1= 8) ?>)		; when start video generation routine
				out		OCR1AH,r30
				ldi		r30,low(<? T($tt1) ?>)	
				out		OCR1AL,r30
				
				ldi		r30,0b01000000			; enable interrupt on OCR1A (video routine)
				out		TIMSK,r30
				
				mov		video_state,_zero		; video_state := 0
				mov		video_ptr_l,_zero		; video address := 0xc000
				ldi		r30,0xc0			
				mov		video_ptr_h,r30
				mov		video_PORTE,_zero				
				
				; blink subsystem
				.equ	blink_period = 50	;	1 Hz
				mov		mask_register,_255				
				ldi		r30,blink_period
				sts		blink_counter,r30
								
				

			; download ROM modul into SRAM from 0x8000 to 0x8ffff 	
change_pmd_type:		
			.equ	monitor_start	=	0x8000
			.equ	monitor_go	=	0x8000
			.equ	monitor_length  =       0x1000
			
			.equ	C_monit1_start=0x00000
			.equ	C_basic1_start=0x01000
			
			.equ	C_games_start =0x03400

				; download monitor to SRAM from external FLASH ( 4KB )

				ldi		XL,low(C_monit1_start)
				ldi		XH,high(C_monit1_start)
				
				ldi		ZL, low( monitor_start )
				ldi		ZH, high( monitor_start ) 
				

				; X: source from first page in FLASH 
				; Z: destination in SRAM
				; A: end source address ( high byte ) 

_monitor_download:				
                		<? flash_read('_zero','XH','XL','A'); ?> 
				adiw		XL,1
								
				out		DDRA,_255		; PORTA = vystup
				
				out		ADDRL,ZL
				out		ADDRH,ZH
				out		PORTA,A
				adiw		ZL,1
				
				MEMWR_pulse
				
				cpi		ZH, high(monitor_start+monitor_length)  ; hi of ( end address + 1 )
				brlo		_monitor_download

						
	                        ; SHIFT & STOP & ALT released
		      		; f0_received = false
				cli
				ldi		ZL,(1<<SHIFT_bit)|(1<<STOP_bit)|(1<<ALT_bit)
				sts		kbd_flags,ZL
				
				
				ldi		ZL, low ( kb_cols )  		; inicialize PMD keyboard model
				ldi		ZH, high ( kb_cols )
				ldi		video_tmp, 0x1f			; 0b11111    
				ldi		r17,16
				
kb_inic:			st		Z+,video_tmp			; 16 keyboard cols set to 0x1f	
				dec		r17
				brne	kb_inic



PMD_RESET:				
				ldi		_PCL,low(monitor_go)
				ldi		_PCH,high(monitor_go)  		; after RESET 

				ldi		r30, low(RAMEND)               	
				ldi		r31, high(RAMEND)               	
				cli						; disable if goes from kbd.asm
				out	   	SPL,r30
				out		SPH,r31				; STACK POINTER SET
				sei						; enable interrupt
								
				
				out		DDRA,_zero			; PORTA = vstup
				SELECT_RAM

				MEMRD_active
				
				sts		kbd_portC,_zero
				sts		kbd_ports + 2,_zero		; SPEAKER Off
								

;------------- begin of instruction cycle without handling PSW & flags ------

i_cycle:
				ldi		ZH, high(i_table)      
_nop:			
_none:
_mov_aa:    
_ei: 
_mov_bb: 
_mov_hh:	
_mov_ll:
_mov_cc: 
_mov_dd:	
_mov_ee:
  Wniop:   
  niop:	    
  _di:


i_cycle_turbo:
				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
  _hlt:									; forever loop (HALT)
				ijmp					; no -> make instruction cycles



;------------- begin of instruction cycle with handling PSW & flags ------

set_flags:		
				in		PSW,SREG
save_parity:
				mov		_last_result,A		; for calculate Parity bit
				
				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				ijmp					; no -> make instruction cycles

clr_CH:			
				in		PSW,SREG
				andi		PSW,~((1<<ATMEL_C)|(1<<ATMEL_H))

				mov		_last_result,A		; for calculate Parity bit
				
				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				ijmp					; no -> make instruction cycles


;------------- begin of instruction cycle with substractions handling PSW & flags ------

set_flags_sub:		
		 		 mov	_last_result,A
set_flags_cmp:		

				 ldi	ZL,1<< ATMEL_H			; after substraction invert half-carry bit(H)
				 in	PSW,SREG
				 eor	PSW,ZL


				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				ijmp					; no -> make instruction cycles

				

				
							


<? 
function _write($h,$l,$data,$output_address=true,$deactive=true,$active=true)
{
	/**
		; write to PMD memory
		; Memory areas (each 16 KB):
		; RAM        0x0000 to 0x7fff  
		; ROM        0x8000 to 0x8fff  
		; <free>     0x9000 to 0xbfff
		; videoram   0xc000 to 0xffff  

	**/
			
		  
if( $deactive ) { ?>
		MEMRD_deactive			
		out		DDRA,_255
<? } ?>		

<? if( $output_address ) { ?>
		out		ADDRL,<? echo $l; ?>    ; output 16 bit address 
		out		ADDRH,<? echo $h; ?>
<? } ?>

		out		PORTA,<? echo $data; ?>

	
		sbrc		<? echo $h; ?>,7	    ; skip if address < 0x8000
		sbrc		<? echo $h; ?>,6	    ; skip if 6th bit is clear
		MEMWR_active
		MEMWR_deactive

<? if( $active ) { ?>
		out		DDRA,_zero			; PORTA input
		MEMRD_active
<? } 
} 

?>



		

;***********************************************************************************************
;***********************************************************************************************
;***********************************************************************************************
;***********************************************************************************************

<?
	
function prepare($r)
{
   	if( $r == 'i' )
   	{
   		echo "
			out		ADDRL,_PCL
			out		ADDRH,_PCH
			adiw		_PCL,1
		     ";
   	}	
   	
   	
   	if( $r == 'm' )
   	{
   		echo "
   			out		ADDRL,L
			out		ADDRH,H
		     ";
			MDELAY();
	}
		     		
   	if( $r == 'm' || $r == 'i')
   	{

		echo	"
         		in		XL,PINA
         		";
         	return "XL";     
         }
         else
         {
         	return strtoupper($r);
         }         		
	
}

$reg = array ( 'a', 'b','c','d','e','h','l', 'm','i' );
 
 foreach( $reg as $r1) 
 {
   $R1 = strtoupper($r1);
   
   if( $r1 != 'm' && $r1 != 'i' )
   {
   
   echo "_inr_$r1:\n";
   INR8($R1);
   echo "\n";

   echo "_dcr_$r1:\n";
   DCR8($R1);
   echo "\n";
   
   echo "_mvi_$r1:\n";
   MVI($R1);
   echo "\n";
   
   echo "_mov_${r1}m:\n";
   MOVRM($R1);
   echo "\n";

   echo "_mov_m${r1}:\n";
   MOVMR($R1);
   echo "\n";
   
   }
   
   
   if( $r1 != 'i' )
     echo "_add_$r1:\n";
   else
     echo "_adi:\n";
     
   ADD8(prepare($r1));
   echo "\n";


   if( $r1 != 'i' )
     echo "_adc_$r1:\n";
   else
     echo "_aci:\n";

   ADC8(prepare($r1));
   echo "\n";

  if( $r1 != 'i' )
     echo "_sub_$r1:\n";
   else
     echo "_sui:\n";

   SUB8(prepare($r1));
   echo "\n";

   
   if( $r1 != 'i' )
     echo "_sbb_$r1:\n";
   else
     echo "_sbi:\n";

   SBB8(prepare($r1));
   echo "\n";

   
   if( $r1 != 'i' )
     echo "_cmp_$r1:\n";
   else
     echo "_cpi:\n";
   
   CMP8(prepare($r1));
   echo "\n";

   $r = "i";
   if( $r1 != 'i' ) $r = "a_$r1";

   echo "_an$r:\n";
   AND8(prepare($r1));
   echo "\n";

   echo "_or$r:\n";
   OR8(prepare($r1));
   echo "\n";

   echo "_xr$r:\n";
   XOR8(prepare($r1));
   echo "\n";

 }


function i_cycle_turbo()
{
 global $turbo;
 
 if($turbo)
 { ?>
 
				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				ijmp					; make instruction cycle

				<?
 }
 else
 {
  echo "\nrjmp	i_cycle_turbo\n";	
 } 	
	
	
}

function set_flags_turbo()
{
 global $turbo;
 
 if($turbo)
 { ?>
				in		PSW,SREG
				mov		_last_result,A
				
				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				ijmp					; no -> make instruction cycles
 <?
 }
 else
 {
  echo "\nrjmp	set_flags\n";	
 } 	
	
	
}


function i_cycle_turbo_clr_CH()
{
 global $turbo;

 if($turbo)
 { ?>
				
				in		PSW,SREG
				andi		PSW,~((1<<ATMEL_C)|(1<<ATMEL_H))

				mov		_last_result,A
				
				out		ADDRL,_PCL
				out		ADDRH,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				ijmp					
      <?
 }
 else
 {
  echo "\nrjmp	clr_CH\n";	
 } 	
}				


function INR8($r) 
{
  echo "
		bst		PSW,0 
		sec
		adc		$r,_zero
		in		PSW,SREG
		bld		PSW,0 	; copy old CY
		mov		_last_result,$r
	        ";
i_cycle_turbo();
}



function DCR8($r)
{
	echo "
		 bst		PSW,0 		; save CY
		 ldi		XL,1
		 sub		$r,XL

		 mov		_last_result,$r
		 in		PSW,SREG
		 bld		PSW,0 ; obnovenie CY
		 ";
		 
		 i_cycle_turbo();
}		 
		 

?>

_inr_m:	
		out		ADDRL,L
		out		ADDRH,H
		bst		PSW,0 		; wait a minute & save CY
		sec
		in		XL,PINA

		adc		XL,_zero

		mov		_last_result,XL
 		in		PSW,SREG
		bld		PSW,0 ; obnovenie CY

		<? _write(H,L,XL,false); ?>
		<? i_cycle_turbo(); ?>


_dcr_m:	
		out		ADDRL,L
		out		ADDRH,H
		bst		PSW,0 		; wait a minute & save CY
          	ldi		XH,1
          	in		XL,PINA

		sub		XL,XH
		
		mov		_last_result,XL
        	in		PSW,SREG
		bld		PSW,0 	; obnovenie CY

		<? _write(H,L,XL,false); ?>
		<? i_cycle_turbo(); ?>



_inx_b:
			subi	C,low(-1)
			sbci	B,high(-1)
 		 	<? i_cycle_turbo(); ?>
			

_inx_d:
			subi	E,low(-1)
			sbci	D,high(-1)
 		 	<? i_cycle_turbo();  ?>

_inx_h:		
			sec
			adc	L,_zero
			adc	H,_zero
 		 	<? i_cycle_turbo(); ?>

_inx_sp:
			adiw 	_SPL,1
 		 	<? i_cycle_turbo(); ?>


_dcx_b:
			subi	C,low(1)
			sbci	B,high(1)
 		 	<? i_cycle_turbo(); ?>
			

_dcx_d:		
			subi	E,low(1)
			sbci	D,high(1)
 		 	<? i_cycle_turbo(); ?>
			

_dcx_h:
			sec
			sbc		L,_zero
			sbc		H,_zero
 		 	<? i_cycle_turbo(); ?>
			
_dcx_sp:
			sbiw 	_SPL,1
 		 	<? i_cycle_turbo(); ?>



;*********************** scitanie 16-bit **********
; ovplynuje len CY 

<?

function LXI( $r1, $r2)
{
   echo "
		out		ADDRL,_PCL
		out		ADDRH,_PCH
		adiw	_PCL,1
		in		$r2,PINA 
		out		ADDRL,_PCL
		out		ADDRH,_PCH
		adiw	_PCL,1
		in		$r1,PINA
  ";
  		i_cycle_turbo();
}
function ADD16($h,$l)
{
	echo "
	                ;  high,low 
			ror		PSW		
			add		L,$l
			adc		H,$h
			rol		PSW"; 
	  		i_cycle_turbo();

}  ?>

_dad_b:		<? ADD16('B','C'); ?>
_lxi_b:		<? LXI('B','C'); ?>

_dad_d:		<? ADD16('D','E'); ?>
_lxi_d:		<? LXI('D','E'); ?>

_dad_h:		<? ADD16('H','L'); ?>
_lxi_h:		<? LXI('H','L'); ?>

_dad_sp:	<? ADD16('_SPH','_SPL'); ?>
_lxi_sp:	<? LXI('_SPH','_SPL'); ?>


<?


function SUB8($r)
{
 	echo	 "
		 sub	A,$r
		 rjmp	set_flags_sub
			";
}			


function SBB8($r)
{
 	echo	 "
		 ror	PSW
		 sez		; must be	
		 sbc	A,$r
		 rjmp	set_flags_sub
		 ";
}			



function  ADD8($r)
{  
  	echo  "
	     add A,$r
	     ";
	 set_flags_turbo();    
} 

function  ADC8($r)
{  
  	echo  "
	     ror	PSW
	     adc 	A,$r
	     ";
	 set_flags_turbo();    
} 



function CMP8($r)
{
	echo "
			mov	XH,A
			sub	XH,$r
			mov	_last_result,XH
			rjmp	set_flags_cmp
	     ";
}


function AND8($r)
{
   echo 	"and		A,$r		";
   		i_cycle_turbo_clr_CH();
}  		


function XOR8($r)
{
   echo 	"
   		eor		A,$r
   		";
   		i_cycle_turbo_clr_CH();   		
}  		


function OR8($r)
{
   echo "
   		or		A,$r
   		";
   		i_cycle_turbo_clr_CH();   		
}  		


?>






;**************************** MOV ra,rb  ********
<?
 $reg = array ( 'a', 'b','c','d','e','h','l' );
 
 foreach( $reg as $r1) 
 {
   $R1 = strtoupper($r1);
   foreach( $reg as $r2 )
   
   {
   $R2 = strtoupper($r2);
   if( $R2 != $R1 )
     echo "_mov_$r1$r2:\t
     		mov		$R1,$R2
          ";
          i_cycle_turbo();

   }
 
 
 
 
 }


function MVI($r)
{
   echo "
		out		ADDRL,_PCL
		out		ADDRH,_PCH 
		adiw		_PCL,1 
		in		$r,PINA 
		";
		i_cycle_turbo();
}

function MOVRM($r)
{
   static $i=1;
   $i++;
   echo "
		out		ADDRL,L
		out		ADDRH,H
		rjmp		PC+1
		in		$r,PINA
	
	";
	
	i_cycle_turbo();	
	
	
}	

function MOVMR($r)
{
        _write(H,L,$r,true); 
	i_cycle_turbo();	
}
?>




;******************************** bitove operacie ********************
			.equ	_CY  =		1
			.equ	_Z	 = 		2
			.equ	_S	 =		0x10
			.equ	_AC	 =		0x20

_cmc:		
			ldi		XL,_CY
			eor		PSW,XL	; C u Atmela je 0.bit
			<? i_cycle_turbo(); ?>

_stc:	
			ori		PSW,1<<0
			<? i_cycle_turbo(); ?>

_cma:		; PSW unchanged
			com		A
			<? i_cycle_turbo(); ?>


_rlca:			;okrem CY neovplyvnuje nic
			ror		PSW
			bst		A,7
			rol		A
			bld		A,0
			rol		PSW
			<? i_cycle_turbo(); ?>
			

_rrca:			;okrem CY neovplyvnuje nic
			ror		PSW
			bst		A,0
			ror		A
			bld		A,7
			rol		PSW
			<? i_cycle_turbo(); ?>
			

_rla:			;okrem CY neovplyvnuje nic
			ror		PSW
			rol		A
			rol		PSW
			<? i_cycle_turbo(); ?>
			
			
_rra:			;okrem CY neovplyvnuje nic
			ror		PSW
			ror		A
			rol		PSW
			<? i_cycle_turbo(); ?>
			

;************************** zasobnikove sracky *******************************
<?php
function PUSH16($h,$l)
{

      echo 	"		
			sbiw		_SPL,1
		";
      _write(_SPH,_SPL,$h,true,true,false); 
		
      echo 	" 	sbiw		_SPL,1
      ";
      _write(_SPH,_SPL,$l,true,false,true); 
		
       			
}

function POP16( $r0,$r1) 
{
   echo "
			out		ADDRL,_SPL
			out		ADDRH,_SPH
			adiw	_SPL,1
			in		$r1,PINA
			out		ADDRL,_SPL
			out		ADDRH,_SPH
			adiw	_SPL,1
			in		$r0,PINA			
	";		
}

?>

_push_h:	<?	PUSH16('H','L'); ?>
		<?	i_cycle_turbo(); ?>

_push_d:	<?	PUSH16('D','E'); ?>
		<?	i_cycle_turbo(); ?>

_push_b:	<?	PUSH16('B','C'); ?>
		<?	i_cycle_turbo(); ?>

_push_a:		
			; from PSW & _last_result ---> XL
			; XL & A --> STACK
			<? calculate_parity(); ?>
			ldi		XL,PMD_PSW
			bld		XL,2	;P copied
			bst		PSW,0
			bld		XL,0  ; CY copied
			bst		PSW,1
			bld		XL,6  ; Z copied
			bst		PSW,2
			bld		XL,7	; S copied
			bst		PSW,5
			bld		XL,4	; A copied
		<?	PUSH16('A','XL'); ?>    
		<?	i_cycle_turbo(); ?>

			
_pop_h:		<? POP16('H','L');
		   i_cycle_turbo();
		 ?>

_pop_d:		<? POP16('D','E');
		   i_cycle_turbo();	
		 ?>

_pop_b:		<? POP16('B','C');
		   i_cycle_turbo();
 ?>


_pop_a:			
		<?	POP16('A','XL'); ?>
			ldi		PSW,0x80; I = 1 => mustbe !!! , inak bysa mohlo zakazat prerusenie a blbla by klavesnica a speaker
			bst		XL,0  	; CY copied
			bld		PSW,0
			bst		XL,6   ; Z copied
			bld		PSW,1
			bst		XL,7	; S copied
			bld		PSW,2
			bst		XL,4	; A copied
			bld		PSW,5
			mov		_last_result,_zero
			sbrs		XL,2   ; T = P; if XL.2 == 1 => skip next
						; parita nuly je jedna !!!, 0x01 => P=0; 0x5b => P = 0
		
			inc		_last_result	;	_last_result := 1			

		<? 	i_cycle_turbo(); ?>


;**************** calls & jumps & rets *****************************************

<?
//1 = parna
//0 = neparna parita(ako u 8080)

function calculate_parity()
{
	
	global $turbo;
	
?>
		; vypocita paritu z registra _last_result; vystup bude v bite T 
		; parita v 8080 znamenala neparnu paritu => paritny bit doplnal vysledok operacie do neparneho poctu bitov
	        ; even parity = parna 
	        ; odd  parity = neparna
	        ; destroy X register, T = result parity bit
	        
	        ldi	XH,high(parity_table)
	        mov	XL,_last_result
	        ld	XL,X
	        bst	XL,0
<? } ?>
	
	
_rc:			out		SREG,PSW
			brbs	0,_ret	  ;	bit 0 of SREG is C and if is set  ( 1 ) do return
			<? i_cycle_turbo(); ?>
			

_rnc:			out		SREG,PSW
			brbc	0,_ret	  ;	bit 0 of SREG is C and if is clear  ( 0 ) do return
			<? i_cycle_turbo(); ?>
			

_rp:        		;return PLUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brpl	_ret	  ;	bit 2 of SREG is N and if is CLEAR !!!!  ( 0 ) do return
			<? i_cycle_turbo(); ?>
			

_rm:        		;call MINUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brmi	_ret	  ;	bit 2 of SREG is N and if is SET !!!!  ( 1 ) do return
			<? i_cycle_turbo(); ?>

		
_ret:		
			<? POP16('_PCH','_PCL');
			i_cycle_turbo();
			 ?>
			

_rpe:	
			<? calculate_parity(); ?>
			brts	_ret
						; EVEN = (PARITY == 1)
			<? i_cycle_turbo(); ?>


_rpo:       
			<? calculate_parity(); ?>
			brtc	_ret
						; ODD = (PARITY == 0)
			<? i_cycle_turbo(); ?>
			

_rz:			out		SREG,PSW
			brbs	1,_ret	  ;	bit 1 of SREG is Z and if is set  ( 1 ) do return
			<? i_cycle_turbo(); ?>
			

_rnz:			out		SREG,PSW
			brbc	1,_ret	  ;	bit 1 of SREG is Z and if is clear  ( 0 ) do return
			<? i_cycle_turbo(); ?>
			

_cpo:       
			<? calculate_parity(); ?>
			brtc	_call 		; ODD = (PARITY == 0)

			adiw	_PCL,2
			<? i_cycle_turbo(); ?>


			

_cc:			out	SREG,PSW
			brbs	0,_call	  ;	bit 0 of SREG is C and if is set  ( 1 ) do call
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_cnc:			out	SREG,PSW
			brbc	0,_call	  ;	bit 0 of SREG is C and if is clear  ( 0 ) do call
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_cp:        		;call PLUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brpl	_call	  ;	bit 2 of SREG is N and if is CLEAR !!!!  ( 0 ) do call
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_cm:        		;call MINUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brmi	_call	  ;	bit 2 of SREG is N and if is SET !!!!  ( 1 ) do call
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>


_cz:			out	SREG,PSW
			brbs	1,_call	  ;	bit 1 of SREG is Z and if is set  ( 1 ) do call
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_cnz:			out	SREG,PSW
			brbc	1,_call	  ;	bit 1 of SREG is Z and if is clear  ( 0 ) do call
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>



_call:		
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw	_PCL,1
			in		XL,PINA
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw	_PCL,1
			in		XH,PINA
_rst_entry:
			<? PUSH16('_PCH','_PCL'); ?>	 ; navratova adresa do stacku
			movw		_PCL,XL
			<? i_cycle_turbo(); ?>

_cpe:	
			<? calculate_parity(); ?>
			brts	_call 		; EVEN = (PARITY == 1)
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>
			




_jm:        		;call MINUS	-> use N(negative) flag at atmel
			out		SREG,PSW
			brmi	_jmp	  ;	bit 2 of SREG is N and if is SET !!!!  ( 1 ) do jump
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

			
_jc:			out	SREG,PSW
			brbs	0,_jmp	  ;	bit 0 of SREG is C and if is set  ( 1 ) do jump
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_jnc:			out	SREG,PSW
			brbc	0,_jmp	  ;	bit 0 of SREG is C and if is clear  ( 0 ) do jump
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_jp:        		;call PLUS	-> use N(negative) flag at atmel
			out	SREG,PSW
			brpl	_jmp	  ;	bit 2 of SREG is N and if is CLEAR !!!!  ( 1 ) do jump
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_jmp:
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XL,PINA
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			mov		_PCL,XL
			nop
			in		_PCH,PINA
			<? i_cycle_turbo(); ?>

_jpe:	
			<? calculate_parity(); ?>
			brts	_jmp 		; EVEN = (PARITY == 1)
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_jpo:			<? calculate_parity(); ?>
			brtc	_jmp 		; ODD = (PARITY == 0)
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_jz:			out	SREG,PSW
			brbs	1,_jmp	  ;	bit 1 of SREG is Z and if is set  ( 1 ) do jump
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>

_jnz:			out	SREG,PSW
			brbc	1,_jmp	  ;	bit 1 of SREG is Z and if is clear  ( 0 ) do jump
			adiw	_PCL,2
			<? i_cycle_turbo(); ?>



                                                 

;******************* RST instructions ****************************************			

<? function RST($n)
   { 
	echo "
			ldi		XL,low(8*$n)
			ldi		XH,high(8*$n)
			rjmp	_rst_entry
	     ";
   }
   
   for($i = 0; $i < 8 ; $i++ )
   {
    echo "_rst$i:\t";
    RST($i);
   } 	     	 	

   function MDELAY()
   {
      echo "	rjmp	PC+1\n";	
   	
   } 

?>
;************************ OPERACIE S pamatou *********************

_lda:		
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XL,PINA
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XH,PINA
			
			out		ADDRL,XL
			out		ADDRH,XH
			<? MDELAY(); ?>
			in		A,PINA
			<? i_cycle_turbo(); ?>


_sta:		
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XL,PINA
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XH,PINA
			<? _write(XH,XL,A,true); ?>
			<? i_cycle_turbo(); ?>
			

_mvi_m:
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XL,PINA
			<? _write(H,L,XL,true); ?>
			<? i_cycle_turbo(); ?>


;************************ a := [ r16 ] nepriame adresovanie pomocou r16. *****

_ldax_b:	
			out		ADDRL,C
			out		ADDRH,B
			<? MDELAY(); ?>
			in		A,PINA
			<? i_cycle_turbo(); ?>

_stax_b:	
			<? _write(B,C,A,true); ?>
			<? i_cycle_turbo(); ?>


_ldax_d:	
			out		ADDRL,E
			out		ADDRH,D
			<? MDELAY(); ?>
			in		A,PINA
			<? i_cycle_turbo(); ?>

_stax_d:	
			<? _write(D,E,A,true); ?>
			<? i_cycle_turbo(); ?>

_lhld:
			out		ADDRL,_PCL
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XL,PINA
			
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XH,PINA

			out		ADDRL,XL
			out		ADDRH,XH
			adiw		XL,1
			in		L,PINA
			
			out		ADDRL,XL
			out		ADDRH,XH
			<? MDELAY(); ?>
			in		H,PINA
			<? i_cycle_turbo(); ?>


_shld:			out		ADDRL,_PCL
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XL,PINA
			out		ADDRL,_PCL	
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		XH,PINA

			<? _write(XH,XL,L,true,true,false); ?>

			adiw		XL,1
			<? _write(XH,XL,H,true,false,true); ?>
			<? i_cycle_turbo(); ?>


_sphl:
			movw		_SPL,L
			<? i_cycle_turbo(); ?>



_pchl:
			movw		_PCL,L
			<? i_cycle_turbo();?>




_xthl:		
			out		ADDRL,_SPL
			out		ADDRH,_SPH
			movw		XL,L
			nop
			in		L,PINA
			
			<? _write(_SPH,_SPL,XL,false); ?>
			adiw		_SPL,1

			out		ADDRL,_SPL
			out		ADDRH,_SPH
			<? MDELAY(); ?>
			in		H,PINA

			<? _write(_SPH,_SPL,XH,false); ?>
			sbiw		_SPL,1
			<? i_cycle_turbo(); ?>


_xchg:			
			movw		XL,L
			movw		L,E
			movw		E,XL
			<? i_cycle_turbo(); ?>


_daa:		
			clr		XH 	    ; add register
			mov		XL,A	
			andi		XL,0x0f   ; low nibble of A
			cpi		XL,9 + 1
			brlo		_daa1
			ori		XH,6
	_daa1:		sbrc		PSW,ATMEL_H		
			ori		XH,6
			sbrc		PSW,ATMEL_C
			ori		XH,0x60
			mov		XL,A
			cpi		XL,0x9f+1
			brlo		_daa2
			ori		XH,0x60
	_daa2:		
			cpi		XL,0x99+1
			brlo		_daa3
			set
			bld		PSW,ATMEL_C ; CY :=1	
	_daa3:		
			cpi		XL,0x90+1
			brlo		_daa4
			andi		XL,0x0f   ; low nibble of A
			cpi		XL,9 + 1
			brlo		_daa4
			ori		XH,0x60
	_daa4:		
			add		A,XH
			rjmp		save_parity
					
			



;*********************************************************************
;****            I/O subsystem                                    ****
;*********************************************************************
in_channels:
			rjmp	in_channel0
			rjmp	in_channel1	
			rjmp	in_channel2
            		rjmp	in_channel3
            		rjmp	in_channel4
            		rjmp	in_channel5
            		rjmp	in_channel6
            		rjmp	in_channel7

out_channels:
			rjmp	out_channel0
			rjmp	out_channel1	
			rjmp	out_channel2
            		rjmp	out_channel3
            		rjmp	out_channel4
            		rjmp	out_channel5
            		rjmp	out_channel6
            		rjmp	out_channel7

rd_usart_status:
			
			
			ldi		XH,7	; data vzdy prijate; TxE = 1, RxRDY=1 , TxDRY=1
			
			
			lds		XL,usart_wr_counter
			set					; T = TxRDY := 1
			cpse		XL,_zero
			clt					; T = TxRDY := 0
			bld		XH,0	; TxRDY (vyslane) T -> A[0.bit] 
			mov		A,XH
			rjmp	i_cycle

			
							





rd_kbd_pb:		lds	XL,kbd_ports + 0  ; hodnota PA 
			andi	XL,0b1111		; nechame iba spodne 4 bity(16 cols)
			subi	XL, low( -kb_cols )
			ldi	XH, high( kb_cols )
			ld	A,X				; nacitame hodnotu stlpca = riadkova hodnota
			lds	XL,kbd_flags
			andi	XL,(1<<SHIFT_bit)|(1<<STOP_bit)
			or	A,XL				; ZAPISEME hodnotu SHIFT + STOP
			
			rjmp	i_cycle

rd_pmd_kbd: 		andi	XL,0b11       ; interne cislo portu v 8255
			cpi	XL,1          ; PB ?
			breq	rd_kbd_pb
			subi		XL, low( -kbd_ports )
			ldi		XH, high( kbd_ports )
			ld		A,X				; nacitame do reg. A
			rjmp	i_cycle


rd_rom_modul: 
			andi	XL,0b11       ; internal port number in 8255
			breq	rd_rom_modul_from_flash
			subi		XL,low(-_rom)
			ldi		XH,high(_rom)
			ld		A,X
			rjmp	i_cycle

rd_channel_0_7:
			mov		XH,XL
			swap		XH
			andi		XH,0x0f
			ldi		ZH,high(in_channels)
			ldi		ZL,low(in_channels)
			add		ZL,XH
			adc		ZH,_zero
			ijmp


_in:		
			out		ADDRL,_PCL
			out		ADDRH,_PCH
			adiw	_PCL,1
			in		XH,PINA
			
			mov	XL,XH		; in XL is port address

			
			
			andi	XH,0b10001100
			cpi	XH,0b10000100
			breq	rd_pmd_kbd
			cpi	XH,0b10001000
			breq	rd_rom_modul
			cpi	XH,0b00001100
			breq	rd_channel_0_7
			cpi	XL,0xf0		; support for USART Didaktiku Alfa ....
			breq	in_channel1
			cpi	XL,0xf1
			breq	in_channel1
			
			rjmp	i_cycle		; read from other port (not implemented/not existss) 
			
rd_rom_modul_from_flash:  
			
			ldi		XL,low(C_basic1_start)
			ldi		XH,high(C_basic1_start)
			lds		ZL,_rom + 1	; byte1
			add		XL,ZL
			lds		ZL,_rom + 2	; byte2
			andi		ZL,0b01111111
			adc		XH,ZL
			
			<? flash_read('_zero','XH','XL','A'); ?> 
			rjmp		i_cycle

in_channel1:  
			;1C a 1E  = DATA
			;USART --> DATA/STATUS register
			
			sbrc	XL,0 		; DATA/status ( 0 = DATA, 1 = STATUS )
			rjmp	rd_usart_status

.dseg

last_byte:	.byte	1
last_count:	.byte	1

.cseg


rd_usart_data:		; output: reg. A  = data from tape (and increment tape pointer)
			; uses RLE compression
			lds		XL,mgf_pointer+0
			lds		XH,mgf_pointer+1
			lds		ZL,mgf_pointer+2

			lds		ZH,last_count
			cpi		ZH,1			; 1 == must read, >1 ... unpack from buffer :) 
			breq		must_read_next_char
			lds		A,last_byte
			cpi		ZH,2
			breq		check_doubles
			dec		ZH			; decrement count of bytes to read from buffer
			sts		last_count,ZH
			rjmp		i_cycle
			
must_read_next_char:	
					

               		<? flash_read('ZL','XH','XL','A'); ?> ; this char will be returned (A)

			adiw		XL,1
			adc		ZL,_zero
check_doubles:
			<? flash_read('ZL','XH','XL','ZH'); ?> ; ZH
			
			adiw		XL,1
			adc		ZL,_zero

			cp		ZH,A
			sts		last_byte,ZH	; remember next char
			ldi		ZH,2		; count :=2
			brne		no_packed
	
			<? flash_read('ZL','XH','XL','ZH'); ?> 	; read count if 
			
			adiw		XL,1
			adc		ZL,_zero
			
no_packed:
			sts		last_count,ZH	; remember count
				
			cpi		ZL,0x08		; over 512 KB? (29F040 has capacity 512KB) 
			brne		store_mgf_pointer

			ldi		XL,byte1(C_games_start)
			ldi		XH,byte2(C_games_start)
			ldi		ZL,byte3(C_games_start)
			
store_mgf_pointer:
			sts		mgf_pointer+0,XL
			sts		mgf_pointer+1,XH
			sts		mgf_pointer+2,ZL

			rjmp	i_cycle







				
out_channel1:		; some games i.e. HLIPE uses USART as a timer (write to data register and then 
                        ; read status. TXC will set in status word 11/1200 s = 9.16 ms (after 143 TV row scans) 
                        ; ) 
                        
			ldi	XL,<? echo round((1+8+1+1)/1200/64e-6); ?>
			
			sts	usart_wr_counter,XL
			
			; go to i_cycle ---> go down
				
out_channel0:	
out_channel2:
out_channel3:
out_channel4:				
out_channel5: 
out_channel6:
out_channel7: 
			rjmp	i_cycle


in_channel4:					; joystick disconnected ;-)
in_channel5: ; TODO
in_channel7: ; TODO
			mov		A,_255
in_channel0:
in_channel2:
in_channel3:
in_channel6:
			rjmp	i_cycle




wr_rom_modul:
			andi		XL,0b11      ; internal port number in IC 8255
			subi		XL,low(-_rom)
			ldi		XH,high(_rom)
			st		X,A
			rjmp		i_cycle

wr_channel_0_7:
			mov		XH,XL
			swap		XH
			andi		XH,0x0f
			ldi		ZH,high(out_channels)
			ldi		ZL,low(out_channels)
			add		ZL,XH
			adc		ZH,_zero
			ijmp



_out:
			out		ADDRL,_PCL
			out		ADDRH,_PCH
			adiw		_PCL,1
			in		ZL,PINA

			mov		XL,ZL		; XL is port number
			
			
			andi	ZL,0b10001100		; decode port number
			cpi		ZL,0b10000100
			breq	wr_pmd_kbd
			cpi		ZL,0b10001000
			breq	wr_rom_modul
			cpi		ZL,0b00001100
			breq	wr_channel_0_7

			rjmp	i_cycle


wr_pmd_kbd:		andi		XL,0b11       ; internal prt number in IC 8255
			mov		ZL,XL
			subi		XL, low( -kbd_ports )
			ldi		XH, high( kbd_ports )

			st		X,A			; write  register A to virtual port
			
			cpi		ZL,3			; CW ?
			breq		wr_kbd_cw
			
			cpi		ZL,2			; PC ?
			breq		wr_kbd_pc			


         		rjmp	i_cycle
				




wr_kbd_cw:
				sbrc		A,7		  ; CW.7 == 0 is ADDRH bit set/reset instruction
				rjmp		i_cycle		  ; CW.7 == 1 is control word (not implemented)	
				
			
				mov		XL,A
				lsr		XL				 
				andi		XL,0b111	  ; in XL is bit number(0..7)
				sec
				clr		ZL

mask_compute:			rol		ZL
				dec		XL
				brne	mask_compute
				
				lds 	XL,kbd_ports + 2     	       ; XL = port C of 8255
				com		ZL                     ; mask AND  
				and		XL,ZL			   
				com		ZL		       ; mask OR 	
				sbrc	A,0			       ; skip if zero bit must be written	
				or		XL,ZL
				
						  
				sts 	kbd_ports + 2,XL    	 	; port C := XL

				; continue to wr_kbd_pc		


wr_kbd_pc:
          ; on port C was connected  LEDs a repro
          ; PC0        00 = repro off   11=tone3
          ;      =     01 = tone1
          ; PC1        10 = tone2
         
          ; PC2 = yellow LED - log.1 lights LED and turn on repro
          ; PC3 = red LED
          
				lds	XL,kbd_ports + 2 ; PC0
				bst	XL,0		 ; PC3 := PC0 
				bld	XL,3
				andi	XL,0b1110
				sts	kbd_portC,XL



	sound_failed:		

				mov	ZL,m64
				mov	XH,ZL
				ori	ZL,0b100
				
				lds	XL,kbd_portC
				
				and	XL,ZL
				
				breq	ton00	
				sbi	PORTD,PD5
			ton00:
				brne	ton11
				cbi	PORTD,PD5
			ton11:	
				cp	XH,m64
				brne	sound_failed
	
			rjmp	i_cycle
 

<?

function flash_read($a2,$a1,$a0,$data)
{
?>
             	out		ADDRL,<? echo $a0 ?> 
		out		ADDRH,<? echo $a1 ?> 
		out		DDRA,_zero
				
		bst		<? echo $a2 ?>,0	;A16
		bld		video_PORTE,1		; PE1
		out		PORTE,video_PORTE				
		
		SELECT_FLASH
		MEMRD_ACTIVE
		in		<? echo $data ?>,PORTD
		bst		<? echo $a2 ?>,1		;A17
		bld		<? echo $data ?>,2		;PD2
		bst		<? echo $a2 ?>,2		;A18
		bld		<? echo $data ?>,1		;PD1
		
		out		PORTD,<? echo $data ?>
		
		RJMP		PC+1		; FLASH is 90 ns, cycle is about 50 ns ==> must be 2 cycle delay 
		RJMP		PC+1		; FLASH is 90 ns, cycle is about 50 ns ==> must be 2 cycle delay 
		in		<? echo $data ?>,PINA

		SELECT_RAM
<?
}
?>

		
			




kb_lookup: 	.include	"kb_lookup.asm"


		.org	(high(PC) + (low(PC) != 0) ) *256 ; alignment 256 words

i_table:		
		.include	"8080.asm"		
 

			



.dseg

		.org	0x100		; reserve in SRAM location 256 bytes for look-up parity table
parity_table:	.byte	0x100		
usart_wr_counter:.byte	1	; for HLIPA
