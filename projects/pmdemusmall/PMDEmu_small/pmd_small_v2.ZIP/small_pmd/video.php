;    PMDEmu - AVR based emulator of Czechoslovak microcomputer PMD-85 originally based on I8080
;    Copyright (C) 2003  Peter Chrenko <peto@kmit.sk>, J.Matusku 2178/21, 955 01 Topolcany, Slovakia

;    video.php

	.equ		total_lines	= 312
	.equ		visible_lines	= 256
	.equ		dark_lines	= 36	
	

interrupt_OCR1A:	

	in	video_SREG,SREG		
	
	in	video_tmp,TCNT1L		;synchronize with 1 and 2 cycles interrupted instuction
	sbrs	video_tmp,0
	rjmp	PC+1
		
	lds	video_tmp,usart_wr_counter	; slow down USART transmitter (HLIPA)
	cpse	video_tmp,_zero
	dec	video_tmp
	sts	usart_wr_counter,video_tmp

	inc	m64
	mov	video_tmp,m64	
	ori	video_tmp,0b100
	
	
	lds	video_DDRA,kbd_portC ; PC0
	and	video_tmp,video_DDRA
	
	breq	ton0	
	sbi	PORTD,PD5
ton0:
	brne	ton1
	cbi	PORTD,PD5
ton1:	

	cpi	video_state,dark_lines		;
	breq	normal_line
	out	PORTE,video_PORTE	; BLACK
	inc	video_state
	
	cpi	video_state,total_lines-visible_lines-1		
	breq	vertical_sync
			
	ldi	video_tmp,48*3*6/4-20/4
wait2:	dec	video_tmp
	nop
	brne	wait2

	rjmp	_reti
	
	
	
vertical_sync:
	cbi	DDRE,DDE2		; DISCONNECT PE2 ( sync ) , output voltage = 0 V
	ldi	video_tmp,24*3*6/3-20/3
wait1:	dec	video_tmp
	brne	wait1
	sbi	DDRE,DDE2		; CONNECT PE2 ( sync ) 
	
	; video address := 0xc000
	ldi		video_tmp,0xc0			
	mov		video_ptr_h,video_tmp

	mov	video_state,_zero	; state := 0
	
	lds		video_tmp,blink_counter
	dec		video_tmp
	brne		no_visibility_change	
	
	com		mask_register
	ldi		video_tmp,blink_period
no_visibility_change:	
	sts		blink_counter,video_tmp
		


	ldi	video_tmp,24*3*6/3-(25-2)/3
wait3:	dec	video_tmp
	brne	wait3

	rjmp	_reti

normal_line:	
	; show TV microline 

	in	video_PORTD,PORTD
	in	video_PORTA,PORTA
	in	video_DDRA,DDRA	
	in	video_portC,ADDRH
	in	video_portB,ADDRL
	
	
	MEMWR_deactive
	out	DDRA,_zero		; PORTA input	
	SELECT_RAM
	MEMRD_active
	
	out	ADDRL,video_ptr_l
	out	ADDRH,video_ptr_h

	push	video_tmp2			; delay & free    video_tmp2
	
	in	video_tmp,PINA		; B X 5 4 3 2 1 0 (B = blink, X = not implemented)
	sbrc	video_tmp,7		; 
	and	video_tmp,mask_register
		
	
<? 
	$count = 48/2;
for( $i = 0; $i < $count; $i++ ){ 
	
	echo "\t; ".(2*$i).".byte\n";
	?>	
	
	out	PORTE,video_tmp		; 0.bit first byte
	lsr	video_tmp
	inc	video_ptr_l
	
	out	PORTE,video_tmp		; 1.bit first byte
	lsr	video_tmp
	out	ADDRL,video_ptr_l	; output low address 
	
	out	PORTE,video_tmp		; 2.bit first byte
	lsr	video_tmp
	in	video_tmp2,PINA		; load next 6 pixels :X X 5 4 3 2 1 0
	
	out	PORTE,video_tmp		; 3.bit first byte
	lsr	video_tmp
	nop
	
	out	PORTE,video_tmp		; 4.bit first byte
	lsr	video_tmp
	nop
	
	out	PORTE,video_tmp		; 5.bit first byte
	sbrc	video_tmp2,7
	and	video_tmp2,mask_register

<?	echo "\t; ".(2*$i+1).".byte\n"; ?>

<? if( $i != $count -  1): ?> 

	
	out	PORTE,video_tmp2		; 0.bit secound byte
	lsr	video_tmp2
	inc	video_ptr_l
	
	out	PORTE,video_tmp2		; 1.bit secound byte
	lsr	video_tmp2
	out	ADDRL,video_ptr_l	; output low address
	
	out	PORTE,video_tmp2		; 2.bit secound byte
	lsr	video_tmp2
	in	video_tmp,PINA		; load next 6 pixels :X X 5 4 3 2 1 0
	
	out	PORTE,video_tmp2		; 3.bit secound byte
	lsr	video_tmp2
	nop
	
	out	PORTE,video_tmp2		; 4.bit secound byte
	lsr	video_tmp2
	nop
	
	out	PORTE,video_tmp2		; 5.bit secound byte
	sbrc	video_tmp,7
	and	video_tmp,mask_register

<? else: ?>
	; last byte on microline
	
	out	PORTE,video_tmp2		; 0.bit secound byte
	lsr	video_tmp2
	out	ADDRL,video_PORTB
	
	out	PORTE,video_tmp2		; 1.bit secound byte
	lsr	video_tmp2
	out	ADDRH,video_portC
	
	out	PORTE,video_tmp2		; 2.bit secound byte
	lsr	video_tmp2
	out	PORTA,video_PORTA
	
	out	PORTE,video_tmp2		; 3.bit secound byte
	lsr	video_tmp2
	ldi	video_tmp,17			; skip also next 16 bytes + normal increment => 17
						; after 48 shown bytes is 16 bytes video-memory gap
						
	 out	PORTE,video_tmp2		; 4.bit secound byte
	 lsr	video_tmp2
	 add	video_ptr_l,video_tmp		; next microline in PMD videomemory
	
 	 out	PORTE,video_tmp2		; 5.bit secound byte
	 adc	video_ptr_h,_zero
         adc	video_state,_zero		; CY ? --> add it
	 
	 out	PORTE,video_PORTE		; blank-> video_data:=0 & FLASH bit is also restored
		
<? endif; ?>


<? } ?>		

	
	
	MEMRD_deactive
	pop	video_tmp2	
	; Ports restore order is O.K. (safe)
	out	DDRA,video_DDRA
	out	PORTD,video_PORTD
	
_reti:
	out	SREG,video_SREG
	sbis	UCSRA,RXC			; USART received char from keyboard?
	reti
	
	.include "kbd.asm"
	
	;cntinue to kbd.asm