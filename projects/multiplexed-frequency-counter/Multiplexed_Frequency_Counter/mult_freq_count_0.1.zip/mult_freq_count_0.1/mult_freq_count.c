/****************************************************************************
 Title :    Multiplexed Frequency Counter
 Author:    Carlos A. Neves <caneves@iq.usp.br>
 Date:      10/24/2004
 Software:  AVR-GCC
 Target:    AT90S2313
 Comments:  This software was FREE inspired on linuxfreqcount.c by 
            Chris efstathiou hendrix@otenet.gr
            It is used to monitoring 4 oscillators.

*****************************************************************************/



#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include "lcd.h"

#define CLOCK_LIMIT      153   /* one second gate */

#define A0   DDD3
#define A1   DDD2

#define N_display_counter 5

static unsigned char clock153Hz; /* CLOCK/(256*256) */
static unsigned char hflag; 
static unsigned char overflowflag;

static unsigned char display_counter;
static unsigned char num_osc;

union{
  unsigned int   cval_word;
  unsigned char  cval_byte[2];
} counts;

unsigned char string[16];

void init_ports(void)
{

  /* Configure PD3 (A0) and PD2 (A1) to output */
  DDRD = _BV(DDD3) | _BV(DDD2);
  
/* Examples... */
/*   to set bits: */
/*   PORTD |= _BV(A0) | _BV(A1); */
/*  to clear bits: */
/*   PORTD &= ~(_BV(A0) | _BV(A1)); */

}

void update_ports(void)
{
  if(display_counter == N_display_counter){
    switch(num_osc){
    case 4:
      num_osc = 1;
      PORTD &= ~(_BV(A0) | _BV(A1));
      break;
    case 1:
      num_osc = 2;
      PORTD &= ~(_BV(A0) | _BV(A1));
      PORTD |= _BV(A0);
      break;
    case 2:
      num_osc = 3;
      PORTD &= ~(_BV(A0) | _BV(A1));
      PORTD |= _BV(A1);
      break;
    case 3:
      num_osc = 4;
      PORTD |= _BV(A0) | _BV(A1);
      break;
    }
    display_counter = 0;
  } else {
    ++display_counter;
  }
}

/* setup the T1 (PD5) counter to get ready for counting.
* You must call once sei() in the main program */
void init_counter(void)
{
  /* add: set nand gates */
  /* timer should generate interrupt on compate match */
  TIMSK = _BV(TOIE1);

  /* write high byte first */
  TCNT1H = 0x00; /* set counter to zero*/
  TCNT1L = 0x00; /* set counter to zero*/

  /* write high byte first */
  OCR1AH = 0xff; /* set internal compare register to max */
  OCR1AL = 0xff; /* set internal compare register to max */
  
  /* Timer/Counter1 disconnected from output pin OC1 */
  TCCR1A = 0x00;

  /* enable counter from T1 pin, needed in case there was an overflow */
  TCCR1B = _BV(CS12) | _BV(CS11) | _BV(CS10);

  /* enable T0 overflow0 interrupt */
  TIMSK = _BV(TOIE0);

  /* start value */
  TCNT0 = 0x00;
  
  /* start 153Hz timer, clock/256 overflow0 every 256 */
  TCCR0 = _BV(CS02);

  /* initiate counter values */
  counts.cval_byte[0] = 0x00;
  counts.cval_byte[1] = 0x00;

  /* start flags */
  overflowflag = 0;
  hflag = 0;

  /* initiate clock counter */
  clock153Hz = 0;

  /* enable interrupt */
  sei();
}

/* this function will be called in 153Hz (8,2ms) intervals 
   if a 8MHz crystal is used. 
   153Hz = 8MHz/(2^16) timer/counter1 of 16bits. */
SIGNAL(SIG_OVERFLOW0){

  if (clock153Hz == CLOCK_LIMIT){

    /* stop 153Hz timer */
    TCCR0 = 0x00;

    /* stop counter */
    TCCR1B = 0x00;

    /* read counter */
    counts.cval_byte[0] = TCNT1L; /* read low first !! */
    counts.cval_byte[1] = TCNT1H;

    hflag=1;

  } 
  else {
   
    if (clock153Hz == 0){
      
      overflowflag=0;
      
      TCNT1H = 0x00; /* set counter to zero*/
      TCNT1L = 0x00; /* set counter to zero*/
      
      /* enable counter from T1 pin, needed in case there was an overflow */
      TCCR1B = _BV(CS12) | _BV(CS11) | _BV(CS10);      
      
    }

  }
  
  clock153Hz++;

}


/* the following function will be called when the counter
 * is out of range. This is a 16bit counter! */
SIGNAL(SIG_OVERFLOW1) {

  overflowflag = 1;

  /* stop counter */
  TCCR1B = 0x00;

}

int main(void){

  unsigned char i;
  char cmd;
  char *val;
  
  lcd_init(LCD_DISP_ON);
  lcd_clrscr();
  lcd_home();

  /* setup the io PORTD */
  init_ports();

  /* start with the oscillator number 1 */
  display_counter = 0;
  num_osc = 1;
  PORTD &= ~(_BV(A0) | _BV(A1));

  /* setup the counter */
  init_counter();

  //  lcd_home(); // lcd_gotoxy is very slow: hang the lcd.
  lcd_puts_P("Oscillator ");
  
  while(1){

    if (hflag == 1){

      if (overflowflag){
	
	/* overflow */
	itoa(num_osc, string, 10);
	lcd_gotoxy(11,0);
	lcd_puts(string);
	lcd_gotoxy(0,1);
	lcd_puts_P("OV        ");
	
      }else{

	itoa(num_osc, string, 10);
	lcd_gotoxy(11,0);
	lcd_puts(string);
	ltoa(counts.cval_word, string, 10);
	lcd_gotoxy(0,1);
	lcd_puts(string);
	lcd_puts_P(" Hz      ");

      }
      
      update_ports();

      TCNT1H = 0x00; /* set counter to zero*/
      TCNT1L = 0x00; /* set counter to zero*/
      
      clock153Hz = 0;
      overflowflag = 0;
      hflag = 0;
      
      /* start 153Hz timer */
      TCCR0 = _BV(CS02);
      
      /* enable counter from T1 pin, needed in case there was an overflow */
      TCCR1B = _BV(CS12) | _BV(CS11) | _BV(CS10);      

    }
    
  }
    
  return 0;
}
  
  
