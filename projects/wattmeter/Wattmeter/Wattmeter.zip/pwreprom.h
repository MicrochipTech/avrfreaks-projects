/*
    Title:    Powermeter initialize
    Author:   Gary Cole
    Date:     7/2001
    Purpose:  Initialize the eeprom for power meter persistant across pwr failure requirements
    needed
    Software: AVR-GCC to compile, AVA to assemble and link
    needed
    Hardware: ATS90S4433 on STK500 board
    Note:    To contact me, go to my web site: http://people.we.mediaone.net/garrycole/index.html
*/

#ifndef PWREPROM_H
#define PWREPROM_H


/* constants/macros */

//externals
extern short nextrecord;

//function prototypes

void eeprom_clear(void);
void eeprom_init(void);
#endif