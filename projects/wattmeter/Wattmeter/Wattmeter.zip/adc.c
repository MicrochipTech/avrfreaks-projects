/*
    Title:    ADC library
    Author:   Gary Cole    Date:     6/2001
    Purpose:  Controling the ADC
    needed
    Software: AVR-GCC to compile
    needed
    Hardware: ATS90S4433 on STK500 board

What I would like to do is have the conveter switch back and forth between the voltage input and the curent input. 
and put the value in respective 
*/

#include <io.h> 
#include <interrupt.h>
#include "global.h"
#include "timer.h"
#include "sig-avr.h"
#include "eeprom.h"
#include "uart.h" /*part of avr library*/
#include "adc.h"
#define pwrlinefreq 60
extern volatile  short adc_voltaged, adc_voltage;
extern volatile int averagevoltage, averagecurrent, avgacvoltage, avgaccurrent; /*volatile is req for a compiler quirk*/
volatile  short adc_currentd, adc_current, cntseconds;
extern volatile  long pwr_cycle, power  ; 
volatile  long  wattmin, pwrmv_avrg, pwrmax ; //pwr_factor
volatile  short convertion_nu, oldconv_nu;
extern volatile  u08 Startcycle;
extern volatile  timekeeper times; 
volatile u08 marker ;

/*set up adc for usage*/
void adc_init(void) 
/* initialize adc*/
/*set up ADC Prescaler*/
{
/*set up prescaler*/
	u08  val;

        outp(0x07 | 0x80 | 0x20 | 0x08 | 0x40,   ADCSR);        /*set up ADC Prescaler Divide 4 mHz by 128 ADC enable 
								ADC Free Run  ADC Interrupt Enable SB 20 samples per hz */
	outp(5 ,  ADMUX);        /*set up mux*/
        val = inp(DDRC);            
	outp( val & 0x0CF ,  DDRC);        /*set up PORT C for inputs*/
	val = inp(PORTC);            
	outp( val & 0x0CF  ,  PORTC);        /*set up PORT C*/

        val = inp(DDRD);            
	outp( val & 0x03F ,  DDRD);        /*set up PORT D for inputs*/
	val = inp(PORTD);            
	outp( val & 0x03F  ,  PORTD);        /*set up PORT D*/

	cntseconds = 60 * pwrlinefreq ; //number of cycles duing a minute
	wattmin = 0; //watts over a minute
	pwrmax = 0;  //maximum power during a minute
	//pwr_factor = 0;
	pwr_cycle = 0;  //The power over one cycle
	power = 0;  //sum of each power measuement during a cycle
	convertion_nu = 0; //number of ADC convetions per cycle
	averagevoltage = 0x01FF;
	averagecurrent = 0x01FF;
}

/*service ADC interrupts*/
SIGNAL(SIG_ADC)     /* signal handler for */
{
u08  val, lowres, highres, switchval;
short result;
volatile long  powernow;
/*point to other input note that convesion is already underway for current pointer*/
/*get value and put into memory*/
lowres = inp(ADCL);
highres = inp(ADCH);
result =  ((short) highres) << 8;
result = ((short) lowres) | result; /*note that 60 X a ten bit number is < 16 bits
						so if the convertion rate less than 3600 samples per sec
						the total sum of all 10 bit numbers will fit in a 16 bit value.
						There will be 40 conversions per cycle.*/
val = inp(ADMUX);  
if (val == 4) { /*was voltage just measured?*/
		convertion_nu ++;
		outp(5,   ADMUX); //point at next conversion current
		adc_voltage = result  - (averagevoltage >> 4); 
		//the averge voltage will settle on 16 times the actual ave Voltage
		//it might take up to 1000 convertions to get to the average value.
		if (result > (averagevoltage >> 4 )) averagevoltage = averagevoltage + 1;
		else averagevoltage = averagevoltage -1;
		/*if voltage goes from - to + move set flag */ 
		if ((adc_voltage > 0) && (adc_voltaged <= 0) && (convertion_nu > 0x0A)){/*watch out for drift around zero xing*/
			Startcycle = 1;
			pwr_cycle = power ; //save sum for background power over one cycle
			oldconv_nu = convertion_nu;
			convertion_nu = 0;
			power = 0; //restart integration of power

		}
		adc_voltaged = adc_voltage; 
	}
else {
	outp(4,   ADMUX);  
	adc_current = result - (averagecurrent >> 4); /**/
	if (result > (averagecurrent >> 4) ) averagecurrent = averagecurrent + 1;
	else averagecurrent = averagecurrent - 1;
	powernow = abs(adc_voltage * adc_current);
	pwrmv_avrg = (pwrmv_avrg + powernow) >> 1; 
	if (powernow > pwrmv_avrg)pwrmax = pwrmv_avrg;
	//read  the switch
	switchval = inp(PORTD);            
	switchval = switchval >> 3;
	switchval = switchval & 0x03;
	//based on switch value display current, voltage, peak power or average power
	switch (switchval){
		case  1 : power = power + pwrmv_avrg;
		case  2 : power = power + (adc_voltage);//2nd position 
		case  3 : power = power + (adc_current); //3rd position
		default : power = power + (powernow ); //most towards Port B connector
		}


	}
                   

/*enable interrupts not required by the SIGNAL specification sei(); */
		
}


/*Background
if +to- 
if one minute move average to EEPROM and set printer transmit statistics.

*/
void calcwattmin(void)
{
volatile long  wattmintemp; //Scope rules don't trully apply unless ram is dedicated.
int result;
//short t;
char  val;
u08 i;
/*Watch for Startcycle flag if set take power and add to power sum
If 60 sums are added, then divide the sum by 60 to obtain average wattminute.
I only have 256 bytes of eeprom so this can only store about 128 records  for a 24 hour 
storeage one record can be stored every 5 minutes.
Let the RS232 modify this resolution
The size of the data is 16 bits only store ADPCM values for each succeding ADPCM value of FF increase the Adaption step
by two.
scan table and build ADCm Parameters
//int Value_multiplier; //number of left shifts required for current differencing value
//int Image_valuep1, Image_valuep, image_valuem1;  
//estimate of next value, current predicted value, previous value
Subtract Image_valuep from true value then divided by multiplier 
 if greater than 7F (-7F)  write 7F (0) to EEPROM Shift the Value multiplier
 The range of a byte is -128 to 128
 left 1 (right) , power is a positive value.  Value_multiplier = 8000  (0001)

predictor
 Take (previous value + current output value * step) /2 + current value = predicted value 
Take current abs(value - predicted value) - 128 if value > 0 then value = +-128 based on sign of  value - predicted value
		then shift the multiplier
else write value.

*/ 
	if ((Startcycle == 1)){
			Startcycle = 0;
			wattmintemp = ((pwr_cycle )/oldconv_nu); //

			if (cntseconds == 0){
				cntseconds = 60 * pwrlinefreq ;  //powerline frequency 
				wattmintemp = (wattmin + wattmintemp)/ cntseconds;   //over 60 seconds
				wattmin = 0; 
				//32 bits must be reduced to 4 bits Find the most significant bit location display the 4
				//most significant bits. 
				for(i=0;i<32;i++){
					result = wattmintemp << i;
					if ((result & 0x80000000)){
						marker = i/2;
						val = (u08)(result >> 12);
						outp( val ,  PORTC);        						
					}
				}

				if (nextrecord != 0) { //stop eeprom rap around
					//in the future consider the ADPCM compression of this storage
					val = (char) (wattmintemp & 0x0FF );
					eeprom_wb(nextrecord, val );
					sei(); /*eeprom stuff disables int but doesn't re-enable it*/
					for (i=0; i < 3; i++){
						//while (eeprom_is_ready() == 0);//wait for eprom to be ready
						nextrecord++;//doesn't work within macro eeprom_wb
						wattmintemp = wattmintemp >> 8;
						val =  (char) (wattmintemp  & 0x0FF);
						eeprom_wb(nextrecord, val);
						sei(); /*eeprom stuff disables int but doesn't re-enable it*/

					}
					nextrecord++;//point to next available byte
				}//end of if nextrecord !=0
		
				
			}else
			{
				wattmin = wattmin + wattmintemp;
				/*indicate scale for 15 seconds*/ 
				if (cntseconds == 60 * pwrlinefreq * 3/4 )outp( marker ,  PORTC);       
				cntseconds--;
			}

	}	
}

