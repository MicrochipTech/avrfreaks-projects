/*
    Title:    timer library
    Author:   Gary C0l3
    Date:     8/4/2001
    Purpose:   16 bit timer.
    needed
    Software: AVR-GCC to compile, AVA to assemble and link
    needed
    Hardware: ATS90S8515 on STK200 board
    Note:     To Do add an interrupt service routine to calculate a weeks worth of time.
	      note that written into the EEPROM is a fudge factor to make up for timing 
	      inacuracies.  The fudge factor is sent to the unit by the Serial port.
*/

#include <io.h>
#include <signal.h>
#include <interrupt.h>
#include "global.h"
#include "timer.h"

//u16 timer_save;
extern timekeeper times;

void timer_init(void) 
/* initialize timer 1 */
{
/*it doesn't seem good that the counter will reload itself with the preset.
It is better to use the Out Comp register to reset the counter to zero and count to the 
Output compare register.*/  
    outp(0x0,   TIMSK);                      /* disable timer interrupts */
    outp(0x0 ,   TCCR1A);                     /* disable PWM and stuff */
    outp(0 | 0x04 | 0x03,   TCCR1B);       /* clear timer 1 on compare match Select div by 4*/
    outp(0,   TCNT1H);                     /* reset TCNT1 */
    outp(0,   TCNT1L);                     /* reset TCNT1 */
    //if implemented this is where the fudge factor would be inserted.
    //The accruacy of this number is the same as the crystal and I don't use time anyway  
    outp(0xf4,   OCR1H);                     /* set OCR1H */
    outp(0x24,   OCR1L);                     /* reset OCR1l */
    outp(PRSC3_SELECT, TCCR1B);            /* count with cpu clock/64 64/4E6 seconds 
							 Roll Over at 1.048 seconds */
    outp(0x040 ,   TIMSK);        /* enable ouput compare register with auto reset of counter */
   
}

/* This interrupt should never happen*/

/*service timer0 interrupts*/
SIGNAL(SIG_OVERFLOW0 )     /* signal handler for Timer 0 over flow*/
{
/*The timer is in free run when it rolls over time has passed.
Increment roll over counter, An interrupt comes every second.
Maintain the times structure*/
}

/* This interrupt should never happen*/


/*service timer1 interrupts*/
SIGNAL(SIG_OVERFLOW1)     /* signal handler for Timer 1 over flow*/
{
/*The timer is in free run when it rolls over time has passed.
Increment roll over counter, An interrupt comes every second.
Maintain the times structure*/
}



/*service timer1 interrupts*/
SIGNAL(SIG_OUTPUT_COMPARE1A)     /* signal handler for Timer 1*/
{
/*This is the one second interrupt.*/

/*times is a pointer to a structure 12hours, hours,minutes,seconds, since power up*/
   switch (times.state){
	case 1:
		if (times.minutes < 60)times.minutes++;
		else times.minutes = 0;
		times.state++;
		break;	
	case 2:
		if (times.hours < 60)times.hours++;
		else times.hours = 0;
		times.state++;
		break;	
	case 3:
		if (times.hours12 < 12)times.hours12++;
		else times.hours12 = 0;
		times.state++;
		break;	
	default: times.state = 0;
   }
   if (times.seconds < 60)times.seconds++;
   else {
	times.seconds = 0;
	times.state = 1;
   }
}

