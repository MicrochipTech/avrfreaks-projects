/*
    Title:    wdt library
    Author:   Gary Cole    Date:     6/2001
    Purpose:  Controling the WDT
    needed
    Software: AVR-GCC to compile
    needed
    Hardware: ATS90S4433 on STK500 board


*/

#include <io.h>
#include <interrupt.h>
#include "global.h"
#include "sig-avr.h"
#include "wdt.h"

void wdt_init(void) 
/* initialize WDT*/
{

    wdt_disable();                      /* disable WDT interrupts */

}



