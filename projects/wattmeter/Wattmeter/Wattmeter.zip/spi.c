/*
    Title:    SPI library
    Author:   Gary Cole    Date:     6/2001
    Purpose:  Controling the ADC
    needed
    Software: AVR-GCC to compile
    needed
    Hardware: ATS90S4433 on STK500 board

This doesn't do much now
*/

#include <io.h>
#include "global.h"
#include "timer.h"
#include "sig-avr.h"
#include "spi.h"


/*set up SPI for usage*/
void spi_init(void) 
/* initialize spi*/
{
	//u8  val;
	outp(  0x0  ,  SPCR);        /*set up SPI*/
}

/*service SPI interrupts*/
SIGNAL(SIG_SPI)     /* signal handler for SPI*/
{

//u8  va;

/*enable interrupts not required by the SIGNAL specification sei(); */
		
}


