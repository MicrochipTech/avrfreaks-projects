/*
    Title:    ANACOMP library
    Author:   Gary Cole
    Date:     5/1999
    Purpose:  starting 16 bit timer.
    needed
    Software: AVR-GCC to compile, AVA to assemble and link
    needed
    Hardware: ATS90S4433 on STK500 board
    Note: To contact me, go to my web site:http://people.we.mediaone.net/garrycole/index.html
*/

#ifndef ANACOMP_H
#define ANACOMP_H


/* constants/macros */
//function protype
void ana_compinit(void); 
#endif