/*
    Title:    ADC library
    Author:   Gary Cole
    Date:     8/4/2001
    Purpose:  Starting the ADC
    needed
    Software: AVR-GCC to compile, 
    needed
    Hardware: ATS90S4433 on STK500 board
    Note:    http://people.we.mediaone.net/garrycole/index.html 
*/

#ifndef ADC_H
#define ADC_H


/* constants/macros */

extern short nextrecord;

void adc_init(void);

#endif