/*
    Title:    timer library
    Author:   Gary Cole Thanks to Volker Oth
    Date:     5/1999
    Purpose:  starting 16 bit timer.
    needed
    Software: AVR-GCC to compile, AVA to assemble and link
    needed
    Hardware: ATS90S4433 on STK500 board
    Note:     http://people.we.mediaone.net/garrycole/index.html
*/

#ifndef TIMER_H
#define TIMER_H


/* constants/macros */
#define F_CPU        4000000               /* 4MHz processor */

#define PRSC1              1  
#define PRSC1_SELECT       1               /* divide by 1 */
#define PRSC3_SELECT       3               /* divide by 64 */
#define PRSC5_SELECT       5               /* divide by 1024 */

#define F_T1     (F_CPU/PRSC1)             /* TCNT1 frequency */

#define T_T1     (1000000*PRSC1/F_CPU)     /* us per timer tick */
#define TICKS_T1 (F_CPU/(1000000*PRSC1))   /* ticks per us */

#define get_ticks() __inw_atomic(TCNT1)

#define timer_start(t) (t) = get_ticks()
#define timer_delta(t) ( (u16)get_ticks() - (u16)(t) )

//extern u16 timer_save;

extern void timer_init(void);

typedef struct {

	short hours12; //number of 12 hour periods since power up
        short  hours; 
        short minutes;
        short seconds;     //#since last seconds worth of macroticks
	short state;       //spread out the update of these values over several interrupts. ticks = 0 macroticks = 1
	} timekeeper ;

#endif