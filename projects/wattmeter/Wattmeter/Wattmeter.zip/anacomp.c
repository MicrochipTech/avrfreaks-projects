/*
    Title:    Analog Comparator library
    Author:   Gary Cole    Date:     6/2001
    Purpose:  Controling the ADC
    needed
    Software: AVR-GCC to compile
    needed
    Hardware: ATS90S4433 on STK500 board

This doesn't do much now
This fuction could be used for finding the zero crossing point of the incomming AC.
Note that the wattmeter is et up for it
It could be used for FSK demodulation
*/

#include <io.h>
#include <interrupt.h>
#include "global.h"
#include "sig-avr.h"
#include "anacomp.h"


/*set up analog comparator for usage*/
void ana_compinit(void) 
/* initialize spi*/
{
	//u8  val;


	outp(  0x0  ,  ACSR);        /*set up SPI*/
}

/*service SPI interrupts*/
SIGNAL(SIG_COMPARATOR )     /* signal handler for SPI*/
{

//u8  va;

/*enable interrupts not required by the SIGNAL specification sei(); */
	sei();
		
}


