/*
    Title:    SPI library
    Author:   Gary Cole
    Date:     8/4/2001
    Purpose:  starting SPI interface.
    needed
    Software: AVR-GCC to compile,
    needed
    Hardware: ATS90S4433 on STK500 board
    Note:     To contact me, go to my web site: http://people.we.mediaone.net/garrycole/index.html
*/

#ifndef SPIGC_H
#define SPIGC_H


/* constants/macros */
//function protype
void spi_init(void) ;
#endif