/*
    Title:    AVR-GCC power meter  for the STK500 eva board
    Author:   Gary Cole
             
    Date:     6/2001
    Purpose:  The ADC measures voltage and current from which power and energy are measured.
		 -- Can be set to trip if voltage/current goes below or above a certain value
              -shows how to inteface an assembler module in C.
              -implements simplified sprintf
              -implements buffered UART I/O
              -implememnts highres time measurement using 16bit TCNT1
		  -Set the fuses in the programmer Brown Out detection and crystal oscillator.
    needed
    Software: AVR-GCC to compile
    needed
    Hardware: atS90S4433 on STK200/300 board
    Note:     To contact me, mail to
    The value captured by the watt minute integrator is Watts = -3.7 + 0.01235 * reading.
    This is accurate to greater than 1%. The largest wattage is 3221 watts or 29 amps.
*/


#include <stdarg.h>
#include <ctype.h>
#include <string.h>
#include <io.h>
#include <interrupt.h>
#include "global.h"
#include "timer.h"
#include "adc.h"
#include "spi.h"
#include "eeprom.h"
#include "pwreprom.h"
#include "anacomp.h"
#include "uart.h" /*part of avr library*/
#include "wdt.h" /*part of avr library*/


#define SCRATCH 16
extern void calcwattmin(void);  //function prototype

/*Globals*/
volatile timekeeper times; 
//volatile short printeroffset, timesold ;
volatile short nextrecord;
volatile  u08 Startcycle;
volatile  long pwr_cycle, power ; 
volatile  short adc_voltaged, adc_voltage; 
volatile int averagevoltage , averagecurrent ; /*volatile is req for a compiler quirk*/

/*
short sprintf(u08 *buf, const u08 *format, ...)
// simplified sprintf 
{
  u08 scratch[SCRATCH];
  u08 format_flag;
  u16 u_val=0, base;
  u08 *ptr;
  va_list ap;

  va_start (ap, format); 
  for (;;){
    while ((format_flag = *format++) != '%'){      // Until '%' or '\0' 
      if (!format_flag){va_end (ap); return (0);}
      *buf = format_flag; buf++; *buf=0;
    }

    switch (format_flag = *format++){

    case 'c':
      format_flag = va_arg(ap,int);
    default:
      *buf = format_flag; buf++; *buf=0;
      continue;
    case 'S':
    case 's':
      ptr = va_arg(ap,char *);
      strcat(buf, ptr);
      continue;
    case 'o':
      base = 8;
      *buf = '0'; buf++; *buf=0;
      goto CONVERSION_LOOP;
    case 'i':
      if (((int)u_val) < 0){
        u_val = - u_val;
        *buf = '-'; buf++; *buf=0;
      }
      // no break -> run into next case 
    case 'u':
      base = 10;
      goto CONVERSION_LOOP;
    case 'x':
      base = 16;

    CONVERSION_LOOP:
      u_val = va_arg(ap,int);
      ptr = scratch + SCRATCH;
      *--ptr = 0;
      do {
        char ch = u_val % base + '0';
        if (ch > '9')
          ch += 'a' - '9' - 1;
        *--ptr = ch;
        u_val /= base;
      } while (u_val);
      strcat(buf, ptr);
      buf += strlen(ptr);
    }
  }
}
*/
/*use pwm to gen FSK
use the uart to xmit */


int main(void)
{
    u08 val, alpha;
    short i;                  /**/

    timer_init();                  /* init timer1 */
    uart_init();                   /* init the UART transmit buffer */
    adc_init();                    /* init the ADC and MUX  buffer */
    spi_init();                    /* init the SPI transmit buffer */
    ana_compinit();		   /*init the Analog Comparitor*/
    eeprom_init();                 /* init the init considerations for eeprom  buffer get pointer out of eeprom*/
    //wdt_reset();		     /* initialize the WDT */
 
    outp( 0x02 ,  DDRB);           /*set up PORT B for inputs*/
    outp( 0x0ff ,  PORTB);         /*set up PORT B*/

    outp( 0x0CF ,  DDRC);          /*set up PORT C for inputs*/
    outp(  0x00  ,  PORTC);        /*set up PORT C*/

    val = inp(DDRD);            
    outp( val & 0x022 ,  DDRD);    /*set up PORT D for inputs*/
    val = inp(PORTD);            
    outp( val & 0x03f ,  PORTD);  /*set up PORT D*/

    sei();                         /* enable interrupts */
   
    uart_putstr("GDC");            //Let the world know that the wattmeter is running
      

    for (;;)                        /* loop forever */
        {
         //wdt_enable(timeout);   
/*
//debug stuff	print out a variable
if ((Startcycle == 1)){   
long  wattmintemp;
int t;

cli();	//get whole variable
wattmintemp = (averagecurrent );
sei();
val = (char) ((wattmintemp & 0x00F )  | 0x30);
while (uart_putchar(val) == 0);
for (i=0; i < 7; i++){
	wattmintemp = wattmintemp >> 4;
	val =  (wattmintemp & 0x0f) | 0x30;
	while (uart_putchar(val) == 0){
		timer_start(t); //give the receiveing pc time to process it's uart interrupt
		while ( timer_delta(t) < 650);
	}
}
while (uart_putchar(0x4D) == 0);
}
*/

                calcwattmin();

                alpha = uart_getchar();
                switch ((char)alpha)
		{
                        case 'd': { /*dump the power records*/
                                	for(i = 0x04 ; i  < 0x100 ; i++)
					{
						//transmit the whole table
						val = eeprom_rb(i);
						sei(); 
						alpha = (val & 0x0F) | 0x30;
						while (uart_putchar(alpha) == 0);

						alpha = ((val >> 4) & 0x0F) | 0x30;
						while (uart_putchar(alpha) == 0){
							int t;
							timer_start(t); //give the receiveing pc time to processe the interrupt
							while ( timer_delta(t) < 650);
						}
						if ((i & 3) == 3)while (uart_putchar(0x50) == 0);//delimiter
					}

                                eeprom_clear(); // 
                                break;
                                }
                        case 'f': ;  //set timer fudge factor
			//set seconds till next write to eeprom with pwr data
     			//factory reset
			default : ;
		}

	     //read the switches.  effect the printer display watts,  display watt hours, display peak power, volts
           //if (times.hours12 > timesold) printeroffset = -1 * printeroffset; /*if printer completes one revolution (12 hours) invert the print out*/
    	//	timesold = times.hours12;
	}        
}

