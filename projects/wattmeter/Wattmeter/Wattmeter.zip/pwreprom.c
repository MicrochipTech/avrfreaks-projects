/*
    Title:    ADC library
    Author:   Gary Cole    Date:     6/2001
    Purpose:  Doing eeprom stuff inialization
    needed
    Software: AVR-GCC to compile
    needed
    Hardware: ATS90S4433 on STK500 board

*/
/*eeprom data arraingment
Address 	Function
0		Note used sb 0
1		# of seconds to next memory write set up via RS232 command
2		55
3		AA indicates that EEPROM has been initialized
4		Time fudge factor Crystal inacuracy causes timing error
5		Power line Frequency
6		Timer fudge factor
7		Timer fudge factor MSByte
6-64
40-FF		Data Storage,

*/

#include <io.h>
#include <interrupt.h>
#include "global.h"
#include "eeprom.h"
#include "pwreprom.h"
#include "uart.h" /*part of avr library*/

short eeprom_save;
/*set up adc for usage*/

void eeprom_init(void) 
/* initialize if random data in EEPROM initialize it note that address 0 is most 
likely corrupted.  If not, continue with collection of data.  If data full rap around.
I only have 256 bytes of eeprom 
If this data is corupted consider the Brown Out Protection fuses*/
{
	eeprom_save = (short) eeprom_rw(2);
   if (eeprom_save != 0xAA55)  //one time initilization RS232 clears things big indian 
	{
		eeprom_clear();
		eeprom_wb(0, 0x00);		//Note used sb 0
		sei(); 
		eeprom_wb(1, 0x00); 		//# of seconds to next memory write set up via RS232 command
		sei(); 
		eeprom_wb(2, 0x55);		//memory is initialized
		sei(); 
		eeprom_wb(3, 0xaa);
		sei(); 
		eeprom_wb(4, 0x00);		//Time fudge factor Crystal inacuracy causes timing error
		sei(); 
		eeprom_wb(0, 60);		//Power line Frequency
		sei(); 
		for (nextrecord = 0x04 ; nextrecord <= 0xFF ; nextrecord++)
		{
	
			eeprom_wb(nextrecord, 0x55);		//initialize
			nextrecord++;
			sei(); 
			eeprom_wb(nextrecord, 0xaa);
			sei(); 
		}
		nextrecord = 4;
	}else
	//find last record written to eeprom
	for (nextrecord = 0x04 ; nextrecord <= 0xFE ; nextrecord++)
	{
		eeprom_save = (short) eeprom_rw(nextrecord);

		if (eeprom_save == 0xAA55){
			break;
		}
		
	
	}

}
void eeprom_clear(void)
{
/*  Write AA55 throughout the Data Strage Area.
    Done after RS232 dump of data 
*/
		for (nextrecord = 0x04 ; nextrecord <= 0xFF ; nextrecord++)
		{
	
			eeprom_wb(nextrecord, 0x55);		//initialize
			nextrecord++;
			sei(); 
			eeprom_wb(nextrecord, 0xaa);
			sei(); 
		}
		nextrecord = 4;
}


