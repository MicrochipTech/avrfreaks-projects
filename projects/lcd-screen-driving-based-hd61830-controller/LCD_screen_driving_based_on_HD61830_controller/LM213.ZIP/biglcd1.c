 /***********************************************************
  *   Program:    LCD driver for LM213xb
  *   Created:    26.12.2001
  *   Author:     Gennady Andreev 
  *               Alex Nikitushkin (nikit@ripc.redline.ru) 
  *                 
  *   Comments:  LM213xb - LCD screen 256*64 based on
  *   	         HD 61830 lcd controller ( about documentation see 
  *                        readme.txt).
  *    LM213xb connection:
  *	LCD       Signal       Port name   8515(DIP40)
  *	7 - 14  --   d0 - d7     PORTA        39 - 32
  *	   4	RS          PORTD.7      17
  *	   5	RW         PORTD.6     16
  *	   6              E            PORTD.5     15	
  *                   all other pins - see lm213.zip 	       		 
  ************************************************************/

#include <string-avr.h>
#include <io.h>
#include <progmem.h>
#include <sig-avr.h>
#include <interrupt.h>
#include <stdlib.h>

typedef unsigned char  u08;
typedef unsigned short u16;


prog_char picpart1[560] = {
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,
 0,0,0,0x1f,0xf0,0,0,0,0,0,
0,0,0,0xe5,0x5c,0x0e,0x60,0,0,0,
 0,0,3,0x1d,0xf2,0x1d,0xd0,0x0f,0xe0,0,
 0,0,0x3c,0x6b,0xfe,0x6e,0x50,0x11,0x90,0,
 0,0,0x7e,0x5e,0x96,0x8b,0x51,0xb6,0x38,0,
0,0,0xff,0x7d,0xdb,0x6b,0xd2,0x78,0xf8,0,
0,7,0xdd,0x9d,0xff,0x17,0x3f,0xe3,0xc8,0,
0,0x38,0xff,0xaa,0xc5,0x0c,0xf0,0x70,0x3c,0,
0,0xc0,0xfe,0x65,0x34,0x83,0x10,0xbf,0xf7,0,
0,0xf8,0x81,0xdd,0xfc,0x81,0xf0,0x8f,0xe7,0,
0,0xe4,0x62,0xff,0xf8,0x81,0xf0,0x63,9,0,
0,0xd4,0x1c,0x83,0xf0,0x42,0x10,0x70,0x80,0,
0,0xbc,0,0x7e,0,0x42,8,3,0x80,0x80,
0,0xb0,0,0x42,0,0x24,4,0,1,0xc0,
0,0xae,0,0x3c,0,0x27,0xfc,0,2,0x40,
0,0xa1,0xff,0xff,0xff,0xe8,3,0xff,0xfc,0x40,
0,0xa1,0,0,0,0x2f,0xfc,0,4,0x60,
1,0x61,0x3b,0x7f,0x80,0x50,2,0,4,0x50,
0,0xa1,0x3f,0xff,0x80,0x50,2,0,4,0x60,
1,0xa1,0,0,0,0xbf,0xfe,0,5,0xd0,
2,0xb1,0,0,0,0xae,0xf6,0,6,0xd0,
1,0xbf,0xff,0xff,0xff,0x4d,0xfb,0xff,0xff,0xd0,
0,0xbf,0xff,0xff,0xfe,0xc0,1,0xff,0xff,0xc8,
0,0xbf,0xff,0xff,0xfd,0x7f,0xff,0xff,0xff,0x78,
0,0xef,0xff,0xff,0xfd,0x7f,0xff,0x7f,0xff,0xc0,
0,0xbf,0xff,0xff,0xbd,0x7f,0xff,0x7f,0xed,0xc0,
0,0xf7,0xdf,0xff,0xfb,0x7e,3,0x7d,0xff,0x40,
0,0xbd,0xff,0x7f,0xfa,0xf1,0xfd,0x3f,0xff,0xc0,
0,0xff,0x7f,0x62,0xda,0xcf,0x73,0x9f,0xbe,0xc0,
0,0xf7,0xff,0xf1,0xd6,0xe6,0x65,0xef,0xff,0x40,
0,0xff,0xff,0xff,0xd6,0x70,0x44,0xef,0xff,0xc0,
0,0xbd,0xfb,0xff,0xd6,0x78,0x0c,0x77,0xed,0xc0,
0,0x77,0xff,0xef,0xd7,0xfc,7,0xfb,0xff,0xc0,
0,0x7d,0xff,0xff,0xd6,0,0,0x3b,0xff,0xc0,
0,0x3f,0xff,0xff,0xd7,0xfc,0x1f,0xfb,0xfc,0x40,
0,0x21,0,0,0x17,0xe8,7,0xba,4,0xc0,
0,0x1f,0,0,0x0f,0xe8,0x46,0xba,7,0,
0,1,0xff,0xff,0xfd,0xf2,0x62,0xbb,0xfc,0,
0,0,0,0,3,0xef,0x7a,0xba,0,0,
0,0,0,0,0,0xeb,0x7f,0x7a,0,0,
0,0,0,0,0,0xfb,0x7b,0x74,0,0,
0,0,0,0,0,0x6d,0x46,0x74,0,0,
0,0,0,0,0,0x6f,0x7d,0xf4,0,0,
0,0,0,0,0,0x2f,0x4c,0xe8,0,0,
0,0,0,0,0,0x37,0xff,0xe8,0,0,
0,0,0,0,0,0x17,0xff,0xd0,0,0,
0,0,0,0,0,0x0b,0xff,0xd0,0,0,
0,0,0,0,0,5,0xff,0xa0,0,0,
0,0,0,0,0,2,0x7f,0x40,0,0,
0,0,0,0,0,1,0x80,0x80,0,0,
0,0,0,0,0,0,0x7f,0,0,0,
0,0,0,0,0,0,0,0,0,0};



/**************************************************

Delay subroutine 

**************************************************/


void lcd_delay(u16 value){
u08 j;
u16 i;
for(i=0;i<value;i++){
for(j=0;j<10;j++);	
	}
}

/**************************************************

Subroutine for transmitting data to screen controller 

**************************************************/


void wscr(u08 ir,u08 dir)
{

cli();
cbi(MCUCR, SRE);					// disable RAM
outp(0xff,DDRA);				
outp(0xff,DDRD);

cbi(PORTD, 6);					// set W
sbi(PORTD, 7);					// set RS
sbi(PORTD, 5);					// set E
outp(ir,PORTA);
cbi(PORTD, 5);
cbi(PORTD, 7);
sbi(PORTD, 5);
outp(dir,PORTA);
cbi(PORTD, 5);
outp(0x00,PORTA);
outp(0x00,DDRA);
sbi(PORTD, 6);
sbi(PORTD, 7);
sbi(PORTD, 5);
while(bit_is_set(0x19,7)); 			//  command accepted?
sbi(MCUCR, SRE);				// enable RAM
sei();

lcd_delay(100);
return;
}
 
/**************************************************

Subroutine for textmode initialization 

**************************************************/

void textmode(void)
{
lcd_delay(1000);
wscr(0,0x3c);
wscr(1,0xd7);
wscr(2,31);
wscr(3,63);
wscr(4,7);
wscr(8,0);
wscr(9,0);
wscr(10,0);
wscr(11,0);
return;
}

/**************************************************

Subroutine for clearing screen area (text mode) 

**************************************************/

void textcls(void)
{
int ib;
for(ib=0;ib<228;ib++)wscr(0x0c,0);
wscr(8,0);
wscr(9,0);
wscr(10,0);
wscr(11,0);
return;
}

/**************************************************

Subroutine for graphmode initialization 

**************************************************/


void graphmode(void)
{
lcd_delay(1000);
wscr(0x00,0x32);
wscr(0x01,0xd7);
wscr(0x02,31);
wscr(0x03,63);
wscr(0x08,0);
wscr(0x09,0);
return;
}

/**************************************************

Subroutine for clearing screen area (graph mode) 

**************************************************/

void graphcls(void)
{
int ib;
for(ib=0;ib<2048;ib++)wscr(0x0c,0);
wscr(0x08,0);
wscr(0x09,0);
wscr(0x0a,0);
wscr(0x0b,0);
return;
}


/**************************************************

Subroutine for reverse image byte 

**************************************************/
u08  reversy(u08 val1)
{
u08 val2;
u08 mask1[8]={1,2,4,8,16,32,64,128};
u08 inkr;
for(inkr=0;inkr<8;inkr++){
	if((val1 & mask1[inkr])  !=  0) val2=val2|mask1[7-inkr];
	}
return(val2);
}

/*******************************************************
Subroutine for printing image (sprite) on the screen (in graph mode)
from program memory (for big pictures)
with reverse byte  ( sometimes it is necessary if you have 
		    inverse byte code)	

*pts - pointer to image array
lsize - image length ( in bytes)
hsize- image height (in bits)
xpos- x-position (in bytes)
ypos- y-position (in bits)

*******************************************************/
void bpic(u08 lsize,u08 hsize,u08 xpos,u08 ypos)
{

u16 inc=0;
u08 val3;
u16 ind=0;
u16 ig=0;
u08 ir=0;
u08 im=0;
u16 lpos=0;
u16  hpos=0;
u16 pos=0;

	pos=32*ypos+xpos;
	hpos=pos/256;
	lpos=pos-(hpos*256);
	ind=lpos;
for(im=0;im<hsize;im++){
	wscr(10,ind);wscr(11,hpos);
	ind=ind+32;
	if(ind > 255){ind=ind-256;hpos=hpos++;}
	for(ir=0;ir<lsize;ir++){val3=reversy(PRG_RDB(&picpart1[inc]));wscr(12,val3);inc=inc++;}
		      }

}


/*******************************************************
Subroutine for printing image (sprite) on the screen (in graph mode)
with reverse byte  ( sometimes it is necessary if you have 
		    inverse byte code)	

*pts - pointer to image array
lsize - image length ( in bytes)
hsize- image height (in bits)
xpos- x-position (in bytes)
ypos- y-position (in bits)

*******************************************************/
void rpsprite(u08 *pts,u08 lsize,u08 hsize,u08 xpos,u08 ypos)
{

u08 val3;
u16 ind=0;
u16 ig=0;
u08 ir=0;
u08 im=0;
u16 lpos=0;
u16  hpos=0;
u16 pos=0;

	pos=32*ypos+xpos;
	hpos=pos/256;
	lpos=pos-(hpos*256);
	ind=lpos;
for(im=0;im<hsize;im++){
	wscr(10,ind);wscr(11,hpos);
	ind=ind+32;
	if(ind > 255){ind=ind-256;hpos=hpos++;}
	for(ir=0;ir<lsize;ir++){val3=reversy(*pts);wscr(12,val3);pts=pts++;}
		      }

}


/*******************************************************
Subroutine for printing image (sprite) on the screen (in graph mode)
(without  reverse of byte) 
   
*pts - pointer to image array
lsize - image length ( in bytes)
hsize- image height (in bits)
xpos- x-position (in bytes)
ypos- y-position (in bits)

*******************************************************/
void psprite(u08 *pts,u08 lsize,u08 hsize,u08 xpos,u08 ypos)
{

u08 val3;
u16 ind=0;
u16 ig=0;
u08 ir=0;
u08 im=0;
u16 lpos=0;
u16  hpos=0;
u16 pos=0;

	pos=32*ypos+xpos;
	hpos=pos/256;
	lpos=pos-(hpos*256);
	ind=lpos;
for(im=0;im<hsize;im++){
	wscr(10,ind);wscr(11,hpos);
	ind=ind+32;
	if(ind > 255){ind=ind-256;hpos=hpos++;}
	for(ir=0;ir<lsize;ir++){wscr(12,*pts);pts=pts++;}
		      }

}

/*******************************************************
Subroutine for clearing image region on the screen (in graph mode)

*pts - pointer to image array
lsize - image length ( in bytes)
hsize- image height (in bits)
xpos- x-position (in bytes)
ypos- y-position (in bits)

*******************************************************/
void csprite(u08 *pts,u08 lsize,u08 hsize,u08 xpos,u08 ypos)
{
u16 ind=0;
u16 ig=0;
u08 ir=0;
u08 im=0;
u16 lpos=0;
u16 hpos=0;
u16 pos=0;

	pos=32*ypos+xpos;
	hpos=pos/256;
	lpos=pos-(hpos*256);
	ind=lpos;
for(im=0;im<hsize;im++){
	wscr(10,ind);wscr(11,hpos);
	ind=ind+32;
	if(ind > 255){ind=ind-256;hpos=hpos++;}
	for(ir=0;ir<lsize;ir++){wscr(12,0);pts=pts++;}
		      }

}



/**************************************************
**************************************************

Test program for graph and text modes

**************************************************
**************************************************/

int main(void)
{
 char str_test[17]="test of bigscreen";
char w[8]={0x11,0x11,0x11,0x11,0x15,0x15,0x0a,0};
char a[8]={0x1c,0x12,0x11,0x11,0x1f,0x11,0x11,0};
char h[8]={0x11,0x11,0x11,0x1f,0x11,0x11,0x11,0};
char p[8]={0x0f,0x11,0x11,0x0f,0x01,0x01,0x01,0};
char y[8]={0x11,0x11,0x11,0x0a,0x04,0x04,0x04,0};
char n[8]={0x11,0x13,0x13,0x15,0x19,0x19,0x11,0};
char e[8]={0x1f,0x01,0x01,0x0f,0x01,0x01,0x1f,0};
char r[8]={0x0f,0x11,0x11,0x0f,0x05,0x09,0x11,0};
char ex[8]={0x10,0x10,0x10,0x10,0x00,0x00,0x10,0};



char bx1[8]={0,0,0,0x18,0x18,0,0,0};
char bx2[8]={0,0,0x3c,0x3c,0x3c,0x3c,0,0};
char bx3[8]={0,0x18,0x7e,0x66,0x66,0x7e,0x18,0};
char nul[8]={0,0,0,0,0,0,0,0};
 u16 i;
char tes1;
char d[4];
uint8_t  radix=10;



	for(i=0;i<200;i++)lcd_delay(9000);  /*
                                                                                  delay for screen initialization
			(we turn on processor and screen power simalteniously) */


/****************************************

Graph mode 

****************************************/

	graphmode();
	graphcls();

	
	bpic(10,56,10,1);	// draw picture	

	for(i=0;i<1000;i++)lcd_delay(9000);
	graphcls();
	
	psprite(h,1,8,5,30);
	psprite(a,1,8,6,30);
	psprite(p,1,8,7,30);
	psprite(p,1,8,8,30);
	psprite(y,1,8,9,30);
	psprite(n,1,8,11,30);
	psprite(e,1,8,12,30);
	psprite(w,1,8,13,30);
	psprite(y,1,8,15,30);
	psprite(e,1,8,16,30);
	psprite(a,1,8,17,30);
	psprite(r,1,8,18,30);
	psprite(ex,1,8,19,30);



/****************************************

Text  mode 

( for testing put comment brackets 
on graph mode and uncomment text mode )

****************************************/
/*  

	textmode();
	textcls();
	 for(i=0;i<17;i++){lcd_char(i,str_test[i]);}      

*/
	
while(1){

	psprite(bx1,1,8,1,10);
	for(i=0;i<100;i++)lcd_delay(9000);
	csprite(bx1,1,8,1,10);
	psprite(bx2,1,8,1,10);
	for(i=0;i<100;i++)lcd_delay(9000);
	csprite(bx2,1,8,1,10);
	psprite(bx3,1,8,1,10);
	for(i=0;i<100;i++)lcd_delay(9000);
	csprite(bx3,1,8,1,10);
	for(i=0;i<100;i++)lcd_delay(9000);

	psprite(bx1,1,8,25,40);
	for(i=0;i<100;i++)lcd_delay(9000);
	csprite(bx1,1,8,25,40);
	psprite(bx2,1,8,25,40);
	for(i=0;i<100;i++)lcd_delay(9000);
	csprite(bx2,1,8,25,40);
	psprite(bx3,1,8,25,40);
	for(i=0;i<100;i++)lcd_delay(9000);
	csprite(bx3,1,8,25,40);
	for(i=0;i<100;i++)lcd_delay(9000);

	}
for(;;);
}
