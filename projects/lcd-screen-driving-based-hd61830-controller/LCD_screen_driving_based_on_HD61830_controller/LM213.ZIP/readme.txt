This program was made for LM213xb - LCD screen 256*64 pixels
based on HD61830 controller 
with AVR 8515 processor operating on 11.059 MHz

file biglcd1.hex - downloadable file in HEX intel format

Datasheets:
LCD
www.hedus.com/sales/pdf/LM213xb.pdf
www.woe.onlinehome.de/e_lcddata.htm
Controller
ftp://citilink.com/users/jsampson/hd61830

We always welcome any questions or suggestions conserning our projects
Our e-mails: alex.nikit@mtu-net.ru, nikit@ripc.redline.ru

				Alex Nikitushkin 
				Gennady Andreev 

