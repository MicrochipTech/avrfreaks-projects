//
// I2C Routiner Af Kim Madsen 21-04-02
//

#define IC2SDAPort PORTA
#define IC2DDRPort DDRA
#define IC2PINPort PINA
#define IC2SDABITVAERDI 2 //1 2 4 8 16 32 64 128 de 8 tilladte v�rdier
//valgt bit 3
#define IC2SCLPort PORTA
#define IC2SCLDRRPort DDRA
#define IC2SCLBITVAERDI 1 //1 2 4 8 16 32 64 128 de 8 tilladte v�rdier
//valgt bit 4
#define IC2Read 1
#define IC2Write 0
#define IC2DELAYVAERDI 20

unsigned char data = 255;

void Delay()
{// hardware afh�ngig justerer frekvensen p� IC2 bussen til max 400 khz / 100 khz
	unsigned int taeller =  IC2DELAYVAERDI;
	while(taeller--);
}

void SetSDA(unsigned char vaerdi)
{
 unsigned char midlertidig;
	midlertidig =  IC2SDAPort &~ IC2SDABITVAERDI;
	if(vaerdi)
		midlertidig |= IC2SDABITVAERDI;
	IC2SDAPort = midlertidig;//opdater porten
}

void SetSCL(unsigned char vaerdi)
{
 unsigned char midlertidig;
	midlertidig =  IC2SCLPort &~ IC2SCLBITVAERDI;
	if(vaerdi)
		midlertidig |= IC2SCLBITVAERDI;
	IC2SCLPort = midlertidig;//opdater porten
}

void StartCond()
{
	data = 255;
	 SetSDA(1);
	 SetSCL(1);
	 SetSDA(0);
	Delay();
	 SetSCL(0);
	 SetSDA(1);
}

void StopCond()
{
	data = 255;
	 SetSDA(0);
	 SetSCL(1);
	Delay();
	 SetSDA(1);
}

void IC2init()
{
// 1: set data og scl pins til output = 0
	IC2DDRPort = IC2DDRPort | IC2SDABITVAERDI;
	IC2SCLPort = IC2SCLPort | IC2SCLBITVAERDI;
	StartCond();
}

unsigned char LaesSDA()
{
//1: Afl�s aktuel mode af DDR register
//2: skift til indput p� SDA benet
//3: Afl�s bit status
//4: Gen etabler DDR register
//5: Afslut
//retur 0 = 0 alle andre = 1

	unsigned char vaerdi = 0;
	unsigned char ddrregister, mdgem;
	
	 SetSDA(1);// v�r sikker p� at sda ud er h�j
	 SetSCL(1);
	 // 1:
	 ddrregister = IC2DDRPort;
	 mdgem = ddrregister &~IC2SDABITVAERDI;
	 IC2DDRPort = mdgem;
	 //2:
	 Delay();
	 //3:
	 vaerdi = IC2PINPort & IC2SDABITVAERDI;
	 //4:
	 IC2DDRPort = ddrregister;
	 SetSCL(0);
	 //5:
	 return vaerdi;
}

void ClockScl()
{/*
  1 s�t SCL h�j
  2 max hastighed p� SCL = 400 khz / 100 khz
  3 s�t SCL lav
 */

	 SetSCL(1);
	 Delay();
	 SetSCL(0);
}

void SendACK(unsigned char state)
{// send master ack 
 // master ack: true = sidste byte 0 = flere bytes forventes

	 SetSDA(state);
	 ClockScl();
}

void SendByte(unsigned char byte)
{// sender byte til kreds via IC2 bus msb f�rst

	unsigned char taeller = 0;
	while(taeller < 8)
	{
		if(byte & 0x80)
			 SetSDA(1);
		else
			 SetSDA(0);
		ClockScl();
		byte = byte << 1;
		++taeller;
	}
}

unsigned char SendAdressen(unsigned char adressen,unsigned char mode)
{/*
 sender ic2 adressen til kredsen
 samt mode 1 = read 0 = write
 */
	adressen = adressen << 1;
	if(mode)
		adressen++;
	 SendByte(adressen);
	return   LaesSDA(); // afl�s kreds ack
}

unsigned char LaesByte(unsigned char state)
{
	unsigned char taeller = 0;
	unsigned char vaer = 0;

	while(taeller++ < 8)
	{// modtag 8 bit med msb f�rst
		vaer = vaer << 1;
		if( LaesSDA())
			vaer +=1;
	}

	 SendACK(state);

	return vaer;
}

unsigned char IC2SendByte(unsigned char Kredsadresse, unsigned char byte, unsigned char StopOff)
{
	unsigned char fejl;
	 StartCond();
	 SendAdressen(Kredsadresse,IC2Write);
	 SendByte(byte);	
	fejl =  LaesSDA(); // afl�s kreds ack
	if(!StopOff)
		 StopCond();
	return fejl;

}

unsigned char IC2LaesByte(unsigned char Kredsadresse)
{//l�ser 1 byte fra IC2 Kreds
 // returner 0 hvis OK ellers 1

	unsigned char byte = 0;
	unsigned char fejl;

	StartCond();
	fejl =  SendAdressen(Kredsadresse,IC2Read);
	byte =  LaesByte(1);// sidste byte
	StopCond();
	return byte; 
}

unsigned char IC2SendStreng(unsigned char Kredsadresse, unsigned char *streng, unsigned int antal)
{// sender antal bytes til kredsen
 // returnerer den sidste ACK
	unsigned char fejl;
	unsigned int taeller = 0;

	 StartCond();
	 SendAdressen(Kredsadresse,IC2Write);
	while(taeller < antal)
	{
		 SendByte(streng[taeller++]);
		fejl =  LaesSDA();
	}
	 StopCond();
	return fejl;
}

unsigned char IC2LaesStreng(unsigned char Kredsadresse, unsigned char *streng,unsigned int antal)
{
	unsigned char fejl;
	unsigned int taeller = 0;

	 StartCond();
	fejl =  SendAdressen(Kredsadresse,IC2Read);
	while(taeller < antal)
	{
		if(taeller < (antal - 1))
			streng[taeller++]= LaesByte(0);// der mangler flere
		else
			streng[taeller++]= LaesByte(1);// sidste byte
	}
	 StopCond();
	return fejl;
}

