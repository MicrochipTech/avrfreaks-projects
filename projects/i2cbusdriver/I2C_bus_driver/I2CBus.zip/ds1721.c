//

#define CONFIG_REGISTER 0xAC
#define START_CONVERT 0x51
#define STOP_CONVERT 0x22
#define TH 0xA1
#define TL 0xA2
#define READ_TEMP 0xAA
#define DS1721BUSYFLAG 0x80
#define ResulutionsBit 0x0C

unsigned char streng[4];

unsigned char DS1721Init()
{
	IC2init();
	return;
}

void StartConvert(unsigned char Kredsadresse)
{
	 IC2SendByte(Kredsadresse,(unsigned char)START_CONVERT,0);	
}

void StopConvert(unsigned char Kredsadresse)
{
	 IC2SendByte(Kredsadresse,(unsigned char)STOP_CONVERT,0);	
}

unsigned char LaesConfig(unsigned char Kredsadresse)
{
	IC2SendByte(Kredsadresse,(unsigned char)CONFIG_REGISTER,1);
	return  IC2LaesByte(Kredsadresse);
}

void SkrivIConfigRegistret(unsigned char Kredsadresse, unsigned char Nyvaerdi)
{
	streng[0]= CONFIG_REGISTER;
	streng[1]= Nyvaerdi;
	IC2SendStreng(Kredsadresse,streng,2);
}

unsigned int HentTH(unsigned char Kredsadresse)
{
	IC2SendByte(Kredsadresse,(unsigned char)TH,1);
	IC2LaesStreng(Kredsadresse,streng,2);
	return ((streng[0]*256)+streng[1]);
}

#pragma warn-
void SkrivTH(unsigned char Kredsadresse, unsigned int nyvaerdi)
{
	streng[0]=TH;
	streng[1]=nyvaerdi/256;
	streng[3]=nyvaerdi-((nyvaerdi/256)* 256);
	IC2SendStreng(Kredsadresse,streng,3);
}
#pragma warn+

unsigned int HentTL(unsigned char Kredsadresse)
{
	IC2SendByte(Kredsadresse,(unsigned char)TL,1);
	IC2LaesStreng(Kredsadresse,streng,2);
	return (streng[0]*256+streng[1]);
}

#pragma warn-
void SkrivTL(unsigned char Kredsadresse, unsigned int nyvaerdi)
{
	streng[0] = TL;
	streng[1] = nyvaerdi/256;
	streng[2] = nyvaerdi-((nyvaerdi/256)*256);
	IC2SendStreng(Kredsadresse,streng,3);
}
#pragma warn+

unsigned int ReadRawTemp(unsigned char Kredsadresse)
{
	IC2SendByte(Kredsadresse,(unsigned char)READ_TEMP,1);
	IC2LaesStreng(Kredsadresse,streng,2);
	return (streng[0]*256+streng[1]);
}

double ReadTemp(unsigned char Kredsadresse)
{
	double temp = 0.0;
	unsigned int tempraw ;
	tempraw =  ReadRawTemp(Kredsadresse);
	if(tempraw > 0x5000)
	{
		tempraw &= 0x8000;
		temp = ((double)256.0-(tempraw / (double)256.0)) + 0.0;
	}else
		temp = (tempraw / (double)256.0) + 0.0;
	return temp;
}

unsigned char DS1721CheckIfDone(unsigned char Kredsadresse)
{
	if( LaesConfig(Kredsadresse) & DS1721BUSYFLAG)
		return 1;

	return 0;
}

unsigned char DS1721GetMode(unsigned char Kredsadresse)
{
	return  LaesConfig(Kredsadresse) & 1;
}

void DS1721SetMode(unsigned char Kredsadresse, char mode)
{
// 0 = continueligt
// 1 = One shot

	unsigned char Convmode;
	Convmode =  LaesConfig(Kredsadresse) & ~1; 
	if(mode)
		Convmode++;
		
	SkrivIConfigRegistret(Kredsadresse,Convmode);
}
