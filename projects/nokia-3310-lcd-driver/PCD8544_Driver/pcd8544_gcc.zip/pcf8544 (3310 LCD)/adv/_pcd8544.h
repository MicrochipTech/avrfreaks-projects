/*** PCD8544 Driver ***********************************************************
 *
 *	AVR-GCC Driver for the PCD8544 LCD Controller
 *	
 *	Copyright (C) 2004, Muhammad J. A. Galadima
 *
 *****************************************************************************/
#include "global.h"



/*** LCD defines **************************************************************
 *	
 *	These are the port/pins I used; if necessary change them to suit your
 *	circuit.
 *	
 **************************************************************************///{
	#define lcdPort		PORTC	// port that LCD is on; needs 5 free pins
	#define lcdPortD	DDRC	//
	
	#define	SCLK		PC0
	#define	SDIN		PC1
	#define	DC			PC2
	#define	SCE_		PC4
	#define	RES_		PC3
//}
// LCD Defines

/*** LCD Simple Controls ******************************************************
 *	
 *	Some low level LCD controls
 *	
 **************************************************************************///{
	#define lcdInvert1	lcdModeCmd;lcdByte(0x0d)					// invert
	#define lcdInvert0	lcdModeCmd;lcdByte(0x0c)					// normal
	
	#define	lcdModeCmd	lcdPort &= (unsigned char)~BV(DC)
	#define	lcdModeData	lcdPort |= (unsigned char)BV(DC)
	
	#define	lcdResume	lcdPort &= (unsigned char)~BV(SCE_)
	#define	lcdSuspend	lcdPort |= (unsigned char)BV(SCE_)
	
	#define	lcdReset	lcdPort &= (unsigned char)~BV(RES_);lcdPort |= (unsigned char)BV(RES_)	// reset the LCD
//}
//	LCD Simple Controls

/*** LCD Size *****************************************************************
 *	
 *	Used mainly during testing on an 8515/stk500. The 8515 has 512 bytes RAM,
 *	and the frame buffer is 6x84=504 bytes leaving too little (8b) for other
 *	stuff. My solution was to decrease the vertical lines available (temporarily
 *	of course) to let me use 5x84=420 bytes, and have enough for other stuff.
 *
 *	If you are using a processor with less than 1K of RAM, you can decrease the
 *	'fbRows' value to 5. You can draw to the last LCD row without the frame
 *	buffer by calling "lcdXY(x,5)" (where 'x' is 0 to 84) and then writing a
 *	byte by calling "lcdByte(value)" to fill in one column at a time.
 *	
 **************************************************************************///{
	#define fbCols		84
	#define fbRows		5	// 6
//}
//	LCD Size

/*** Global Vars **************************************************************
 *	
 *	Just the framebuffer and frame buffer cursor
 *	
 **************************************************************************///{
	u08 frameBuffer[fbCols][fbRows];	// __attribute__ ((section (".noinit")));
	s16 fbBox[4] =						// bounding box for text
			{0,0,fbCols,fbRows*8};
	s16 fbXY[2];						// frame buffer cursor location
//}
//	Global Variables

/*** Constants ****************************************************************
 *	
 **************************************************************************///{
	#define	IS_PSTR		0
	#define	IS_SRAM		1
	#define	WRAP_CHR	0
	#define	WRAP_COL	2
//}
// Constants



/*** lcdByte ******************************************************************
 *	
 *	Send one byte to the LCD
 *	
 *	shift out given byte, MSB fisrt; dc is 1 (data) or 0 (command) 
 *	(lcdModeData/lcdModeCmd) and is set in calling function
 *	
 **************************************************************************///{
void lcdByte(u08 data) {
	u08 i;
	
	lcdResume;
	
	for(i=0; i<8; i++) {		// clock out the byte, MSB first
		if(bit_is_set(data, 7))
			lcdPort |= (unsigned char)BV(SDIN);
		else
			lcdPort &= (unsigned char)~BV(SDIN);
		
		// clock out the bit
		lcdPort &= (unsigned char)~BV(SCLK);
		lcdPort |= (unsigned char)BV(SCLK);

		data <<= 1;
	}
	
	lcdSuspend;
}
//}
//	void lcdByte(u08 data)

/*** lcdDot *******************************************************************
 *	
 *	Draw a dot to the frame buffer
 *	
 **************************************************************************///{
void lcdDot(s16 x, s16 yLine, u08 color) {
	u08 yBit;			// 00LL LBBB

	if( (x>=fbBox[0]) && (yLine>=fbBox[1]) && (x<fbBox[2]) && (yLine<fbBox[3]) ) {
		// separate line number (0-5) from atual pixel in line (0-7)
		//	this is done by divide
		yBit	= yLine & 7;	// 0b0000 0bbb
		yLine	= yLine >> 3;	// yline / 8 ; 0b00l ll00 => 0b0000 0lll
	
		// if color is diff from frameBuffer (0 or 1), toggle; if color is
		//	toggle (2) then expression is always true
		if( color ^ (frameBuffer[x][yLine] & BV(yBit))>>yBit ) {
			frameBuffer[x][yLine] ^= BV(yBit);
		}
	}
}
//}
//	void lcdDot(u08 x, u08 yLine, u08 color)

/*** fontWidth ****************************************************************
 *	
 *	Get width of given char
 *	
 **************************************************************************///{
u08 fontWidth(u08* fontSet, u08 ch) {
	u08 i,tmp,sz=0;
	u08 x = pgm_read_byte(fontSet+1);
	
	for(i=0; i<x; i++) {
		tmp = pgm_read_byte(fontSet+(x*ch+3)+i);
		
		if(tmp > 0x00) {
			sz = i;
		}
	}
	
	return (sz);
}
//}
//	u08 fontWidth(u08* fontSet, u08 ch)

/*** fbBoundChk ***************************************************************
 *	
 *	If cursor is not within fbBox[] x-space, move to start of next line
 *	
 **************************************************************************///{
void fbBoundChk(u08 x, u08 y) {
	if((fbXY[0]+x) >= fbBox[2]) {
		fbXY[1] +=	y + 1;
		fbXY[0] = fbBox[0];
	}
}
//}
//	void fbBoundChk(u08 y)

/*** lcdCh ********************************************************************
 *	
 *	Write a character from selected font to screen at location fbXY[0], fbXY[1]
 *	
 **************************************************************************///{
u16 lcdCh(u08* fontSet, u08 ch, u08 status) {
	u08 i, j, tmp;
	u08 k = pgm_read_byte(fontSet+0);	// size i.e. num chars
	u08 x = pgm_read_byte(fontSet+1);
	u08 y = pgm_read_byte(fontSet+2);
	u16 szCh=0;
	
	lcdModeData;
	
	if(ch<k) {
		if( ((fbBox[3]-fbBox[1]) > y) && !(status & WRAP_COL)) {
			fbBoundChk(fontWidth(fontSet, ch),y);
		}
		
		for(i=0; i<x; i++) {
			fbBoundChk(0,y);
			
			tmp = pgm_read_byte(fontSet+(x*ch+3)+i);
			if(tmp != 0x00) {
				for(j=0; j<y; j++) {
					k=0;
					if(tmp & BV(j)) {
						k=1;
					}
					
					lcdDot(fbXY[0],fbXY[1]+j,k);
				}
				
				szCh++;
				fbXY[0]++;
			}
		}
	}
	else {
		fbBoundChk(0,y);
		
		// if we're at the beginning of a new line, dont bother to put a space
		//	what to do for intentional space? write directly to framebuffer
		for(i=0; i<(x/2); i++) {
			if(fbXY[0] != fbBox[0]) {
				for(j=0; j<y; j++) {
					lcdDot(fbXY[0],fbXY[1]+j,0);		// show empty if out of range
				}
				
				szCh++;
				fbXY[0]++;
			}
			else {
				i=x;	// stop for loop
			}
		}
	}
	
	return (szCh);
}
//}
//	void lcdCh(u08* fontSet, u08 ch)

/*** fontTranslate ************************************************************
 *	
 *	Translate char to equivalent in selected fontSet
 *	
 **************************************************************************///{
u08 fontTranslate(u08 ch) {
	u08 offset;
	
	if(ch > 32) {
		offset = 33;
		
		if( (ch>96) && (ch<123) ) {
			offset = 65;
		}
		else if(ch>122) {
			offset = 60;
		}
		
		ch -= offset;
	}
	else {
		ch = 255;	// empty (not recognized)
	}
	
	return ch;
}
//}
//	u08 fontTranslate(u08 ch)

/*** lcdWrite *****************************************************************
 *	
 *	Convert input to selected font, Write to display at set location
 *	
 **************************************************************************///{
u16 lcdWrite(u08* fontSet, u08* buf, u08 status) {
	u08 i=0, ch;//, offset;
	u16 szBuf=0;

	// check if string is in flash/sram and read appropriately
	if(status & IS_SRAM) {
		ch = buf[i];
	}
	else {
		ch = pgm_read_byte(buf+i);
	}
	
	do {
/*		ch = lcdCh(fontSet, fontTranslate(ch), status);	// use 'ch' as temp var here
		if(status & WRAP_COL) {	// inc by 'ch' cols
			szBuf += ch;
		}
		else {
			szBuf++;				// inc by one char
		}
*/
		// if required, user can get # chars in calling function
		szBuf += lcdCh(fontSet, fontTranslate(ch), status);	// returns # cols
		
		fbXY[0]++;	// char spacing
		
		i++;
		
		// check if string is in flash/sram and read appropriately
		if(status & IS_SRAM) {
			ch = buf[i];
		}
		else {
			ch = pgm_read_byte(buf+i);
		}

	} while(ch != '\0');
	
	return (szBuf);
}
//}
//	void lcdWrite(u08* fontSet, u08* buf, u08 is_pstr)

/*** fbClr ********************************************************************
 *	
 *	Clear the frame buffer
 *	
 **************************************************************************///{
void fbClr(void) {
	u08 x, yLine;
	
	for(yLine=0; yLine<fbRows; yLine++) {
		for(x=0; x<fbCols; x++) {
			frameBuffer[x][yLine] = 0x00;
		}
	}
}
//}
//	void fbClr(void)

/*** lcdClr *******************************************************************
 *	
 *	Clears the LCD. Call this first to get rid of junk data on the screen.
 *	
 **************************************************************************///{
void lcdClr(void) {
	u16 i;

	lcdModeData;
	for(i=0; i<504; i++) {
		lcdByte(0x00);
	}
}
//}
//	void lcdClr(void)

/*** lcdInit ******************************************************************
 *	
 *	Initialize the LCD, get it ready to be used; returns in cmd mode
 *	
 **************************************************************************///{
void lcdInit(void) {
	lcdPortD |= (unsigned char)(BV(SCLK) | BV(SDIN) | BV(DC) | BV(SCE_) | BV(RES_));	// set the direction on these pins to output
	lcdPort  |= (unsigned char)(BV(SCLK) | BV(SDIN) | BV(DC) | BV(SCE_) | BV(RES_));	// set RES: disable reset; IC ready to run
		// set all (except RES_); IC in suspend, leave RES_ reset (on)

//	lcdReset;
	lcdClr();

	// init settings
	lcdModeCmd;		// set command mode
	lcdByte(0x21);	// extended instruction set
	
	lcdByte(0x90);	// set VOP
	lcdByte(0x06);	// set temperature co-eff
	lcdByte(0x13);	// bias (1:48)
	
	lcdByte(0x20);	// normal instruction set: PD= 0, V= 0
//	lcdByte(0x22);	// normal instruction set: PD= 0, V= 1
	lcdByte(0x0c);	// normal mode: d=1, e=0
}
//}
//	void lcdInit(void)

/*** lcdXY ********************************************************************
 *	
 *	Set cursor to location x:y (0-83:0-47).
 *	
 **************************************************************************///{
void lcdXY(s08 x, s08 y) {
	lcdModeCmd;
	lcdByte(x|0x80);	// 0b1xxx xxxx
	lcdByte(y|0x40);	// 0b0100 0xxx
}
//}
//	void lcdXY(u08 x, u08 y)

/*** lcdDisplay ***************************************************************
 *	
 *	Display the contents of the frame buffer to the LCD
 *	
 **************************************************************************///{
void lcdDisplay(void) {
	u08 x;
	u08 yLine;

	lcdXY(0,0);

	lcdModeData;
	for(yLine=0; yLine<fbRows; yLine++) {
		for(x=0; x<fbCols; x++) {
			lcdByte(frameBuffer[x][yLine]);
		}
	}
}
//}
//	void lcdDisplay(void)
