20041002

This code implements a driver which lets control the PCD8544 LCD controller,
(the controller used in the 3310s' LCD).

In the 'adv' is some code I was working on to write text within a specified
bounding box. It should work, but there were some things I had wanted to
fine-tune...