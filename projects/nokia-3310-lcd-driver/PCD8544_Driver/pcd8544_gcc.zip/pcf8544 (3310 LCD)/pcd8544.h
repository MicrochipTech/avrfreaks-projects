/*** PCD8544 Driver ***********************************************************
 *
 *	File Name	: pcd8544.h
 *	Title		: AVR-GCC Driver for the PCD8544 LCD Controller
 *	Author		: Muhammad J. A. Galadima
 *	Created		: 2004 / 01 / 27
 *	Revised		: 2004 / 02 / 05
 *	Version		: 0.7
 *	Target MCU	: Atmel AVRs w/1k+ RAM
 *	
 *	
 *	
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version 2
 *	of the License, or (at your option) any later version.
 *	
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *	
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software Foundation, 
 *	Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *	
 **************************************************************************///{
#include "global.h"


/*** LCD defines **************************************************************
 *	
 *	These are the port/pins I used; change if necessary them to suit your
 *	circuit.
 *	
 **************************************************************************///{
	#define lcdPort		PORTC	// port that LCD is on; needs 5 free pins
	#define lcdPortD	DDRC	//
	
	#define	SCLK		PC0
	#define	SDIN		PC1
	#define	DC			PC2
	#define	SCE_		PC4
	#define	RES_		PC3
//}
//	LCD Defines

/*** LCD Simple Controls ******************************************************
 *	
 *	Some low level LCD controls
 *	
 **************************************************************************///{
	#define lcdInvert1	lcdModeCmd;lcdByte(0x0d)					// invert
	#define lcdInvert0	lcdModeCmd;lcdByte(0x0c)					// normal
	
	#define	lcdModeCmd	lcdPort &= (unsigned char)~BV(DC)
	#define	lcdModeData	lcdPort |= (unsigned char)BV(DC)
	
	#define	lcdResume	lcdPort &= (unsigned char)~BV(SCE_)
	#define	lcdSuspend	lcdPort |= (unsigned char)BV(SCE_)
	
	#define	lcdReset	lcdPort &= (unsigned char)~BV(RES_);lcdPort |= (unsigned char)BV(RES_)	// reset the LCD
//}
//	LCD Simple Controls

/*** LCD Size *****************************************************************
 *	
 *	Used mainly during testing on an 8515/stk500. The 8515 has 512 bytes RAM,
 *	and the frame buffer is 6x84=504 bytes leaving too little (8b) for other
 *	stuff. My solution was to decrease the vertical lines available (temporarily
 *	of course) to let me use 5x84=420 bytes, and have enough for other stuff.
 *
 *	If you are using a processor with less than 1K of RAM, you can decrease the
 *	'fbRows' value to 5. You can draw to the last LCD row without the frame
 *	buffer by calling "lcdXY(x,5)" (where 'x' is 0 to 84) and then writing a
 *	byte by calling "lcdByte(value)" to fill in one column at a time.
 *	
 **************************************************************************///{
	#define fbCols		84
	#define fbRows		5	// 6
//}
//	LCD Size

/*** Global Vars **************************************************************
 *	
 *	Just the framebuffer and frame buffer cursor
 *	
 **************************************************************************///{
	u08 frameBuffer[fbCols][fbRows];	// __attribute__ ((section (".noinit")));
	u08 fbXY[2];						// frame buffer cursor location
//}
//	Global Variables




/*** lcdByte ******************************************************************
 *	
 *	Send one byte to the LCD
 *	
 *	shift out given byte, MSB fisrt; dc is 1 (data) or 0 (command) 
 *	(lcdModeData/lcdModeCmd) and is set in calling function
 *	
 **************************************************************************///{
void lcdByte(u08 data) {	// 
	u08 i;
	
	lcdResume;
	
	for(i=0; i<8; i++) {		// clock out the byte, MSB first
		if(bit_is_set(data, 7))
			lcdPort |= (unsigned char)BV(SDIN);
		else
			lcdPort &= (unsigned char)~BV(SDIN);
		
		// clock out the bit
		lcdPort &= (unsigned char)~BV(SCLK);
		lcdPort |= (unsigned char)BV(SCLK);

		data <<= 1;
	}
	
	lcdSuspend;
}
//}
//	void lcdByte(u08 data)

/*** lcdDot *******************************************************************
 *	
 *	Draw a dot to the frame buffer
 *	
 **************************************************************************///{
void lcdDot(u08 x, u08 yLine, u08 color) {
	u08 yBit;			// 00LL LBBB
	
	// f x is more than screen x-res, wrap
	while(x>=fbCols)
		x		-= fbCols;
	// if yLine is more than screen y-res, wrap
	while(yLine>=(fbRows*8))
		yLine	-= (fbRows*8);
	
	
	// separate line number (0-5) from atual pixel in line (0-7)
	//	this is done by divide
	yBit	= yLine & 7;	// 0b0000 0bbb
	yLine	= yLine >> 3;	// yline / 8 ; 0b00l ll00 => 0b0000 0lll

	// if color is diff from frameBuffer, toggle; if color is toggle (2) expression is always true
	if( color ^ (frameBuffer[x][yLine] & BV(yBit))>>yBit ) {
		frameBuffer[x][yLine] ^= BV(yBit);
	}
}
//}
//	void lcdDot(u08 x, u08 yLine, u08 color)

/*** lcdCh *******************************************************************
 *	
 *	Write predefined fonts to screen at set location
 *	
 **************************************************************************///{
void lcdCh(u08* fontSet, u08 ch) {
	u08 i, j;
	u08 k = pgm_read_byte(fontSet);
	u08 x = pgm_read_byte(fontSet+1);
	u08 y = pgm_read_byte(fontSet+2);

	lcdModeData;
	if(ch < k) {
		for(i=0; i<x; i++) {
			for(j=0; j<y; j++) {
				k=0;
				if(pgm_read_byte(fontSet+(x*ch+3)+i) & BV(j)) {
					k=1;
				}
				
				lcdDot(fbXY[0],fbXY[1]+j,k);
			}
			fbXY[0]++;
		}
	}
	else {
		for(j=0; j<y; j++) {
			lcdDot(fbXY[0],fbXY[1]+j,0);		// show empty if out of range
		}
		fbXY[0]++;
	}
}
//}
//	void lcdCh(u08* fontSet, u08 ch)

/*** lcdWrite *****************************************************************
 *	
 *	Translate input to selected font, Write to display at set location
 *	
 **************************************************************************///{
void lcdWrite(u08* fontSet, u08* buf, u08 is_pstr) {
	u08 i=0, offset, ch;

	// check if string is in flash/sram and read appropriately
	if(is_pstr) {
		ch = pgm_read_byte(buf+i);
	}
	else {
		ch = buf[i];
	}

	do {
		if(ch > 32) {
			offset = 33;
			
			if( (ch>96) && (ch<123) ) {
				offset = 65;
			}
			else if(ch>122) {
				offset = 60;
			}
	
			lcdCh(fontSet, ch-offset);
		}
		else {
			lcdCh(fontSet, 255);	// empty (not recognized)
		}
		fbXY[0]++;	// char spacing
		
		i++;
		
		// check if string is in flash/sram and read appropriately
		if(is_pstr) {
			ch = pgm_read_byte(buf+i);
		}
		else {
			ch = buf[i];
		}

	} while(ch != '\0');
}
//}
//	void lcdWrite(u08* fontSet, u08* buf, u08 is_pstr)

/*** fbClr ********************************************************************
 *	
 *	Clear the frame buffer
 *	
 **************************************************************************///{
void fbClr(void) {
	u08 x, yLine;
	
	for(yLine=0; yLine<fbRows; yLine++) {
		for(x=0; x<fbCols; x++) {
			frameBuffer[x][yLine] = 0x00;
		}
	}
}
//}
//	void fbClr(void)

/*** lcdClr *******************************************************************
 *	
 *	Clears the LCD. Call this first to get rid of junk data on the screen.
 *	
 **************************************************************************///{
void lcdClr(void) {
	u16 i;

	lcdModeData;
	for(i=0; i<504; i++) {
		lcdByte(0x00);
	}
}
//}
//	void lcdClr(void)

/*** lcdInit ******************************************************************
 *	
 *	Initialize the LCD, get it ready to be used; returns in cmd mode
 *	
 **************************************************************************///{
void lcdInit(void) {
	lcdPortD |= (unsigned char)(BV(SCLK) | BV(SDIN) | BV(DC) | BV(SCE_) | BV(RES_));	// set the direction on these pins to output
	lcdPort  |= (unsigned char)(BV(SCLK) | BV(SDIN) | BV(DC) | BV(SCE_) | BV(RES_));	// set RES: disable reset; IC ready to run
		// set all (high); RESET complete, LCD in suspend

//	lcdReset;
	lcdClr();

	// init settings
	lcdModeCmd;		// set command mode
	lcdByte(0x21);	// extended instruction set
	
	lcdByte(0x90);	// set VOP
	lcdByte(0x06);	// set temperature co-eff
	lcdByte(0x13);	// bias (1:48)
	
	lcdByte(0x20);	// normal instruction set: PD= 0, V= 0
//	lcdByte(0x22);	// normal instruction set: PD= 0, V= 1
	lcdByte(0x0c);	// normal mode: d=1, e=0
}
//}
//	void lcdInit(void)

/*** lcdXY ********************************************************************
 *	
 *	Set cursor to location x:y (0-83:0-47).
 *	
 **************************************************************************///{
void lcdXY(u08 x, u08 y) {
	lcdModeCmd;
	lcdByte(x|0x80);	// 0b1xxx xxxx
	lcdByte(y|0x40);	// 0b0100 0xxx
}
//}
//	void lcdXY(u08 x, u08 y)

/*** lcdDisplay ***************************************************************
 *	
 *	Display the contents of the frame buffer to the LCD
 *	
 **************************************************************************///{
void lcdDisplay(void) {
	u08 x;
	u08 yLine;

	lcdXY(0,0);

	lcdModeData;
	for(yLine=0; yLine<fbRows; yLine++) {
		for(x=0; x<fbCols; x++) {
			lcdByte(frameBuffer[x][yLine]);
		}
	}
}
//}
//	void lcdDisplay(void)
