/*H***************************************************************************
 *
 * $RCSfile: menu.c,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-20 20:51:54+01 $
 * $Revision: 1.2 $
 *----------------------------------------------------------------------------
 *      $Log: menu.c,v $
 *      Revision 1.2  2003-11-20 20:51:54+01  mika
 *      Changed menu_t pointer const.
 *
 *      Revision 1.1  2003-11-15 20:07:18+01  mika
 *      Lint and indent. Chaned comments.
 *
 *      Revision 1.0  2003-11-12 20:51:55+01  mika
 *      Initial revision
 *
 ****************************************************************************/
#include "menu.h"
#include "menu_cfg.h"
#include "button.h"
#include "display_data.h"
#include <string.h>

/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/
typedef enum 
{
   menu_nav,
   action
} menu_state_t;


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static menu_t const *m_menu_p = &level1[0];
static menu_state_t m_menu_state = menu_nav;


/*****************************************************************************
*                                                                            *
*  Global function : Menu_init                                               *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description : Displays the inital string from the menu system.            *
*                                                                            *
*                                                                            *
*****************************************************************************/
void Menu_init(void)
{

   char *buf_p = 0;

   DisplayData_reserve_resouces(menu, &buf_p);
   strcpy(buf_p, m_menu_p->menu_string);
   DisplayData_release_resource();

}


/*****************************************************************************
*                                                                            *
*  Global function : tMenu                                                   *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description : Menu task, handles the menu system at runtime.              *
*                                                                            *
*                                                                            *
*****************************************************************************/
void tMenu(void)
{

   menu_t const *top_p = NULL;
   menu_t const *curr_p = NULL;
   char *buf_p = NULL;
   button_evt_t menu_button_evt;
   Button_get(&menu_button_evt);

   /* The menu system is only executed if an event has occurred in the Button
      object. */
   if (menu_button_evt.button_action == button_no_action) {
      return;                   /* <########## RETURN ##########> */
   }


   /* Basiclly the menu system can be in one of two states, menu navigation and
      action handling (see the menu_state_t type). 

      In menu navigation stated the user can navigate through the menus using
      the button_up and button_down in butt0on_pressed action. 

      State transitions are marked <# TRANSITION - [state] #>. */
   switch (m_menu_state) {
   
      case menu_nav:

         /* Reserve the shared memory in DisplayData object. */
         DisplayData_reserve_resouces(menu, &buf_p);

         if ((menu_button_evt.button_action == button_pressed) &&
             (menu_button_evt.button == button_enter) && (m_menu_p->child_p == NULL)) {
            /* <# TRANSITION - action # > */
            m_menu_state = action;
            m_menu_p->action_handler_p(&menu_button_evt);
         }
         else {
            if (menu_button_evt.button_action == button_pressed) {

               /* Next menu item by button_up. */
               if (menu_button_evt.button == button_up) {
                  if (m_menu_p->list_part == tail) {
                     /* Search the head object of the menu group. */
                     while (m_menu_p->list_part != head) {
                        m_menu_p--;
                     }
                  }
                  else {
                     m_menu_p++;
                  }
                  strcpy(buf_p, m_menu_p->menu_string);
               }

               /* Next menu item by button_down. */
               if (menu_button_evt.button == button_down) {
                  if (m_menu_p->list_part == head) {
                     while (m_menu_p->list_part != tail) {
                        m_menu_p++;
                     }

                  }
                  else {
                     m_menu_p--;
                  }
                  strcpy(buf_p, m_menu_p->menu_string);
               }

               /* Next menu level by button_back. */
               if (menu_button_evt.button == button_back) {
                  if (m_menu_p->parent_p != NULL) {
                     /* Determine the position in the menu level and store it.
                        It will be used as the entry menu the next tine we
                        enter this menu group. */
                     top_p = m_menu_p;
                     curr_p = m_menu_p;
                     while (top_p->list_part != head) {
                        top_p--;
                     }
                     m_menu_p = m_menu_p->parent_p;
                     *(m_menu_p->submenu_entry_p) = (uint8_t) (curr_p - top_p);
                     strcpy(buf_p, m_menu_p->menu_string);
                  }
               }

               /* Next menu level by_button_down */
               if (menu_button_evt.button == button_enter) {
                  if (m_menu_p->child_p != NULL) {
                     m_menu_p = &(m_menu_p->child_p[*(m_menu_p->submenu_entry_p)]);
                     strcpy(buf_p, m_menu_p->menu_string);
                  }
               }
            }
         }

         /* Release the shared memory in DisplayData object. */
         DisplayData_release_resource();
         break;


      /* The action state of the menu system calls the menu action handler 
         stated as a function pointer in the menu configuration(menu_cfg.c). 

         The action state is always left when the user activates button_back
         in button_pressed mode. Note that the menu action handler is
         informed about the transition, the call is made first, then the state
         transition occurs. */
      case action:

         /* Call the action handler. */
         (m_menu_p->action_handler_p) (&menu_button_evt);

         if ((menu_button_evt.button_action == button_pressed) && (menu_button_evt.button == button_back)) {

            DisplayData_reserve_resouces(menu, &buf_p);
            strcpy(buf_p, m_menu_p->menu_string);
            DisplayData_release_resource();

            /* <# TRANSITION - action # > */
            m_menu_state = menu_nav;
         }
         break;

      default:
         /* panic(); */
         break;
   }

   return;
}
