/*H***************************************************************************
 *
 * $RCSfile: timer0.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 17:31:57+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: timer0.c,v $
 * Revision 1.0  2003-11-16 17:31:57+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/io.h>
#include "timer0.h"


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static boolean_t m_10ms_tm;


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static void init_timer0_registers(void);


/*****************************************************************************
*                                                                            *
*  Global function : Timer0_has_10ms_passed                                  *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : Has it ?, TRUE or FALSE                                 *
*                                                                            *
*  Description     :                                                         *
*                                                                            *
*                                                                            *
*****************************************************************************/
boolean_t Timer0_has_10ms_passed(void)
{

   if (m_10ms_tm == TRUE) {
      m_10ms_tm = FALSE;
      return TRUE;
   }
   else {
      return FALSE;
   }

}


/*****************************************************************************
*                                                                            *
*  Global function : Timer0_init                                             *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : bool, TRUE or FALSE                                     *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void Timer0_init(void)
{

   init_timer0_registers();
   m_10ms_tm = FALSE;

}



/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  Private function : init_timer0_registers                                  *
*                                                                            *
*  Argument         : none                                                   * 
*                                                                            *
*  Return           : none                                                   *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
static void init_timer0_registers(void)
{

   outp(0x05, TCCR0);

   /* Prescaler : TCK0/1024 */
   outp(0xF0, TCNT0);

   timer_enable_int(BV(TOIE0));

}



/*****************************************************************************
*                                                                            *
*  Interrupt handler                                                         *
*                                                                            *
*****************************************************************************/
INTERRUPT(SIG_OVERFLOW0)
{

   m_10ms_tm = TRUE;

   /* Clear the Timer0 Overflow interrupt in the Timer 
      Interrupt Flag register. */
   outp(0xd0, TCNT0);
   cbi(TIFR, TOV0);


   sei();


}
