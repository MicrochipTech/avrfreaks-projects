/*H***************************************************************************
 *
 * $RCSfile: lang.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 17:43:50+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: lang.c,v $
 * Revision 1.0  2003-11-16 17:43:50+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include "lang.h"
#include <string.h>



/*****************************************************************************
*                                                                            *
*  P R I V A T E   C O N S T A N T S                                         *
*                                                                            *
*****************************************************************************/
#define LANG_N_LANGUAGES ((int)(3))


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/
typedef struct lang_data_tag
{
   char lang_string[LANG_N_CHARSINLANG];
   lang_id_t lang_id;
} lang_data_t;



const lang_data_t lang_data[LANG_N_LANGUAGES] = {
   {"Svenska", svenska},
   {"English", english},
   {"Deutsch", deutsch}
};


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static lang_id_t m_language_selector = svenska;


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/



/*****************************************************************************
*                                                                            *
*  Global function : lang_get_language_id                                    *
*                                                                            *
*  Argument        : lang - pointer to lang_id_t.          .                 *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description : Returns the language id currently set in the Language       *
*                object.                                                     *
*                                                                            *
*****************************************************************************/
void lang_get_language_id(lang_id_t * lang_p)
{

   *lang_p = m_language_selector;

}



/*****************************************************************************
*                                                                            *
*  Global function : lang_set_language                                       *
*                                                                            *
*  Argument        : change_t - Change the language in the change_t          *
*                    direction.                                              *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description : Tries to change the language in the direction stated in     *
*                type.                                                       *
*                                                                            *
*****************************************************************************/
void lang_set_language(change_t type)
{


   lang_id_t lang = m_language_selector;

   switch (type) {
      case change_inc_step:
         lang++;
         break;
      case change_dec_step:
         lang--;
         break;
   }


   if ((lang != lang_enum_tail) && (lang != lang_enum_head)) {
      m_language_selector = lang;
   }

}


/*****************************************************************************
*                                                                            *
*  Global function : lang_set_default_language                               *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description : Set the degfult laguage in the language object.             *
*                                                                            *
*****************************************************************************/
void lang_set_default_language(void)
{

   m_language_selector = svenska;

}


/*****************************************************************************
*                                                                            *
*  Global function : lang_get_language_string                                *
*                                                                            *
*  Argument        : char pointer                                            *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description : Set the degfult laguage in the language object.             *
*                                                                            *
*****************************************************************************/
void lang_get_language_string(char *str_p)
{

   uint8_t c;

   for (c = 0; c < LANG_N_LANGUAGES; c++) {
      if (lang_data[c].lang_id == m_language_selector) {
         break;
      }
   }

   (void)strcpy(str_p, &(lang_data[c].lang_string[0]));
}
