/*H***************************************************************************
 *
 * $RCSfile: display_data.c,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-16 16:27:09+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: display_data.c,v $
 *      Revision 1.0  2003-11-16 16:27:09+01  mika
 *      Initial revision
 *
 *
 ****************************************************************************/
#include "display_data.h"


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
char g_data[DISPLAY_DATA_N_BYTES];
static display_info_provider_t m_data_provider = menu;


/*****************************************************************************
*                                                                            *
*  Global function : DisplayData_reserve_resouces                            *
*                                                                            *
*  Argument        : buf_pp - to be assigned to the shared memory.           *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Reserves the shared memory of the DataDisplay object.   *
*                                                                            *
*                                                                            *
*****************************************************************************/
void DisplayData_reserve_resouces(display_info_provider_t provider, char **buf_pp)
{

   switch (provider) {
      case menu:
      case error_handler:
      case info:
         m_data_provider = provider;
         break;

      case display:
         break;

      default:
         /* panic(); */
         break;
   }

   *buf_pp = &g_data[0];

}

void DisplayData_release_resource(void)
{

   ;

}
