/*H***************************************************************************
 *
 * $Workfile: debug.c $
 * 
 *  Descript: Debug module, for any debug purpose.
 *
 *   Creator: Mikael Carlsson
 *   Project: Greenhouse control
 * 
 *   $Author: emwmika $
 *     $Date: 2003-09-17 11:23:02+02 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: debug.c,v $
 *      Revision 1.0  2003-09-17 11:23:02+02  emwmika
 *      Initial revision
 *
 * 
 * 1     :1-12-30 14:45 Mika
 * First version.
 ****************************************************************************/
#include "config.h"
#include "display.h"
#include "tm162_drv.h"
#include <string.h>
#include "button.h"


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/

const uint8_t pos_ac[] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 
                            0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
                            0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
                            0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };                            

const char display_string[] = {   'J', 'a', 'g', ' ', 's', 'k', 'a', 'l', 'l',
                                    ' ', 'r', 'a', 'k', 'a', ' ', ' ', 'd', 'i', 'n',
                                    ' ', 's', 't', 'j', 0xe1, 'r', 't', '.' };

const char c_down[] = "Button down pressed";
const char c_up[] = "Button up pressed";
const char c_right[] = "Button right pressed";
const char c_left[] = "Button left pressed";
const char c_hold[] = "Button hold down";
const char c_ng[] = "Button is ng";
const char c_idle[] = "Button is now idle";

static uint8_t bajs = 0;

void Display_init( void ) {

    boolean_t busy = TRUE;
    uint8_t   address = 0;
   

    while( busy == TRUE ) {
        tm162_read_busy_flag_and_address( &address, &busy );
    }
    tm162_function_set( eight_bit_interface, two_line_mode, five_x_eleven_dot );

    busy = TRUE;
    while( busy == TRUE ) {
        tm162_read_busy_flag_and_address( &address, &busy );
    }
    tm162_display_on_off_control( on, off, off );

    busy = TRUE;
    while( busy == TRUE ) {
        tm162_read_busy_flag_and_address( &address, &busy );
    }
    tm162_clear_display();

    busy = TRUE;
    while( busy == TRUE ) {
        tm162_read_busy_flag_and_address( &address, &busy );
    }
    tm162_entry_mode_set( right_direction, off );
}


/*****************************************************************************
*                                                                            *
*  Global function : HW_init                                                 *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void tDisplay( void )
{

    boolean_t busy = TRUE;
    char data[32];
    size_t len = 0;
    button_t b;
    button_action_t ba;
    const char *p = NULL;
    uint8_t c = 0;
    uint8_t   address = 0;    
   
    
    Button_get( &b, &ba );
    if( ba == button_no_action )  {
        bajs = 0;    
        return;
    }
    else if (( ba == button_hold_down ) && ( bajs == 0 )) {
        p = &c_hold[0];
        bajs = 1;
    }
    else if ( ba == button_pressed ) {
        switch ( b ) {
            case button_up :
                p = &c_up[0];
                break;

            case button_down :
                p = &c_down[0];
                break;

            case button_right :
                p = &c_right[0];
                break;

            case button_left :
                p = &c_left[0];
                break;

            default :
                p = &c_ng[0];
                break;
        }
    }
    else {
        return;
    }

    

    (void)strcpy( &data[0], p );
    len = strlen( &data[0] );
    
    while( busy == TRUE ) {
        tm162_read_busy_flag_and_address( &address, &busy );
    }
    tm162_clear_display();
   
    for( c=0; c<len; c++ ) {
        busy = TRUE;
        while( busy == TRUE ) {
            tm162_read_busy_flag_and_address( &address, &busy );
        }
        tm162_set_ddram_address( (uint8_t)(pos_ac[c]) );

        busy = TRUE;
        while( busy == TRUE ) {
            tm162_read_busy_flag_and_address( &address, &busy );
        }
        tm162_write_data_to_ram( (uint8_t)(data[c]) );
/*            tm162_write_data_to_ram( (uint8_t)(display_string[c]) ); */

    }
            

}
