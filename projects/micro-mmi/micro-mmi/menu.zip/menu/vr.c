/*H***************************************************************************
 *
 * $RCSfile: vr.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 20:32:06+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: vr.c,v $
 * Revision 1.0  2003-11-16 20:32:06+01  mika
 * Initial revision
 *
 *
 *
 ****************************************************************************/
#include <avr/interrupt.h>
#include "config.h"
#include "hw.h"
#include "timer0.h"
#include "button.h"
#include "display.h"
#include "display_data.h"
#include "menu.h"


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/
static void update_scheduler(void);


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static boolean_t m_task_10_Hz = FALSE;
static boolean_t m_task_1_Hz = FALSE;
static boolean_t m_task_100hz = FALSE;
static uint8_t m_task_10_Cnt = 0;
static uint8_t m_task_1_Cnt = 0;


/*****************************************************************************
*                                                                            *
*  Global function : main                                                    *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
int main(void)
{

   HW_init();
   Timer0_init();
   Display_init();
   Menu_init();


   m_task_10_Hz = FALSE;
   m_task_1_Hz = FALSE;
   m_task_10_Cnt = 0;
   m_task_1_Cnt = 0;

   sei();


   for (;;) {


      update_scheduler();

      if (m_task_100hz == TRUE) {
         tButton();
         m_task_100hz = FALSE;
      }


      if (m_task_10_Hz == TRUE) {
         tMenu();
         tDisplay();
      }

      if (m_task_1_Hz == TRUE) {
         ;
      }

   }

}



/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  Private function : update_scheduler                                       *
*                                                                            *
*  Argument         : none                                                   * 
*                                                                            *
*  Return           : none                                                   *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
static void update_scheduler(void)
{

   boolean_t has_passed_10ms;

   has_passed_10ms = Timer0_has_10ms_passed();

   if (has_passed_10ms == TRUE) {
      m_task_10_Cnt++;
      m_task_100hz = TRUE;
   }

   if (m_task_10_Hz == TRUE) {
      m_task_1_Cnt++;
   }

   if (m_task_1_Cnt >= 10) {
      m_task_1_Hz = TRUE;
      m_task_1_Cnt = 0;
   }
   else {
      m_task_1_Hz = FALSE;
   }

   if (m_task_10_Cnt >= 10) {
      m_task_10_Hz = TRUE;
      m_task_10_Cnt = 0;
   }
   else {
      m_task_10_Hz = FALSE;
   }



}
