/*H***************************************************************************
 *
 * $RCSfile: freq.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 18:05:41+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: freq.c,v $
 * Revision 1.0  2003-11-16 18:05:41+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include "freq.h"



/*****************************************************************************
*                                                                            *
*  P R I V A T E   C O N S T A N T S                                         *
*                                                                            *
*****************************************************************************/
#define FREQ_N_CHANNELS ((int8_t)(9))
const uint8_t frequency_channels[FREQ_N_CHANNELS] = { 87, 88, 90, 91, 186, 187, 190, 201, 202 };

#define FREQ_N_HOPMODES ((int8_t)(4))
const char frequency_hoppingmodes[FREQ_N_HOPMODES] = { 'A', 'E', 'F', 'Z' };


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/



/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static int8_t m_channel_selector = 0;
static int8_t m_hoppingmode_selector = 0;


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/



/*****************************************************************************
*                                                                            *
*  Global function : freq_getchannel                                         *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void freq_getchannel(uint8_t * channel_p)
{

   *channel_p = (uint8_t) (frequency_channels[m_channel_selector]);

}



/*****************************************************************************
*                                                                            *
*  Global function : freq_setchannel                                         *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void freq_setchannel(change_t type)
{


   switch (type) {
      case change_inc_step:
         m_channel_selector++;
         break;
      case change_dec_step:
         m_channel_selector--;
         break;
   }


   if (m_channel_selector >= (FREQ_N_CHANNELS - 1)) {
      m_channel_selector = (FREQ_N_CHANNELS - 1);
   }

   if (m_channel_selector <= 0) {
      m_channel_selector = 0;
   }



}



/*****************************************************************************
*                                                                            *
*  Global function : freq_sethoppingmode                                     *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void freq_sethoppingmode(change_t type)
{


   switch (type) {
      case change_inc_step:
         m_hoppingmode_selector++;
         break;
      case change_dec_step:
         m_hoppingmode_selector--;
         break;
   }

   if (m_hoppingmode_selector >= (FREQ_N_HOPMODES - 1)) {
      m_hoppingmode_selector = (FREQ_N_HOPMODES - 1);
   }

   if (m_hoppingmode_selector <= 0) {
      m_hoppingmode_selector = 0;
   }

}


/*****************************************************************************
*                                                                            *
*  Global function : freq_gethoppingmode                                     *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void freq_gethoppingmode(char *hop_p)
{

   *hop_p = (char)(frequency_hoppingmodes[m_hoppingmode_selector]);
   return;
}
