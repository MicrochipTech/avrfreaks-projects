#ifndef _MENU_CFG_H_
#define _MENU_CFG_H_
/*H***************************************************************************
 *
 * $RCSfile: menu_cfg.h,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: Wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-15 23:00:58+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: menu_cfg.h,v $
 *      Revision 1.0  2003-11-15 23:00:58+01  mika
 *      Initial revision
 *
 *      Revision 1.0  2003-11-12 20:54:16+01  mika
 *      Initial revision
 *
 *
 ****************************************************************************/
#include <inttypes.h>


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   T Y P E S                                               *
*                                                                            *
*****************************************************************************/
#define MAX_CHARS_IN_MENU ((uint8_t)(50))

typedef enum {
	head,
	body,
	tail
} list_descr_t;


typedef struct menu_tag {

list_descr_t		list_part;
const struct menu_tag		*parent_p;
const struct menu_tag		*child_p;
char				menu_string[MAX_CHARS_IN_MENU];
uint8_t				*submenu_entry_p;
void				(*action_handler_p)();

} menu_t;


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   C O N S T A N T S                                       *
*                                                                            *
*****************************************************************************/
#define LEVEL1_MENUS    ((uint8_t)(2))
#define LEVEL2A_MENUS   ((uint8_t)(2))
#define LEVEL2B_MENUS   ((uint8_t)(2))

extern const menu_t level2a[LEVEL2A_MENUS];
extern const menu_t level2b[LEVEL2B_MENUS];
extern const menu_t level1[LEVEL1_MENUS];


/*****************************************************************************
*                                                                            *
*  E X P O R T E D  M E T H O D S                                            *
*                                                                            *
*****************************************************************************/

#endif
