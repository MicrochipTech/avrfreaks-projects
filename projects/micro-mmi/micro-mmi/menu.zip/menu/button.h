#ifndef _BUTTON_H_
#define _BUTTON_H_
/*H***************************************************************************
 *
 * $RCSfile: button.h,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: Wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-16 14:46:53+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: button.h,v $
 *      Revision 1.0  2003-11-16 14:46:53+01  mika
 *      Initial revision
 *
 *
 *
 ****************************************************************************/


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   C O N S T A N T S                                       *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   T Y P E S                                               *
*                                                                            *
*****************************************************************************/
typedef enum
{
   button_hold_down,
   button_pressed,
   button_no_action
} button_action_t;


typedef enum
{
   button_up,
   button_down,
   button_left,
   button_right,
   button_enter,
   button_back,
   button_no_press
} button_t;


typedef struct button_evt_tag
{
   button_action_t button_action;
   button_t button;
} button_evt_t;


/*****************************************************************************
*                                                                            *
*  E X P O R T E D  M E T H O D S                                            *
*                                                                            *
*****************************************************************************/
void tButton(void);
void Button_get(button_evt_t * button_event);

#endif
