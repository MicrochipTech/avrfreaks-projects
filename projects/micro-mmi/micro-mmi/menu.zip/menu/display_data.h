#ifndef _DISPLAY_DATA_H_
#define _DISPLAY_DATA_H_
/*H***************************************************************************
 *
 * $RCSfile: display_data.h,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: Wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-16 16:27:11+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: display_data.h,v $
 *      Revision 1.0  2003-11-16 16:27:11+01  mika
 *      Initial revision
 *
 *
 ****************************************************************************/
#include <inttypes.h>


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   C O N S T A N T S                                       *
*                                                                            *
*****************************************************************************/
#define DISPLAY_DATA_N_BYTES ((uint8_t)(32))


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   T Y P E S                                               *
*                                                                            *
*****************************************************************************/
typedef enum
{
   menu,
   error_handler,
   info,
   display
} display_info_provider_t;


/*****************************************************************************
*                                                                            *
*  E X P O R T E D  M E T H O D S                                            *
*                                                                            *
*****************************************************************************/
void DisplayData_reserve_resouces(display_info_provider_t provider, char **buf_pp);
void DisplayData_release_resource(void);

#endif
