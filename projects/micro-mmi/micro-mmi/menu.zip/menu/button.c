/*H***************************************************************************
 *
 * $RCSfile: button.c,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-16 14:46:28+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: button.c,v $
 *      Revision 1.0  2003-11-16 14:46:28+01  mika
 *      Initial revision
 *
 *
 *
 ****************************************************************************/
#include "button.h"
#include <inttypes.h>
#include <avr/io.h>


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/
typedef enum
{
   button_state_idle,
   button_state_pre_push_down,
   button_state_hold_down
} button_state_t;


/*****************************************************************************
*                                                                            *
*  P R I V A T E   C O N S T A N T S                                         *
*                                                                            *
*****************************************************************************/
#define BUTTON_HOLD_DOWN_TRSH     ((uint8_t)(150))
#define BUTTON_PRESSED_TRSH       ((uint8_t)(2))

#define BUTTON_PORT       (PINB)
#define BUTTON_PORT_IDLE  (0xFF)
#define BUTTON_UP         (0x7F)
#define BUTTON_DOWN       (0xBF)
#define BUTTON_RIGHT      (0xDF)
#define BUTTON_LEFT       (0xEF)
#define BUTTON_ENTER      (0xF7)
#define BUTTON_BACK       (0xFB)


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static button_t m_button = button_no_press;
static button_action_t m_button_action = button_no_action;
static button_state_t m_button_state = button_state_idle;
static uint8_t m_button_last_val = BUTTON_PORT_IDLE;
static uint8_t m_button_cnt = 0;


/*****************************************************************************
*                                                                            *
*  Global function : tButton                                                 *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : The button object interpretates a digital input and     *
*                    creates a button_event. A button_event consists of one  *
*                    button-action and one button-selection information,     *
*                    button-action might be pressed and button-selection     *
*                    might be up or enter.                                   *
*                                                                            *
*                    Button task shall be executed with 100 hz.              *
*                                                                            *
*****************************************************************************/
void tButton(void)
{

   /* Read in-port to get the button-port raw data. */
   uint8_t button_val = inb(BUTTON_PORT);


   /* To save cpu resources, execution shall be minimized when no the user
      does not interact with the button-port.

      The button object can be in one of the following states
      button_state_idle, button_state_pre_push_down and button_state_hold_down.
      The functionality is quit simple, the button-port is normally in 
      BUTTON_PORT_IDLE, e.g. no buttons are pressed. When the user presses a
      button AND the combination is legal, the state is changed to 
      button_state_pre_push_down. If the button is released or the user keeps
      holding the button down for BUTTON_HOLD_DOWN_TRSH, the button object
      will set an button-event. 

      Transitions are marked <# TRANSITION - [new state] #> */


   /* Handle no change on the button-port. Normally the button state will be
      button_state_idle resulting in a return. If button state is in 
      button_state_pre_push_down and has been for a certain amount of time 
      the button-event will be set and the state will change to
      button_state_hold_down. */
   if (m_button_last_val == button_val) {
      if (m_button_state == button_state_pre_push_down) {
         if (m_button_cnt > BUTTON_HOLD_DOWN_TRSH) {

            /* <# TRANSITION - [button_state_hold_down] #> */
            m_button_state = button_state_hold_down;
            m_button_action = button_hold_down;
         }
         else {
            m_button_cnt++;
         }
      }
      return;                   /* < ########## RETURN ########## > */
   }


   /* Below this point the button-port has changed it's value from the last
      execution. */
   switch (m_button_state) {

      /* In button_state_idle, the state will change to 
         button_state_pre_push_down if the new button-port value is valid, 
         handled it the switch( button_val ). */
      case button_state_idle:
         if (button_val != BUTTON_PORT_IDLE) {

            /* <# TRANSITION - [button_state_pre_push_down] #> */
            m_button_state = button_state_pre_push_down;
            switch (button_val) {
               case BUTTON_UP:
                  m_button = button_up;
                  break;
               case BUTTON_DOWN:
                  m_button = button_down;
                  break;
               case BUTTON_RIGHT:
                  m_button = button_right;
                  break;
               case BUTTON_LEFT:
                  m_button = button_left;
                  break;
               case BUTTON_ENTER:
                  m_button = button_enter;
                  break;
               case BUTTON_BACK:
                  m_button = button_back;
                  break;
               default:
                  /* If the button selection is not legal the state will be
                     reset to it's original state. E.g this is not a state
                     transition. */
                  m_button_state = button_state_idle;
                  break;
            }
         }
         break;

      /* In button_state_pre_push_down the button_event is set if the new
         button-port is BUTTON_PORT_IDLE and the last button selection was
         active for some time(BUTTON_PRESSED_TRSH). E.g. the user has
         pressed a valid button selection for some time and then released it. 

         Please note the difference in button-event for hold-down and pressed.
         A pressed event is set until another object reads the information or
         if a new event occurs. The hold-down event is only valid as long as
         the user interacts with the button object. */
      case button_state_pre_push_down:
         if ((button_val == BUTTON_PORT_IDLE) && (m_button_cnt > BUTTON_PRESSED_TRSH)) {
            switch (m_button_last_val) {
               case BUTTON_UP:
               case BUTTON_DOWN:
               case BUTTON_RIGHT:
               case BUTTON_LEFT:
               case BUTTON_ENTER:
               case BUTTON_BACK:
                  m_button_action = button_pressed;
                  break;
               default:
                  /* panic(); */
                  break;
            }
         }
         m_button_state = button_state_idle;
         break;

      /* The event hold down is cleared whenever the user changes the button 
         selection, see comment above. */
      case button_state_hold_down:
         m_button_state = button_state_idle;
         m_button_action = button_no_action;
         break;

      default:
         /* panic(); */
         break;
   }

   /* Always clear the time measurement when the button selectiom is changed by
      the user. */
   m_button_cnt = 0;

   /* Remember this button-port in the next execution. */
   m_button_last_val = button_val;
}




/*****************************************************************************
*                                                                            *
*  Global function : Button_get                                              *
*                                                                            *
*  Argument        : button_event - the current button event.                *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Returns the currect button event. Please note that      *
*                    event with action pressed causes the member data to be  *
*                    cleared.                                                *
*                                                                            *
*****************************************************************************/
void Button_get(button_evt_t * button_event)
{

   /* Always set the button action. */
   button_event->button_action = m_button_action;

   /* Set the button selection. Always set button selection to no_press if
      button action is no-action. */
   if (m_button_action == button_no_action) {
      button_event->button = button_no_press;
   }
   else {
      button_event->button = m_button;
   }


   /* Clear button event member data if button action is pressed. */
   if (m_button_action == button_pressed) {
      m_button = button_no_press;
      m_button_action = button_no_action;
   }

}
