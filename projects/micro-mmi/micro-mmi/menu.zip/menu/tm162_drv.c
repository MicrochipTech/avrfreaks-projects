/*H***************************************************************************
 *
 * $RCSfile: tm162_drv.c,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-16 16:10:56+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: tm162_drv.c,v $
 *      Revision 1.0  2003-11-16 16:10:56+01  mika
 *      Initial revision
 *
 *
 ****************************************************************************/
#include "tm162_drv.h"
#include <avr/io.h>


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   C O N S T A N T S                                         *
*                                                                            *
*****************************************************************************/
#define CLEAR_DISPLAY_CMD              (0x01)
#define RETURN_HOME_CMD                (0x02)
#define ENTRY_MODE_CMD                 (0x04)
#define DISPLAY_ON_OFF_CONTROL_CMD     (0x08)
#define CURSOR_OR_DISPLAY_SHIFT_CMD    (0x10)
#define FUNCTION_SET_CMD               (0x20)
#define SET_CGRAM_ADDRESS_COUNTER_CMD  (0x40)
#define SET_DDRAM_ADDRESS_COUNTER_CMD  (0x80)

#define DB_WRITE    (PORTA)
#define DB_READ     (PINA)
#define DB_DIR      (DDRA)
#define DB_OUTPUT   (0xFF)
#define DB_INPUT    (0x00)

/* Control port, E, R/W and RS. */
#define CTRL        (PORTD)
/* Enable; Bit set->enable read and write. */
#define E           (PD0)
/* Read/write; Bit set->write; Bit clear->read. */
#define R_W         (PD1)
/* Register select; Bit set->data; Bit clear->Instruction. */
#define RS          (PD2)

const uint8_t pos_ac[] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
   0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
   0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
   0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F
};
const uint8_t line_two_start_address = 0x40;
const uint8_t line_two_posistion = 0x0F;



/*****************************************************************************
*                                                                            *
*  Global function : tm162_clear_display                                     *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Write 20H to DDRAM and set DDRAM address to 00H         *
*                    from AC. Execution time is minimum 1.53ms.              *
*                                                                            *
*                                                                            *
*****************************************************************************/
void tm162_clear_display(void)
{

   /* Set instruction mode, clear RS bit in control part of display
      interface. */
   cbi(CTRL, RS);

   /* Set write mode, clear RW bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output clear display command to DB0-DB7. */
   outb(DB_WRITE, CLEAR_DISPLAY_CMD);

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);


   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);


}


/*****************************************************************************
*                                                                            *
*  Global function : tm162_return_home                                       *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Set DDRAM address to 00H from AC and return cursor to   *
*                    its Original position if shifted.                       *
*                                                                            *
*                    The contents of DDRAM are not changed. Execution time   *
*                    is minimum 1.53ms.                                      *
*                                                                            *
*****************************************************************************/
void tm162_return_home(void)
{

   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output return home command to DB0-DB7. */
   outb(DB_WRITE, RETURN_HOME_CMD);

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);


}


/*****************************************************************************
*                                                                            *
*  Global function : tm162_entry_mode_set                                    *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Assign cursor moving direction and enable the shift of  *
*                    entire display. Minimum execution time is 39us          *
*                                                                            *
*****************************************************************************/
void tm162_entry_mode_set(display_dir_t i_d, on_off_t sh)
{

   uint8_t setting = 0;

   switch (i_d) {
      case right_direction:
         setting = 0x02;
         break;

      case left_direction:
         setting = 0x00;
         break;

      default:
         /* panic(); */
         break;
   }

   if (sh == on) {
      setting |= 0x01;
   }


   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output mode set command plus mode setting bits to DB0-DB7. */
   outb(DB_WRITE, (ENTRY_MODE_CMD | setting));

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);


}



/*****************************************************************************
*                                                                            *
*  Global function : tm162_display_on_off_control                            *
*                                                                            *
*  Argument        : Se description.                                         *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Set display(D), cursor(C), and blinking of cursor(B)    *
*                    on/off control bit. Minimum execution time is 39us.     *
*                                                                            *
*****************************************************************************/
void tm162_display_on_off_control(on_off_t d, on_off_t c, on_off_t b)
{

   uint8_t setting = 0;

   if (d == on) {
      setting = 0x04;
   }

   if (c == on) {
      setting |= 0x02;
   }

   if (b == on) {
      setting |= 0x01;
   }


   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output display on/off command to DB0-DB7. */
   outb(DB_WRITE, (DISPLAY_ON_OFF_CONTROL_CMD | setting));

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);


}



/*****************************************************************************
*                                                                            *
*  Global function : tm162_cursor_or_display_shift                           *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Set cursor moving and display shift control bit, and    *
*                    the direction, without changing of DDRAM data. Minimum  *
*                    execution time is 39us.                                 *
*                                                                            *
*                    Shift patterns according to S/C and bits                *
*                                                                            *
*              S/C R/L Operation                                             *
*              0   0   Shift cursor to the left, AC is decreased by 1        *
*              0   1   Shift cursor to the right, AC is increased by 1       *
*              1   0   Shift all the display to the left, cursor moves       *
*                      according to the display.                             *
*              1   1   Shift all the display to the right, cursor moves      *
*                      according to the display.                             *
*****************************************************************************/
void tm162_cursor_or_display_shift(display_shift_t s_c, display_dir_t r_l)
{

   uint8_t setting = 0;

   switch (s_c) {
      case shift_display:
         setting = 0x08;
         break;

      case shift_cursor:
         setting = 0x00;
         break;

      default:
         /* panic(); */
         break;
   }

   switch (r_l) {
      case right_direction:
         setting |= 0x04;
         break;

      case left_direction:
         /* OK to be here, bit cleared in s_c setting. */
         break;

      default:
         /* panic(); */
         break;
   }


   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output CoDs command plus setting to DB0-DB7. */
   outb(DB_WRITE, (CURSOR_OR_DISPLAY_SHIFT_CMD | setting));

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);


}



/*****************************************************************************
*                                                                            *
*  Global function : tm162_function_set                                      *
*                                                                            *
*  Argument        : See description.                                        *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Set interface data length (DL:8-bit/4-bit), numbers of  *
*                    display line (N: 2-line/1-line) and, display font type  *
*                    (F: 5x11dots/5x8dots). Minimum execution time is 39us.  *
*                                                                            *
*                                                                            *
*****************************************************************************/
void tm162_function_set(display_interface_t dl, display_line_mode_t n, display_format_t f)
{

   uint8_t setting = 0;

   switch (dl) {
      case eight_bit_interface:
         setting = 0x10;
         break;

      case four_bit_interface:
         setting = 0x00;
         break;

      default:
         /* panic(); */
         break;
   }

   switch (n) {
      case two_line_mode:
         setting |= 0x08;
         break;

      case one_line_mode:
         /* OK to be here, bit cleared in s_c setting. */
         break;

      default:
         /* panic(); */
         break;
   }

   switch (f) {
      case five_x_eleven_dot:
         setting |= 0x04;
         break;

      case five_x_eight_dot:
         /* OK to be here, bit cleared in dl setting. */
         break;

      default:
         /* panic(); */
         break;
   }


   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output function set command plus settings to DB0-DB7. */
   outb(DB_WRITE, (FUNCTION_SET_CMD | setting));

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);


   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);

}


/*****************************************************************************
*                                                                            *
*  Global function : tm162_set_cgram_address                                 *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Set CGRAM address in address Counter. Minimum execution *
*                    time is 39us.                                           *
*                                                                            *
*****************************************************************************/
void tm162_set_cgram_address(uint8_t ac)
{


   if (ac > 0x3F) {
      /* panic(); */
      ac &= 0x3F;
   }

   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output cgram address plus command to DB0-DB7. */
   outb(DB_WRITE, (SET_CGRAM_ADDRESS_COUNTER_CMD | ac));

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);

}



/*****************************************************************************
*                                                                            *
*  Global function : tm162_set_ddram_address                                 *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Set DDRAM address in address Counter. Minimum execution *
*                    time is 39us.                                           *
*                                                                            *
*                                                                            *
*****************************************************************************/
void tm162_set_ddram_address(uint8_t ac)
{


   if (ac > 0x7F) {
      /* panic(); */
      ac &= 0x7F;
   }

   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output set ddram address plus command to DB0-DB7. */
   outb(DB_WRITE, (SET_DDRAM_ADDRESS_COUNTER_CMD | ac));

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);
}



/*****************************************************************************
*                                                                            *
*  Global function : tm162_read_busy_flag_and_address                        *
*                                                                            *
*  Argument        : See description.                                        *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Whether during internal operation or not can be known   *
*                    by reading BF. The contents of address counter can also * 
*                    be read.                                                *
*                                                                            *
*****************************************************************************/
void tm162_read_busy_flag_and_address(uint8_t * ac, boolean_t * bf)
{

   uint8_t reg;

   /* Set RS bit in control part of display interface. */
   cbi(CTRL, RS);

   /* Set read mode bit in control part of display interface and set 
      DB0-DB7 to input. */
   outb(DB_DIR, DB_INPUT);
   sbi(CTRL, R_W);

   /* tSU = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tD = 120 ns. */
   asm volatile ("nop\n\t" "nop\n\t"::);

   /* Read valid data from DB0-DB7. */
   reg = inb(DB_READ);

   /* tW - tD = 230ns - 120 ns = 110ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* Validate result from diplay and set agruments. */
   *ac = (reg & 0x7F);
   if ((reg & 0x80)) {
      *bf = TRUE;
   }
   else {
      *bf = FALSE;
   }
}



/*****************************************************************************
*                                                                            *
*  Global function : tm162_write_data_to_ram                                 *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Write data into internal RAM. Minimum execution time is *
*                    43us.                                                   *
*                                                                            *
*****************************************************************************/
void tm162_write_data_to_ram(uint8_t d)
{


   /* Set RS bit in control part of display interface. */
   sbi(CTRL, RS);

   /* Set write mode bit in control part of display interface and set 
      DB0-DB7 t output. */
   cbi(CTRL, R_W);
   outb(DB_DIR, DB_OUTPUT);

   /* tSU1 = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tW - tSU2 = 230 ns - 80ns = 150ns. */
   asm volatile ("nop"::);

   /* Output data to write to DB0-DB7. */
   outb(DB_WRITE, d);

   /* tSU2 = 80ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* tH2 = 10ns. */
   asm volatile ("nop"::);

}


/*****************************************************************************
*                                                                            *
*  Global function : tm162_read_data_from_ram                                *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Read from internal RAM. Minimum execution time is       *
*                    43us.                                                   *
*                                                                            *
*****************************************************************************/
void tm162_read_data_from_ram(uint8_t * d)
{

   uint8_t reg;

   /* Set RS bit in control part of display interface. */
   sbi(CTRL, RS);

   /* Set read mode bit in control part of display interface and set 
      DB0-DB7 to input. */
   outb(DB_DIR, DB_INPUT);
   sbi(CTRL, R_W);

   /* tSU = 40 ns */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface high. */
   sbi(CTRL, E);

   /* tD = 120 ns. */
   asm volatile ("nop\n\t" "nop\n\t"::);

   /* Read valid data from DB0-DB7. */
   reg = inb(DB_READ);

   /* tW - tD = 230ns - 120 ns = 110ns. */
   asm volatile ("nop"::);

   /* Set E bit in control part of display interface low again. */
   cbi(CTRL, E);

   /* Set agrument. */
   *d = reg;

}
