/*H***************************************************************************
 *
 * $RCSfile: menu_ah_freq.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 20:21:27+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: menu_ah_freq.c,v $
 * Revision 1.0  2003-11-16 20:21:27+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include "menu_ah_freq.h"
#include "freq.h"
#include "avr_stdio.h"
#include "display_data.h"


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  Global function : menu_ah_set_freq                                        *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void menu_ah_set_freq(const button_evt_t * env_p)
{

   change_t step;
   uint8_t channel;
   char *buf_p = 0;

   if (env_p->button_action == button_pressed) {

      switch (env_p->button) {

         case button_up:
            step = change_inc_step;
            freq_setchannel(step);
            break;

         case button_down:
            step = change_dec_step;
            freq_setchannel(step);
            break;

         default:
            /* Ok to be here. */
            break;

      } /*lint !e788 */
   } 

   freq_getchannel(&channel);

   DisplayData_reserve_resouces(menu, &buf_p);
   (void)avr_sprintf(buf_p, "Set frequency channel %i", (int)channel);
   DisplayData_release_resource();


}




/*****************************************************************************
*                                                                            *
*  Global function : menu_ah_freq_hopp                                       *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void menu_ah_freq_hopp(const button_evt_t * env_p)
{
   change_t step;
   char hop;
   char *buf_p = 0;


   if (env_p->button_action == button_pressed) {
      switch (env_p->button) {

         case button_up:
            step = change_inc_step;
            freq_sethoppingmode(step);
            break;

         case button_down:
            step = change_dec_step;
            freq_sethoppingmode(step);
            break;

         default:
            /* Ok to be here. */
            break;

      } /*lint !e788 */
   } 

   freq_gethoppingmode(&hop);

   DisplayData_reserve_resouces(menu, &buf_p);
   (void)avr_sprintf(buf_p, "Set frequency channel %c", hop);
   DisplayData_release_resource();
}
