#ifndef _LANG_H_
#define _LANG_H_
/*H***************************************************************************
 *
 * $RCSfile: lang.h,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: Wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-20 20:49:53+01 $
 * $Revision: 1.1 $
 *----------------------------------------------------------------------------
 *      $Log: lang.h,v $
 *      Revision 1.1  2003-11-20 20:49:53+01  mika
 *      Changed comments.
 *
 *
 ****************************************************************************/
#include <inttypes.h>
#include "config.h"


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   C O N S T A N T S                                       *
*                                                                            *
*****************************************************************************/
#define LANG_N_CHARSINLANG ((uint8_t)(10))


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   T Y P E S                                               *
*                                                                            *
*****************************************************************************/
typedef enum
{
   lang_enum_head,
   english,
   svenska,
   deutsch,
   lang_enum_tail
} lang_id_t;


/*****************************************************************************
*                                                                            *
*  E X P O R T E D  M E T H O D S                                            *
*                                                                            *
*****************************************************************************/
void lang_get_language_id(lang_id_t * lang_p);
void lang_set_language(change_t type);
void lang_set_default_language(void);
void lang_get_language_string(char *str_p);

#endif
