/*H***************************************************************************
 *
 * $RCSfile: hw_mega16.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 17:23:30+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: hw_mega16.c,v $
 * Revision 1.0  2003-11-16 17:23:30+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#include "hw.h"


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/
static void set_porta(void);
static void set_portb(void);
static void set_portc(void);
static void set_portd(void);


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  Global function : HW_init                                                 *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void HW_init(void)
{

   set_porta();
   set_portb();
   set_portc();
   set_portd();

}




/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/

/*****************************************************************************
*                                                                            *
*  Private function : set_porta                                              *
*                                                                            *
*  Argument         : none                                                   * 
*                                                                            *
*  Return           : none                                                   *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
static void set_porta(void)
{
   outp(0x00, DDRA);
   outp(0x00, PORTA);
}


/*****************************************************************************
*                                                                            *
*  Private function : set_portb                                              *
*                                                                            *
*  Argument         : none                                                   * 
*                                                                            *
*  Return           : none                                                   *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
static void set_portb(void)
{
   outp(0x00, DDRB);
   outp(0x00, PORTB);
}


/*****************************************************************************
*                                                                            *
*  Private function : set_portc                                              *
*                                                                            *
*  Argument         : none                                                   * 
*                                                                            *
*  Return           : none                                                   *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
static void set_portc(void)
{
   outp(0x00, DDRC);
   outp(0x00, PORTC);
}


/*****************************************************************************
*                                                                            *
*  Private function : set_portd                                              *
*                                                                            *
*  Argument         : none                                                   * 
*                                                                            *
*  Return           : none                                                   *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
static void set_portd(void)
{
   outp(0xFF, DDRD);
   outp(0x00, PORTD);
}
