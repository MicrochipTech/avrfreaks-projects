/*H***************************************************************************
 *
 * $RCSfile: display.c,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-16 17:09:31+01 $
 * $Revision: 1.0 $
 *----------------------------------------------------------------------------
 *      $Log: display.c,v $
 *      Revision 1.0  2003-11-16 17:09:31+01  mika
 *      Initial revision
 *
 *
 ****************************************************************************/
#include "display.h"
#include "display_data.h"
#include "config.h"
#include "tm162_drv.h"
#include <string.h>



/*****************************************************************************
*                                                                            *
*  P R I V A T E   C O N S T A N T S                                         *
*                                                                            *
*****************************************************************************/
#define DISPLAY_N_MAX_DIFF    ((uint8_t)(6))


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static char m_data[DISPLAY_DATA_N_BYTES];



/*****************************************************************************
*                                                                            *
*  Global function : Display_init                                            *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : Initialises the tm162 hardware.                         *
*                                                                            *
*                                                                            *
*****************************************************************************/
void Display_init(void)
{

   boolean_t busy = TRUE;
   uint8_t address = 0;


   while (busy == TRUE) {
      tm162_read_busy_flag_and_address(&address, &busy);
   }
   tm162_function_set(eight_bit_interface, two_line_mode, five_x_eleven_dot);

   busy = TRUE;
   while (busy == TRUE) {
      tm162_read_busy_flag_and_address(&address, &busy);
   }
   tm162_display_on_off_control(on, off, off);

   busy = TRUE;
   while (busy == TRUE) {
      tm162_read_busy_flag_and_address(&address, &busy);
   }
   tm162_clear_display();

   busy = TRUE;
   while (busy == TRUE) {
      tm162_read_busy_flag_and_address(&address, &busy);
   }
   tm162_entry_mode_set(right_direction, off);
}


/*****************************************************************************
*                                                                            *
*  Global function : tDisplay                                                *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description     : The Display task handles the runtime behaviour of the   *
*                    Display object. To be executed at 10 hz.                *
*                                                                            *
*****************************************************************************/
void tDisplay(void)
{


   uint8_t ndiffs = 0;
   uint8_t c = 0;
   char *buf_p = 0;
   boolean_t busy = TRUE;
   uint8_t len_buf = 0;
   uint8_t len_data = 0;
   uint8_t address = 0;
   uint8_t diff_pos[DISPLAY_N_MAX_DIFF];


   DisplayData_reserve_resouces(display, &buf_p);


   /* Acquire the length of private display string and DisplayData object
      display string. */
   len_buf = (uint8_t) (strlen(buf_p));
   len_data = (uint8_t) (strlen(&m_data[0]));

   /* If the differ set number of bytes that differ to the length of
      DisplayData string. ndiffs == len_buf indicates that the entire display
      must be overwritten. */
   if (len_data != len_buf) {
      ndiffs = len_buf;
   }
   else {

      /* The length of the display string appears to be the same. Now determine
         how much that actually differs. */
      for (c = 0; c < len_buf; c++) {

         /* For each difference store the position in a array, diff_pos. */
         if (buf_p[c] != m_data[c]) {
            diff_pos[ndiffs] = c;
            ndiffs++;

            /* If we have more than DISPLAY_N_MAX_DIFF, overwrite the entire
               display. As stated before ndiffs == len_buf is an indication
               that the entire display must be overwritten. */
            if (ndiffs >= DISPLAY_N_MAX_DIFF) {
               ndiffs = len_buf;
               break;
            }
         }
      }
   }

   /* Shall the entire display be overwritten (if ndiffs equals len_buf this
      is the case). If soalways clear the display first, done here. */
   if (ndiffs == len_buf) {
      while (busy == TRUE) {
         tm162_read_busy_flag_and_address(&address, &busy);
      }
      tm162_clear_display();
   }

   /* For each difference do the following, split up in this cases, overwrite
      entire display, partial update. */
   for (c = 0; c < ndiffs; c++) {

      /* Entire display shall be overwritten. 

         The address counter is set to the start position in the
         "clear display" command. Just write the data, the address counter
         is incremented automatically, for one exception, the second row starts
         with address 40H. Set it when you get there. */
      if (ndiffs == len_buf) {
         /* Find the first position on the second row. Set the address counter
            to 40H. */
         if (c == (line_two_posistion + 1)) {
            busy = TRUE;
            while (busy == TRUE) {
               tm162_read_busy_flag_and_address(&address, &busy);
            }
            tm162_set_ddram_address((uint8_t) (line_two_start_address));
         }

         /* Write display string to tm162. */
         busy = TRUE;
         while (busy == TRUE) {
            tm162_read_busy_flag_and_address(&address, &busy);
         }
         tm162_write_data_to_ram((uint8_t) (buf_p[c]));
      }
      else {

         /* Partial update only. 

            Both address and data must be set for each write. The address
            position might not be in a precedence order. */
         busy = TRUE;
         while (busy == TRUE) {
            tm162_read_busy_flag_and_address(&address, &busy);
         }
         tm162_set_ddram_address((uint8_t) (pos_ac[diff_pos[c]]));      /*lint !e644 */
         busy = TRUE;
         while (busy == TRUE) {
            tm162_read_busy_flag_and_address(&address, &busy);
         }
         tm162_write_data_to_ram((uint8_t) (buf_p[diff_pos[c]]));       /*lint !e644 */
      }
   }

   /* This is the case when something has been updated on the display. Copy the
      data in DisplayData object. */
   if (ndiffs != 0) {
      (void)strcpy(&m_data[0], buf_p);
   }

   DisplayData_release_resource();


}
