/*H***************************************************************************
 *
 * $RCSfile: menu_ah_lang.c,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-16 20:21:27+01 $
 *    $Revision: 1.0 $
 *----------------------------------------------------------------------------
 * $Log: menu_ah_lang.c,v $
 * Revision 1.0  2003-11-16 20:21:27+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include "menu_ah_lang.h"
#include "lang.h"
#include "display_data.h"
#include <string.h>
#include "avr_stdio.h"

/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/
typedef enum
{
   lang_question,
   lang_executed
} lang_state_t;


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
static lang_state_t lang_state = lang_question;



/*****************************************************************************
*                                                                            *
*  Global function : menu_ah_set_lang                                        *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void menu_ah_set_lang(const button_evt_t * env)
{

   change_t step;
   char str[LANG_N_CHARSINLANG];
   char *buf = 0;

   if (env->button_action == button_pressed) {

      switch (env->button) {

         case button_up:
            step = change_inc_step;
            lang_set_language(step);
            break;

         case button_down:
            step = change_dec_step;
            lang_set_language(step);
            break;

         default:
            /* Ok to be here. */
            break;

      } /*lint !e788 */
   }


   lang_get_language_string(&str[0]);

   DisplayData_reserve_resouces(menu, &buf);
   (void)avr_sprintf(buf, "Change language to %s", &str[0]);
   DisplayData_release_resource();

}




/*****************************************************************************
*                                                                            *
*  Global function : menu_ah_lang_default                                    *
*                                                                            *
*  Argument        : none                                                    *
*                                                                            *
*  Return          : none                                                    *
*                                                                            *
*  Description :                                                             *
*                                                                            *
*                                                                            *
*****************************************************************************/
void menu_ah_lang_default(const button_evt_t * env)
{
   char *buf = 0;

   DisplayData_reserve_resouces(menu, &buf);

   if (lang_state == lang_question) {

      if (env->button_action == button_pressed) {

         strcpy(buf, "Set default language ?");
         switch (env->button) {

            case button_enter:
               lang_set_default_language();
               lang_state = lang_executed;
               break;

            default:
               break;

         } /*lint !e788 */
      }
   }
   else {

      if (env->button_action == button_pressed) {
         strcpy(buf, "Done.");
         switch (env->button) {
            case button_back:
               lang_state = lang_question;
               break;
            default:
               /* OK to be here. */
               break;
         } /*lint !e788 */
      } 
   }

   DisplayData_release_resource();

}
