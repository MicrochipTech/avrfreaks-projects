/*H***************************************************************************
 *
 * $RCSfile: menu_cfg.c,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-20 20:48:38+01 $
 * $Revision: 1.1 $
 *----------------------------------------------------------------------------
 *      $Log: menu_cfg.c,v $
 *      Revision 1.1  2003-11-20 20:48:38+01  mika
 *      Added comments. Possible problem found, how is a menu group with only one entry handled by head, body and tail?
 *
 *
 *
 ****************************************************************************/
#include "menu_cfg.h"
#include "menu_ah_freq.h"
#include "menu_ah_lang.h"
#include <stddef.h>


/*****************************************************************************
*                                                                            *
*  P R I V A T E   M E T H O D S                                             *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   T Y P E S                                                 *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  P R I V A T E   D A T A                                                   *
*                                                                            *
*****************************************************************************/
uint8_t level1_entry[LEVEL1_MENUS];
uint8_t level2a_entry[LEVEL2A_MENUS];
uint8_t level2b_entry[LEVEL2B_MENUS];


/* The idea of the menu system is basically a tree structure. Each menu can
   have a group of submenus. All menus end up in a menu action handler.
   One action handler can of course serve several menus.
   
   The menu system it self contains no application data. All application
   data interactions are handled through the menu action handlers. For
   example when we would like to change data in a specific object through
   the menu system, the action handler will ask the object what the data is 
   currently, present it, and wait for the used to change it. The menu system
   will then ask the object if the change is valid and if so present it.
   
   When designing menus, try to group the menus in data interactions; what
   object shall be interfaced in this menu. Then try to create the action
   handlers. Next create the menu navigation, e.g. create the menu 
   navigation above the menu action handler up to the top level. 
   
   The type definition for a menu entry is found in menu_cfg.h
   
   const menu_t level2a[LEVEL2A_MENUS] = {
   {
    head,
    &level1[0],
    NULL,
    "Set language",
    NULL,
    menu_ah_set_lang },
   
   Entry            Description
   ============================================================================
   head             This is a body descriptor for the menu system. Each menu
                    menu group must have a descriptor indicating the beginning
                    and the end of the group. This is used to parse the menu.
                    
   &level1[0]       This is a pointer to the menu group in the level above;
                    to the parent menu group, e.g. this is where we came from
                    once.
                    
   NULL             This the pointer to the menu group below this menu; if the
                    user press enter, this is the menu group we shall go to.
                    In this case there is no sublevel menu to go to, instead
                    an action handler is stated.
                    
   "Set language"   This is the menu string to be printed on the display.
   
   NULL             This is the preferred sub menu entry. The position in a
                    sublevel menu is stored to this pointer when we leave
                    a sublevel menu. This way the user will enter then same
                    menu in the sublevel he/she left the last time. In this
                    case when we do not have a sublevel menu this pointer is
                    set to NULL.
                    
   menu_ah_set_lang This is the function pointer to the action handler.
   
   
   */

const menu_t level2a[LEVEL2A_MENUS] = {
   {
    head,
    &level1[0],
    NULL,
    "Set language",
    NULL,
    menu_ah_set_lang},
   {
    tail,
    &level1[0],
    NULL,
    "Set default language",
    NULL,
    menu_ah_lang_default}
};


const menu_t level2b[LEVEL2B_MENUS] = {
   {
    head,
    &level1[1],
    NULL,
    "Set frequency",
    NULL,
    menu_ah_set_freq},
   {
    tail,
    &level1[1],
    NULL,
    "Set hopping frequency",
    NULL,
    menu_ah_freq_hopp}
};


const menu_t level1[LEVEL1_MENUS] = {
   {
    head,
    NULL,
    &level2a[0],
    "Language settings",
    &level1_entry[0],
    NULL},
   {
    tail,
    NULL,
    &level2b[0],
    "Channel settings",
    &level1_entry[1],
    NULL}
};
