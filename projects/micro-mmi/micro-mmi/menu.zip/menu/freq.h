#ifndef _FREQ_H_
#define _FREQ_H_
/*H***************************************************************************
 *
 * $RCSfile: freq.h,v $
 * 
 *  Description: Menu system.
 *
 *      Creator: Mikael Carlsson
 *      Project: Wireless lightcontrol
 * 
 *      $Author: mika $
 *        $Date: 2003-11-20 20:49:32+01 $
 *    $Revision: 1.1 $
 *----------------------------------------------------------------------------
 * $Log: freq.h,v $
 * Revision 1.1  2003-11-20 20:49:32+01  mika
 * Added config.h include.
 *
 * Revision 1.0  2003-11-16 18:05:43+01  mika
 * Initial revision
 *
 *
 ****************************************************************************/
#include "config.h"
#include <inttypes.h>


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   C O N S T A N T S                                       *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   T Y P E S                                               *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
*                                                                            *
*  E X P O R T E D  M E T H O D S                                            *
*                                                                            *
*****************************************************************************/
void freq_getchannel(uint8_t * channel_p);
void freq_setchannel(change_t type);
void freq_gethoppingmode(char *hop_p);
void freq_sethoppingmode(change_t type);

#endif
