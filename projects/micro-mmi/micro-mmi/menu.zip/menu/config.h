#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <inttypes.h>


typedef enum 
{
  FALSE = 0,
  TRUE
} boolean_t;

typedef enum {
	on,
	off
} on_off_t;

typedef enum {
	change_inc_step,
	change_dec_step
} change_t;

#endif
