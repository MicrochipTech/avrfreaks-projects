#include <stdarg.h>


int avr_sprintf(char *buf, const char *format, ...);
