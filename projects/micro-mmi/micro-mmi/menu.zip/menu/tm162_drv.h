#ifndef _TM162_DRV_H_
#define _TM162_DRV_H_
/*H***************************************************************************
 *
 * $RCSfile: tm162_drv.h,v $
 * 
 *  Descript: Menu system.
 *
 *   Creator: Mikael Carlsson
 *   Project: Wireless lightcontrol
 * 
 *   $Author: mika $
 *     $Date: 2003-11-20 20:50:26+01 $
 * $Revision: 1.1 $
 *----------------------------------------------------------------------------
 *      $Log: tm162_drv.h,v $
 *      Revision 1.1  2003-11-20 20:50:26+01  mika
 *      Removed q.h include; not used.
 *
 *      Revision 1.0  2003-11-16 16:10:59+01  mika
 *      Initial revision
 *
 *
 ****************************************************************************/
#include "config.h"


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   C O N S T A N T S                                       *
*                                                                            *
*****************************************************************************/
extern const uint8_t pos_ac[];
extern const uint8_t line_two_start_address;
extern const uint8_t line_two_posistion;


/*****************************************************************************
*                                                                            *
*  E X P O R T E D   T Y P E S                                               *
*                                                                            *
*****************************************************************************/
typedef enum display_dir_t {
	right_direction,
	left_direction
} display_dir_t;

typedef enum {
	shift_cursor,
	shift_display
} display_shift_t;

typedef enum {
	eight_bit_interface,
	four_bit_interface
} display_interface_t;

typedef enum {
	two_line_mode,
	one_line_mode
} display_line_mode_t;
	
typedef enum {
	five_x_eight_dot,
	five_x_eleven_dot
} display_format_t;



/*****************************************************************************
*                                                                            *
*  E X P O R T E D  M E T H O D S                                            *
*                                                                            *
*****************************************************************************/
/* Clear all the display data by writing �20H� (space code) to all DDRAM
   address, and set DDRAM address to �00H� into AC(address counter). Return
   cursor to the original status, namely, bring the cursor to the left edge
   on the first line of the display. */
void tm162_clear_display( void );

/* Return home is cursor return home instruction.

   Set DDRAM address to �00H� into the address counter. Return home to its
   original site and return display to its original status, if shifted.
   Counters of DDRAM does not change. */
void tm162_return_home( void );

/* Set the moving direction of cursor and display.

   I/D: Increment / decrement of DDRAM address (cursor or blink)
   When I/D = �High�, cursor/blink moves to right and DDRAM is increased by 1.
   When I/D = �Low�, cursor/blink moves to left and DDRAM is decreased by 1.

   Note: CGRAM operates the same way as DDRAM, when reading from or writing 
         to CGRAM.
         
   SH: shift of entire display
   When DDRAM read (CGRAM read/write) operation or SH = �Low�, shifting of
   entire display is not performed.
   if SH = �High� and DDRAM write operation, shift of entire display is
   performed according to I/D value
   (I/D = �High�: shift left, I/D = �Low�: shift RIGHT). */
void tm162_entry_mode_set( display_dir_t i_d, on_off_t sh );

/* Control display /cursor/blink ON/OFF 1 bit register.

   D: display on/off control bit
   When D = �High�, entire display is turned on.
   When D = �Low�, entire display is turned off, but display data remains in
            DDRAM,

   C: cursor on/off cursor bit
   When C = �High�, cursor is turned on.
   When C = �Low�, cursor is disappeared in current display, but I/D register
            preserves its data.

   B: cursor blink on/off control bit
   When B = �High�, cursor blink is on which performs alternately between all
            the �High� data when B = �Low�, blink is off. */
void tm162_display_on_off_control( on_off_t d, on_off_t c, on_off_t b );

/* Shifting of right/left cursor position or display without writing or reading
   of display data.
   
   This instruction is used to correct or search display data.
   During 2-line mode display, cursor moves to the 2nd line after the 40th
   digit of the 1st line. Note that display shift is performed simultaneously
   in all the lines. When display data is shifted repeatedly, each line is
   shifted individually. When display shift is performed, the contents of the
   address counter are not changed.
   
   Shift patterns according to S/C and bits
   
   S/C R/L Operation
   0   0   Shift cursor to the left, AC is decreased by 1.
   0   1   Shift cursor to the right, AC is increased by 1.
   1   0   Shift all the display to the left, cursor moves according to the
           display.
   1   1   Shift all the display to the right, cursor moves according to the
           display. */
void tm162_cursor_or_display_shift( display_shift_t s_c, display_dir_t r_l );

/* DL: interface data length control bit
   When DL= �High�, it means 8-bit bus mode with MPU.
   When DL = �Low�, it means 4-bit bus mode with MPU. Hence, DL is a signal to
   select 8-bit or 4-bit bus mode. When 4-bit bus mode, it needs to transfer
   4-bit data twice.

   N: display line number control mode is set.
   When N= �Low�, 1-line display mode is set.
   When N = �High�, 2-line display mode is set.
   
   F: display font type control bit
   When F= �Low�, 5 x 8 dots format display mode is set.
   When F= �High�, 5 x 11 dots format display mode. */
void tm162_function_set( display_interface_t dl, display_line_mode_t n, display_format_t f );

/* Set CGRAM address to AC.

   This instruction makes CGRAM data available from MPU. */
void tm162_set_cgram_address( uint8_t ac );

/* Set DDRAM address to AC.

   This instruction makes DDRAM data available from MPU.
   
   When 1-line display mode (N=Low), DDRAM address is from �00H� to �27H�.
   In 2-line display mode (N=High), DDRAM address in the 1st line is from
   �00H�to �27H�, and DDRAM address in the 2nd line is from �40H� to �67H�. */
void tm162_set_ddram_address( uint8_t ac );

/* This instruction shows whether KS0066U is in internal operation or not.
   If the resultant BF is �High�, internal operation is in progress and should
   wait until BF is to be Low, which by then the next instruction can be
   performed. In this instruction you can also read the value of the address
   counter. */
void tm162_read_busy_flag_and_address( uint8_t *ac, boolean_t *bf );

/* Write binary 8-bit data to DDRAM/CGRAM.
   
   The selection of RAM from DDRAM, and CGRAM, is set by the previous address
   set instruction (DDRAM address set, CGRAM address set). RAM set instruction
   can also determine the AC direction to RAM. After write operation, the
   addressis automatically increased/ decreased by 1, according to the entry
   mode. */
void tm162_write_data_to_ram( uint8_t d );

/* Read binary 8-bit data from DDRAM/CGRAM.

   The selection of RAM is set by the previous address set instruction if the
   address set instruction of RAM is not performed before this instruction, the
   data that has been read first is invalid, as the direction of AC is not yet
   determined. If RAM data is read several times without RAM address
   instructions set before read operation, the correct RAM data can be obtained
   from the second. But the first data would be incorrect, as there is no time
   margin to transfer RAM data. In case of DDRAM read operation, cursor shift
   instruction plays the same role as DDRAM address set instruction, it also
   transfers RAM data to output data register. After read operation, address
   counter is automatically increased/ decreased by 1 according to the entry
   mode.
   
   After CGRAM read operation, display shift may not be executed correctly.

   Note: In case of RAM write operation, AC is increased/decreased by 1 as in
   read operation. At this time, AC indicates the next address position, but
   only the previous data can be read by the read instruction. */
void tm162_read_data_from_ram( uint8_t *d );

#endif



