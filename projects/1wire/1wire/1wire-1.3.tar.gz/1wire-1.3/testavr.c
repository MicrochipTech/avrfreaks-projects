/*
 * Test various AVR bits and pieces
 *
 * $Id: testavr.c,v 1.7 2004/09/01 08:16:15 darius Exp $
 *
 * Copyright (c) 2004
 *      Daniel O'Connor <darius@dons.net.au>.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "1wire.h"

#define UART_BAUD_SELECT(baudRate,xtalCpu) ((xtalCpu)/((baudRate)*16l)-1)
#define UART_BAUD_RATE      19200

void		uart_putsP(const char *addr);
void		uart_puts(const char *addr);
int		uart_putc(char c);
int		uart_getc(void);
void		uart_puts_dec(uint8_t a, uint8_t l);
void		uart_puts_hex(uint8_t a);

int
main(void) {
    uint8_t	ROM[8];
    char	cmdbuf[40];
    int8_t	i, arg;
    
    cli();

    outp(0xfc, DDRC);
    outp(0x00, PORTC);

    /* Init UART */
    outp(UART_BAUD_SELECT(UART_BAUD_RATE,XTAL_CPU), UBRR);

    /* Enable receiver and transmitter. Turn on transmit interrupts */
    outp(BV(RXEN) | BV(TXEN), UCR);

    uart_putsP(PSTR("\n\r\n\r===============\n\r"
		    "Inited!\n\r\n\r"));

    while (1) {
	uart_putsP(PSTR("> "));
	i = 0;
	while (1) {
	    cmdbuf[i] = tolower(uart_getc());
	    if (cmdbuf[i] == '\n' || cmdbuf[i] == '\r')
		break;
	    
	    /* Backspace */
	    if (cmdbuf[i] == 010) {
		if (i > 0) {
		    uart_putsP(PSTR("\010\040\010"));
		    i--;
		}
		continue;
	    }

	    /* Anything unprintable just ignore it */
	    if (!isprint(cmdbuf[i]))
		continue;
	    
	    uart_putc(cmdbuf[i]);
	    i++;
	    if (i == sizeof(cmdbuf)) {
		uart_putsP(PSTR("\n\rLine too long"));
		i = 0;
		break;
	    }
	}
	cmdbuf[i + 1] = '\0';
	uart_putsP(PSTR("\n\r"));
	if (i == 0)
	    continue;

	if (cmdbuf[0] == '?') {
	    uart_putsP(PSTR("rs               Reset and check for presence\n\r"
			    "sr               Search the bus for ROMs\n\r"
			    "re               Read a bit\n\r"
			    "rb               Read a byte\n\r"
			    "wr bit           Write a bit\n\r"
			    "wb byte          Write a byte (hex)\n\r"
			    "wc cmd [ROMID]   Write command\n\r"
			    "te ROMID         Read the temperature from a DS1820\n\r"));
	    
	    continue;
	}
	
	if (i < 2)
	    goto badcmd;
	
	if (cmdbuf[0] == 'r' && cmdbuf[1] == 's') {
	    uart_putsP(PSTR("Resetting... "));
	    
	    if (OWTouchReset() == 1)
		uart_putsP(PSTR("No presense pulse found\n\r"));
	    else
		uart_putsP(PSTR("Presense pulse found\n\r"));
	} else if (cmdbuf[0] == 'r' && cmdbuf[1] == 'e') {
	    if (OWReadBit())
		uart_putsP(PSTR("Read a 1\n\r"));
	    else
		uart_putsP(PSTR("Read a 0\n\r"));
	} else if (cmdbuf[0] == 'r' && cmdbuf[1] == 'b') {
	    uart_putsP(PSTR("Read a 0x"));
	    uart_puts_hex(OWReadByte());
	    uart_putsP(PSTR("\n\r"));
	} else if (cmdbuf[0] == 'w' && cmdbuf[1] == 'r') {
	    arg = strtol(cmdbuf + 3, (char **)NULL, 10);
	    OWWriteBit(arg);
	    uart_putsP(PSTR("Wrote a "));
	    if (arg)
		uart_putsP(PSTR("1\n\r"));
	    else
		uart_putsP(PSTR("0\n\r"));
	} else if (cmdbuf[0] == 'w' && cmdbuf[1] == 'b') {
	    arg = (int)strtol(cmdbuf + 3, (char **)NULL, 16); 
	    OWWriteByte(arg);
	} else if (cmdbuf[0] == 'w' && cmdbuf[1] == 'c') {
	    i = strlen(cmdbuf);
	    if (i < 5) {
		uart_putsP(PSTR("No arguments\n\r"));
		continue;
	    }
	    
	    arg = (int)strtol(cmdbuf + 3, (char **)NULL, 16);
	    if (arg == 0) {
		uart_putsP(PSTR("Unparseable command\n\r"));
		continue;
	    }

	    if (i == 5) {
		OWSendCmd(NULL, arg);
		continue;
	    }
	    
	    if (i < 29) {
		uart_putsP(PSTR("Can't parse ROM ID\n\r"));
		continue;
	    }
	    for (i = 0; i < 8; i++)
		ROM[i] = (int)strtol(cmdbuf + 6 + (3 * i), (char **)NULL, 16);

	    OWSendCmd(ROM, arg);
	} else if (cmdbuf[0] == 't' && cmdbuf[1] == 'e') {
	    uint8_t	crc, buf[9];;
	    int8_t	temp;
	    uint16_t	tfrac;
	    
	    if (strlen(cmdbuf) < 26) {
		uart_putsP(PSTR("Unable to parse ROM ID\n\r"));
		continue;
	    }

	    for (i = 0; i < 8; i++)
		ROM[i] = (int)strtol(cmdbuf + 3 * (i + 1), (char **)NULL, 16);

	    if (ROM[0] != OW_FAMILY_TEMP) {
		uart_putsP(PSTR("ROM specified isn't a temperature sensor\n\r"));
		continue;
	    }
	    
	    OWSendCmd(ROM, OW_CONVERTT_CMD);
	    i = 0;
	    while (OWReadBit() == 0) {
		i++;
	    }
	    OWSendCmd(ROM, OW_RD_SCR_CMD);
	    crc = 0;
	    for (i = 0; i < 9; i++) {
		buf[i] = OWReadByte();
		if (i < 8)
		    OWCRC(buf[i], &crc);
	    }
	    
	    if (crc != buf[8]) {
		uart_putsP(PSTR("CRC mismatch\n\r"));
		continue;
	    }
	    
#if 0
	    uart_putsP(PSTR("temperature "));
	    uart_puts_dec(temp >> 4, 0);
	    uart_putsP(PSTR("."));
	    uart_puts_dec((temp << 12) / 6553, 0);
	    uart_putsP(PSTR("\n\r"));
#else
	    /* 0	Temperature LSB
	     * 1	Temperature MSB
	     * 2	Th
	     * 3	Tl
	     * 4	Reserved
	     * 5	Reserved
	     * 6	Count Remain
	     * 7	Count per C
	     * 8	CRC
	     */
#if 0
	    for (i = 0; i < 9; i++) {
		uart_puts_dec(buf[i], 0);
		uart_putsP(PSTR("\n\r"));
	    }
#endif
	    temp = buf[0];
	    if (buf[0] & 0x01)
		temp -= 256;
	    temp >>= 1;

	    tfrac = buf[7] - buf[6];
	    tfrac *= (uint16_t)100;
	    tfrac /= buf[7];
	    tfrac += 75;
	    if (tfrac < 100) {
		temp--;
	    } else {
		tfrac -= 100;
	    }
	    
	    if (temp < 0){
		uart_putc('-');
		uart_puts_dec(-temp, 0);
	    } else
		uart_puts_dec(temp, 0);
	    uart_putsP(PSTR("."));
	    uart_puts_dec(tfrac, 1);
	    uart_putsP(PSTR("\n\r"));
	    
#endif
	} else if (cmdbuf[0] == 's' && cmdbuf[1] == 'r') {
	    memset(ROM, 0, 8);

	    i = OWFirst(ROM, 1, 0);
	    do {
		switch (i) {
		case OW_BADWIRE:
		    uart_putsP(PSTR("Presense pulse, but no module found, bad module/cabling?\n\r"));
		    break;

		case OW_NOPRESENCE:
		    uart_putsP(PSTR("No presense pulse found\n\r"));
		    break;
		    
		case OW_BADCRC:
		    uart_putsP(PSTR("Bad CRC\n\r"));
		    break;

		case OW_NOMODULES:
		case OW_FOUND:
		    break;
		    
		default:
		    uart_putsP(PSTR("Unknown error from 1 wire library\n\r"));
		    break;
		}
		
		if (i != OW_FOUND)
		    break;

		for (i = 0; i < 7; i++) {
		    uart_puts_hex(ROM[i]);
		    uart_putc(':');
		}
		uart_puts_hex(ROM[7]);
		uart_putsP(PSTR("\n\r"));

		i = OWNext(ROM, 1, 0);
	    } while (1);
	} else {
	  badcmd:
	    uart_putsP(PSTR("Unknown command, ? for a list\n\r"));
	}

    }
    
    return(0);
}

int
uart_putc(char c) {
    loop_until_bit_is_set(USR, UDRE);
    outp(c, UDR);

    return(0);
}

void
uart_putsP(const char *addr) {
    char c;

    while ((c = PRG_RDB((unsigned short)addr++)))
	uart_putc(c);
}

void
uart_puts(const char *addr) {
    while (*addr)
	uart_putc(*addr++);
}

void
uart_puts_dec(uint8_t a, uint8_t l) {
    char	s[4];
    
    if (l && a < 10)
	uart_putsP(PSTR("0"));
    uart_puts(utoa(a, s, 10));
}

void
uart_puts_hex(uint8_t a) {
    char	s[3];
    
    if (a < 0x10)
	uart_putc('0');
    
    uart_puts(utoa(a, s, 16));
}

int
uart_getc(void) {
    while (!(inp(USR) & 0x80))
	;
    
    return (inp(UDR));
}

