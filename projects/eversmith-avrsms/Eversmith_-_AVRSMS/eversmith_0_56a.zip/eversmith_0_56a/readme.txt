
                 Eversmith
       AVR-SMS (c) 2003 Martin Thomas
          Version 0.56a, Oct. 2003

|
| see manual.pdf for more details
|

This    is    a    firmware   for    ATMEL
(www.atmel.com)   ATmega  microcontrollers
to  send  and receive short  messages in a  
GSM  Network (SMS)   with   a  GSM  Mobile   
Phone/Cell Phone/Handy  connected  to  the  
AVR    serial   port.  The   firmware   is     
completely written in  AVR-Assembler Code. 
You  may call it: YAAS-Yet Another AVR SMS 
Software.

Features:
-   Sends and receives Short Message in
    SMS PDU-Format. PDU creation and decoding
    is done on the fly, so only one memory
    area is needed that can be shared.
-   Switches output on receive of SMS.
-   Send status on demand.
-   Sends SMS if input pins where enabled.
-   Menu-based configuration - no special
    software needed.
-   Configuration values are kept in
    EEPROM storage.
-   Debouncing of input keys.
-   Buffered UART.
-   Compact code, but sometimes cryptic.
    (it�s Assembler and my first AVR-Project,
    16 years after I�ve left the Commodore 64
    and 6510 Assembler)

Required Hardware 
-   ATMEL ATmega
-   a GSM Modem or Mobile/Cell-
    Phone/Handy (ME) that supports AT-commands
    on a serial bus and the SMS PDU-Mode
    according to standard GSM 07.05
-   connection between serial ports, RS232 V24
    level shifter for configuration, output 
    hardware (LEDs, Relais etc.), Inputs 
    (switches etc.), Power Supply...
 
More details in the manual (manual.pdf).

The supplied hex-file is for an ATmega16
at 8 MHz.

Authors e-mail: eversmith@heizung-thomas.de

Licensed under the Aladdin Free Public License
- free for NON-COMMERCIAL use -