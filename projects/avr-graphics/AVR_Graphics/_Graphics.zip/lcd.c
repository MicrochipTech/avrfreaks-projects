/*
  Copyright (C) 2001 Peter Kunst <SCALAR@HOME.NL>.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation, 
  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// ---------------------------------------------------------------------------------------------------------------------------------------------
// This program was made using an Atmega103 running coldly on 10MHz. :)
// ---------------------------------------------------------------------------------------------------------------------------------------------
/*
LCD display is 240 pixels by 128 pixels, using Toshiba controller T6963C, 8Kb. RAM, fontsize set to 6x8, set to 40 chars per line
databus <d0-d7> processor connected to databus lcd <d0-d7>
port E pin 2 -> lcd CE (active low)
port E pin 3 -> lcd Command/Data (data is active low, command high)
port E pin 6 -> lcd reset (active low)
port E pin 7 -> lcd WR (active low)
lcd RD is connected to +5V (active low) we don't use this one
*/
// ---------------------------------------------------------------------------------------------------------------------------------------------
#include <string-avr.h>
#include <io.h>
#include <progmem.h>
#include <sig-avr.h>
#include <interrupt.h>

#include "lcd.h"

typedef unsigned char  u08;
typedef unsigned short u16;
typedef unsigned long  u32;
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_command(unsigned char data)
{
cli();
cbi(MCUCR, SRE);				// disable EXTRAM
outp(0xff,DDRA);				// set datadir. as output
outp(0xde,DDRE);				// set datadir. as output
outp(data,PORTA);				// output data on databus
sbi(PORTE, 3); 				//command mode
cbi(PORTE, 7); 				//WR on
cbi(PORTE, 2); 				// CE on
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");				// crude timing put more in as you clock higher. This amount is for a 10MHz x-tal on a Atmega103
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
sbi(PORTE, 2); 				// CE off
sbi(MCUCR, SRE);				// enable RAM
sei();
return;
}
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_data(unsigned char data)
{
cli();
cbi(MCUCR, SRE);				// disable EXTRAM
outp(0xff,DDRA);				// set datadir. as output
outp(0xde,DDRE);				// set datadir. as output
cbi(PORTE, 3); 				// data mode
outp(data,PORTA);				// output data on databus
cbi(PORTE, 7); 				//WR on
cbi(PORTE, 2); 				// CE on
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");				// crude timing put more in as you clock higher. This amount is for a 10MHz x-tal on a Atmega103
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
asm volatile("nop");
sbi(PORTE, 2); 				// CE off
sbi(PORTE, 7); 				//WR off
//sbi(PORTE, 3); 				// commandmode
sbi(MCUCR, SRE);				// enable RAM
sei();
return;
}
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_init(void)
{
//	Init LCD display port
	int i;
	outp(0xde,DDRE);				// datadir. output
	cbi(PORTE, 6); 				//Reset on
	for (i=0; i < 20; i++) {};
	sbi(PORTE, 6); 				//Reset off
	for (i=0; i < 20; i++) {};
	sbi(PORTE, 2); 				// CE off
	for (i=0; i < 20; i++) {};
	sbi(PORTE, 3); 				// data mode
	for (i=0; i < 20; i++) {};
	sbi(PORTE, 7); 				//WR off
	for (i=0; i < 20; i++) {};

	lcd_data(0x81);				//low byte  81?
	lcd_data(0x02);				//high byte
	lcd_command(0x42);			//set graphics home address, 1 pages of text free at 0 (40*16 =0x280)+1
	
	lcd_data(0x28);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x43);			//set graphics line length 40 characters
	
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x40);			//set text home address
	
	lcd_data(0x28);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x41);			//set text line length 40 characters
	
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x21);			//set cursor position
	
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x24);			//set start of text position
	
	lcd_command(0x81);			//XOR mode (text and graphics pixels)
	lcd_command(0xA3);			//set cursor pattern
	lcd_command(0x9F);			//display mode 97=textonly, 98=graph.only, 9F=both  on
	return;
}
// ---------------------------------------------------------------------------------------------------------------------------------------------	
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_row (unsigned char data)
{
	unsigned int address;
	unsigned char low_byte;
	unsigned char high_byte;
	address=(data*40);
	low_byte=address&0xFF;
	address>>=8;
	high_byte=address&0xFF;
	lcd_data(low_byte);
	lcd_data(high_byte);
	lcd_command(0x24);			//set start of text position
}
// ---------------------------------------------------------------------------------------------------------------------------------------------	
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_print(unsigned char data)
{
	lcd_data((data-0x20));
	lcd_command(0xC0);		// flush character
	return;
}     
// ---------------------------------------------------------------------------------------------------------------------------------------------	
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_write_char(unsigned char x,unsigned char y, unsigned char data)
{
	unsigned char pos;
	pos=y*40+x;
	lcd_data(pos);
	lcd_data(0x00);
	lcd_command(0x24);		//write address
	lcd_data(data);
	lcd_command(0xC0);
	return;
}     
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_clear_full(void)
{
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x24);			//set start of text position
	lcd_command(0xB0);			//set autodata mode on

	u32 y;
	unsigned char d=0;

	for ( y=0;y<8192;y++)			// 8 kb. ram cleaning
	{
		lcd_data(d);
	}

	lcd_command(0xB2);			//set autodata mode off
	 
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x24);			//set start of text position

	lcd_data((0x00));				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x21);			//set cursor position

	 return;
}    
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_clear_text(void)
{
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x24);			//set start of text position
	lcd_command(0xB0);			//set autodata mode on

	u32 y;
	unsigned char d=0;

	for ( y=0;y<640;y++)			// 1 page of 40*16 chars
	{
		lcd_data(d);
	}

	lcd_command(0xB2);			//set autodata mode off
	
	lcd_data(0x00);				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x24);			//set start of text position

	lcd_data((0x00));				//low byte
	lcd_data(0x00);				//high byte
	lcd_command(0x21);			//set cursor position

	 return;
}    
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_string(char s[])				//print string on lcd (no auto linefeed)
{
    register u08 *c;

    if (!(c=s)) return;

    while (*c)
    {
        lcd_print(*c);    
        c++;
    }
}
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_pixel_on(unsigned char x, unsigned char y) // x->0-239   y->0-127
{
	int adress;
	adress = 0x281 + (y*40)+(x/6); 	//start adress 281, 40 chars per row, 6 bytes per char
	lcd_data(adress%256);
	lcd_data(adress>>8);
	lcd_command(0x24);
	lcd_command(0xF8 | (5-(x%6)));  //F8 = set individual bit--------- F0 = clear individual bit
}
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
void lcd_pixel_off(unsigned char x, unsigned char y) // x->0-239   y->0-127
{
	int adress;
	adress = 0x281 + (y*40)+(x/6); 	//start adress 281, 40 chars per row, 6 bytes per char
	lcd_data(adress%256);
	lcd_data(adress>>8);
	lcd_command(0x24);
	lcd_command(0xF0 | (5-(x%6)));  //F8 = set individual bit--------- F0 = clear individual bit
}
// ---------------------------------------------------------------------------------------------------------------------------------------------
// --------    EOF  --------    EOF  ----------    EOF  ---------    EOF  ---------    EOF  ---------    EOF  --------    EOF  ---------
// ---------------------------------------------------------------------------------------------------------------------------------------------
