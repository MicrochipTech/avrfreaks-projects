/*
  Copyright (C) 2001 Peter Kunst <SCALAR@HOME.NL>.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation, 
  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

void lcd_command(unsigned char data);
void lcd_data(unsigned char data);
void lcd_init(void);
void lcd_write_char(unsigned char x,unsigned char y, unsigned char data);
void lcd_clear_full(void); 
void lcd_clear_text(void); 
void lcd_row(unsigned char data);
void lcd_print(unsigned char data);
void lcd_string(char s[]);
void lcd_pixel_on(unsigned char x, unsigned char y); // x->0-240   y->0-128
void lcd_pixel_off(unsigned char x, unsigned char y); // x->0-240   y->0-128
// ---------------------------------------------------------------------------------------------------------------------------------------------
// --------    EOF  --------    EOF  ----------    EOF  ---------    EOF  ---------    EOF  ---------    EOF  --------    EOF  ---------
// ---------------------------------------------------------------------------------------------------------------------------------------------