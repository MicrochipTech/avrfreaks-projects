/*
  Copyright (C) 2001 Peter Kunst <SCALAR@HOME.NL>.

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation, 
  Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// ---------------------------------------------------------------------------------------------------------------------------------------------
// This program was made using an Atmega103 running coldly on 10MHz. :)
// ---------------------------------------------------------------------------------------------------------------------------------------------
/*
LCD display is 240 pixels by 128 pixels, using Toshiba controller T6963C, 8Kb. RAM, fontsize set to 6x8, set to 40 chars per line
databus <d0-d7> processor connected to databus lcd <d0-d7>
port E pin 2 -> lcd CE (active low)
port E pin 3 -> lcd Command/Data (data is active low, command high)
port E pin 6 -> lcd reset (active low)
port E pin 7 -> lcd WR (active low)
lcd RD is connected to +5V (active low) we don't use this one
*/
// ---------------------------------------------------------------------------------------------------------------------------------------------
#include <string-avr.h>
#include <io.h>
#include <progmem.h>
#include <sig-avr.h>

#include "lcd.h"

typedef unsigned char  u08;
typedef unsigned short u16;
typedef unsigned long  u32;
// ---------------------------------------------------------------------------------------------------------------------------------------------
int main( void )
{
	lcd_init();
	lcd_clear_full();
	lcd_clear_text();
	lcd_row(0);
	lcd_string("Display up and running.......");
	lcd_row(8);
	lcd_string("Testing the display.......");
// ---------------------------------------------------------------------------------------------------------------------------------------------
	// put pixel in corners
	lcd_pixel_on (0,0);
	lcd_pixel_on (239,0);
	lcd_pixel_on (239,127);
	lcd_pixel_on (0,127);
// ---------------------------------------------------------------------------------------------------------------------------------------------
	u08 x;
	u08 y;
	u08 loop;

	for (loop=0;loop<4;loop++)
	{
		
		for (x=0;x<240;x=x+2)
		{
			for(y=0;y<128;y=y+2)
			{
				lcd_pixel_on (x,y);
			}
		}
		
		for (x=0;x<240;x=x+2)
		{
			for(y=0;y<128;y=y+2)
			{
				lcd_pixel_off (x,y);
			}
		}
// ---------------------------------------------------------------------------------------------------------------------------------------------
		for (x=0;x<240;x=x+4)
		{
			for(y=0;y<128;y=y+4)
			{
				lcd_pixel_on (x,y);
			}
		}
		
		for (x=0;x<240;x=x+4)
		{
			for(y=0;y<128;y=y+4)
			{
				lcd_pixel_off (x,y);
			}
		}
		
	}
// ---------------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------------------
		lcd_clear_full(); // clear screen

		x=0;
		y=0;
		u08 xx=0;
		u08 yy=0;
		u08 a=1;
		u08 b=1;
		int w=0;		
		
		lcd_clear_text();
		lcd_row(8);
		lcd_string(" Welcome to the famous BOUNCING BALL !!" );
		
		while (1)
		{
			if (a==1) x++;
			else x--;
			
			if (b==1) y=y+2;
			else y--;
			
			if (x>239) a=0; //count down
			if (y>127)
			{
				b=0; //count down
				y=127;
			}

			if (x==0) a=1; //count up
			if (y==0) b=1; //count up
						
			lcd_pixel_on (x,y); // set new pixel
			
			for (w=0;w<25000;w++) {}; // SPEED WAITLOOP, GO AND CHANGE AS YOU LIKE, depends on crystal speed
			
			lcd_pixel_off (xx,yy); // clear old pixel
			
			xx=x; // old pixel = new pixel
			yy=y; // old pixel = new pixel
			
			for (w=0;w<25000;w++) {};// SPEED WAITLOOP, GO AND CHANGE AS YOU LIKE, depends on crystal speed
		
		} // loop forever

} // end main
// ---------------------------------------------------------------------------------------------------------------------------------------------
// --------    EOF  --------    EOF  ----------    EOF  ---------    EOF  ---------    EOF  ---------    EOF  --------    EOF  ---------
// ---------------------------------------------------------------------------------------------------------------------------------------------
