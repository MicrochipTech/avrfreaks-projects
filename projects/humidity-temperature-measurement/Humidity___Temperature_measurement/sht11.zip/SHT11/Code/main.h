#ifndef MAIN_H
#define MAIN_H

#include <string-avr.h>
#include <stdlib.h>

#include "hal_lcd.h"
#include "typedefs.h"
#include "hal_sht11.h"


#endif
