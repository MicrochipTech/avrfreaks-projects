Serial (not RS232) controlled 4 digit displays.

Author: Peter N Lewis <peter@stairways.com.au>

Project: Dash display for our solar car <http://www.sungroper.asn.au>, displaying four 4-digit numbers.

Hardware: 

We used the Four Digit Presetable Counter from Frank Crivelli <frank@ovitronics.com> at Ozitronics <http://www.ozitronics.com/counters.html#k154> (also available from jayCar, and described in detail in the May issue of Silicon Chip <http://www.siliconchip.com.au>), which costs around AU$35 each.  Although not designed for our purposes, the board consists of an AT90S1200 AVR, 4-digit led display and transistor drivers, reset control and several inputs and so by reprogramming the AVR and repurposing the inputs we were able to control the display to our purposes without having to design a PCB.

For pictures of the hardware, see <http://www.sungroper.asn.au/gallery/day/2001-07-07-Dash-Displays.html>

Hardware Modifications:

From the kit, make the following modifications:

If you wish to drive it from a 5V source, replace diode D1 and the 78L05 with links.

On the reset line, replace the capacitor with a .1uF cap and the 27k resistor with a link (so it can be controlled for programming)

On each input line (PD1, 3 & 4), replace the 27k resistor with a link, remote the capacitor, and remote the switch/button.  For our purposes, PD1 is used as an input, and PD3&4 are used as selector for the board number - for each board, ground one or other or both or neither of the switches to select display number 0, 1, 2, 3.

On the output line (PB0), remove the transistor and zenner diode, and replace the 1k resistor with a 270 ohm resistor.  Using a piece of wire, connect the output end of the resistor to pin 3 on the led display - this adds control for the decimal point.

Software:

Program the AT90S1200 chip with the attached asm code.

You will then be able to control one or more of these devices from another AVR (or any other device) using a simple serial protocol.  AVR code in C for this protocol is also attached.  The protocol is:

Clock speed of 2.5kHz.
Leave the line low for at least 10 clocks.
Raise the line high for 4 clocks.
Send a packet of data by toggling the clock between each bit, leaving it constant for one clock for 0 bits, two clocks for 1 bits (MSB first)
The packet format is
length byte (length of data excluding the length byte and checksum)
repeat
  control byte
  value low byte
  value high byte
for each device
-checksum (sum of all bytes except the checksum, plus $55, negated).

control byte is the brightness of the display in the top 6 bits, and the decimal point position in the bottom two bytes.  Currently, low brightness from about 1 to 6 flicker more than desirable.  Value (hilo) is a number from -999 to 9999.  If the decimal point is in the top digit (ie 3), or the number is more negative than -999 then the negative sign will not display.


