// Author: Peter N Lewis <peter@stairways.com.au>
// Version: 1.0, 7 July 2001
// Copyright 2001 Peter N Lewis
// This code is free for any use.  Please attribute the source appropriately.

// *** INCLUDES ***

#include <io.h>
#include <io4433.h>
#include <interrupt.h>
#include <timer.h>
#include <sig-avr.h>
#include <string.h>

// *** EXTRA DEFINES ***

typedef uint8_t u8;
typedef uint16_t u16;
typedef int8_t i8;
typedef int16_t i16;

// *** GLOBALS ***

typedef struct {
  u8 control; // decimal pos bits 0&1, bright percent bits 2-8 (N/127)
  i16 value; // -999 to 9999
} DisplayEntry;

typedef struct {
  DisplayEntry disp0;
  DisplayEntry disp1;
  DisplayEntry disp2;
  DisplayEntry disp3;
} DisplayData;

DisplayData gDisplayData;

enum {
  kDisplayDataSize = sizeof(DisplayData),
};

// *** ACCESSORS ***

// BV( n )
#define OUTPUT 0xFF

static inline void OutputOff()
{
  outp( inp(PORTD) & ~OUTPUT, PORTD );
}

static inline void OutputOn()
{
  outp( inp(PORTD) | OUTPUT, PORTD );
}

static inline void OutputToggle()
{
  outp( inp(PORTD) ^ OUTPUT, PORTD );
}

SIGNAL (SIG_OVERFLOW0)
{
  static u8 t10kHz = 0;
  static u8 t100Hz = 0;
  static u8 displaysend[kDisplayDataSize+2];
  static u8 state = 0; // 0 = doingtrailer, 1 = data
  static u8 waitcount = 1; // clocks until next action
  static u8 curbyte;
  static u8 curbit;

  outp( 256-100, TCNT0 );

  t10kHz++;
  if ( t10kHz == 100 ) {
    t10kHz = 0;
    t100Hz++;
    if ( t100Hz == 100 ) {
      t100Hz = 0;
    }
  }
  
  if (t10kHz % 4 == 0) { // 2.5kHz clock
    waitcount--;
    if (waitcount == 0) {
      switch (state) {
        case 0: // idle
          OutputOn();
          state = 1;
          waitcount = 4;
          
          displaysend[0] = kDisplayDataSize;
          memcpy( &displaysend[1], &gDisplayData, kDisplayDataSize );
          // Optimize checksum using asm!
          u8 checksum = 0x55 + kDisplayDataSize;
          u8 i;
          for( i = 1; i <= kDisplayDataSize+1; i++ ) {
//            displaysend[i] = *(((u8 *)&gDisplayData)+i-1)
            checksum += displaysend[i];
          }
          displaysend[kDisplayDataSize+1] = -checksum;
          
          curbyte = 0;
          curbit = 8;
          break;
        case 1: // data
          OutputToggle();
          if (curbit == 0) {
            curbyte++;
            curbit = 8;
          }
          if (curbyte == kDisplayDataSize+2) {
            state = 0;
            waitcount = 10; // Give the receiver chance to deal with packet
          } else {
            if ((displaysend[curbyte] & 0x80) != 0) {
              waitcount = 2;
            } else {
              waitcount = 1;
            }
            displaysend[curbyte] <<= 1;
            curbit--;
          }
          break;
      }
    }
  }
  
  if ( t10kHz == 0 && t100Hz % 10 == 0 ) {
    outp( ~inp(PORTC), PORTC );
  }
  if ( t10kHz == 0 && t100Hz == 0 ) {
    outp( ~inp(PORTB), PORTB );
    gDisplayData.disp3.value++;
    if (gDisplayData.disp3.value >= 10000) {
      gDisplayData.disp3.value = -999;
    }
    gDisplayData.disp1.control = (gDisplayData.disp1.control & 0xFC) + 
    							((gDisplayData.disp1.control+1) & 0x03);
    gDisplayData.disp2.control += 4;
  }
}

int main( void ) {

  // use all pins on for output
  outp( 0xff, DDRD );
  outp( 0xff, DDRC );
  outp( 0xff, DDRB );

  outp( 1, TCNT0 );
  outp( BV( TOIE0 ), TIMSK); // Enable Timer 0 overflow interrupt
  outp( CK8, TCCR0 ); // Timer 0 source is clk/1024

  gDisplayData.disp0.control = 0x40;
  gDisplayData.disp0.value = 99;
  gDisplayData.disp1.control = 0x81;
  gDisplayData.disp1.value = -88;
  gDisplayData.disp2.control = 0xC2;
  gDisplayData.disp2.value = 999;
  gDisplayData.disp3.control = 0xFF;
  gDisplayData.disp3.value = 123;
  
  sei();
    
  while( 1 ) {
  } // end while
} // end main()
