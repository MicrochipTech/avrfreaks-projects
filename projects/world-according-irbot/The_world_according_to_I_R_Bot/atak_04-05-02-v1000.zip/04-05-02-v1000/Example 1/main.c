/*********************************************
This program was produced by the
CodeWizardAVR V1.0.1.4b Light
Automatic Program Generator
� Copyright 1998-2001
Pavel Haiduc, HP InfoTech S.R.L.
http://infotech.ir.ro
e-mail:dhptechn@ir.ro , hpinfotech@mail.com

Project : Kernel test project
Version : 
Date    : 12/3/2001
Author  : Mark Verlinden
Company : 
Comments: 


Chip type           : AT90S8515
Clock frequency     : 4.000000 MHz
Memory model        : Small
Internal SRAM size  : 512
External SRAM size  : 32768
Ext. SRAM wait state: 0
Data Stack size     : 128
*********************************************/

#include <90s8515.h>
#define TEST_CASE

#define UART_DRIVER
#define TRACER

#include "kernel.h" 

#ifdef TRACER
	#include "tracer.h"
#endif
                           
#ifdef UART_DRIVER
	#include "uart_driver.h"	
#endif                    


#ifdef TEST_CASE
	atak_TASK(Task1, arg);
	atak_TASK(Task2, arg);
	atak_TASK(Task3, arg); 
	atak_TASK(Task4, arg);  
#endif           

#ifdef TEST_CASE
	TCB 	tcb1;
	TCB 	tcb2;
	TCB 	tcb3;
	TCB 	tcb4;
#endif

// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
// Place your code here

}

// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
	atak_SchedulerEntry();
}
 
interrupt [UART_RXC] void uart_rx_isr(void)
{                                  
	unsigned char data = 0xFF;
	data = UDR; 

	if (PORTB.4 == 1) PORTB.4 = 0; else PORTB.4 = 1;                     

	switch(data)
	{
#ifdef TRACER
	 	case 'T': Trace(data,INTERRUPT_CALL); break;
	 	case 'E': Trace(data,INTERRUPT_CALL); break;
	 	case 'R': Trace(data,INTERRUPT_CALL); break;
	 	case 'D': Trace(data,INTERRUPT_CALL); break;  
	 	case 'H': Trace(data,INTERRUPT_CALL); break;	 		 	
	 	case 'S': Trace(data,INTERRUPT_CALL); break;
	 	case 'Q': Trace(data,INTERRUPT_CALL); break;	 	
		case 'I': atak_PostMessage(&messageQueue,data,INTERRUPT_CALL);break;	 	
#endif		         
		return;
	}
}    

// Timer 1 overflow interrupt service routine
interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
// Place your code here
}

// Timer 1 output compare A interrupt service routine
interrupt [TIM1_COMPA] void timer1_compa_isr(void)
{
// Place your code here
	system.operationTime++;         
//	ee_prom_struct_system.life_time = system.operationTime;
	TCNT1H=0x00;
	TCNT1L=0x00;	
}

// Timer 1 output compare B interrupt service routine
interrupt [TIM1_COMPB] void timer1_compb_isr(void)
{
// Place your code here

}

// Declare your global variables here

void main(void)
{
// Declare your local variables here

// Input/Output Ports initialization
// Port A
DDRA=0x00;
PORTA=0x00;

// Port B
DDRB=0x00;
PORTB=0x00;

// Port C
DDRC=0x00;
PORTC=0x00;

// Port D
DDRD=0x00;
PORTD=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Output Compare
// OC0 output: Disconnected
TCCR0=0x02;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Output Compare
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
TCCR1A=0xA3; // 0x00
TCCR1B=0x03; // 0x05
TCNT1H=0x00;
TCNT1L=0x00;
OCR1AH=0x0F;
OCR1AL=0x41;
OCR1BH=0x00;
OCR1BL=0x00;

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Low level
// INT1: Off
GIMSK=0x00;
MCUCR=0x80;
GIFR=0x40;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0xE2;

// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
// UART Baud rate: 9600
//UCR=0x18;
//UBRR=0x19;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;

#ifdef UART_DRIVER
	uart_Initialize(25,INT_UART);
#endif                              

DDRB = 0xFF;
PORTB.7 = 1;
PORTB.6 = 1;
PORTB.5 = 1;
PORTB.4 = 1;

#ifdef TEST_CASE
	atak_Initialize();                    
	atak_CreateTask('A',Task1,&tcb1,0);   
	atak_CreateTask('B',Task2,&tcb2,0);          
	atak_CreateTask('C',Task3,&tcb3,0); 
	atak_CreateTask('D',Task4,&tcb4,11); 
	atak_Run();	
#endif
while (1)
      {};
}

#ifdef TEST_CASE

atak_TASK(Task1,arg)
{              
//	unsigned int x = 0, y = 0;
//	x = arg;	
	arg = arg;
        while(1)
        {
/*		for(x=0;x<65500;x++)
		{
			PORTB.0 = 0;
			y++; 
			if(y>=30000)
			{
				PORTB.0 = 1;
				atak_PostMessage(&messageQueue,'A',NON_INTERRUPT_CALL); 
				y = 0;
			}
		}    */    
		atak_PostMessage(&messageQueue,'A',NON_INTERRUPT_CALL);                                                                
//		atak_SuspendTask(&tcb1);
	}
}
atak_TASK(Task2,arg)
{ 
//	unsigned int x = 0, y = 0;

       	arg = arg;
            
        while(1)
        {
/*		for(x=0;x<65000;x++)
		{
			PORTB.1 = 0;
			y++;
			if(y>=30000)
			{      
				atak_PostMessage(&messageQueue,'B',NON_INTERRUPT_CALL);
				y = 0;
			}					
		}   */
		atak_PostMessage(&messageQueue,'B',NON_INTERRUPT_CALL);
		PORTB.1 = 0;
		atak_Delay(1000);
		PORTB.1 = 1;
		atak_Delay(1000);			
//		atak_SuspendTask(&tcb2);       
	}
}
  
atak_TASK(Task3,arg)
{        
//	unsigned int x = 0, y = 0;

       	arg = arg;        
        while(1)
        {	
 /*		for(x=0;x<65000;x++)
		{
			PORTB.2 = 0;
			y++; 
			if(y>=30000)
			{
				PORTB.2 = 1; 
  				       atak_PostMessage(&messageQueue,'C',NON_INTERRUPT_CALL);
				       y = 0; 
			}			
		} */               
		PORTB.2 = 0;
		atak_Delay(100);
		PORTB.2 = 1;
		atak_Delay(100);
//		atak_PostMessage(&messageQueue,'C',NON_INTERRUPT_CALL);                                                
//		atak_SuspendTask(&tcb3);
	}
}

atak_TASK(Task4,arg)
{        
       	unsigned char data = 0;
       	arg = arg;

        
        while(1)
        {                    
	        data = atak_GetMessage(&messageQueue,NON_INTERRUPT_CALL);
	       //	TransmitByte(data); 
	       	//atak_GetMessage(&messageQueue,NON_INTERRUPT_CALL);
	//	atak_SuspendTask(&tcb4);
		PORTB.3 = 0;
		atak_Delay(50);
		PORTB.3 = 1;
		atak_Delay(50);	
	}
}        
#endif // #ifdef TEST_CASE
