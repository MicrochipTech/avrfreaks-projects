/*                                                           
 * atak - a tiny Avr kernel: pre-emptive multi-tasking mcu kernel
 * Copyright (C) 2001 by Mark Verlinden. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by M.Verlinden
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY M.VERLINDEN AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL M.VERLINDEN
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * -
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#include "list.h"

#pragma used+
LIST_ITEM* AddToList(LIST_ITEM* head, LIST_ITEM *item)
{         
	LIST_ITEM* last;
	
	if(head == 0){
	    head = item;
	    last = head->previous;
	    item->next = item;
	    item->previous = item;
	}
	else{ 
	    // let this new task point to the front
	    item->next = head;
	    // determine last item
	    last = head->previous;
	    // let the first point to the last
	    head->previous = item;
	    // let the last point to newly created
	    last->next = item;
	    // point to last	    
            item->previous = last;        
	}    
	return head;
}            
#pragma used-
             
#pragma used+
LIST_ITEM* RemoveFromList(LIST_ITEM * head, LIST_ITEM *item)
{
	LIST_ITEM* right;
	LIST_ITEM* left;
         
        // IF YOU TAKE THESE CONDITIONS IN ONE IF STATEMENT CODEVISION MAKES A MISTAKE!                   
	if(item == head){	
		if(item->next == item){
			if(item->next == item->previous){
			// empty list if this is only one item
				head = 0;
				item->next = 0;
				item->previous = 0;
				return head;
			}
		}
	}

	// left of the item to be removed
	left = item->previous;           
	// right of the item to be removed
	right = item->next;               
	// detour from left to right
	left->next = right;         
	// and back
	right->previous = left;	

	// update head             
	if(head == item){
		return head->previous;
	}
	else{
		return head;  	
	}
}
#pragma used-
