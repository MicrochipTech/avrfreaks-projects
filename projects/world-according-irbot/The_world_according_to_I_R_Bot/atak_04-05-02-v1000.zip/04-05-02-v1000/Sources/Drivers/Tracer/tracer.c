/*                                                           
 * Tracer for a tiny Avr kernel: pre-emptive multi-tasking mcu kernel
 * Copyright (C) 2001 by Mark Verlinden. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by M.Verlinden
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY M.VERLINDEN AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL M.VERLINDEN
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * -
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
 
#include "tracer.h"
#include <stdio.h>
 
#pragma used+
void Trace(unsigned char byte, unsigned char mode)
{
#ifdef TRACER      
	int i = 0, y = 0;
	unsigned int *stackpointer;
	TCB* tempTCB;
	TCB* tempTCB2;
	LIST_ITEM* item; 
	
	putsf("\rMy tiny AVR Kernel Tracer Version 1.0 (C) 2002 by M.Verlinden\r\n");
		
	switch(byte)
	{
		case 'T':
			printf("Total running tasks : (%X)\rSystem time tick(s) : (%X)\rOperating time      : %u hours, %u min, %u total ticks\r\n",system.task_counter,system.system_tick,system.operationTime/3600,system.operationTime/60,system.operationTime);
			printf("Current running task : [Address (%X), Name : (%c), Status : (%X)] \r\n",currentRunningTask,currentRunningTask->taskName,currentRunningTask->status);			
		break;

#ifdef LERROR		
		case 'E':     
			printf("Last error [Status : (%X), Task : (%X), Point : (%X)]\r",system.last_error.status,system.last_error.currentTask,system.last_error.point);
		break;
#endif		
		
		case 'R':    
			printf("RUNNING TASK(S)\r");
			ListTrace(headRunningList);		
		       	printf("\rCurrent running task : {Address (%X), Name (%c), Status (%X)]\r",currentRunningTask,currentRunningTask->taskName,currentRunningTask->status);									
			printf("\rSLEEPING TASK(S)\r");		       	
                        ListTrace(headSleepingTask);
			printf("\rDELAYED TASK(S)\r");                        
			ListTrace(headDelayedTask);                       
			printf("\rDESTROYED TASK(S)\r");			
			ListTrace(headDestroyedTask);			
		break;

		case 'D': 
			printf("\r");		 
			stackpointer = Idle;
			for(i=0;i <= 0x7FFF; i++){ 
				printf("[%X]",stackpointer);               
				for(y=0;y <= 0x07; y++){        
					stackpointer++;        
					if(*stackpointer != 0) printf(" 0x%X ",*stackpointer);else printf(" 0x0000 ");			
				}               
				printf("\r");
			}
		break;    
		case 'H':
			printf("Help tracer \r\n");
			printf("T = Traces system information \r");			
			printf("E = Prints the last error occured\r");			
			printf("R = Task information\r");
			printf("D = Dumps the entire stack\r");	
			printf("Q = Queue information\r");								
			printf("H = Help on the commands, guess you found the Help command ;-)\r");					
		break;	

		case 'Q': 
			tempTCB = messageQueue.busyBlock.front;
			if(tempTCB == 0){
				printf("No pending tasks for busy block!\r");
			}
			else{
				while(tempTCB != 0){
				       	printf("Task [name (%c), Address (%X),nextTask (%X), Status (%X)] \r",tempTCB->taskName,tempTCB,item->next,tempTCB->status);			
					tempTCB = tempTCB->nextTaskSemaphore;			       	
				}
			}
			tempTCB = messageQueue.fullBlock.front;
			if(tempTCB == 0){
				printf("No pending tasks for full block!\r");
			}
			else{
				while(tempTCB != 0){
				       	printf("Task [name (%c), Address (%X),nextTask (%X), Status (%X)] \r",tempTCB->taskName,tempTCB,item->next,tempTCB->status);			
					tempTCB = tempTCB->nextTaskSemaphore;			       	
				}
			}
			printf("Queue size (%u), Queue ii (%u), oi (%u)\r",messageQueue.size,messageQueue.ii,messageQueue.oi);
		break;
	}
#endif	
}
#pragma used-
             
#pragma used+
void ListTrace(LIST_ITEM* list)
{
	int i = 0, y = 0;
	TCB* tempTCB;
	TCB* tempTCB2;
	LIST_ITEM* item; 
	void* owner;
	SEMAPHORE* tempSEMA;
	
	if(list != 0){         

		printf("Name , Task , Next , Prev , SEMA , DS   , SP   ,Status, Delay\r");			

		item = list; 
		owner = item->owner;
		tempTCB = tempTCB2 = (TCB*) owner; 
					
		for(i=0;i <= MAX_TASKS; i++){                
			printf("(%c)  ,(%X),(%X),(%X),(%X),(%X),(%X),(%X),(%X)\r",tempTCB2->taskName,tempTCB2,item->next,item->previous,tempTCB2->nextTaskSemaphore,tempTCB2->dataStackPointer,tempTCB2->stackPointer,tempTCB2->status,tempTCB2->delay);
			item = item->next;
			owner = item->owner;
			tempTCB2 = (TCB*) owner;
			if(item == list) break;
		} 
	}
	else{
		printf("No items found!\r");
	}
}
#pragma used-

