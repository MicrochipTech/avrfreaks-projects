/*                                                           
 * UART driver for a tiny Avr kernel: pre-emptive multi-tasking mcu kernel
 * Copyright (C) 2001 by Mark Verlinden. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by M.Verlinden
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY M.VERLINDEN AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL M.VERLINDEN
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * -
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
#include "uart_driver.h"
 
void uart_Initialize(unsigned char baudrate, unsigned char type)
{
	// set the baud rate 
	UBRR = baudrate;                 

	uartInformation.baudrate = baudrate;
	uartInformation.uartType = type;
	
	if(uartInformation.uartType == POLL_UART){
		// enable UART receiver and transmitter 
		UCR = ( (1<<RXEN) | (1<<TXEN) );  
	}else{
		UCR = ( (1<<RXEN) | (1<<TXEN) | (1<<RXCIE)); 
	}
}

void uart_TransmitByte(unsigned char data)
{                                 
	if(uartInformation.uartType == POLL_UART){
		// wait for empty transmit buffer 
		while(!(USR & (1<<UDRE)));
	}       
	// start transmittion 	 
	UDR = data; 	
}

#pragma used+
unsigned char uart_ReceiveByte()
{
	if(uartInformation.uartType == POLL_UART){
		// wait for incomming data 
		while ( !(USR & (1<<RXC)) );
		// return the data 
		return UDR;
	}  
	// INT_UART used
	return 0;
}                                          
#pragma used-