/*                                                           
 * atak - a tiny Avr kernel: pre-emptive multi-tasking mcu kernel
 * Copyright (C) 2001 by Mark Verlinden. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by M.Verlinden
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY M.VERLINDEN AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL M.VERLINDEN
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * -
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef _KERNEL_H_
#define _KERNEL_H_

#include "systemdefinitions.h"
#include "list.h"           
#include "config.h"

#pragma used+
                     
#define atak_TASK(task, arg) void task(void *arg)
#define atak_TASK_ARGUMENT *(unsigned int *) 0

typedef struct {
    U_TYPE c_r31;
    U_TYPE c_r30;
    U_TYPE c_r27;
    U_TYPE c_r26;
    U_TYPE c_r25;
    U_TYPE c_r24;
    U_TYPE c_r23;
    U_TYPE c_r22;
    U_TYPE c_r21;
    U_TYPE c_r20;
    U_TYPE c_r19;
    U_TYPE c_r18;
    U_TYPE c_r17;
    U_TYPE c_r16;
    U_TYPE c_r15;
    U_TYPE c_r14;
    U_TYPE c_r13;
    U_TYPE c_r12;
    U_TYPE c_r11;
    U_TYPE c_r10;
    U_TYPE c_r9;
    U_TYPE c_r8;
    U_TYPE c_r7;
    U_TYPE c_r6;
    U_TYPE c_r5;
    U_TYPE c_r4;
    U_TYPE c_r3;
    U_TYPE c_r2;
    U_TYPE c_r1;
    U_TYPE c_r0;
    U_TYPE c_pchi;
    U_TYPE c_pclo;
} CONTEXT;
//----------------------------------------------------------------------
typedef struct {
    U_TYPE arghi;
    U_TYPE arglo;
    U_TYPE sreg;
    U_TYPE pchi;
    U_TYPE pclo;
} TASK_ENTRY_POINT;
//---------------------------------------------------------------------- 

// kernel definitions
typedef struct TCB_TYPE{                                     
        unsigned int			stackPointer;
        unsigned int			dataStackPointer;
	LIST_ITEM			list;		
	unsigned char 			status;		// status	
	unsigned char 			datastack[DATA_STACK_SIZE];
        unsigned char 			stack[STACK_SIZE];
	CONTEXT				context;
	TASK_ENTRY_POINT		entryPoint; 
	struct TCB_TYPE* 		nextTaskSemaphore;
	unsigned int			delay;
	
#ifdef	TRACER
	char 				taskName;		// used for trace only
#endif
	
	//unsigned char			priority;    
}TCB;          

// shared resources
TCB* 	 		currentRunningTask 	= 0; 		// Task in front, current task 
LIST_ITEM*		headRunningList		= 0;
LIST_ITEM*		headSleepingTask	= 0; 
LIST_ITEM*		headDelayedTask		= 0;
LIST_ITEM*		headDestroyedTask	= 0;
      
#ifdef LERROR                  
typedef struct LAST_ERROR{
	unsigned char status;
	char currentTask;
	int point;
}error;     
#endif

typedef struct SYSTEM_VAR{
	unsigned int 	task_counter; 	// total current running task(s)
	unsigned int 	system_tick; 	// system tick only changed in interrupt handler 
	unsigned int    delay_tick;	// tick for delays
#ifdef LERROR
	error	 	last_error;	// used when an error occurs  
#endif	
	unsigned int    operationTime;  
} system_var;

system_var system;

#define BEGIN_CRIT_SECTION() #asm("cli")
#define END_CRIT_SECTION()   #asm("sei") 
#define ENABLE_INTERRUPTS()  #asm("sei") 
#define DISABLE_INTERRUPTS() #asm("cli") 

typedef struct _SEMAPHORE{
	struct TCB_TYPE *front;  	
  	struct TCB_TYPE *back;  
	int value;            
} SEMAPHORE; 

#if FIFO_SIZE > 255
	#error fifo size must not be greater than 255, or set fifo type to int
#endif  

typedef struct _QUEUE{       
  SEMAPHORE busyBlock; 
  SEMAPHORE fullBlock;
  unsigned char ii,oi,size;      
  unsigned char fifo[FIFO_SIZE];           
}QUEUE;      

QUEUE	messageQueue;
TCB 	idleTask;     

atak_TASK(Idle, arg); 	

void  atak_Initialize(void);
void  atak_CreateTask(char name, void (*fp)(), TCB* tcb,void *arg);
void  atak_SuspendTask(TCB* tcb);  
void  atak_ResumeTask(TCB* tcb);
void  atak_DestroyTask(TCB* tcb); 
void  atak_Run();
void  atak_Scheduler(unsigned char type);
void  atak_Context_Switch(void);
void  atak_ThreadEntry(void);
void  atak_SchedulerEntry(void);
void  atak_InitSemaphore(SEMAPHORE *pSemaphore, unsigned char value);
void  atak_SignalSemaphore(SEMAPHORE *pSemaphore);
int   atak_SignalSemaphoreInterrupt(SEMAPHORE *pSemaphore);
void  atak_SemaphoreWait(SEMAPHORE *pSemaphore);
char  atak_GetMessage(QUEUE *pQueue, unsigned char mode);
void  atak_PostMessage(QUEUE *pQueue, unsigned char data, unsigned char mode);
void  atak_InitMessageQueue(QUEUE *pQueue, unsigned char size);    
void  atak_Delay(unsigned int ticks);                  
void  atak_uDelay(unsigned int delay);
void  atak_UpdateDelayTasks(TCB* tcb);
TCB*  atak_ChangeStatus(TCB* tcb,unsigned char status);          
#pragma used-

#endif // _KERNEL_H_
