/*                                                           
 * UART driver for a tiny Avr kernel: pre-emptive multi-tasking mcu kernel
 * Copyright (C) 2001 by Mark Verlinden. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by M.Verlinden
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY M.VERLINDEN AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL M.VERLINDEN
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * -
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
 
#ifndef _UART_DRIVER_H_
#define _UART_DRIVER_H_

// UART Control Register Bit Definitions 
#define RXCIE 7
#define TXCIE 6
#define UDRIE 5
#define RXEN 4
#define TXEN 3
#define CHR9 2
#define RXB8 1
#define TXB8 0                          

// UART Status Register Bit Definitions 
#define RXC 7
#define TXC 6
#define UDRE 5
#define FE 4
#define OVR 3

#define POLL_UART 	1
#define INT_UART	2
#pragma used+
typedef struct _UART_INFORMATION{
	unsigned char uartType;
	unsigned char baudrate;	
}UART_INFORMATION;

UART_INFORMATION uartInformation;

void 		uart_Initialize(unsigned char baudrate, unsigned char type);
void 		uart_TransmitByte(unsigned char byte);
unsigned char 	uart_ReceiveByte();  
#pragma used-
#endif