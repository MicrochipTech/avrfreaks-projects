/*                                                           
 * atak - a tiny Avr kernel: pre-emptive multi-tasking mcu kernel
 * Copyright (C) 2001 by Mark Verlinden. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by M.Verlinden
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY M.VERLINDEN AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL M.VERLINDEN
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * -
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
#include "kernel.h" 

#pragma used+  
void atak_Scheduler(unsigned char type)
{             
	// Round robin schedule algorithm
	// if timeslice for current tasks is finished, then reschedule. Called round robin
	if(type != FORCE_RESCHEDULE_LOCK){
		BEGIN_CRIT_SECTION()	
	}
	
	if(system.system_tick == TIME_SLICE || type == FORCE_RESCHEDULE || type == FORCE_RESCHEDULE_LOCK){                
		system.system_tick = 0;
	        atak_Context_Switch(); 
	} 		
	END_CRIT_SECTION()			
}              
#pragma used-  

#pragma used+ 
// should be called before creating other tasks! 
void atak_Initialize(void)
{                        
	system.task_counter = 0;
	system.system_tick = 0; 
	system.delay_tick = 0;  
	system.operationTime = 0;     
   
#ifdef LERROR
	system.last_error.status = 0;
#endif	    
	// Create idle task
	atak_CreateTask('K',Idle,&idleTask,0);  
	currentRunningTask = &idleTask;
	atak_InitMessageQueue(&messageQueue,FIFO_SIZE);
}             
#pragma used-  

#pragma used+  
void atak_Run(void)
{           
#asm                  
	rjmp startTask       
#endasm             
}             
#pragma used- 
 
#pragma used+  
void atak_CreateTask(char name, void (*fp)(), TCB* tcb,void *arg)
{                   
	LIST_ITEM* listItem;   
BEGIN_CRIT_SECTION()	
	if(system.task_counter >= MAX_TASKS){
#ifdef LERROR
		system.last_error.status = MAX_TASKS_REACHED; 
	#ifdef TRACER
	       	system.last_error.currentTask = currentRunningTask->taskName;
	#endif			
		system.last_error.point = 2;		
#endif	
		return;
	}  
	
	tcb->status = ATAK_TASK_RUNNING; 
	tcb->delay = 0;
	tcb->stackPointer = (unsigned int)(tcb->context) - 1; 
	tcb->dataStackPointer = tcb->stackPointer - STACK_SIZE;

	tcb->entryPoint.pchi = (unsigned char)(((unsigned int)fp) >> 8);
	tcb->entryPoint.pclo = (unsigned char)(((unsigned int)fp) & 0xff);
	tcb->entryPoint.sreg = 0x80;
	tcb->entryPoint.arglo = (unsigned char)(((unsigned int)arg) & 0xff);
	tcb->entryPoint.arghi = (unsigned char)(((unsigned int)arg) >> 8);
	
	tcb->context.c_pclo = (unsigned char)(((unsigned int)atak_ThreadEntry) & 0xff);
	tcb->context.c_pchi = (unsigned char)(((unsigned int)atak_ThreadEntry) >> 8);
	
	// used for trace only
#ifdef	TRACER  
	tcb->taskName = name;
#endif
        tcb->list.owner = (void*)tcb;

	// the first item will be the first to run
	headRunningList = AddToList(headRunningList,&tcb->list);
	// if task is created, then increment task counter
	system.task_counter++;                    

END_CRIT_SECTION()	
}
#pragma used-
             
#pragma used+                       
// not finished yet
void atak_DestroyTask(TCB* tcb)
{                      
	// delete from running or sleeping list
	if(system.task_counter == 0){
		return;
	}                   
	else{
      //		headRunningList = atak_RemoveTCB(headRunningList,tcb);
		// todo, add to free list!!!!
	}
}            
#pragma used-             

#pragma used+  
// this is a kernel service routine, should only be used by kernel
atak_ResumeService(TCB* tcb)
{
	system.task_counter++;      
	
	// remove from list
	switch(tcb->status)
	{    
		case ATAK_TASK_SLEEPING:
			headSleepingTask = RemoveFromList(headSleepingTask, &tcb->list);
		break;
		case ATAK_TASK_DELAYED:
			headDelayedTask = RemoveFromList(headDelayedTask, &tcb->list);		
		break;
	}	
	// add to running list at end of queue
	AddToList(headRunningList, &tcb->list);		
	atak_ChangeStatus(tcb,ATAK_TASK_RUNNING);		
}            
#pragma used- 

#pragma used+
void atak_ResumeTask(TCB* tcb)
{
BEGIN_CRIT_SECTION() 
	atak_ResumeService(tcb);
END_CRIT_SECTION()
}            
#pragma used- 

#pragma used+ 
// when calling this service enabling of interrupts are enabled by the service                  
void atak_SuspendService(TCB* tcb)
{
	// decrement system task counter
	system.task_counter--;        

	// remove from running list
	headRunningList	= RemoveFromList(headRunningList, &tcb->list);

	switch(tcb->status)
	{    
		case ATAK_TASK_SLEEPING:
			// add to sleeping list at end of queue
			headSleepingTask = AddToList(headSleepingTask, &tcb->list);
		break;
		case ATAK_TASK_DELAYED:
			// add to sleeping list at end of queue
			headDelayedTask = AddToList(headDelayedTask, &tcb->list);		
		break;
	}
	
      	if(currentRunningTask == tcb){  
    		// Force scheduling                    
   		atak_Scheduler(FORCE_RESCHEDULE_LOCK);
        } 
        else{
		ENABLE_INTERRUPTS();        	
        }
}            
#pragma used- 

#pragma used+
void atak_SuspendTask(TCB* tcb)
{     
BEGIN_CRIT_SECTION() 
	atak_SuspendService(tcb);
}            
#pragma used- 

#pragma used+         
/*
	The Data Stack area is used to dynamically store local variables, passing function parameters and saving registers R0, R1, R22, R23, R24, R25, R26, R27, R30, R31 and SREG during interrupt routine servicing.
	The Data Stack Pointer is implemented using the Y register.
	At start-up the Data Stack Pointer is initialized with the value 5Fh+Data Stack Size.
	When saving a value in the Data Stack, the Data Stack Pointer decrements.

	When the value is retrieved, the Data Stack Pointer in incremented back.
	The data stack pointer is kept in r28/29
*/                  

void atak_Context_Switch(void)
{
        void *ownerTCB;
#asm
        push r0       
        push r1       
        push r2       
        push r3       
        push r4       
        push r5       
        push r6       
        push r7       
        push r8       
        push r9       
        push r10      
        push r11      
        push r12      
        push r13      
        push r14      
        push r15      
        push r16      
        push r17      
        push r18      
        push r19      
        push r20      
        push r21      
        push r22      
        push r23      
        push r24      
        push r25      
        push r26      
        push r27
        push r30      
        push r31
        in   r30,SPL
        in   r31,SPH           
	lds r26,_currentRunningTask
	lds r27,_currentRunningTask + 1
	st  x+,r30	;store in tcb.stack_pointer
	st  x+,r31
        st  x+,r28      ;save the data stack pointer (Y)
        st  x,r29     
#endasm                                                             
	headRunningList = headRunningList->next;     
	ownerTCB = headRunningList->owner;
       	currentRunningTask =  (TCB*) ownerTCB;
#asm        
startTask:           
	lds  r26,_currentRunningTask 
	lds  r27,_currentRunningTask + 1
	ld   r30,x+ 		; set stack pointer to current task
        ld   r31,x+
        out  SPL,r30
        out  SPH,r31
        ld   r28,x+ 		; set data stack pointer Y to current task
        ld   r29,x  
        pop  r31
        pop  r30
        pop  r27       
        pop  r26       
        pop  r25       
        pop  r24       
        pop  r23       
        pop  r22       
        pop  r21       
        pop  r20       
        pop  r19       
        pop  r18       
        pop  r17       
        pop  r16       
        pop  r15       
        pop  r14       
        pop  r13       
        pop  r12       
        pop  r11       
        pop  r10       
        pop  r9        
        pop  r8        
        pop  r7        
        pop  r6        
        pop  r5        
        pop  r4        
        pop  r3        
        pop  r2        
        pop  r1        
        pop  r0  
        sei
#endasm
}
#pragma used-       

#pragma used+
void atak_ThreadEntry(void)
{
#asm   
	pop r1
	pop r0
	pop r30
	out SREG,r30
	reti
#endasm	
}            
#pragma used-       
                              
#pragma used+
void atak_InitSemaphore(SEMAPHORE *pSemaphore, unsigned char value)
{                  
	int y;
	y = value;
	pSemaphore->value = value;
	pSemaphore->front = pSemaphore->back = 0;
}            
#pragma used-

#pragma used+
void atak_SignalSemaphore(SEMAPHORE *pSemaphore)
{
	TCB *this;

	DISABLE_INTERRUPTS();
	if (++pSemaphore->value <= 0){
    		// get first task in line
    		this = pSemaphore->front;
    		// if this is only then reset semaphore pointers
    		if ((pSemaphore->front = this->nextTaskSemaphore) == 0){
    			pSemaphore->back = 0;
    		}   
    		this->nextTaskSemaphore = 0;
		atak_ResumeService(this);
    		ENABLE_INTERRUPTS();
    		//if (this->priority > proc_curpid->priority) used if priority used
    		//  atak_Scheduler();
  	}
	else ENABLE_INTERRUPTS();
} 
#pragma used-

#pragma used+
int atak_SignalSemaphoreInterrupt(SEMAPHORE *pSemaphore)
{
	TCB *this;

	if (++pSemaphore->value <= 0){
		this = pSemaphore->front;
		if ((pSemaphore->front = this->nextTaskSemaphore) == 0){
			pSemaphore->back = 0;
		}                        
		atak_ResumeService(this);
		return(1);
	}  
  	return(0);
}
#pragma used-  

#pragma used+
void atak_SemaphoreWait(SEMAPHORE *pSemaphore)
{
	TCB *this;
       
	// reset task semaphore
	currentRunningTask->nextTaskSemaphore = 0;              
	DISABLE_INTERRUPTS();
	if (--pSemaphore->value < 0){
       		if ((this = pSemaphore->back) == 0){                                
       			// there is one task using semaphore
      			pSemaphore->front = pSemaphore->back = currentRunningTask;    
 		}
       		else{                                                                  
       			// insert task at semaphore list tail 
      	       		this->nextTaskSemaphore = pSemaphore->back = currentRunningTask; 
    		}
       		// this task is blocked, thus sleeping until wake up call by signal
       		atak_ChangeStatus(currentRunningTask,ATAK_TASK_SLEEPING);
       		//currentRunningTask->task_Status = ATAK_TASK_SLEEPING;
		atak_SuspendService(currentRunningTask);
		// interrupt is enabled in suspendservice
  	}
  	else{
  		ENABLE_INTERRUPTS();
  	}
}
#pragma used-      

#pragma used+
void atak_InitMessageQueue(QUEUE *queuePointer, unsigned char size)
{       
	atak_InitSemaphore(&(queuePointer->busyBlock), 0);
	atak_InitSemaphore(&(queuePointer->fullBlock), size);
	queuePointer->ii = queuePointer->oi = 0;
	queuePointer->size = size;
}            
#pragma used-

#pragma used+
void atak_PostMessage(QUEUE *queuePointer, unsigned char data, char mode)
{
	unsigned char i;

	if(mode == NON_INTERRUPT_CALL){
		// checks semaphore whether queue is full, if so then postmessage is blocked!
		atak_SemaphoreWait(&(queuePointer->fullBlock));
       		DISABLE_INTERRUPTS();
	}
	else{
		if (queuePointer->fullBlock.value > 0) {
			queuePointer->fullBlock.value--;
		}
		else{
#ifdef LERROR		
			system.last_error.status = OVERFLOW_BY_INT;
	#ifdef TRACER
			system.last_error.currentTask = currentRunningTask->taskName;
	#endif	
			system.last_error.point = 3;
#endif			
			return;
		}	
	}	
	
	if ((i = (queuePointer->ii + 1)) >= queuePointer->size){
		i = 0;
	}
	queuePointer->fifo[i] = data;
	queuePointer->ii = i;
	
	if(mode == NON_INTERRUPT_CALL){
		ENABLE_INTERRUPTS();
		// signal semaphore that it is finished using put command for queue
		atak_SignalSemaphore(&(queuePointer->busyBlock));
	} 
	else{
		if(atak_SignalSemaphoreInterrupt(&(queuePointer->busyBlock)) == 0){ 
#ifdef LERROR		
			system.last_error.status = INTERRUPT_ERROR;
	#ifdef TRACER
			system.last_error.currentTask = currentRunningTask->taskName;
	#endif	
			system.last_error.point = 5;		
#endif			
		}
        } 	

}
#pragma used-             
             
#pragma used+

// When using a queue from an interrupt, do not disable interrupts
char atak_GetMessage(QUEUE *queuePointer, char mode)
{
	unsigned char  i; 
	char data;

	if(mode == NON_INTERRUPT_CALL){
		atak_SemaphoreWait(&(queuePointer->busyBlock));
       		DISABLE_INTERRUPTS();
	}
	else{
		if (queuePointer->busyBlock.value > 0) {
		queuePointer->busyBlock.value--;
		}
		else{
#ifdef LERROR		
			system.last_error.status = BUSY;   
	#ifdef TRACER
			system.last_error.currentTask = currentRunningTask->taskName;
	#endif			
			system.last_error.point = 4;			
#endif			
			return;
		}	
	}
	
	if ((i = (queuePointer->oi + 1)) >= queuePointer->size){
		i = 0;
	}
	data = queuePointer->fifo[i];
	queuePointer->oi = i;
	
	if(mode == NON_INTERRUPT_CALL){
		ENABLE_INTERRUPTS();
		atak_SignalSemaphore(&(queuePointer->fullBlock));		
	}
	else{
		if(atak_SignalSemaphoreInterrupt(&(queuePointer->fullBlock)) == 0){
#ifdef LERROR		
	       		system.last_error.status = INTERRUPT_ERROR;
	#ifdef TRACER
			system.last_error.currentTask = currentRunningTask->taskName;
	#endif	
			system.last_error.point = 6;		
#endif			
		}		        
        } 
	return(data);
}            
#pragma used-
                   
#pragma used+                   
void  atak_Delay(unsigned int ticks)
{                  
BEGIN_CRIT_SECTION()  
	if(currentRunningTask->delay == 0){        
		// reset counter
		currentRunningTask->delay = ticks;
		// suspend immediately  
		atak_ChangeStatus(currentRunningTask,ATAK_TASK_DELAYED);
		atak_SuspendService(currentRunningTask);				
	} 
}            
#pragma used-       
                   
atak_TASK(Idle,arg)
{        
       	arg = arg;
	
        while(1)
        {
		if(system.task_counter > 1){
			atak_Scheduler(FORCE_RESCHEDULE); 
		}     
	}       	
}
                                                 
/* This kernel service should be placed in a interrupt call like a timer overflow/compare,
/  the tick time depends on the timer settings */
#pragma used+  
void  atak_SchedulerEntry(void)
{              
	LIST_ITEM* temp;
	void* owner;
	TCB* tcb;
	
	// Update system tick every interrupt call
	system.system_tick++;
	system.delay_tick++;
	
	// call the scheduler	
	atak_Scheduler(TIMESLICE_SCHEDULE);  	
	
	if( (headDelayedTask != 0) && (system.delay_tick >= DELAY_RESOLUTION) ){
		system.delay_tick = 0;
		temp = headDelayedTask->next;
		// follow through whole sleeping tcb list, end list should be zero		
		while(temp != headDelayedTask){
			owner = temp->owner;
			tcb = (TCB*) owner; 
			
			// first get next, before resuming this item
			temp = temp->next;
			       		
			atak_UpdateDelayTasks(tcb);	
		}
		owner = temp->owner;
		tcb = (TCB*) owner;
	        atak_UpdateDelayTasks(tcb);	
	} 
}
#pragma used-        

void atak_UpdateDelayTasks(TCB* tcb)
{    
	if(tcb->delay > 0){
		// decrement system delay counter for tcb
		tcb->delay--;    
		// if ticks are decremented to zero, wake up task
		if(tcb->delay == 0){
			// take tcb of sleeping list 
		       	atak_ResumeService(tcb);
		}
	} 
}
                     
#pragma used+
TCB*  atak_ChangeStatus(TCB* tcb,unsigned char status)
{               
	tcb->status = status;
	return tcb;
}
#pragma used-             
                          
#pragma used+
void atak_uDelay(unsigned int delay)
{          
	// each NOP takes about 1 CLK at 4 MHz 0.25 us per NOP  
	// 			      at 8 MHz 0.125 us per NOP	
	
	// LDI 1 CLK
	// DEC 1 CLK
	// NOP 1 CLK
	// CPI 1 CLK 
	// BRNE 1/2 CLK	
	
	// 1 + (1 + n*NOP + 1 + 1/2)*DELAY_RESOLUTION_u - 1/2
	unsigned int x = 0;
	for(x = 0; x<delay; x++){
#asm      
	ldi r25,DELAY_RESOLUTION_u
loop: 
	dec r25
	nop
	cpi r25,$00
	brne loop
#endasm     
	}
}                         
#pragma used-             