/********************************************************************/
/********************************************************************/
/*																	*/
/*						Simple CPU Emulator							*/
/*																	*/
/********************************************************************/
/********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "cpu.h"

CPU c;

void SystemHandler(BYTE SysFunc,void *Status)
{
	printf("* SYSTEM FUNCTION %d [%s] *\n",SysFunc,CPUGetSysCallName(SysFunc));
    CPUDump((CPU *)Status,stdout);
    if (SysFunc == SYS_GFXSPRITE)
	        c.PC += c.Memory[c.PC]+1;
}

void main(void)
{
    int ch;
	CPUReset(&c,"TEST.BIN");
    c.SysHandler = SystemHandler;
    CPUDump(&c,stdout);
    while (ch = getch(),ch == ' ')
    {
    	CPUExecute(&c);
        CPUDump(&c,stdout);
    }
}