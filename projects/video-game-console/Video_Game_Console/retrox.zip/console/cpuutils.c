/********************************************************************/
/********************************************************************/
/*																	*/
/*					General Functions for the CPU					*/
/*																	*/
/********************************************************************/
/********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cpu.h"

/********************************************************************/
/*						Reset an emulated CPU						*/
/********************************************************************/

void CPUReset(CPU *Cpu,char *FileName)
{
	int i;
    FILE *f;
    Cpu->SP = 0;						/* Empty Stack */
    Cpu->PC = 0;						/* PC is zero */
    Cpu->SysHandler = (HANDLER)NULL;	/* And no handler is installed */

    for (i = 0;i < 64;i++)				/* Randomise registers & stack */
    				Cpu->Reg[i] = rand() & 0xFF;
    for (i = 0;i < 8;i++)
    				Cpu->Stack[i] = rand() & 0xFFF;

    if (FileName != NULL)				/* File load required */
    {
    	for (i = 0;						/* Erase memory */
        	i < sizeof(Cpu->Memory);i++) Cpu->Memory[i] = 0;
    	f = fopen(FileName,"rb");		/* Open file */
        Cpu->CodeSize = 0;				/* No code */
        if (f != NULL)					/* Opened okay */
        {
        	Cpu->CodeSize =				/* Read in the program */
            	fread(Cpu->Memory,1,sizeof(Cpu->Memory),f);
            fclose(f);					/* Close the source file */
        }
    }
}

/********************************************************************/
/*					Dump the CPU to a given stream					*/
/********************************************************************/

void CPUDump(CPU *Cpu,FILE *Stream)
{
	int i;
	fprintf(Stream,"PC:%03X    %s\n",Cpu->PC,CPUDisassemble(Cpu->Memory+Cpu->PC));
    for (i = 0;i < 64;i++)
    {
		if (i % 16 == 0) fprintf(Stream,"    R%02x: ",i);
		fprintf(Stream,"%02X ",Cpu->Reg[i]);
		if (i % 16 == 7) fprintf(Stream,": ");
        if (i % 16 == 15) fprintf(Stream,"\n");
    }
    fprintf(Stream,"    Stack:  ");
    i = Cpu->SP-1;
    while (i >= 0) fprintf(Stream," %03X",Cpu->Stack[i--]);
    fprintf(Stream,"\n");
}

/********************************************************************/
/*						Disassemble an instruction					*/
/********************************************************************/

char *CPUDisassemble(BYTE *p)
{
	unsigned int Opcode;
    static char Buffer[32];
    Opcode = *p++;						/* Read the opcode */
    if ((Opcode >> 4) == O_CALL)		/* Call is a special case */
    {
        sprintf(Buffer,"%-4s %1X%02X",
	                    CPUBaseOpcodeToText(O_CALL),Opcode & 0xFF,*p);
    }
    else								/* All the others */
    {
    	sprintf(Buffer,"%-4s ",			/* Get text name */
        			CPUBaseOpcodeToText(Opcode >> 4));
        Opcode = Opcode & 0x0F;			/* Work out address mode */
        if (Opcode < 8)					/* Direct */
	        	sprintf(Buffer+strlen(Buffer),"r%d",Opcode & 7);
        if (Opcode >= 8 && Opcode < 15)	/* Indirect */
	        	sprintf(Buffer+strlen(Buffer),"[r%d]",Opcode & 7);
        if (Opcode == 15)				/* Immediate */
	        	sprintf(Buffer+strlen(Buffer),"#%X",*p);
    }
	return Buffer;
}

/********************************************************************/
/*				Calculate the length of an opcode					*/
/********************************************************************/

int CPULength(int Opcode)
{
	if ((Opcode >> 4) == O_CALL)		/* Calls are all 2 */
    						return 2;
    return ((Opcode & 15) == 15)		/* Of the rest, only imm. are 2 */
	    						? 2 : 1;
}

/********************************************************************/
/*		Convert a CPU Base Opcode (0-15) to a text equivalent		*/
/********************************************************************/

char *CPUBaseOpcodeToText(int Base)
{
	char *Name = NULL;
	switch(Base)
    {
		case O_CALL:	Name = "call";break;
		case O_LDR:		Name = "ldr";break;
        case O_STR:		Name = "str";break;
        case O_ADD:		Name = "add";break;
        case O_SUB:		Name = "sub";break;
        case O_AND:		Name = "and";break;
        case O_OR:		Name = "or";break;
        case O_XOR:		Name = "xor";break;
        case O_INC:		Name = "inc";break;
        case O_DEC:		Name = "dec";break;
        case O_SYS:		Name = "sys";break;
        case O_BRA:		Name = "bra";break;
        case O_SKZ:		Name = "skz";break;
        case O_SKNZ:	Name = "sknz";break;
        case O_XCH:		Name = "xch";break;
        case O_RET:		Name = "ret";break;
    }
    return Name;
}

/********************************************************************/
/*				Convert System Call Number to Name					*/
/********************************************************************/

char *CPUGetSysCallName(int CallID)
{
	char *Name = NULL;
    switch(CallID)
    {
	    case SYS_GFXCLEAR:		Name = "GFXClear";break;
    	case SYS_GFXSPRITE:		Name = "GFXSprite";break;
	    case SYS_GFXCHAR:		Name = "GFXChar";break;
	    case SYS_SYSSETTIMER:	Name = "SYSSetTimer";break;
    	case SYS_SYSGETTIMER:	Name = "SYSGetTimer";break;
	    case SYS_SYSSETSOUND:	Name = "SYSSetSound";break;
        case SYS_SYSRANDOM:		Name = "SYSRandom";break;
		case SYS_KEYREAD:		Name = "KEYRead";break;
		case SYS_SETPLAYERCOUNT:Name = "KEYSetPlayerCount";break;
		case SYS_SETPITCH:		Name = "SYSSetPitch";break;
    }
    return Name;
}

/********************************************************************/
/*					   Convert a key mask to a name					*/
/********************************************************************/

char *CPUKeyMaskToName(int Mask)
{
	char *Name = NULL;
	switch(Mask)
	{
		case KEYB_UP:	Name = "KEYBUp";break;
		case KEYB_DOWN:	Name = "KEYBDown";break;
		case KEYB_LEFT:	Name = "KEYBLeft";break;
		case KEYB_RIGHT:Name = "KEYBRight";break;
		case KEYB_FIRE:	Name = "KEYBFire";break;
	}
	return Name;
}

/********************************************************************/
/*							CPU Emulation							*/
/********************************************************************/

void CPUExecute(CPU *Cpu)
{
	BYTE Opcode,Operand,Mode;
    BYTE *DatPtr;
    UINT Result,Tgt;
    Cpu->PC = Cpu->PC & 0xFFF;			/* Force into range */
    Opcode = Cpu->Memory[Cpu->PC++];	/* Fetch an instruction */

    if ((Opcode >> 4) == O_CALL)		/* Handle CALL seperately */
    {
    	Tgt = (Opcode & 0x0F);			/* Get MSNibble of target */
        Operand=Cpu->Memory[Cpu->PC++];	/* Get the lower byte */
        Tgt = (Tgt << 8) + Operand;		/* Make the target address */
        Cpu->Stack[Cpu->SP] = Cpu->PC;	/* Push the PC */
        Cpu->SP = (Cpu->SP+1) & 7;		/* Bump the stack pointer */
		Cpu->PC = Tgt;					/* Set the new address */
		return;							/* And exit */
    }

    									/* Make DatPtr point to EAC */
    Mode = Opcode & 0x0F;				/* Isolate address mode, lower bits */
    if (Mode < 8)						/* 0-7 is Direct mode */
    		DatPtr = &(Cpu->Reg[Mode]);
	if (Mode >= 8 && Mode < 15)			/* 8-14 is Indirect Mode */
	    	DatPtr = &(Cpu->Reg[(Cpu->Reg[Mode & 7]) & 63]);
    if (Mode == 15)						/* 15 is Immediate Mode */
    {
    	Operand=Cpu->Memory[Cpu->PC++];	/* Get the operand to a temp. var */
    	DatPtr = &Operand;				/* Use a pointer to that */
    }									/* INC #42 does *NOT* write ProgMem */

    switch(Opcode >> 4)					/* Decode it */
    {
 	case O_LDR:               			/* LDR: Load Register R0 */
    	Cpu->Reg[0] = *DatPtr;break;
    case O_STR:							/* STR: Store Register R0 */
    	*DatPtr = Cpu->Reg[0];break;
    case O_ADD:							/* ADD: Add to Register R0 */
    	Result = Cpu->Reg[0] + (*DatPtr);
		Cpu->Reg[0] = Result & 0xFF;
        Cpu->Reg[7] = (Result >> 8) & 1;
        break;
    case O_SUB:							/* SUB : Sub from Register R0 */
    	Result = Cpu->Reg[0] + ((*DatPtr)^0xFF) + 1;
		Cpu->Reg[0] = Result & 0xFF;
        Cpu->Reg[7] = (Result >> 8) & 1;
        break;
	case O_AND:							/* AND : And with Register R0 */
    	Cpu->Reg[0] &= (*DatPtr);break;
	case O_OR:							/* OR  : Or with Register R0 */
    	Cpu->Reg[0] |= (*DatPtr);break;
	case O_XOR:							/* XOR : Xor with Register R0 */
    	Cpu->Reg[0] ^= (*DatPtr);break;
	case O_INC:							/* INC : Increment Register */
    	*DatPtr = ((*DatPtr)+1) & 0xFF;break;
	case O_DEC:							/* DEC : Increment Register */
    	*DatPtr = ((*DatPtr)-1) & 0xFF;break;
    case O_SYS:							/* SYS : Call Library Function */
    	if (Cpu->SysHandler != NULL)
	            (*(Cpu->SysHandler))(*DatPtr,Cpu);
        break;
    case O_BRA:							/* BRA : Branch Relative */
    	Tgt = *DatPtr;					/* Get offset */
        if (Tgt & 0x80)					/* Sign extend it */
	        	Tgt = -128+(Tgt & 0x7F);
        Cpu->PC = (Cpu->PC+Tgt) & 0xFFF;/* Do the branch */
        break;
    case O_SKZ:             			/* SKZ : Skip if zero */
    	if (*DatPtr == 0)
        	Cpu->PC = Cpu->PC + CPULength(Cpu->Memory[Cpu->PC]);
        break;
    case O_SKNZ:             			/* SKNZ : Skip if not zero */
    	if (*DatPtr != 0)
        	Cpu->PC = Cpu->PC + CPULength(Cpu->Memory[Cpu->PC]);
        break;
    case O_XCH:             			/* XCH : Exchange with R0 */
    	Tgt = *DatPtr;*DatPtr = Cpu->Reg[0];Cpu->Reg[0] = Tgt;
    	break;
    case O_RET:							/* RET : Return & Load */
    	Cpu->Reg[0] = *DatPtr;			/* Data copy */
        Cpu->SP = (Cpu->SP-1) & 0x7;	/* Decrement the stack pointer */
        Cpu->PC = Cpu->Stack[Cpu->SP];	/* Get the return address */
        break;
    }
}

