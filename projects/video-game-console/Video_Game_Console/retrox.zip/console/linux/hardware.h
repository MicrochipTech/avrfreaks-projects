/********************************************************************/
/********************************************************************/
/*																	*/
/*				  Include file, hardware interface					*/
/*																	*/
/********************************************************************/
/********************************************************************/

void HWInitialise(void);				/* Function prototypes */
void HWTerminate(void);
void HWGraphicsMode(void);
void HWTextMode(void);
long HWClock(void);
int  HWIsKeyPressed(int);
void HWSetSound(int,int);
void HWSetPixel(int,int,int);
int  HWGetPixel(int,int);

#define ESCAPE	(-1)					/* Escape/Exit key */
#define RESET	(-2)					/* Reset key */

#ifdef ALLEGRO							/* Allegro includes */
#include <allegro.h>
#endif

