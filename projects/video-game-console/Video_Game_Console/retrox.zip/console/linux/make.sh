gcc `allegro-config --cflags` -DUNIX -DALLEGRO  -o retro retro.c cpuutils.c hardware.c `allegro-config --libs`
