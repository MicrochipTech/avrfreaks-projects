/********************************************************************/
/********************************************************************/
/*																	*/
/*			   Convert named file to assembler include				*/
/*																	*/
/********************************************************************/
/********************************************************************/

#include <stdio.h>
#include <stdlib.h>

unsigned char Code[8192];				/* Buffer for code */

void main(int argc,char *argv[])
{
	FILE *f;
    int  n,Size;
	if (argc != 2)            			/* No parameter */
    	exit(fprintf(stderr,"TOHEX <binary file>\n\n"));
    for (n = 0;n < sizeof(Code);n++)	/* Fill buffer */
    						Code[n] = 0xFF;
    f = fopen(argv[1],"rb");			/* Open file */
    if (f == NULL)						/* Check opened ok */
    	exit(fprintf(stderr,"Can't open '%s'\n",argv[1]));
	Size = fread(Code,1,8192,f);		/* Read program and close it */
    fclose(f);
    if (Size % 2 != 0) Size++;			/* Make it an even number of bytes */
    for (n = 0;n < Size;n++)			/* Work through them */
    {
    	if (n % 16 == 0)				/* Every 16, new line */
        		printf("\n        .db ");
        else printf(",");				/* otherwise comma */
        printf("$%02X",Code[n]);		/* then the number */
    }
    printf("\n");						/* End line */
}
