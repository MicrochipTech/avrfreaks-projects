/*

	Generate Graphics for Combat

*/

#include <stdio.h>
#include <conio.h>

static char *Tank1[5] = {				/* Tank, straight up */
	 "..x..",
	 "x.x.x",
	 "xxxxx",
	 "xxxxx",
	 "x...x" };

static char *Tank2[5] = {				/* Tank, up and left */
	 "..x.x",
	 ".xxx.",
	 "xxxxx",
	 ".xxx.",
	 "..x.."
     };

static char *Plane1[5] = {				/* Plane, straight up */
	 "..x..",
	 ".xxx.",
	 ".xxx.",
	 "xxxxx",
	 "x...x" };

static char *Plane2[5] = {				/* Plane, up and left */
	 "..xxx",
	 "xxxxx",
	 ".xxxx",
	 "..xx.",
	 "...x." };

void GenerateCode(char **UpChar,char **UpRtChar,char *FileName);
void LoadBitmap(int *BitMap,char **Def);
void RotateBitmap(int *BitMap);

void main()
{
	GenerateCode(Tank1,Tank2,"com_tank.inc");
	GenerateCode(Plane1,Plane2,"com_plan.inc");
}

void GenerateCode(char **UpChar,char **UpRtChar,char *FileName)
{
	FILE *f = fopen(FileName,"w");
	int i,j,BitMap[5];
	fprintf(f,"; Generated with program Combat.C\n");
	for (i = 0;i < 8;i++)
	{
		fprintf(f,"    sys #GFXSprite\n");
		fprintf(f,"    .db 5\n");
		if (i % 2 == 0) LoadBitmap(BitMap,UpChar);
		else 			LoadBitmap(BitMap,UpRtChar);

		for (j = 0;j < i/2;j++) RotateBitmap(BitMap);

		fprintf(f,"    .db $%02x,$%02x,$%02x,$%02x,$%02x\n",
						BitMap[0],BitMap[1],BitMap[2],BitMap[3],BitMap[4]);
		fprintf(f,"    ret\n");
	}
	fclose(f);
}

void LoadBitmap(int *BitMap,char **Def)
{
	int i,j;
	for (i = 0;i < 5;i++)
	{
		BitMap[i] = 0;
		for (j = 0;j < 5;j++)
			 if (Def[i][j] != '.') BitMap[i] += (0x80 >> j);
	}
}

void RotateBitmap(int *Bitmap)
{
	int i,j;
	int Old[5];
	for (i = 0;i < 5;i++)
	{
		Old[i] = Bitmap[i];
		Bitmap[i] = 0;
	}
	for (i = 0;i < 5;i++)
		for (j = 0;j < 5;j++)
			if (Old[i] & (0x80 >> j))
			{
				Bitmap[j] |= (0x80 >> 4-i);
			}
}

