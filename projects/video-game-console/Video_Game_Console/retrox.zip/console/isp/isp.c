/*

				ISP for Elf Simulator in Hardware

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <dos.h>

void Reset(void);
unsigned long DoCommand(unsigned Send1,unsigned Send2,
									unsigned Send3,unsigned Send4);
unsigned long DoByte(unsigned long Send);
unsigned long Read(unsigned long Addr);
void Write(unsigned long Addr,unsigned long Value);
void Pause(void);
void LongPause(void);
void ProgramLinear(char *FileName);

unsigned int Port;
unsigned long PinDelay = 3400L;
unsigned long WriteDelay = 90000L;

int main(int argc,char *argv[])
{
	int i;
    long l;
	Port = 0x378;
    for (i = 1;i < argc;i++)
    {
    	switch(toupper(*argv[i]))
        {
        case 'P':
        	sscanf(argv[i]+1,"%x",&Port);
            break;
        case 'S':
        	sscanf(argv[i]+1,"%d",&l);
            PinDelay = PinDelay * l / 100L;
            WriteDelay = WriteDelay * l / 100L;
			break;
        }
    }
    printf("Port = $%03x. Delay = %ld\n\n",Port,WriteDelay);
    printf("Connections :-\n");
    printf("     LPT : D0  (Pin 2)  to 8515 SCK  (PB7)\n");
    printf("     LPT : D1  (Pin 3)  to 8515 MOSI (PB5)\n");
    printf("     LPT : D2  (Pin 4)  to 8515 Reset pin\n");
    printf("     LPT : ACK (Pin 10) to 8515 MISO (PB6)\n");
    printf("     LPT : GND (Pin 25) to 8515 0v\n\n");

	Reset();							/* Reset processor */
	DoCommand(0xAC,0x53,0,0);			/* Enable Programming */
	printf("Device Manufacturer : %02lx [$1E = Atmel]\n",
    					DoCommand(0x30,0xA5,0,0x5A) & 0xFF);
	printf("Device Size Code    : %02lx\n",
    					DoCommand(0x30,0xA5,1,0x5A) & 0xFF);
	i = (int)(DoCommand(0x30,0xA5,2,0x5A) & 0xFF);
	printf("Device Subcode      : %02x\n",i);
    if (i != 0x01)
    {
    	fprintf(stderr,"Device is not an AT90S815\n");
        outportb(Port,0xFF);
        exit(1);
    }

	DoCommand(0xAC,0x80,0,0);			/* Erase Flash */
    LongPause();
	Reset();							/* Reset processor */
    ProgramLinear("MAIN.HEX");
	outportb(Port,0xFF);
    return(0);
}

void Reset(void)
{
	outportb(Port,0);					/* Take all low */
	LongPause();
	outportb(Port,0x4);					/* Take reset high */
	LongPause();
	outportb(Port,0);					/* Take all low */
	LongPause();

	DoCommand(0xAC,0x53,0,0);
}

unsigned long DoCommand(unsigned Send1,unsigned Send2,
									unsigned Send3,unsigned Send4)
{
	unsigned long Result;
	Result = DoByte(Send1);
	Result = DoByte(Send2);
	Result = Result * 256 + DoByte(Send3);
	Result = Result * 256 + DoByte(Send4);
	return(Result);
}

unsigned long DoByte(unsigned long Send)
{
	unsigned long Bit,Res,BitV;

	Res = 0;
	for (Bit = 7; Bit < 8;Bit--)
	{
    	Pause();
		Res = Res * 2;
		if (inportb(Port+1) & 64) Res++;
		BitV = (Send & (1 << Bit)) ? 2 : 0;
		outportb(Port,BitV);Pause();
		outportb(Port,BitV+1);Pause();
		outportb(Port,BitV);Pause();
	}
	return(Res);
}

void Pause(void)
{
	long l;
	for (l = 0;l < PinDelay;l++) {}
}

void WritePause(void)
{
	long l;
	for (l = 0;l < WriteDelay;l++) {}
}

void Write(unsigned long Addr,unsigned long Value)
{
	DoCommand(0x48,(int)Addr/256,(int)Addr%256,(int)Value/256);
	WritePause();
	DoCommand(0x40,(int)Addr/256,(int)Addr%256,(int)Value%256);
    WritePause();
}

unsigned long Read(unsigned long Addr)
{
	unsigned long Result,Temp;

	Result = DoCommand(0x20,(int)Addr / 256,(int)Addr % 256,0);
	Result = Result & 0xFF;

	Temp = DoCommand(0x28,(int)Addr / 256,(int)Addr % 256,0);
	Temp = Temp & 0xFF;

	Result = Result + 256*Temp;
	return(Result);
}

void LongPause(void)
{
	long t = clock() + 2L;
    while (clock() < t) {}
}

void ProgramLinear(char *FileName)
{
	unsigned int Addr,Word,n = 0;
    char Buffer[182];
	FILE *f;
    f = fopen(FileName,"r");
    if (f == NULL) exit(fprintf(stderr,"No file.\n"));
	while (fgets(Buffer,sizeof(Buffer),f) != NULL)
    {
    	if (sscanf(Buffer,"%x:%x",&Addr,&Word) == 2)
        {
			Write(Addr,Word);
        	if (Read(Addr) != Word)
            	exit(fprintf(stderr,"BAD: %x %x %x\n",Addr,Word,Read(Addr)));
            if (n % 256 == 0)
            	printf("Written %d words.\n",n);
            n++;
        }
    }
    fclose(f);
}
