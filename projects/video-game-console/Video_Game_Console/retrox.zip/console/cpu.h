/********************************************************************/
/********************************************************************/
/*																	*/
/*					Generic Constants for the CPU					*/
/*																	*/
/********************************************************************/
/********************************************************************/

#define	O_CALL	(0)						/* Opcode Constants */
#define O_LDR	(1)
#define O_STR	(2)
#define O_ADD	(3)
#define O_SUB	(4)
#define O_AND	(5)
#define O_OR 	(6)
#define O_XOR	(7)
#define O_INC	(8)
#define O_DEC	(9)
#define O_SYS	(10)
#define O_BRA	(11)
#define O_SKZ	(12)
#define O_SKNZ	(13)
#define O_XCH	(14)
#define O_RET	(15)

#define	SYS_GFXCLEAR		(0)			/* System functions */
#define SYS_GFXSPRITE		(1)
#define SYS_GFXCHAR			(2)
#define	SYS_SYSSETTIMER		(3)
#define SYS_SYSGETTIMER		(4)
#define SYS_SYSSETSOUND		(5)
#define SYS_SYSRANDOM		(6)
#define SYS_KEYREAD			(7)
#define SYS_SETPLAYERCOUNT	(8)
#define SYS_SETPITCH		(9)

#define	SCREENX		(64)				/* Screen size */
#define SCREENY		(48)

#define KEYB_UP				(0x01)		/* Keypad bitmasks */
#define KEYB_DOWN			(0x02)
#define KEYB_LEFT			(0x04)
#define KEYB_RIGHT			(0x08)
#define KEYB_FIRE			(0x80)

#define HASIMMEDIATE(o)	((o) != O_INC && (o) != O_DEC && (o) != O_STR && (o) != O_XCH)

typedef unsigned char BYTE;				/* 8 bit byte structure */
typedef unsigned int  UINT;				/* 16 bit word structure */

typedef	void (*HANDLER)(BYTE,void *);	/* SYS command handler */

typedef struct _CPU						/* Structure representing the CPU */
{
	BYTE	Memory[4096];				/* Program Memory */
	BYTE	Reg[64];					/* The registers */
    UINT	Stack[8];					/* The stack */
    BYTE	SP;							/* The stack pointer */
    UINT	PC;							/* The program counter */
    HANDLER	SysHandler;					/* System function handler */
    int		CodeSize;					/* Bytes read */
} CPU;

char *CPUBaseOpcodeToText(int);			/* Convert opcode base to text */
void CPUReset(CPU *,char *);			/* Reset the CPU */
void CPUDump(CPU *,FILE *);				/* Dump the CPU */
char *CPUDisassemble(BYTE *);			/* Disassemble an instruction */
int  CPULength(int);					/* Return the length of an instruction */
void CPUExecute(CPU *);					/* Execute an instruction */
char *CPUGetSysCallName(int);			/* Get name of system call */
char *CPUKeyMaskToName(int);
