gcc -DALLEGRO  -o retro retro.c cpuutils.c hardware.c
