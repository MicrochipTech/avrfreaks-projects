/********************************************************************/
/********************************************************************/
/*																	*/
/*					Generate TASM Table for the CPU					*/
/*																	*/
/********************************************************************/
/********************************************************************/

#include <stdio.h>
#include <string.h>
#include "cpu.h"

static char *Colour[7] =
	{ "Blue","Green","Cyan","Red","Purple","Yellow","White" };

void main(void);
void GenerateEntry(int Base,FILE *f);

void main(void)
{
	int i;
    char *p;
    FILE *f = fopen("TASM1.TAB","w");
    fprintf(f,"\"Retro Asm\"\n\n");		/* Heading */
    fprintf(f,".MSFIRST\n");			/* CALL goes MSB LSB */
	fprintf(f,"LDR  #0     %02X   1 NOP 1\n",O_XOR*16);
    for (i = 0;i < 16;i++)				/* Work through the opcodes */
    {
        if (i == O_CALL)				/* Call is special */
			    fprintf(f,"CALL *      %04X 2 T1 1 0 0FFF\n",i * 16);
        else
		    	GenerateEntry(i,f);
    }
    									/* Other cases... */
    fprintf(f,"RET  \"\"     %02X   1 NOP 1\n",O_RET*16);
    fprintf(f,"NOP  \"\"     %02X   1 NOP 1\n",O_LDR*16);
	fprintf(f,"JMP  *      %02X   2 R1  1\n",O_BRA*16+15);
	fprintf(f,"CLR  R0     %02X   1 NOP 1\n",O_XOR*16);
    fclose(f);

	f = fopen("Retro.Inc","w");
	fprintf(f,"SWidth  .equ %d\n",SCREENX);
	fprintf(f,"SHeight .equ %d\n",SCREENY);
    fprintf(f,";\n");
	for (i = 0;i < 8;i++)
		fprintf(f,"r%-11d .equ    %d\n",i,i);
    fprintf(f,";\n");
	for (i = 0;i < 7;i++)
		fprintf(f,"C%-11s .equ    %d\n",Colour[i],(i+1) << 4);
	fprintf(f,"XORDraw      .equ    $80\n");
    fprintf(f,";\n");
    i = 0;
    while (p = CPUGetSysCallName(i),p != NULL)
    {
    	if (*p != '\0')
			fprintf(f,"%-20s .equ    $%04x\n",p,i);
        i++;
	}
	i = 0x01;
    fprintf(f,";\n");
	while (i < 0x100)
	{
		p = CPUKeyMaskToName(i);
		if (p != NULL) fprintf(f,"%-12s .equ    $%02x\n",p,i);
		i = i << 1;
	}
    fclose(f);
}

void GenerateEntry(int Base,FILE *f)
{
	char Text[32];
    strcpy(Text,CPUBaseOpcodeToText(Base));
    strupr(Text);
    									/* Standard register direct */
    fprintf(f,"%-4s [*]    %02X   1 TDMA 1 0 7\n",Text,Base*16+8);
    									/* Immediate if it is there */
    if (HASIMMEDIATE(Base))
    		fprintf(f,"%-4s #*     %02X   2 NOP  1\n",Text,Base*16+15);
            							/* Indirect */
    fprintf(f,"%-4s *      %02X   1 TDMA 1 0 7\n",Text,Base*16);
}

