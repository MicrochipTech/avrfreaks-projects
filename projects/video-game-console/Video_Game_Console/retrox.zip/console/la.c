#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void Process(char *Str);

void main(int argc,char *argv[])
{
	FILE *f;
    char Buffer[256];
	if (argc != 2) exit(fprintf(stderr,"LA <file>\n"));
    f = fopen(argv[1],"r");
    if (f == NULL) exit(fprintf(stderr,"Can't open %s\n",argv[1]));
    while (fgets(Buffer,sizeof(Buffer),f) != NULL)
    {
    	while (Buffer[0] != '\0' && Buffer[strlen(Buffer)-1] <= ' ')
								        	Buffer[strlen(Buffer)-1] = '\0';
        Process(Buffer);
    }
    fclose(f);
}

void Process(char *Str)
{
	char *p = Str;
    if (*p == '0')
    {
    	while (isxdigit(*p) ||
        	   *p == ' ' && isxdigit(p[1]))
        {
        	*p++ = ' ';
        }
    }
    if (strlen(Str) >= 9 &&				/* Comment */
    					Str[9] == ';')
    {
    	printf("%s\n",Str+9);
        return;
    }
    if (Str[10] != ' ' &&				/* Label */
    			strlen(Str) >= 10)
    {
    	printf("%s\n",Str+10);
        return;
    }
    while (*Str == ' ' || *Str == '\t') Str++;
    printf("        %s\n",Str);
}