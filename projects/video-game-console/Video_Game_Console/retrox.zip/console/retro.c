/********************************************************************/
/********************************************************************/
/*																	*/
/*							Full Emulator							*/
/*																	*/
/********************************************************************/
/********************************************************************/

#include <stdio.h>						/* Standard Includes */
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "cpu.h"						/* Our includes */
#include "hardware.h"

CPU	Cpu;								/* CPU state */
int SysTimer;							/* System timer (50Hz) */
int SysSound;							/* Sound timer (50Hz) */
long LastClock;							/* Last clock */
int  ModCounter;
int  Pitch;								/* Current pitch */
int  Monochrome;						/* Force black and white */

void SystemHandler(BYTE Func,void *Status);
void DrawSprite(CPU *c,BYTE *pSprite);
void SystemReset(void);
void RunProgram(int BreakPoint);
void RunDebugger(void);
static int TogglePixel(int x,int y,int Colour);

/********************************************************************/
/*							Main program							*/
/********************************************************************/

int main(int argc,char *argv[])
{
	HWInitialise();						/* Initialise hardware */
	Monochrome = 0;
	if (argc > 1 && *argv[1] == '-')
	{
		Monochrome = 1;
		argv[1]++;
	}
    CPUReset(&Cpu,						/* Reset and load */
    			argc == 1 ? "test.bin" : argv[1]);
    SystemReset();
    #ifdef DEV							/* Decide what to do */
    RunDebugger();
    #else
    RunProgram(-1);
    #endif
	HWTerminate();       				/* End hardware */
	return 0;
}

/********************************************************************/
/*				Run program to breakpoint or ESCAPE					*/
/********************************************************************/

void RunProgram(int BreakPoint)
{
	int i,ICount = 0;
    long NewClock;
    HWGraphicsMode();					/* Switch to graphics mode */
    while (HWIsKeyPressed(ESCAPE) == 0	/* Until escape or breakpoint */
		    			&& Cpu.PC != BreakPoint)
    {
		for (i = 0;i < 64 && Cpu.PC != BreakPoint;i++)
	        if (ICount > 0)
    	    {
		        CPUExecute(&Cpu);
	            ICount--;
            }
		NewClock = HWClock();			/* Read new clock */
        i = (int)(NewClock-LastClock);	/* Difference ? */
        LastClock = NewClock;
        if (i != 0)          			/* Clock time elapsed */
        {
        	SysTimer = SysTimer - i;	/* Change system timer */
            if (SysTimer < 0) SysTimer = 0;
            SysSound = SysSound - i;	/* Change sound timer */
            if (SysSound < 0) SysSound = 0;
			HWSetSound(SysSound,Pitch);	/* Update sound */
	        if (HWIsKeyPressed(RESET))	/* Reset check */
				            	SystemReset();
			ICount = i * 150;			/* approx 150 instructions a frame */
            ICount = 32767;				/* No limit */
        }
    }
    HWTextMode();						/* Switch to text mode */
}

/********************************************************************/
/*							4 x 5 Font Data							*/
/********************************************************************/

static BYTE FontData[60] =
	{
    	5,0xF0,0x90,0x90,0x90,0xF0,		/* Digit 0 */
		5,0x10,0x10,0x10,0x10,0x10,		/* Digit 1 */
    	5,0xF0,0x10,0xF0,0x80,0xF0,		/* Digit 2 */
    	5,0xF0,0x10,0xF0,0x10,0xF0,		/* Digit 3 */
    	5,0x90,0x90,0xF0,0x10,0x10,		/* Digit 4 */
    	5,0xF0,0x80,0xF0,0x10,0xF0,		/* Digit 5 */
    	5,0xF0,0x80,0xF0,0x90,0xF0,		/* Digit 6 */
    	5,0xF0,0x10,0x10,0x10,0x10,		/* Digit 7 */
    	5,0xF0,0x90,0xF0,0x90,0xF0,		/* Digit 8 */
    	5,0xF0,0x90,0xF0,0x10,0xF0		/* Digit 9 */
	};
/********************************************************************/
/*						Handle System Calls							*/
/********************************************************************/

#define CHECK(Mask,Key) (HWIsKeyPressed(Key) ? Mask : 0)

void SystemHandler(BYTE Func,void *Status)
{
	CPU *c = (CPU *)Status;
	int n,x,y;
	char *p;
    switch(Func)           				/* Decide what to do.... */
    {
    case SYS_GFXCLEAR:					/* Clear the screen */
    	for (x = 0;x < SCREENX;x++)
        	for (y = 0;y < SCREENY;y++)
            	HWSetPixel(x,y,0);
        break;
    case SYS_GFXSPRITE:					/* Sprite at R0,R1 */
		DrawSprite(c,c->Memory+c->PC);	/* Draw it */
        c->PC = c->PC +					/* Bump the PC past the sprite */
					(c->Memory[c->PC] & 0x0F) + 1;
        break;
    case SYS_GFXCHAR:					/* Char R2 at R0,R1 */
    	c->Reg[7] = 0;					/* Clear collision */
    	if (c->Reg[2] < 10)				/* only if 0..9 */
			DrawSprite(c,FontData + (c->Reg[2] * 6));
        break;
    case SYS_SYSSETTIMER:				/* Set 50Hz Timer */
    	SysTimer = c->Reg[0];break;
    case SYS_SYSGETTIMER:				/* Get 50Hz Timer */
    	c->Reg[0] = SysTimer;break;
    case SYS_SYSSETSOUND:				/* Set 50Hz Sound Timer */
    	SysSound = c->Reg[0];
		HWSetSound(SysSound,Pitch);
        break;
	case SYS_SYSRANDOM:					/* Random number generator */
    	c->Reg[0] = rand() & 255;
        break;
	case SYS_KEYREAD:                	/* Read keypad */
		p = "ZXCFG";					/* Select keys */
		if (c->Reg[0]) p = "1236+";
		n = CHECK(0x01,p[3])+			/* Build the byte up */
				CHECK(0x02,p[2])+CHECK(0x04,p[0])+
				CHECK(0x08,p[1])+CHECK(0x80,p[4]);
		c->Reg[0] = n;					/* Store in R0 */
		break;
	case SYS_SETPLAYERCOUNT:			/* Set number of players */
		break;
	case SYS_SETPITCH:					/* Set the sound pitch */
		Pitch = c->Reg[0];break;
    }
}

/********************************************************************/
/*		Draw a sprite at R0,R1, given pointer to sprite data		*/
/********************************************************************/

void DrawSprite(CPU *c,BYTE *pSprite)
{
	int SizeByte,n,Pix,x,y,Count;
    y = c->Reg[1];     					/* Initial y position */
    x = c->Reg[0];						/* Initial x position */
    x = x & 0xFF;
    if (x & 0x80) x = x-256+SCREENX*10;
    y = y & 0xFF;
    if (y & 0x80) y = y-256+SCREENY*10;
    x = (x + SCREENX*10) % SCREENX;		/* Force into range */
    y = (y + SCREENY*10) % SCREENY;

    SizeByte = Count = *pSprite++;		/* Get vertical size of sprite */
    Count = Count & 0xF;				/* Mask off size */
    c->Reg[7] = 0;						/* Clear collision */
    while (Count > 0)					/* Until whole sprite done */
    {
    	x = c->Reg[0];					/* Reset x position */
        Pix = *pSprite++;				/* Get the pixel data */
        while (Pix != 0)				/* Until complete */
        {
        	if (Pix & 0x80)				/* Most sig. bit set ? */
			{
				n = TogglePixel(x,y,SizeByte >> 4);
                if (n != 0) c->Reg[7]=1;/* Set collision flag */
            }
        	x = (x + 1) % SCREENX;		/* One pixel to right */
            Pix = (Pix << 1) & 0xFF;	/* Shift pixel data */
        }
        y = (y + 1) % SCREENY;			/* Next line down */
        Count--;						/* One fewer lines to do */
    }
}

/********************************************************************/
/*					Toggle pixel appropriately						*/
/********************************************************************/

static int TogglePixel(int x,int y,int Colour)
{
	int n;
	n = HWGetPixel(x,y);	/* Read pixel */
	if (Monochrome) Colour = 0;
	if (Colour == 0)
		HWSetPixel(x,y,n == 0 ? 7 : 0);
	if (Colour > 0 && Colour < 8)
		HWSetPixel(x,y,n == 0 ? Colour:0);
	if (Colour >= 8)
		HWSetPixel(x,y,n^(Colour & 7));
	return (n != 0);
}

/********************************************************************/
/*						Reset the whole system						*/
/********************************************************************/

void SystemReset(void)
{
	HWSetSound(0,32);					/* Sound off */
	while (HWIsKeyPressed(RESET)) {};	/* Wait for reset release */
	Pitch = 32;							/* Reset the pitch */
    CPUReset(&Cpu,NULL);				/* Reset the CPU */
    LastClock = HWClock();				/* Read the clock */
    SysTimer = SysSound = 0;			/* Reset sound/timer hardware */
	Cpu.SysHandler = SystemHandler;		/* Set up the system call handler */
}

/********************************************************************/
/*							Run the debugger						*/
/********************************************************************/

void RunDebugger(void)
{
	char Line[64];
    int x,y,m;
	do
    {
    	printf("] ");					/* Display prompt */
        gets(Line);strupr(Line);		/* Get and convert line */
        m = Cpu.PC;sscanf(Line+1,"%x",&m);
        switch(*Line)					/* Decide on action */
        {
        case 'R':						/* [R] dump registers */
        	CPUDump(&Cpu,stdout);
            break;
        case 'M':						/* [Mxxx] dump memory */
        	for (x = 0;x < 8;x++)
            {
            	printf("%03x : ",m);
            	for (y = 0;y < 16;y++)
                {
                	printf("%02x ",Cpu.Memory[m]);
					m = (m+1) & 0xFFF;
                }
                printf("\n");
            }
            break;
        case 'D':
        	for (x = 0;x < 16;x++)		/* [Dxxx] disassemble code */
            {
            	printf("%03x : %s\n",m,CPUDisassemble(Cpu.Memory+m));
                m = m + CPULength(Cpu.Memory[m]);
            }
			break;
        case 'X':						/* [X] Execute program */
			RunProgram(-1);break;
        case 'G':						/* [Gxxx] run to breakpoint */
        	RunProgram(m);
            CPUDump(&Cpu,stdout);
            break;
        case 'S':						/* [S] Single Step */
        	CPUExecute(&Cpu);
            CPUDump(&Cpu,stdout);
            SysTimer = SysSound = 0;
			HWSetSound(0,Pitch);
            break;
        case 'V': 						/* [V] View Display */
        	HWGraphicsMode();
            getch();
            HWTextMode();
            break;
        }
        strupr(Line);
    } while (*Line != 'Q');				/* Until quit */
}

