/********************************************************************/
/********************************************************************/
/*																	*/
/*						Hardware I/O Functions						*/
/*																	*/
/********************************************************************/
/********************************************************************/

#include <stdio.h>						/* Standard includes */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>						/* MSDOS includes */
#include <dos.h>
#include <conio.h>
#include "cpu.h"
#include "hardware.h"

long	ClockStart;						/* Clock on initialisation */
int		CurrentKey;						/* Current key pressed */
long	KeyReleaseTime;					/* Time key should be released */
int		SoundState;						/* Current sound state */
char	Pixel[SCREENX][SCREENY];		/* Screen map */
int 	PixelGfx[4]={ 32,220,223,219 };	/* Pixel to character mapping */
int		xStart,yStart,xSize,ySize;		/* Pixel scaling */
int		InGraphic;						/* Graphic mode flag */

#ifdef ALLEGRO
SAMPLE 	*SoundSample;					/* Sound sample ptr for Allegro */
SAMPLE  *RandomSample;					/* White noise sample */
#else
unsigned char far *VideoRAM;			/* Screen Memory for Turbo C */
#endif

#define COL_PIXON	(0x0F)				/* for Turbo C only */
#define COL_PIXOFF	(0x00)

void    AllegroTimerProc(void);

/********************************************************************/
/*				Initialise all hardware functions					*/
/********************************************************************/

void HWInitialise(void)
{
	int x,y;
	double d;
	ClockStart = clock();				/* Remember the current time */
    CurrentKey = 0;KeyReleaseTime = 0;	/* Reset the keyboard I/O Stuff */
    SoundState = 0;						/* Sound off */
    for (x = 0;x < SCREENX;x++) 		/* Randomise all pixels */
    	for (y = 0;y < SCREENY;y++)
				        	Pixel[x][y] =  rand()&1;
	InGraphic = 0;
	#ifdef ALLEGRO						/* Allegro initialisation */
	allegro_init();						/* Init lib */
	install_keyboard();					/* Install keyboard,timer */
	install_timer();
	install_int(AllegroTimerProc,20);	/* Install 50Hz timer routine */
	install_sound(DIGI_AUTODETECT,		/* Install sound */
							MIDI_AUTODETECT,NULL);
	SoundSample = create_sample(8,0,	/* Create a simple sample */
								840,256);
	for (x = 0;x < SoundSample->len;x++)
		((BYTE *)SoundSample->data)[x] = x % 2 ? 255:0;
	RandomSample = create_sample(8,0,1840,256);
	for (x = 0;x < RandomSample->len;x++)
		((BYTE *)RandomSample->data)[x] = rand() & 255;
	#endif
}

/********************************************************************/
/*				Terminate all hardware functions					*/
/********************************************************************/

void HWTerminate(void)
{
	#ifdef ALLEGRO
	stop_sample(SoundSample);			/* Sound off allegro */
	stop_sample(RandomSample);
	#else
	nosound();							/* Sound off TC */
	#endif
}

/********************************************************************/
/*						Switch to graphics mode						*/
/********************************************************************/

void HWGraphicsMode(void)
{
	unsigned int x,y,n;
    union REGS r;
	InGraphic = 1;

	#ifdef GRAPH
    r.x.ax = 0x13;int86(0x10,&r,&r);	/* 320x200x256 Video Mode */
    VideoRAM = (unsigned char far *)	/* Pointer to VGA video memory */
    						(0xA000L << 16);
	x = 320*200;						/* Erase screen */
	while (x != 0) VideoRAM[--x] = COL_PIXOFF;
	#endif

	#ifdef TEXT
	textattr(0x17);clrscr();			/* Clear the screen */
    VideoRAM = (unsigned char far *)	/* Pointer to Text video memory */
    						(0xB800L << 16);
	#endif

	#ifdef ALLEGRO
	set_color_depth(8);					/* Switch to 640x480x8 */
	set_gfx_mode(GFX_AUTODETECT,640,480,0,0);
	#endif

    for (x = 0;x < SCREENX;x++) 		/* Actually refresh all pixels */
    	for (y = 0;y < SCREENY;y++)
        {
	      	n = Pixel[x][y];			/* Get state */
            Pixel[x][y] = 99;			/* Forces a redraw ! */
        	HWSetPixel(x,y,n);			/* Draw the pixel */
        }
}


/********************************************************************/
/*						Switch back to text mode					*/
/********************************************************************/

void HWTextMode(void)
{
	union REGS r;
	InGraphic = 0;
	#ifdef GRAPH						/* Return to text mode */
    r.x.ax = 0x03;int86(0x10,&r,&r);
    #endif
	textattr(0x7);clrscr();				/* Clear the screen */
}

/********************************************************************/
/*					Allegro 50Hz timer routine						*/
/********************************************************************/

#ifdef ALLEGRO

volatile long FrameTimer = 0L;			/* Tick counter, must be volatile */

void AllegroTimerProc(void)
{
	FrameTimer++;
}
#endif

/********************************************************************/
/*					 Return the 50Hz tick counter					*/
/********************************************************************/

long HWClock(void)
{
	#ifdef ALLEGRO
	return FrameTimer;
	#else
	return (clock()-ClockStart) * 3L;
	#endif
}


/********************************************************************/
/*					Check to see if a key is pressed				*/
/********************************************************************/

int  HWIsKeyPressed(int KeyID)
{
	#ifdef ALLEGRO						/* Allegro keys */
	if (KeyID == ESCAPE)				/* Escape and reset */
					return key[KEY_ESC];
	if (KeyID == RESET)
					return key[KEY_R];
	switch(KeyID)						/* Map characters to scancodes */
	{
		case 'Z':	return key[KEY_Z];
		case 'X':	return key[KEY_X];
		case 'C':	return key[KEY_C];
		case 'F':	return key[KEY_F];
		case 'G':	return key[KEY_G];
		case '1':	return key[KEY_1_PAD];
		case '2':	return key[KEY_2_PAD];
		case '3':	return key[KEY_3_PAD];
		case '6':	return key[KEY_6_PAD];
		case '+':	return key[KEY_PLUS_PAD];
	}
	return 0;
	#else

	static long LastClock = 0;			/* A rubbish simple key routine */
    long Clock;
    Clock = clock();
    if (Clock != LastClock)				/* Only check keys at 18Hz */
    {
		if (clock() > KeyReleaseTime)	/* Key "released" */
    						CurrentKey = 0;
	    if (kbhit())					/* Key pending */
    	{
	    	CurrentKey = getch();		/* Read the key */
    	    CurrentKey = toupper(CurrentKey);
        	KeyReleaseTime = clock()+10;/* Time when it is released */
	    }
        LastClock = Clock;
	}
    if (KeyID == ESCAPE)				/* Check for ESCAPE key */
	    	return (CurrentKey == 27);
    if (KeyID == RESET)               	/* Check for RESET key */
    		return (CurrentKey == 'R');
	return (CurrentKey == KeyID);		/* True if reqd key pressed */
	#endif
}

/********************************************************************/
/*							Sound On/Off							*/
/********************************************************************/

void HWSetSound(int NewState,int Pitch)
{
	int Freq;
	NewState = (NewState != 0) ? 1 : 0;	/* Std values for on/off */
	if (NewState != SoundState)			/* State changed ? */
    {
		SoundState = NewState;			/* Update it, turn on or off */
		#ifdef ALLEGRO
		if (SoundState)					/* Allegro */
		{
			Freq = 15625/Pitch;
			if (Pitch == 1)
			{
				stop_sample(SoundSample);
				play_sample(RandomSample,255,128,1000,1);
			}
			else
			{
				stop_sample(RandomSample);
				play_sample(SoundSample,255,128,1000*Freq/440,1);
			}
		}
		else
		{
			stop_sample(SoundSample);
			stop_sample(RandomSample);
		}
		#else
		if (SoundState)
        {
        	if (Pitch == 1) Pitch = 200;
			sound(15625/Pitch);			/* Turbo C */
        }
		else
			nosound();
		#endif
    }
}

/********************************************************************/
/*							Set a screen pixel						*/
/********************************************************************/

void HWSetPixel(int x,int y,int IsOn)
{
	unsigned int i,n,x1,y1;
    unsigned long l;
	if (x < 0 || y < 0 ||				/* Check range */
    			x >= SCREENX || y >= SCREENY) return;
    if (Pixel[x][y] == IsOn) return;	/* Check no change */
	Pixel[x][y] = IsOn;					/* Update screen */

    if (!InGraphic) return;
    #ifdef GRAPH
	l = IsOn ? IsOn+8 : 0;
	l = l + (l << 8) + (l << 16) + (l << 24);
	#ifdef LCD
	l = l & 0xFFFFFF00L;
	#endif
	n = x * 4 + y * 320 * 4 + 32 + (100-SCREENY*2)*320;
    *((unsigned long far *)(VideoRAM+n)) = l;
    *((unsigned long far *)(VideoRAM+n+320)) = l;
	*((unsigned long far *)(VideoRAM+n+640)) = l;
	#ifndef LCD
	*((unsigned long far *)(VideoRAM+n+960)) = l;
	#endif
	#endif

	#ifdef TEXT
    y = y & 0xFE;						/* Pixels are in pairs */
	n = (Pixel[x][y] ? 1 : 0) * 2 +		/* Composite of two pixels */
					(Pixel[x][y+1] ? 1 : 0);
	i = x * 2 + y * 80 + 16;			/* Offset in screen */
    VideoRAM[i] = PixelGfx[n];			/* Draw Pixel */
    VideoRAM[i+1] = (COL_PIXOFF << 4)+COL_PIXON;
	#endif

	#ifdef ALLEGRO
	x1 = x * 10;
	y1 = y * 10 + (240-SCREENY*5)/2;
	rectfill(screen,x1,y1,x1+9,y1+9,IsOn ? IsOn+8:0);
	#endif
}

/********************************************************************/
/*							Get a screen pixel						*/
/********************************************************************/

int  HWGetPixel(int x,int y)
{
	if (x < 0 || y < 0 ||				/* Check range */
   			x >= SCREENX || y >= SCREENY) return 0;
	return Pixel[x][y];					/* Return value */
}