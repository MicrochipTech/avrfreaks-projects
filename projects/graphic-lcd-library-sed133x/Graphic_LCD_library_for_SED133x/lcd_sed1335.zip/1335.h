/***********************************************************************
Content: Graphic library for Epson SED-1335 based LCD displays.
Last modified: 15.05.2003
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
***********************************************************************/

/***********************************************************************
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/


/***********************************************************************
Includes
***********************************************************************/
#include <io8515v.h>
#include <macros.h>
#include <stdarg.h>
#include <math.h>


/***********************************************************************
Port, PINS and LCD defines 
***********************************************************************/
// Data port
#define LCDDATAPIN 	   PINC
#define LCDDATADDR     DDRC
#define LCDDATAPORT    PORTC
// Control port
#define LCDCTLPIN 	   PINA     
#define LCDCTLDDR	   DDRA
#define LCDCTLPORT	   PORTA
// Control pins
#define RST			   0x01  
#define RD             0x02
#define WR             0x04
#define A0             0x08  	  
// LCD display data
#define LCD_X_SIZE     320
#define LCD_Y_SIZE     240
#define LCD_XTAL       10000000


/***********************************************************************
Prototypes
***********************************************************************/
// General LCD functions
unsigned char lcd_read_data(void);
void lcd_write_data(unsigned char data);
void lcd_write_command(unsigned char command);
void lcd_init(void);
void lcd_delay(void);
// Text functions
void lcd_clear_text(void);
void lcd_goto(unsigned char column, unsigned char line);
void lcd_write_string(char *ptr);
void lcd_show_cursor(unsigned char show);
// Graphic functions
void lcd_clear_graphics(void);
void lcd_pixel(int x, int y, unsigned char show);
void lcd_rectangle(int x1, int y1, int x2, int y2, unsigned char show);
void lcd_line(int x1, int y1, int x2, int y2, unsigned char show);
void lcd_circle(int x, int y, int radius, unsigned char show);
void lcd_degree_line(int x, int y, int degree, int inner_radius, int outer_radius, unsigned char show);