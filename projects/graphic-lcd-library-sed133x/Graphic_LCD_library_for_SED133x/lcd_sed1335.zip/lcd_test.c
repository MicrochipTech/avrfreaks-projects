/***********************************************************************
Content: Test for graphic library for Epson SED-1335 based LCD displays.
Last modified: 15.05.2003
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
***********************************************************************/

/***********************************************************************
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/


/***********************************************************************
Includes
***********************************************************************/
#include "1335.h"


/***********************************************************************
Defines and globals 
***********************************************************************/
#define ClockX		   160
#define ClockY		   120
#define ClockOR		   40
#define ClockIR		   2
int sec = 0;
int min = 0;


/***********************************************************************
Main 
***********************************************************************/
void main()
{
  int i = 0;
  int o = 0;
  // Init the display
  lcd_init();
  lcd_clear_text();
  lcd_clear_graphics();
  // Disable all interrupts
  CLI();
  // Set up timer 1 for about 1 second 
  TCCR1B = 0x00;
  TCNT1H = 0xC2;
  TCNT1L = 0xF7;
  OCR1AH = 0x3D;
  OCR1AL = 0x09;
  OCR1BH = 0x3D;
  OCR1BL = 0x09;
  TCCR1A = 0x00;
  TCCR1B = 0x04;
  MCUCR = 0x00;
  GIMSK = 0x00;
  TIMSK = 0x80;
 
  // Draw a frame
  lcd_rectangle(1,1,320,240,1);
  lcd_rectangle(3,3,318,238,1);
  // Write some text
  lcd_goto(10,4);
  lcd_write_string("  Baardsen Software");
  lcd_goto(10,5);
  lcd_write_string("   Svennahaugen 39");
  lcd_goto(10,6);
  lcd_write_string("5516 Haugesund, Norway");
  // DrawClockOutline();
  lcd_circle(ClockX,ClockY,ClockIR,1);
  lcd_circle(ClockX,ClockY,ClockOR,1);
  i = 0;
  while (i < 360)
  {
    lcd_degree_line(ClockX,ClockY,i,ClockOR-5,ClockOR,1);
	i = i + 30;
  }
  // Ok, then we enable interrupts and timer which will simulate
  // a good old analog clock. Enjoy !
  SEI();
}


/***********************************************************************
Interrupt handler for Timer 1 - 1 Second 
***********************************************************************/
#pragma interrupt_handler timer1_ovf_isr:7
void timer1_ovf_isr(void)
{
  TCNT1H = 0xC0;
  TCNT1L = 0x00;
  // Draw seconds
  lcd_degree_line(ClockX,ClockY,sec,ClockIR+1,ClockOR-7,0); 
  sec = sec + 6;
  lcd_degree_line(ClockX,ClockY,sec,ClockIR+1,ClockOR-7,1); 
  // Draw minute
  lcd_degree_line(ClockX,ClockY,min,ClockIR+1,ClockOR-15,1); 
  // Some simple checking....
  if (sec >= 360) 
  {
    sec = 0;
    lcd_degree_line(ClockX,ClockY,min,ClockIR+1,ClockOR-15,0);
    min = min + 6;
    lcd_degree_line(ClockX,ClockY,min,ClockIR+1,ClockOR-15,1);
  }
  if (min >= 360)
  {
    min = 0;
  }
}

