// Floating Point ASCII output routine
//
// Unlike many other library routines, this function does not use a lot of stack space
// masses of floating point routines or printf.
// 
// It is pretty fast but not as fast as some other methods (that do use lots of 
// stack or buffer space)
//
//
// Uses global unsigned char Precision to determine how many digits to print
// Uses global flag.Fixed (a bit flag) to print either FIXED (123.456) or Scientific
// format (1.23456E2)
// Uses global float round that is internally for rounding calculations.
//
// Values are correctly rounded. The initialisation routine Init_xprintf MUST
// be called once to set rounding correctly and any time Precision is changed.
// If Precision is made a constant, you can hard code the value of round
//
// As coded it assumes exponent is between -9 to +9. If the full range is required (ie +-E38)
// change last line of code to something like
// 
//  charout(pow10/10+'0');
//  charout(pow10%10+'0');
//
// stdlib "div(a,b) could be used to provide a faster solution (since the above generally
// generally results in TWO divides rather than one.
//
// Note that no check is made on validity of Precision - you can ask for and get
// 100 digits!
//
// An external routine charout is called to output the character.
//
// A floating point library function is used to produce a fast *10 routine
//
//      f=ldexp(f+ldexp(f,2),1);       //f*=10 but faster
//
// This is simpley (f<<3) +(f<<1) or f*8 + f*2;
// Can be replaced by f*=10;
//
// FIXED point overflow is handled by calling 
//
//          put_message(over);
//
// This occurs after sign is correctly printed so you can use to
// print -OVERFLOW or +OVERFLOW
//
// Andy Hutchinson
//
#include <math.h>    
static void xprintf(float f);
float round;
void Init_xprintf(void)
{            
  unsigned char i;            
  float temp=0.5;
  for (i=0;i<Precision;i++) temp/=10;
  round=temp;
}

static void xprintf(float f)
{
  // printout floating point value using precision and prefix            
  signed char pow10;
  char i,n;
  char dp;
  // check sign and make positive
  if (f<0) {                                                  
      f=-f;
      charout('-');              // print minus sign
  }
  else
  {
///      charout('+')';          // uncomment for leading "+"
  }

   // normalise between +-1.0000 and +-9.9999 
   // first get f below 10 when rounded       
   // if we don't allow for rounding 9.9999 could change to 10.00 in calculations 
  f+=round;
  pow10=0;
  {
    while (f>=10.0) {
        f/=10;               
        pow10++;
    }
  } 
  if (flags.Fixed)
  {  // we leave number between 0 and 9.999 - so we can give a FIXED result
      dp=pow10;                       // handle exponent by moving decimal point
      pow10=0;
      if (dp>Precision)      // can't print more than precision
      {
          put_message(over);
          return;                         // overload
      }
  }
  else
  { 
    dp=0;                   // handle small numbers
    if (pow10==0)          // skip this part if we were >10
    {
        if (f!=0.0)          // skip if zero
        {                  
          while (f<1.0)      // make f < 1.0 (negative exponent)
          {              
              f=ldexp(f+ldexp(f,2),1);    //f*=10;
              pow10--;
          }
        }
    }  
  }         
  //pow10 is now equal to exponent
  // f is in range 1.0<=f<10
  // PRINT MANTISSA. Include decimal point and print until precision runs out  
  for (i=0;i<Precision;i++) 
  {  
      f-= (n=f);
      charout(n+'0');
      f=ldexp(f+ldexp(f,2),1);       //f*=10 but faster
      if (i==dp) charout('.');
  }         
  // no exponent for zero power
  if (pow10==0) return;
  charout('E'); 
  //we handle only one digit
  if (pow10<0) { 
    pow10=-pow10; 
    charout('-');
  }
  
  charout(pow10+'0');
    
}
