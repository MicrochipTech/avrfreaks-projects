/*****************************************************************************
This is a piece of software designed to be used with a Polaroid SONAR module
from one of thier camera's that use ultrasonics to focus. Thier are two types of
units, one has a nice round transducer and one has a smaller square transducer.
This code should probably work for both of them.

Interrupts are NOT used, as the timer counts pretty slow (256 prescale) the
interrupts don't really add any accuracy, but they do add size to the code and
are less portable. Plus they chew up a lot of hardware resources (you might want
them for something else).

If your version of AVR-GCC doesn't store stuff in the avr\ directory, change
<avr\interrupt.h> to <interrupt.h>, same thing with io.h

Designed for AtMega8 controller, probably would work with others. If it doesn't
compile with them, I guess it doesn't work as is!

This code written by Colin O'Flynn, e-mail me at c_oflynn@yahoo.com or
coflynn@newae.com if you have questions, comments, or found my project useful!
Note: I am aware that this really isn't SONAR as it is above-ground... but its
just an easy word to use...

Version: 				1.00
Last Modification:	Jan 7, 2003
Note: Tab stops set to 3 in my coding environment

This file should have come with a schematic that shows you how to connect the
modified polaroid board up, with the modification from www.robotprojects.com

Hardware used:
3x		Port pins
1x		Timer1
******************************************************************************/

#include <avr\io.h>
//need some macros (cli() basically)
#include <avr\interrupt.h>

//Where to connect signal that allows you to power up transducer (active high)
#define TRIGGER_PORT		PORTC
#define TRIGGER_DDR		DDRC
#define TRIGGER_PIN		1

//Where to connect "Pulse Sent" input (active high)
#define TRANS_PORT_IN   PIND
#define TRANS_DDR       DDRD
#define TRANS_PIN       2

//Where to connect "Echo" input (active high)
#define ECHO_PORT_IN		PINB
#define ECHO_DDR 			DDRB
#define ECHO_PIN        0

//start timer1 with prescale
#define start_timer1()	TCCR1B = 1<<CS12
//stop timer1
#define stop_timer1()	TCCR1B = 0;

//How long we wait for the transducer to respond before declaring that its not
//responding
#define SONIC_TIMEOUT	65000

void			 									TIM16_WriteTCNT1
	(
   unsigned int				i
   );

unsigned int									TIM16_ReadTCNT1
	(
   void
   );

/* Setup sonar ports used and timer1 */
void                                   init_sonar
	(
   void
   )
   {
	//setup sonar port
	TRIGGER_DDR |= 1<<TRIGGER_PIN;
   TRANS_DDR &= ~(1<<TRANS_DDR);
   ECHO_DDR &= ~(1<<ECHO_DDR);

   //don't use any of the fancy features
   TCCR1A = 0;

   //stop timer1
   stop_timer1();

   return;
   }

/*Get the distance to an object. It returns something in the range of 1 to
30000, (maybe higher). As it so happens by pure luck if your processor speed happens
to be around 4 MHz the returned distance is roughly in CM. Though if you want
accuracy you will have to multiply the returned value by a calibration factor!!

IMPORTANT: If this thing returns 0, it means that it never received a response
from the transducer, so it timed out.

Do *NOT* call this routine in a loop with no delay, the ultrasonics need some
down-time to recover!!!! Exact time delay not really important, experiment
around until you find one that is reliable */
unsigned int									get_distance_to_object
	(
   void
   )
   {
   //timeout counter
   unsigned int				counter;

   init_sonar();

   //stop TIMER1
   stop_timer1();

   //reset TIMER1
   TIM16_WriteTCNT1(0);

   //ping ultrasonic transducer
   TRIGGER_PORT |= 1<<TRIGGER_PIN;

   //clear timeout counter
   counter = 0;

   //wait for transmit to go high
   while ((TRANS_PORT_IN & 1<<TRANS_PIN) != 1<<TRANS_PIN)
   	{
      counter++;
      //check if the unit has timed out
      if (counter == SONIC_TIMEOUT)
      	{
         return 0;
         }
      }

   //start counting time until echo returns
   start_timer1();

   //clear timeout counter
  	counter = 0;

   //wait for echo
   while ((ECHO_PORT_IN & 1<<ECHO_PIN) != 1<<ECHO_PIN)
   	{
      counter++;
      //check if the unit has timed out
      if (counter == SONIC_TIMEOUT)
      	{
         return 0;
         }
      }

   //stop timer from counting
   stop_timer1();

   //power down SONAR box
   TRIGGER_PORT &= ~(1<<TRIGGER_PIN);

   return TIM16_ReadTCNT1();
   }

//do an Atomic write of TCNT1 (interrupts disabled)
void 												TIM16_WriteTCNT1
	(
   unsigned int 				i
   )
	{
	unsigned char 				sreg;
	/* Save Global Interrupt Flag */
	sreg = SREG;
	/* Disable interrupts */
	cli();
	/* Set TCNT1 to i */
	TCNT1 = i;
	/* Restore Global Interrupt Flag */
	SREG = sreg;
	}

//do an Atomic read of TCNT1 (interrupts disabled)
unsigned int									TIM16_ReadTCNT1
	(
   void
   )
	{
   unsigned int 				i;
	unsigned char 				sreg;
	/* Save Global Interrupt Flag */
	sreg = SREG;
	/* Disable interrupts */
	cli();
	/* Set i to TCNT1 */
	i = TCNT1;
	/* Restore Global Interrupt Flag */
	SREG = sreg;
   /*Return i*/
   return i;
	}
