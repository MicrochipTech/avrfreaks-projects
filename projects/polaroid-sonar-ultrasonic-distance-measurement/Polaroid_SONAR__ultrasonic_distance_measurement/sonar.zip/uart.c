/* Simple routine to use the hardware UART. Designed to NOT use interrupts,
this code is extreamly portable, and also extreamly simple.

Created by: Colin O'Flynn
Contact: c_oflynn@yahoo.com or coflynn@newae.com or username c_oflynn on
www.avrfreaks.net

These routines are released free of restrictions, but if anything bad happens
(including but not limited to loss of your time, loss of profit, loss of life,
injury, loss of money, loss of your dog) it is your OWN fault, NO ONE else
can be held responsible*/

#include <avr/IO.h>
#include "uart.h"

#define BAUD_RATE0_REG  (unsigned int)(CPU_CLK_SPEED / (16 * BAUD_RATE0) ) - 1
//Actual baud rate, can be used to calculate error
#define ACTUAL_BAUD0    (unsigned int)(CPU_CLK_SPEED / (16 * BAUD_RATE0_REG + 1)

/* If the AVR you want to use isn't supported yet, it is very simple to add. If
the AVR has the same register names as another already defined chip (say for
example the AtMega8), then just add another line to the #if statement. So
instead of being
#if 	defined(__AVR_ATmega8__)
//if chip is AtMega8
	#define BAUDREGS			2
	#define BAUD0H_REG		UBRRH
   #define....

it becomes

#if 	defined(__AVR_ATmega8__) || \
		defined(__AVR_ATname__)
//if chip is AtMega8 or ATname
	#define BAUDREGS			2
	#define BAUD0H_REG		UBRRH

If this isn't the case, then look through the data-sheet and map all the register
names to the generals defines used in this program. 
*/

#if 	defined(__AVR_ATmega8__) 	|| \
		defined(__AVR_ATmega16__)	|| \
      defined(__AVR_ATmega32__)   
	#define NUM_OF_BAUDREGS	2
	#define BAUD0H_REG		UBRRH
	#define BAUD0L_REG		UBRRL
   #define NUM_OF_UARTS    1
	#define RXTXEN0_REG		UCSRB
	#define STAT0RXTX_REG 	UCSRA
   #define UDR0				UDR
   #define RX0EN				RXEN
   #define TX0EN				TXEN
   #define RX0C				RXC
   #define UDR0E				UDRE

#elif	defined(__AVR_AT90S4433__)
	#define NUM_OF_BAUDREGS	1
	#define BAUD0L_REG		UBRR
   #define NUM_OF_UARTS    1
	#define RXTXEN0_REG		UCSRB
	#define STAT0RXTX_REG 	UCSRA
   #define UDR0				UDR
   #define RX0EN				RXEN
   #define TX0EN				TXEN
   #define RX0C				RXC
   #define UDR0E				UDRE

#elif defined(__AVR_AT90S8515__) || \
		defined(__AVR_AT90S2313__) || \
      defined(__AVR_AT90S8535__) || \
      defined(__AVR_ATmega103__)
	#define BAUDREGS			1
	#define BAUD0L_REG		UBRR
   #define NUM_OF_UARTS    1
	#define RXTXEN0_REG		UCR
	#define STAT0RXTX_REG 	USR
   #define UDR0				UDR
   #define RX0EN				RXEN
   #define TX0EN				TXEN
   #define RX0C				RXC
   #define UDR0E				UDRE

//if chip is AtMega128
#elif 	defined(__AVR_ATmega128__) || \
		defined(__AVR_ATmega64__)
	#define NUM_OF_BAUDREGS	2
	#define BAUD0H_REG		UBRR0H
	#define BAUD0L_REG		UBRR0L
   #define NUM_OF_UARTS    2
	#define RXTXEN0_REG		UCSR0B
	#define STAT0RXTX_REG 	UCSR0A
   #define UDR0				UDR0
   #define RX0EN				RX0EN
   #define TX0EN				TX0EN
   #define RX0C				RX0C
   #define UDR0E				UDR0E

#else
	#error "No supported chip type in use for UART.C"
#endif

/*if you want to be able to change the baud rate "on the fly", just add in some
code that calculates the proper baud rate register settings. The calculations
are used above with #define BAUD_RATE0_REG. However, if you want to change
baud rates BUT will only need a few, it would be easier to pre-calculate
the baud register settings in pre-processor, and use a switch statement that
lets you select between a few baud rates*/

void												init_uart0
	(
   void
   )
   {
	//turn on TX and RX
   RXTXEN0_REG = (1<<RX0EN) | (1<<TX0EN);

   //set up baud rate
   #if (BAUDREGS == 2)
   	BAUD0H_REG = (unsigned char)(BAUD_RATE0_REG >> 8);
   	BAUD0L_REG = (unsigned char)BAUD_RATE0_REG;
   #else
   	BAUD0L_REG = (unsigned char)BAUD_RATE0_REG;
   #endif              
   return;
   }

unsigned char									input_ch_w_timeout_0
	(
   char *					 	data,
   volatile unsigned int				timeout
   )
   {
   unsigned int				timeout_counter = 0;
   
   //check if a byte has been recieved or if the timeout has been excedded
   while (timeout_counter != timeout)
		{	
		if ((STAT0RXTX_REG & (1<<RX0C)) == (1<<RX0C))
			{
			*data = UDR0;
			return BYTE_REC;
			}
		timeout_counter++;
		}
		
	return TIMEOUT;
	}
		
char												input_ch_0
	(
   void
   )
   {
   //check if a byte has been recieved or if the timeout has been excedded
   while ((STAT0RXTX_REG & (1<<RX0C)) != (1<<RX0C))
		{
		continue;		
		}		
	return UDR0;
	}
	
void												output_ch_0
	(
	char							data
	)
	{
	while ((STAT0RXTX_REG & (1<<UDR0E)) != (1<<UDR0E))
		{
		continue;
		}
	UDR0 = data;
	
	return;
	}
   





