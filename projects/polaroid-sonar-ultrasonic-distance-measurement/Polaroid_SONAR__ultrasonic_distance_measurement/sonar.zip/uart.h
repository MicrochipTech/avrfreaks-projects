/* Simple routine to use the hardware UART. Designed to NOT use interrupts,
this code is extreamly portable, and also extreamly simple.

Created by: Colin O'Flynn
Contact: c_oflynn@yahoo.com or coflynn@newae.com or username c_oflynn on
www.avrfreaks.net

These routines are released free of restrictions, but if anything bad happens
(including but not limited to loss of your time, loss of profit, loss of life,
injury, loss of money, loss of your dog) it is your OWN fault, NO ONE else
can be held responsible*/


//CPU clock speed in Hz
#define CPU_CLK_SPEED		3690000
//Baud rate we want
#define BAUD_RATE0			115200

//Init UART0, set to baud rate as defined in header file
void												init_uart0
	(
   void
   );

//Input a char on UART0 and store it to data, however if no char is recieved
//within timeout, then abort and return TIMEOUT, otherwise return BYTE_REC
//(note: timeout is NOT a reliable value, as it uses a simple C loop that
//will change with different compiler settings likely
unsigned char									input_ch_w_timeout_0
	(
   char *						data,
   volatile unsigned int	timeout
   );

//wait forever for a char on UART 0 and return it
char												input_ch_0
	(
   void
   );

//output char data on UART0
void												output_ch_0
	(
	char							data
	);

//error codes returned by functions
#define BYTE_REC				0
#define TIMEOUT				1
