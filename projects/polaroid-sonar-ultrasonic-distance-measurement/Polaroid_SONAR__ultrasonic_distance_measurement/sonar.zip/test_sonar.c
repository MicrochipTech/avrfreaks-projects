#include <avr\io.h>

//need the delay's
#include <avr\delay.h>

//need the itoa() function
#include <stdlib.h>

//need UART functions (be sure to set up uart in uart.h!!!!>
#include "uart.h"

//need SONAR functions
#include "sonar.h"

int main(void)
	{
   char							distance[10];
   unsigned char				n;

   //init UART
   init_uart0();

   //init SONAR
   init_sonar();

   while (1)
   	{
      //get distance to object, convert to base 10 ASCII, store in distance var
      itoa(get_distance_to_object(), distance, 10);

      //output distance
      n = 0;
      while (distance[n] != '\0')
      	{
         output_ch_0(distance[n]);
         n++;
         }

      //you will have to set your terminal emulator to LF to incomming CR
      output_ch_0('\r');

      //wait a while
      _delay_loop_2(60000);
      _delay_loop_2(60000);
      }

   return 1;
   }
