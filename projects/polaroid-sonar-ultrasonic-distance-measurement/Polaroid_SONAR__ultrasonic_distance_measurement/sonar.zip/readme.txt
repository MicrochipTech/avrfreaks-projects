SONAR Project

This project uses a Polaroid camera that is ripped apart. Likely first you will want to check out the
www.robotprojects.com folder, which has information on the Sonar board itself, thanks to Scott Savage 
for putting up this website! I have provided a local copy of the website, but you can just go to 
www.robotprojects.com if you happen to be online at the time.

There is also a newer version of this polaroid board that you can just buy off places, and
you don't need to modify it at all to get it working. http://www.acroname.com/robotics/parts/c_Sensors.html
is one example of such a place.

The polaroid board is supposed to be good from 6 inches to 35 feet, or roughly 30cm to 10m. My board seemed to work up
to about 8 meters. Be careful though as the board doesn't detect just straight ahead, its a cone.

The correction factor at 3.69 MHz was around 1.106, so multiply the result of the function by 1.106 to get CM. Of course
this is ONLY at that frequency, and with the speed of sound the same (depends on temperature, amoung other things).

The function will return 0 if something went wrong! This normally means the sonar board either (1) never sent a pulse or
(2)never received an echo, normally because the cables aren't connected properly or something like that.


Advised order of looking at this project:

1) read dissecting a Polaroid Camera in www.robotprojects.com
2) read Polaroid Sonar Modification, same place
3) read Polaroid Sonar Project, same place
4) look at sonar.pdf
5) look at sonar.c

I packaged my sonar transducer, Polaroid board, and interface electronics all in one box with a DB25 connector.

-Colin O'Flynn

c_oflynn@yahoo.com
coflynn@newae.com