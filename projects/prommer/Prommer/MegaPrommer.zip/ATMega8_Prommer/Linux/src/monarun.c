/***************************************************************************
                          monarun.c  -  description
                             -------------------
    begin                : Sa Sep 25 2004
    copyright            : (C) 2004 by root
    email                : root@tobbynet
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

 #include <stdio.h>
 #include "hw.h"

 int main (void)
 {
		initio();
		sleep (1);
		set_vcc();
		clr_reset();
		sleep (1);
		set_reset();
		while (1)
		{
			if (isset_miso())
				set_led();
			else
				clr_led();
		}
	}
	