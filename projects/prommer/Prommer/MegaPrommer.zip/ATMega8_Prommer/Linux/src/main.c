#include <stdio.h>
#include "hw.h"
#include "prom.h"
#include "hexfileread.h"


void exit_safe(char *meld)
{
  initio();
  power_down_sequence();
  printf ("You may now remove the ATMega\n");
  if (meld!=NULL)
    printf ("%s\n",meld);
  exit (0);
}

void testcode (void)
{
  struct pg_readword pg_read;
  struct pg_writeword pg_write;
  pg_read.adr=0x00;
  printf ("readword:%x\n",prom_code (PG_READWORD,&pg_read));

  pg_write.word=0xaffe;
  pg_write.adr=0;
  prom_code (PG_WRITEWORD,&pg_write);

  pg_read.adr=0x00;
  printf ("readword:%x\n",prom_code (PG_READWORD,&pg_read));

  pg_read.adr=0x1f;
  printf ("readword @0x1f:%x\n",prom_code (PG_READWORD,&pg_read));
  pg_read.adr=0x20;
  printf ("readword @0x20:%x\n",prom_code (PG_READWORD,&pg_read));

  pg_write.adr=0x1f;
  pg_write.word=0xaffe;
  prom_code (PG_WRITEWORD,&pg_write);

  pg_write.adr=0x20;
  pg_write.word=0xc1a0;
  prom_code (PG_WRITEWORD,&pg_write);

  pg_read.adr=0x1f;
  printf ("readword @0x1f:%x\n",prom_code (PG_READWORD,&pg_read));
  pg_read.adr=0x20;
  printf ("readword @0x20:%x\n",prom_code (PG_READWORD,&pg_read));

  power_down_sequence();

  exit_safe("Ok!");
}  
int mywritecallback(uint16_t adr,uint16_t word)
{
  struct pg_readword pg_read;
  struct pg_writeword pg_write;
  static volatile uint16_t  prgword;
  if (adr&1)
  {
    prgword+=(word<<8);
    pg_write.adr=(adr>>1);
    pg_write.word=prgword;
    prom_code (PG_WRITEWORD,&pg_write);
    printf ("prommin\n");
  }
  else
  { printf ("storing\n");
    prgword=word;
  }
  
  return 0xaa;
}
int myreadcallback(uint16_t adr,uint16_t word)
{
  struct pg_readword pg_read;
  struct pg_writeword pg_write;
  static volatile uint16_t  prgword;
  if (adr&1)
  {
    prgword+=(word<<8);
    pg_read.adr=(adr>>1);
    if  (prom_code (PG_READWORD,&pg_read)!=prgword)
    {  printf ("Verify error!!!!\n");
        exit(0);
    }
    printf ("prommin\n");
  }
  else
  { printf ("storing\n");
    prgword=word;
  }

  return 0xaa;
}

        
int main (int argc,char *args[])
{
  struct pg_readword pg_read;
  struct pg_writeword pg_write;
  unsigned int devcode;

  //callbackf=mywritecallback;
  //prog_hexfile ("main.hex");
  //exit (0);
  initio();
  if (argc!=2)
  {
		printf ("Monaprog usage:\n\r\t%s <filename.hex>\n\rProgrammes hexfile over SPI of ATMega's\r\n",args[0]);
		exit (0);
	}
  printf ("Insert ATMega\n");
  getchar();
  power_up_sequence();
  if (prom_code (PG_PROGENABLE,NULL))
    exit_safe("Fehler_Progenable");

  printf ("DevCode: %x\n",(devcode=prom_code (PG_READSIG,NULL)));
  if (devcode&0x00ff0000!=0x07)
    exit_safe ("Achtung: Kein ATMega8\n");
    

  if (prom_code (PG_CHIPERASE,NULL))
    exit_safe("Fehler beim Chip L�schen\n");

  callbackf=mywritecallback;
  prog_hexfile (args[1]);

  callbackf=myreadcallback;
  prog_hexfile (args[1]);
  exit_safe("ok!");
}  