#include <elf.h>

void power_up_sequence(void);
void power_down_sequence(void);
unsigned short write_byte(unsigned short);
unsigned long write_dword(unsigned long);

#define PG_PROGENABLE 0x0a
#define PG_CHIPERASE  0xa0
#define PG_READWORD   0xca
#define PG_READSIG    0xac
#define PG_WRITEWORD  0x10


struct pg_readword
{
  uint16_t adr;
};

struct pg_writeword
{
  uint16_t word;
  uint16_t adr;
};

