#include <stdio.h>
#include <elf.h>
#include "hw.h"
#include "prom.h"

#define SHORT_BRK 10
#define LONG_BRK  100

#define PROM_DEBUG

uint8_t wrpage=0x00;
uint8_t wrflag=0;

unsigned short write_byte (unsigned short byteval)
{
  int cou;
  unsigned short inbyte;
  inbyte=0;

#ifdef	PROM_DEBUG
  printf ("Writing %x:",byteval);
#endif
  for (cou=0;cou<8;cou++)
  {
    if (byteval&128)
    {
#ifdef	PROM_DEBUG
      printf ("1");
#endif
      set_mosi();
    }
    else
    {
#ifdef	PROM_DEBUG
      printf ("0");
#endif
      clr_mosi();
    }
    mn_sleep (SHORT_BRK);
    set_sck();        /* TICK */
    mn_sleep (SHORT_BRK);
    if (isset_miso())
      inbyte+=(1<<(7-cou));
    clr_sck();       /* TACK */
    mn_sleep (SHORT_BRK);
    byteval<<=1;
  }
#ifdef	PROM_DEBUG
  printf (" Inbyte: %x\n",inbyte);
#endif
  return inbyte;
}

unsigned long write_dword(unsigned long dw)
{
  int resu1,resu2,resu3,resu4;
  resu1=write_byte ((dw>>24)&0xff);
  resu2=write_byte ((dw>>16)&0xff);
  resu3=write_byte ((dw>>8)&0xff);
  resu4=write_byte (dw&0xff);
#ifdef	PROM_DEBUG
  printf ("------------------\n");
#endif
  return ((unsigned long)(resu1<<24)|(resu2<<16)|(resu3<<8)|resu4);
}

void flush_page(void)
{
#ifdef	PROM_DEBUG
  printf ("Flushing page %x\n",wrpage);
#endif
  write_dword (0x4c000000|(wrpage<<13)); /* flush memory page */
  sleep (1);
  return ;
}
  

int prom_code (unsigned short pgcode,uint8_t *pg)
{
  unsigned long retcode;
  int retval;
  uint8_t lowadr;
  uint8_t page;
  switch (pgcode)
  {
    case PG_PROGENABLE:
      printf ("Prog enable\n");
      if ((write_dword (0xac530000)&0x0000ff00)!=0x5300)
        return 1;
      else
        return 0;
      break;
    case PG_CHIPERASE:
        wrflag=0;
        write_dword(0xac800000);
        return 0;
    case PG_READWORD:
        printf ("READ WORD\n");
        if (pg==NULL)
          return 1;
        if (wrflag==1)
        {
          wrflag=0;
          flush_page();
        }
        retcode=write_dword (0x28000000|(pg[0]<<8)|((pg[1]&0x0f)<<16));
        retval=(retcode&0xff)<<8;
        retcode=write_dword (0x20000000|(pg[0]<<8)|((pg[1]&0x0f)<<16));
        retval|=(retcode&0xff);
        return retval;
      break;

    case PG_READSIG:
        printf ("READ SIGNATURE\n");
        if (wrflag==1)
        {
          wrflag=0;
          flush_page();
        }
        retcode=write_dword(0x30000000);
        retval=(retcode&0xff);
        retcode=write_dword(0x30000100);
        retval|=(retcode&0xff)<<8;
        retcode=write_dword(0x30000200);
        retval|=(retcode&0xff)<<16;
        retcode=write_dword(0x30000300);
        retval|=(retcode&0xff)<<24;
        return retval;
      break;

    case PG_WRITEWORD:
          printf ("Write WORD\n");
    
          lowadr=pg[2]&0x1f;
          page=(pg[2]>>5)|(pg[3]<<3);
          if (wrflag==0)
          {
            wrflag=1;
            wrpage=page;
          }
          if (page!=wrpage)
          {
            flush_page();
            wrpage=page;
          }
          write_dword (0x40000000|(lowadr<<8)|(pg[0]&0xff));
          write_dword (0x48000000|(lowadr<<8)|(pg[1]&0xff));
        break;
    default:
        printf ("Illegal PG-Code\n");
        return 1;
    
  }
}
      
    


void power_up_sequence (void)
{
  initio();
  clr_sck();
  clr_reset();
  clr_led();
  mn_sleep (SHORT_BRK);
  set_vcc();
  sleep (1);
  set_reset();
  mn_sleep (LONG_BRK);
  clr_reset();
  mn_sleep (LONG_BRK);
}

void power_down_sequence (void)
{
  if (wrflag==1)
  {
    wrflag=0;
    flush_page();
  }

  clr_reset();
  clr_sck();
  clr_mosi();
  clr_vcc();
  sleep (1);
  set_led();
}
  
  