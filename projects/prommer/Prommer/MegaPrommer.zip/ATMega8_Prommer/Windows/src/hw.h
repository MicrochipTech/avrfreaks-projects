int pinval;
void outpin(void);

void initio(void);

void set_mosi(void);
void clr_mosi(void);

void set_reset(void);
void clr_reset(void);

void set_led(void);
void clr_led(void);

void set_sck(void);
void clr_sck(void);
void toogle_sck(void);

void set_vcc(void);
void clr_vcc(void);

int isset_miso(void);

void sleep(short );