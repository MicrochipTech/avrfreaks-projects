/***************************************************************************
                          hexfileread.c  -  description
                             -------------------
    begin                : Do Sep 23 2004
    copyright            : (C) 2004 by root
    email                : root@tobbynet
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

 #include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hw.h"
#include "prom.h"

 FILE *fp;
 unsigned int (*callbackf)(uint16_t,uint16_t);

 int strpos(char *haystack,char needle)
 {
   unsigned int cou;
   
   for (cou=0;cou<strlen(haystack);cou++)
   {
     if (haystack[cou]==needle)
      return cou;
   }
   return -1;
     
 }
 
 uint16_t hextoint (char *val)
 {
   int cou;
   int pos;
   int potcou;
   char hx[]="0123456789abcdef";
   uint16_t retval;
   retval=0;
   potcou=0;
   for (cou=strlen(val)-1;cou>=0;cou--)
   {
      if ((pos=strpos(hx,tolower(val[cou])))==-1)
        return -1;
      else
      {
        retval+=pos*(1<<(potcou*4));
      }
      potcou++;
   }
   
   return retval;  
 }

 int prog_hexfile(char *fname)
 {
    char c[120];
    char adr[5];
    char len[3];
    char typ[3];
    char dta[3];
    int cou;
    int intadr;
    if ((fp=fopen(fname,"r"))==NULL)
      return 1;

    printf ("File opened\n");
    while (fgets(c,119,fp)!=NULL)
    {
      printf ("read:%s\n",c);
      if (c[0]==':')
      {
        strncpy (len,c+1,2); len[2]=0;
        strncpy (adr,c+3,4); adr[4]=0;
        strncpy (typ,c+7,2); typ[2]=0;
        printf ("len: %s,%d\n",len,hextoint(len));
        printf ("adr: %s,%d\n",adr,hextoint(adr));
        printf ("typ: %s,%d\n",typ,hextoint(typ));
        if (hextoint(typ)==0)
        {
          intadr=hextoint(adr);
          for (cou=0;cou<hextoint(len);cou++)
          {
            strncpy (dta,c+9+(cou*2),2); dta[2]=0;
            if (callbackf!=NULL)
            {
              callbackf(intadr,hextoint(dta));
            }
            intadr++;
          }
        }
        else
        {
          printf ("Warnung: Ignoring type: %d\n",hextoint(typ));
        }
          
      }
      else
      {
        printf ("Ignoring");
      }
    } 
    
    
    fclose (fp);
    return 0;
    
   
 }
 
 
 