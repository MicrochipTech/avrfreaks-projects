#include "StdAfx.h"

#include "hw.h"
#include "io.h"

#define BASEIO	888

#define PIN_VCC	0x01
#define PIN_AVCC 0x02
#define PIN_RESET 0x04
#define PIN_SCK	0x08
#define PIN_MOSI 0x10
#define PIN_LED 0x80

#define PIN_MISO 64

int pinval;
void outpin(void)
{
	PortOut((short int)BASEIO,(char)pinval);
	return ;
}
void initio(void)
{
	LoadIODLL();
	if (!IsDriverInstalled())
	{
		printf ("Error while init I/O\n");
		exit(0);
	}

	pinval=PIN_LED;
	outpin();
}
void set_mosi(void)
{
	pinval|=PIN_MOSI;
	outpin();
	return ;
}

void clr_mosi(void)
{
	pinval&=~PIN_MOSI;
	outpin();
}

void set_reset(void)
{
	pinval|=PIN_RESET;
	outpin();
}

void clr_reset(void)
{
	pinval&=~PIN_RESET;
	outpin();
}

void set_led(void)
{
	pinval|=PIN_LED;
	outpin();
}

void clr_led(void)
{
	pinval&=~PIN_LED;
	outpin();
}

void set_sck(void)
{
	pinval|=PIN_SCK;
	outpin();
}

void clr_sck(void)
{
	pinval&=~PIN_SCK;
	outpin();
}

void toggle_sck(void)
{
	if (pinval&PIN_SCK)
		clr_sck();
	else
		set_sck();
	return ;
}

void set_vcc(void)
{
	pinval|=PIN_VCC;
	pinval|=PIN_AVCC;
	outpin();
}

void clr_vcc(void)
{
	pinval&=~PIN_VCC;
	pinval&=~PIN_AVCC;
	outpin();
}

int isset_miso(void)
{
	return (PortIn(BASEIO+1)&PIN_MISO);
}

void mn_sleep(unsigned int brk)
{
	SleepEx(1,0);
}

void sleep (short int brk)
{
	SleepEx(brk*100,0);
}
