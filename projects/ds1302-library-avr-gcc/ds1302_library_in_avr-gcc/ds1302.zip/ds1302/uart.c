

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdlib.h>
#include <stdio.h>
#include <avr/delay.h>

void init_uart(void);
int uart_putchar(char);

int uart_putchar(char c)
{
	if (c == '\n')
		uart_putchar('\r');
	loop_until_bit_is_set(USR, UDRE);
	UDR = c;
	return 0;
}

void init_uart(void)
{
	// UART initialization
	// Communication Parameters: 8 Data, 1 Stop, No Parity
	// UART Receiver: On
	// UART Transmitter: On
	// UART Baud rate: 19200
	UCR=0x18;
	UBRR=0x0B;
	
	fdevopen(uart_putchar, NULL, 0);
}


