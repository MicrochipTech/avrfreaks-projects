
#include "delay.h"
#include "usart.c"

#include "ds1302.c"

#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>

unsigned char alarm_1_set, alarm_2_set, alarm_3_set;
unsigned char b10;
unsigned char bpm;


int main(void)
{
	unsigned char sec, temp;
	sec = 0;
  	
	init_usart();
	
	write_byte(w_protect,0x00);	//make sure that the WP bit is cleared
	write_byte(sec_w,0x00);		//set seconds to 0

	while (1)
	{                   	
		temp = sec;
		sec = read_byte(sec_r);	//read the seconds
		if(sec != temp){
			printf("seconds: %u", sec);
			printf("\r");
		}
		delay_ms(100);
	}
}
