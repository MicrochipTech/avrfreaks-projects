//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MbusTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MBUSTEST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_ICON_CD                     132
#define IDI_ICON_RADIO                  133
#define IDI_ICON_ERR                    134
#define IDC_COMBO_PORT                  1000
#define IDC_LIST                        1003
#define IDC_CHECK_CONNECTED             1005
#define IDC_RADIO_MONITOR               1008
#define IDC_RADIO_CHANGER               1009
#define IDC_RADIO_RADIO                 1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
