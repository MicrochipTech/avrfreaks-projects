
	-*- 7.8 signed fixed point binary coded decimal (BCD) math library -*-
	-*- Coded By Rolf R Bakke -*-


View this file with a monospace font!
Keep in mind that english is not my 1st language!

This library is a set of macros/commands to calculate decimal numbers with high precison
for Atmel AVR Mega163. (and other AVR's with hardware multiplier)

There is 10 macros/commands, including add, subtract, multiply, divide and compare.
There is also commands for converting between binary and BCD.

The numbers is stored in a binary coded decimal format. That is, each decimal digit is 
represented by a 4 bit binary number. To save space two decimal digits is stored in one byte,
referred as 'packed BCD'. For decimal numbers longer than 2 digits, more than 1 byte is used.
This library uses 8 bytes, containing one sign and 15 digits. The digits is divided into two
fields: 7 integer digits and 8 decimal digits. (see description of the fldi command)

Note: some commands does not use all digits.

The numbers is stored in registers. Each register takes 8 bytes of SRAM space.
The registers is numbered in the same way as the AVR registers. 
Just tink of them as oversized AVR registers

executing the commands does not destroy any of the AVR registers. 
(exept the funpack and fbcd2bin command, see their descriptions)

There in no overflow,underflow or divide by zero indication. 
Divide by zero returns zero.

Read the 'example.asm' file for examples and instructions on how to use library in your
own programs.


N O T E !
When assembling, the 'math_lib.asm' file may generate warnings: 
'register already defined by the .DEF directive'
Ignore these warnings.


Comments welcome!  Modellfly@hotmail.com

Regards,
Rolf R Bakke



-*-  L I S T  O F  C O M M A N D S  -*-


-*- THE FLDI COMMAND -*-

The fldi command loads a register with a 7.8 number
This example loads -12345.6789 into register 0
Do not forget the '0x' part of the numbers.


	fldi 0,0x10012345,0x67890000
	     |   |---+---   ----+---
	     |   |   |          |
	     |   |   |          +--- decimal part, 8 digits
	     |   |   |
	     |   |   +-------------- integer part, 7 digits
	     |   |
	     |   +------------------ sign:  0=positive  1=negative
	     |
	     +---------------------- destination register




-*- THE FMOV COMMAND -*-

The fmov command does a move between two registers


	fmov 0,1
	     | |
	     | +----- source register
	     |
	     +------- destination register 




-*- THE FCOMP COMMAND -*-

The fcomp command does a 7.8 and 7.8 signed compare on two registers
Valid branches after fcomp is:

  breq	(Branch if equal)
  brne	(Branch if not equal)
  brsh  (Branch if same or higher)
  brlo  (branch if lower)	


	fcomp 0,1
	      | |
	      | +----- second source register
	      |
	      +------- first source register 


-*- THE FADD COMMAND -*-

The fadd command does a 7.8 + 7.8 into 7.8 signed addition between two registers
destination register can be any register, including any of the 
source registers


	fadd 0,1,0
	     | | |
	     | | +--- destination register
	     | |
	     | +----- second source register
	     |
	     +------- first source register 


-*- THE FSUB COMMAND -*-

The fsub command does a 7.8 - 7.8 into 7.8 signed subtraction between two registers
Destination register can be any register, including any of the 
source registers


	fsub 0,1,0
	     | | |
	     | | +--- destination register
	     | |
	     | +----- second source register
	     |
	     +------- first source register 



-*- THE FMULT COMMAND -*-

The fmult command does a 7.4 * 7.4 into 7.8 signed multiply between two registers
The last four decimal digits of source is ignored.
Destination register can be any register, including any of the 
source registers


	fmult 0,1,0
	      | | |
	      | | +--- destination register
	      | |
	      | +----- second source register
	      |
	      +------- first source register 



-*- THE FDIV COMMAND -*-

The fdiv command does a 6.8 / 6.8 into 7.8 signed divide between two registers
Destination register can be any register, including any of the 
source registers


	fdiv 0,1,0
	     | | |
	     | | +--- destination register
	     | |
	     | +----- second source register
	     |
	     +------- first source register 



-*- THE FUNPACK COMMAND	 -*-

The funpack command presents a register in a suitable format for
sending to a LCD or similar.
The Z register points to 16 bytes in SRAM, where each byte contains
one digit:

byte 0   : sign (one digit: 0 or 1)
byte 1-7 : integer part (7 digits: 0 to 9)
byte 8-F : decimal part (8 digits: 0 to 9)


	funpack 0
	        |
	        +---- source register



-*- THE FBIN2BCD COMMAND -*-

The fbin2bcd command convert a 16bit unsigned binary number to a
5.0 positive BCD. Other registers than xl,xh can be used, exept
register r17,r18


	fbin2bcd 0,xl,xh
	         | |  |
	         | |  +--- source 16bit register high
	         | +------ source 16bit register low
	         |
	         +-------- destination BCD register




-*- THE FBCD2BIN COMMAND -*-

The fbcd2bin command convert a 5.0 BCD to a 16bit unsigned binary number.
Sign of 5.0 BCD is ignored.
Other registers than xl,xh can be used, exept
register r17,r18


	fbcd2bin 0,xl,xh
	         | |  |
	         | |  +--- destination 16bit register high
	         | +------ destination 16bit register low
	         |
	         +-------- source BCD register





Happy coding! :)