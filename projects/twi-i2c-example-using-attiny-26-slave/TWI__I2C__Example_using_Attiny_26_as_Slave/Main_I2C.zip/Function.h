#ifndef Function_H
#define Function_H

#define XTAL_CPU         4000000
#define DELAY_SHIFT XTAL_CPU/8000000

void delay(unsigned long int uMicroSeconds);
void Port_test (unsigned char Port_Num);

#endif //Function_H
