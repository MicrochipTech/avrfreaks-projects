#ifndef Main_I2c_h
#define Main_I2C_h

#define TWI_Data   		USIDR
#define TWI_Status  	USISR
#define TWI_Control 	USICR
#define tiny26			0xA0
#define TWI_buffer_size 0x20

void USI_init(void);

#endif //Main_Per_h

