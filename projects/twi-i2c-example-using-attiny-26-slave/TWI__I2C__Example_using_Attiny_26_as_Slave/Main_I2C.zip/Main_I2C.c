/*************************************************************************
Title:    example I2C / TWI program for the Attiny 26 
Author:   Huey Hano	<Hhano2@msn.com> if anyone has improvements let me know
File:     Main_I2C.c, Main_I2C.h, Function.h, Function.c, makefile
Software: avr-gcc (GCC) 3.3.2
Hardware: tested on ATtiny26 at 4 Mhz talking to a mega16 at 8 Mhz
		  Both devices programmed with STK500. No external pullup
		  resistors were used on the I2C lines. The internal pullup
		  resistors work fine in this example.


DESCRIPTION:  This example shows how to use the Attiny26 as a slave for I2C.
			  I used a mega16 as a master programmed with 
			  i2c.test from http://hubbard.engr.scu.edu/embedded/avr/avrlib
			  Received data is inverted and displayed on PORTA of the tiny26.
			  If no data is present PORTA will scroll back and forth.
			  The data received is sent back when a Master requests data
			  from the tiny26 slave. The entire I2C software is interrupt driven
			  thus keeping the processor free for other tasks.

Price:	  Free
Warranty: None
*************************************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include "Function.h"
#include "Main_I2C.h"

//tiny26		0xA0


volatile unsigned char Char_Buff[TWI_buffer_size];
volatile unsigned char COMM_STATUS = 0,j,k;

int main(void)
{
DDRA = 0xff;
Port_test ('A');

USI_init();
sei();



	for(;;)
	{	
		k=0;
		Port_test ('A');
		delay(1000000);
		while ((!Char_Buff[k] == 0) && (k < TWI_buffer_size))
		{
		PORTA = ~Char_Buff[k++];
		delay(500000);
		}

	}	

}



SIGNAL(SIG_USI_START) //USIS interrupt
{
TWI_Status = 0xf0; // clear everything, write 1 to clear flags
TWI_Control |= _BV(USIOIE);// enable TWI interrupt on overflow
DDRB &= ~_BV(PB2); //make sure SCL is released
COMM_STATUS = 0; // reset status reigister
j=0;
}




SIGNAL(SIG_USI_OVERFLOW) //USIOI interrupt comes in on rising edge
{

	while (PINB & _BV(PB2));// wait until clock(SCL) goes low
	PORTB &= ~_BV(PB2); //now hold the line low
	DDRB |= _BV(PB2);
		
		switch(COMM_STATUS)
		{
			
		case 0: // if not receiving valid address
				if ((TWI_Data & 0xfe) != tiny26)
				TWI_Control &= ~_BV(USIOIE);// disable TWI interrupt on overflow 
				
				else //else address is valid
				{
				COMM_STATUS = ((TWI_Data & 0x01) + 1); // address[0] = 1 =  master receive
				TWI_Status = 0x0e;  // reload counter for ACK, (SCL) high and back low
				TWI_Data = 0x00; // //load 0 for ack, must change bit only when SCL is low
				DDRB |= _BV(PB0);  //make DDRB = 1(output), SDA = 0 (ACK)
				}
				break;
				
		case 1:
				COMM_STATUS = 3;// ack complete in master transmitt mode
				TWI_Status = 0x00; //reload counter for data
				DDRB &= ~_BV(PB0); //make DDRB = 0(input), SDA = 1,  release SDA ACK complete
				break;
				
		case 2:
				COMM_STATUS = 4;//ack complete in master receive mode
				if(j < TWI_buffer_size) //send data
				{
				TWI_Data = Char_Buff[j++];
				}
				TWI_Status = 0x00; //reload counter for data
				PORTB |= _BV(PB0); //make output high
				//DDRB |= _BV(PB0); //make DDRB = 1(output) for data (already done)
				break;
				
		case 3:
				if (j < TWI_buffer_size) //receive new data
				{
				Char_Buff[j++] = TWI_Data; //save data
				TWI_Status = 0x0e;  // reload counter for ACK, (SCL) high and back low
				TWI_Data =0x00; //load 0 for ack
				DDRB |= _BV(PB0); //make DDRB = 1(output), SDA = 0 (ACK)
				COMM_STATUS = 1;
				}
				else TWI_Control &= ~_BV(USIOIE);// disable TWI interrupt on overflow
				break;
				
		case 4:
				COMM_STATUS = 5; 	// setup for ack receive
				DDRB &= ~_BV(PB0); //make DDRB = 0(input), SDA = 1
				TWI_Status = 0x0e; //load counter for ack receive
				TWI_Data = 0xff; // setup for ack receive
				break;	
			
		case 5: 
				//send data //if ack received
				if ((~TWI_Data & 0x01) && (j < TWI_buffer_size)) 
				{
				COMM_STATUS = 4; //flag ack receive complete
				TWI_Status = 0x00; //
				TWI_Data = Char_Buff[j++];
				// PORTB |= _BV(PB0); //make output high (already done)
				DDRB |= _BV(PB0); //make DDRB = 1(output), SDA = 0 (ACK)
				}
				//else nack received or no more data to send
				else TWI_Control &= ~_BV(USIOIE);// disable TWI interrupt on overflow 
				// DDRB &= ~_BV(PB0); //make DDRB = 0(input), SDA = 1 (already done)
				break;
			
		}	//else not talking to my address
TWI_Status |= _BV(USIOIF);	// also releases SCL
DDRB &= ~_BV(PB2); // make sure it stays released
}




/*************************************************************************
Function: USI_init()
Purpose:  initialize universal Serial Interface
Input:    none
Returns:  none
**************************************************************************/
void USI_init(void)
{					// 2-wire mode; Hold SCL on overflow; interrupt on start
TWI_Control = _BV(USISIE) |_BV(USIWM1) |_BV(USIWM0) |_BV(USICS1);// |_BV(USICS0);
DDRB &= 0xFA;	// make SDA and SCL both inputs
PORTB &= 0xFA;
}


