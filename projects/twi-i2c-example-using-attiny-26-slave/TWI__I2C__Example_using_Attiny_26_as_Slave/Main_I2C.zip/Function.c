
#include <avr/io.h>
#include "Function.h"


/****************************************************************************************
delay routine in microseconds from 32 bits in length from 0 to 4,294,967,295
*****************************************************************************************/

void delay(unsigned long int uMicroSeconds)
{
	uMicroSeconds <<= DELAY_SHIFT;
	uMicroSeconds -= uMicroSeconds >> 2;
	for(;uMicroSeconds>0;uMicroSeconds--)
	asm("nop");

}



/*****************************************************************
port test program
******************************************************************/

void Port_test (unsigned char Port_Num)
{
unsigned char p = 0;
    if (Port_Num == 'A') PORTA = ~p;
	if (Port_Num == 'B') PORTB = ~p;
	delay(50000);
	
	p = 1;
	while(p < 127)
		{
		if (Port_Num == 'A') PORTA = ~p;
		if (Port_Num == 'B') PORTB = ~p;
		delay(50000);
		p <<=1;
		}
		
	while(p > 0)
		{
		if (Port_Num == 'A') PORTA = ~p;
		if (Port_Num == 'B') PORTB = ~p;
		delay(50000);
		p >>=1;
		}
}

