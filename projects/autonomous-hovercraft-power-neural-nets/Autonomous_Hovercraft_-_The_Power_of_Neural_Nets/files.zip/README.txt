Autonomous Hovercraft - The Power of Neural Nets

This was a project entered in the 2002 IISEF (Intel International Science and Engineering Fair).
For this reason there are lots of files, such as various write-ups. You'll need Microsoft word
to view a lot of these files. They contain a fair amount of embedded documents, so you really do
need word. Although the files did open on OpenOffice in Linux Mandrake, and they had very few errors
(mostly colours off, images swapped around). 

documents	>> various documents related to the project
images    	>> images of the hovercraft
schematics	>> schematics of the boards (in Multisim format)
source_code	>> source code in BASCOM-AVR format

IMPORTANT: READ the file READ_ME_NOW.txt in the source_code directory!!


Thanks to J-Y Besqueut of France for helping me with the original neural network prorgam! This is
version 2.0 included here, but without his help I may not have started the project!

questions or comments?

c_oflynn@yahoo.com

coflynn@newae.com   (this just redirects to c_oflynn@yahoo.com, but if I lose c_oflynn@yahoo.com
i'll redirect this to my real e-mail, so try c_oflynn@yahoo.com first)

MSN messenger
c_oflynn@yahoo.com

ICQ
91962033