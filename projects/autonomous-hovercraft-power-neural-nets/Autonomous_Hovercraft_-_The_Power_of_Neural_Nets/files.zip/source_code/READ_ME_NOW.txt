Note: Its is EXTREAMLY important to ALWAYS test the neural network. As of June 23, 2002 you NEED
the latest version of BASCOM-AVR, which is version 1.11.6.7 to support the exp function properly.
Some earlier version's didn't work. You can check this by running the code:

Dim Test As Single
Test = Exp(12.1112)
Print Test
End

and simulating it. It should give 181897.75 , you can check that with a scientific calculator.

Also always check the code. Give the ANN a certain input, and record teh output. Then run the same
ANN on your computer with the same input, the outputs should be fairly close to each other. Check
this with a few different inputs. This just checks that the lesson files is properly set up and
whatnot.