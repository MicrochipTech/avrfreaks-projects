This is bootloader for the ATmega8

1.Use you STK500 program the uart.hex into atmega8
2.Programming the fuse as the 1MHz internal RC ocsillator,bootloader size 512 words,reset from the bootloader.
3.Reset your target board.Now you can open the hyperterminal(it is a windows build-in program),press key 'D',if see the CCC (if not ,disconnect the port,change the serial port property to 4800,8,none,2,none. And connnect again. )press alt+T,select the protocol XMODEM,and select the file to download.Notice the file to dowload should be plain binary ,and normally the output file of the compiler is the hex file,you should convert the hex file into the binary file with the cmd hex2bin.exe(it is an open source program.For saving the space,I did not include its source file ,you can find it on the gnu.org.) in this directory first.

If you have any problem,please send me  email(wumingqi@etang.com).