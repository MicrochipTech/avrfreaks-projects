LH-Converter Project v0.23 - All parts (C) 2002 by Dupont Engineering
=====================================================================

This distribution set contains:
-------------------------------

01_readme.txt......................This file

LH_Convert-v03.pdf.................Project documentation in Adobe Acrobat Reader .pdf format 

LH_Convert-schematic-v8.gif........Project schematic in GIF format

8535def.inc........................Register definition file for Atmel Studio 3.53

lh_convert-irq09a.asm..............Assembler source code for LH-Converter firmware 
                                   To be assembled with Atmel Studio 3.53 (from www.atmel.com)

lh_convert-irq09a.hex..............Assembled Intel-HEX file to be programmed into Atmel microcontroller 


This project is released only for non-profit or educational purposes.
Commercial use is prohibited.


-End of file-