#include <90s2313.h>
// CodeVisionAVR C Compiler
// (C) 1998-2000 Pavel Haiduc, HP InfoTech S.R.L.

// I/O registers definitions for the AT90S2313

#ifndef _90S2313_INCLUDED_
#define _90S2313_INCLUDED_

#pragma used+
sfrb ACSR=8;
sfrb UBRR=9;
sfrb UCR=0xa;
sfrb USR=0xb;
sfrb UDR=0xc;
sfrb PIND=0x10;
sfrb DDRD=0x11;
sfrb PORTD=0x12;
sfrb PINB=0x16;
sfrb DDRB=0x17;
sfrb PORTB=0x18;
sfrb EECR=0x1c;
sfrb EEDR=0x1d;
sfrb EEAR=0x1e;
sfrb WDTCR=0x21;
sfrb ICR1L=0x24;
sfrb ICR1H=0x25;
sfrw ICR1=0x24;   // 16 bit access
sfrb OCR1L=0x2a;
sfrb OCR1H=0x2b;
sfrw OCR1=0x2a;   // 16 bit access
sfrb TCNT1L=0x2c;
sfrb TCNT1H=0x2d;
sfrw TCNT1=0x2c;  // 16 bit access
sfrb TCCR1B=0x2e;
sfrb TCCR1A=0x2f;
sfrb TCNT0=0x32;
sfrb TCCR0=0x33;
sfrb MCUSR=0x34;
sfrb MCUCR=0x35;
sfrb TIFR=0x38;
sfrb TIMSK=0x39;
sfrb GIFR=0x3a;
sfrb GIMSK=0x3b;
sfrb SPL=0x3d;
sfrb SREG=0x3f;
#pragma used-

#define OCR1AL OCR1L
#define OCR1AH OCR1H

// Interrupt vectors definitions

#define EXT_INT0 2
#define EXT_INT1 3
#define TIM1_CAPT 4
#define TIM1_COMP 5
#define TIM1_OVF 6
#define TIM0_OVF 7
#define UART_RXC 8
#define UART_DRE 9
#define UART_TXC 10
#define ANA_COMP 11

#endif

// #define abs_hoehe 

#ifdef abs_hoehe 
float log(float x);
unsigned int abs(int x);

  #pragma library math.lib
#endif
unsigned int abs(int x);

  #pragma library math.lib

/* 
 * Variablendeklaration
 *
 */

#define CS   0x10               // Chip Sel. LTC2400
#define SCK  0x04               // Clk LTC2400
#define DIN  0x01               // Data out LTC2400

char init;                       // Nach Reset auf 1

char AdcTimerFlag;		// alle 200ms einmal A/D einlesen
char AdcTimer;
char TimerTicks;                // einmal pro 2ms erh�hen

char FiltTimerFlag;             // filtert die Variometerfrequenz
char FiltTimer;                 // dadurch keine sprunghafte �nderung
char Filt;                      // der Variofrequenz
float out;
int vario;                      // Vario-Frequenzfilter
char ptr;			// Zeiger f�r UART

unsigned int start;             // Pos. Flanke timer
//unsigned int stop;            // Neg. Flanke timer
unsigned int Puls;		// Pulsbreite vom Sender 2us genau. 

float f_adc_filt;
float f_adc_alt;
float f_adc;			// ADC als Float-wert


#ifdef abs_hoehe
  float p0;			// ist Eingangsvariable f�r H�hendifferenz
  int hoehe;                    // Differenzh�he seit letztem Reset
#endif

//long ADC_in;			// eingelesene Datenbits von externem IRQ
union Adc
{
   long ADC_in;
   unsigned char in[4];
} help;


//long ADC_filt;
//long ADC_alt;                   // Filter, Differenzierer

int  v_vertikal;                // steigen / fallen, in m/sec mit 2 nachkomma
int vario_frq;			// Periodendauer /2 -> toggle OC1
/*
union b
{
   unsigned char byte[2];
   unsigned int frq;
} vario_frq;       
*/
union c
{
   unsigned char byte[2];
   unsigned int  word;
} uword;       

union d
{
   unsigned char byte[4];
   unsigned long dword;
} ulong;       


/*

 * Timer 0 overflow IRQ, alle 10ms ein Interrupt
 * generiert die Zeitbasis f�r Adc einlesen und 
 * das Hauptprogramm
 *
 */
 
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{

// Reload T0 , 2 ms Zyklus
TCNT0=0x83;  

TimerTicks++; 
if ( TimerTicks == AdcTimer){
   AdcTimerFlag = 0xFF;                 // einmal A/D anstossen
   AdcTimer     = TimerTicks + 100;     // wieder 200ms warten
   }

Filt++;
if ( Filt == FiltTimer){
   FiltTimerFlag = 0xFF;                // einmal Filter anstossen
   FiltTimer     = Filt + 5;            // wieder 10ms warten
   }

if(ptr > 0){
   UDR = ulong.byte[--ptr];		// ADC_in auf V24   
   }
}

interrupt [TIM1_COMP] void timer1_isr(void)
{
// Reload T1 Compare, Vario-Frequenz wird hier generiert

   uword.byte[0] = TCNT1L;
   uword.byte[1] = TCNT1H;
   uword.word    = uword.word + vario_frq;
   OCR1H     = uword.byte[1];
   OCR1L     = uword.byte[0];

}

/*
 *  IRQ1 misst die Pulsbreite vom Sender aus. Aufl�sung �ber Timer1
 *  16 Bit mit 2us Genauigkeit. Mit der Pulsbreite wird das eigensinken
 *  kompensiert.
 *
 */
interrupt [EXT_INT1] void ext1_isr(void)
{

   if(PIND.3){                    
      MCUCR     = 0x08;           // pos. Flanke liegt an, startzeit nehmen
      uword.byte[0] = TCNT1L;
      uword.byte[1] = TCNT1H;     // Timerstand nehmen
      start = uword.word;         // als Startzeit speichern
   }
   else{
      MCUCR     = 0x0c;           // pos. Flanke erzeugt Interrupt
      uword.byte[0] = TCNT1L;
      uword.byte[1] = TCNT1H;     // Timerstand nehmen
//    stop = uword.word;          // Stopzeit
      Puls = uword.word - start;  // Pulsbreite
   }
   

}
void main(void)
{
unsigned char i,x;


// Port B  -> LCD-Ausgabe, vario Frequenz
   DDRB      = 0x8;
   PORTB     = 0x0;

// Port D  -> ADC input, UART
   DDRD      = 0xf6;
   PORTD     = 0xF6;

// Timer 0 init
   TCCR0     = 0x03;
   TCNT0     = 0x83;

// Timer 1 init
   vario_frq = 375;		// 660 Hz
   TCCR1A    = 0x40;
   TCCR1B    = 0x02;
   TCNT1H    = 0;
   TCNT1L    = 0;
   
   uword.byte[0] = TCNT1L;
   uword.byte[1] = TCNT1H;
   uword.word    = uword.word + vario_frq;
   OCR1H     = uword.byte[1];
   OCR1L     = uword.byte[0];

/*
   vario_frq = 0xFE88;		// 660 Hz
   TCCR1A    = 0x40;
   TCCR1B    = 0x02;
   TCNT1H    = (unsigned char) (vario_frq>>8);
   TCNT1L    = (unsigned char)  vario_frq;
   OCR1H     = 0xff;
   OCR1L     = 0xff;
*/
// External Interrupts: IRQ 0 aktiv
   GIMSK     = 0x80;
   MCUCR     = 0x0C;           // pos. Flanke erzeugt Interrupt
   GIFR      = 0x40;

// TimerInterrupts init
   TIMSK    = 0x42;

// UART init 9K6
   UCR      = 0x08;
   UBRR     = 0x19;

// Analog Comparator off
   ACSR     = 0x80;

// Global enable interrupts
#asm("sei")

// Variablen Init           
   
   init          = 0xff;

//   TimerTicks    = 0;
   AdcTimer      = TimerTicks + 100;     // wieder 200ms warten
//   AdcTimerFlag  = 0;

//   FiltTimerFlag = 0;
//   Filt          = 0;
   FiltTimer     = Filt + 5;
//   v24_count	 = 0;

while (1)
      {


if(FiltTimerFlag == 0xff){
   FiltTimerFlag = 0;                            // Filter 10ms rechnen

   out       =  out + ((float)(vario)-out)/10;
   vario_frq = (int)out;
  }


if(  AdcTimerFlag == 0xff){
   AdcTimerFlag = 0;                            // H�he und vario alle 200ms rechnen

// ADC Lesen 

   PORTD = PORTD & ~SCK;             		// SCK low
   PORTD = PORTD & ~CS;              		// CS low, ext. SCK
   help.ADC_in = 0;
   
   for(x=3;x+1>0;x--){
      for(i=0;i<8;i++){                		// 8 Datenbits vom ADC holen
       help.in[x] = help.in[x]<<1 ;             // ADC schieben
       help.in[x] = help.in[x] |(PIND & 0x01);  // mit anliegendem Datenbit beschreiben
       PORTD  =  PORTD |  SCK;        		// Pegelwechsel fordert n�chstes Bit an
       PORTD  =  PORTD & ~SCK;
       } 
   }

   PORTD = PORTD | CS ;
   help.ADC_in = ((help.ADC_in>>4) & 0x00ffffff);                     	// CS wieder high
   f_adc = (float)help.ADC_in ;  	// 24 Bit begrenzung
//     f_adc = (float)((help.ADC_in>>4) & 0x00ffffff);
   if(init == 0xff){
      	f_adc_filt   = f_adc;              	// nach Reset Filter
      	f_adc_alt    = f_adc;              	// und Differenzierer
      	init         = 0;                       // initialisieren
      	
        
#ifdef abs_hoehe
        p0         = f_adc;        
#endif

    }



f_adc_filt    =  f_adc_filt + (f_adc -f_adc_filt)/3;
v_vertikal = ((int)((f_adc_filt - f_adc_alt)) / 2)  ;
f_adc_alt = f_adc_filt;
   v_vertikal = v_vertikal + (Puls - 800);
   
   if(v_vertikal > 400)
       v_vertikal = 400;
   if(v_vertikal < -400)
       v_vertikal = -400;                       // max. +-4m/sec
   
   if(abs(v_vertikal) < 35)
        DDRB      = 0;
   else 
        DDRB      = 0x8;

   
   vario  = (unsigned int)( (float)250000 / (float)(660-v_vertikal));
                                               // umrechnen in Timer Ladewert
   ulong.dword = (unsigned long)Puls;
   ptr = 4;
#ifdef abs_hoehe                                               
   hoehe = (int)((log(p0/(float)help.ADC_in)*75500));   
                                               // h�he nach barom. H�henformelmit 1nk
#endif
   }
 };//while
}
