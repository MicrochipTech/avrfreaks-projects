/***********************************************************************
Content: Library for PWM functions in Timer1 (2*8bit)
Created: 16.02.2004
Last modified: 17.02.2004
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
------------------------------------------------------------------------
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/



/***********************************************************************
Includes
***********************************************************************/
#include "common.h"
#include "pwm.h"
 

/***********************************************************************
Init the PWM and hardware for PWM output / 2 * 8-Bit Phase Correct modus
***********************************************************************/
void pwm_init(void)
{
  TCCR1A=0xA1;  
  TCCR1B=0x02;  
  TCNT1H=0x00;  
  TCNT1L=0x00;
  OCR1AH=0x00;
  OCR1AL=0x00; 
  OCR1BH=0x00;
  OCR1BL=0x00; 
  SET_PWM_A_TO_OUTPUT();
  SET_PWM_B_TO_OUTPUT();
}


/***********************************************************************
Set PWM duty cycle for Channel A on Timer 1 
***********************************************************************/
void pwm_set_a(BYTE value)
{
  OCR1AL = value;
}


/***********************************************************************
Set PWM duty cycle for Channel B on Timer 1 
***********************************************************************/
void pwm_set_b(BYTE value)
{
  OCR1BL = value;
}


/***********************************************************************
End of code listing
***********************************************************************/