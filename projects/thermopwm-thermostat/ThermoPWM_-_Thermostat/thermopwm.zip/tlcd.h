/***********************************************************************
Content: Library for Hitachi 44780 based 1 or 2 line Text LCD displays.
Created: 28.05.2003
Last modified: 17.02.2004
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
------------------------------------------------------------------------
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/



/***********************************************************************
Port and Pin configuration 
***********************************************************************/
// LCD pins
#define DB7       0x01
#define DB6       0x02
#define DB5       0x04
#define DB4       0x08
#define ENABLE    0x10
#define RS        0x20
// Switch pins (Optional if needed in application)
#define SW1		  0x40
#define SW2		  0x80
// Port
#define LCDDDR    DDRC
#define LCDPORT   PORTC
#define LCDPIN    PINC
// General defines
#define DATA      0x01
#define CTRL      0x00


/***********************************************************************
Prototypes
------------------------------------------------------------------------
Set up selected port and initialize the LCD controller in 4-bit modus.  
***********************************************************************/
void tlcd_init(void);

/***********************************************************************
Clears all text.
***********************************************************************/
void tlcd_cls(void);

/***********************************************************************
Goto specified column and line. 1,1 is the upper left corner.
***********************************************************************/
void tlcd_goto(BYTE column, BYTE line);

/***********************************************************************
Write strings to the display. Set position with tlcd_goto first.
Text will wrap if to long to show on one line.
***********************************************************************/
void tlcd_write_string(char *ptr);

/***********************************************************************
Write const strings to the display. Set position with tlcd_goto first.
Text will wrap if to long to show on one line.
***********************************************************************/
void tlcd_write_const_string(const char *ptr);

/***********************************************************************
Most for internal use only
***********************************************************************/
void tlcd_write_byte(BYTE control, BYTE data);


/***********************************************************************
End of code listing
***********************************************************************/