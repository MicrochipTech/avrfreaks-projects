/***********************************************************************
Content: Library for PWM functions in Timer1 (2*8bit)
Created: 16.02.2004
Last modified: 17.02.2004
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
------------------------------------------------------------------------
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/



/***********************************************************************
Port and Pin configuration 
***********************************************************************/
#define PWMPORT 					PORTD
#define PWMDDR						DDRD
#define PWMA                        5
#define PWMB                        4


/***********************************************************************
Macros
***********************************************************************/
#define SET_PWM_A_TO_OUTPUT()       SETBIT(PWMDDR, PWMA)
#define SET_PWM_B_TO_OUTPUT()       SETBIT(PWMDDR, PWMB)


/***********************************************************************
Common prototypes
------------------------------------------------------------------------
Init the PWM and hardware for PWM output / 2 * 8-Bit Phase Correct modus
***********************************************************************/
void pwm_init(void);

/***********************************************************************
Set PWM duty cycle for Channel A. Value: 1=0%, 128=50%, 255=100% 
***********************************************************************/
void pwm_set_a(BYTE value);

/***********************************************************************
Set PWM duty cycle for Channel B. Value: 1=0%, 128=50%, 255=100% 
***********************************************************************/
void pwm_set_b(BYTE value);


/***********************************************************************
End of code listing
***********************************************************************/