/***********************************************************************
Content: Example on LCD, I2C sensor reading and PWM output on ATMega16
Created: 16.02.2004
Last modified: 17.02.2004
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
------------------------------------------------------------------------
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/



/***********************************************************************
Comments:

In this example we have connected the LCD display to PORTB using PINS
0 to 5, and PINS 6 and 7 to two switches. The switch should be connected
from the PIN to GND. Important: Connect the LCD R/W to GND. 
*** Change any LCD hardware changes in tlcd.h

PWM output is generated with Timer1 and outputs is on PORTD.5. This can
be directly connected through a 100 Ohm resitor to an FET driving a 
lamp, motor, fan etc.

Temperature is read from an Dallas DS1621 coded with address 0.
*** Change any I2C hardware changes in i2c.h

The duty cycle will rise with higher temperatures. At 70�C or higher the
duty cycle is 100%.

This was tested on a ATmega16, but all AVR with an Timer1 (PWM) should
be able to do the work... Code will use about 4.5k so no AT90S2313 :-\
***********************************************************************/



/***********************************************************************
Includes
***********************************************************************/
#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include "tlcd.h"
#include "i2c.h"
#include "pwm.h"



/***********************************************************************
Calculate the PWM duty cycle based on temperature specified and update
the LCD display with temperature and duty cycle percent.
***********************************************************************/
void pwm_set(BYTE centigrades)
{
  float tmp_f;
  BYTE tmp_b;
  unsigned char str[12];  
  // 2-step increase where 3.643 * 70�C = 255, or 100% duty cycle
  if (centigrades < 35) tmp_f = 2 * centigrades; else tmp_f = 3.643 * centigrades;
  // If higher than 70�C make sure we dont get register values higher than 255
  if (tmp_f > 255) tmp_f = 255; 
  // Set the PWM register
  pwm_set_a(tmp_f);
  // Write the temperature to the display
  tlcd_goto(1,1);
  sprintf(str,"T:%d�C ",centigrades);	
  tlcd_write_string(str);
  // Calculate duty cycle in percent and write it to the display
  tmp_f = tmp_f / 255 * 100;
  tmp_b = tmp_f;
  tlcd_goto(9,1);
  sprintf(str,"Fan:%d%% ",tmp_b);	
  tlcd_write_string(str);
}


/***********************************************************************
MAIN
***********************************************************************/
void main(void)
{
  BYTE temp;
  // Disable all interupts
  CLI();
   // Init the PWM
  pwm_init();
  // Init the I2C hardware
  i2c_init();
  // Init the LCD hardware
  tlcd_init();
  // Cleaning up the LCD
  tlcd_cls();
  // Enable all interupts
  SEI();
 
  // And now, the everlasting looooooooop :-)
  while(1) 
  {
	// Get the temperature from the Dallas 1621
    temp = get_ds1621_temperature(0);
	// Set PWM and update LCD
	pwm_set(temp);
	// Wait 2 seconds...
	waitms(2000);
  }
}


/***********************************************************************
End of code listing
***********************************************************************/