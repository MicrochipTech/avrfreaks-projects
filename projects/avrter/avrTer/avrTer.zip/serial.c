#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <stdio.h>

/* Buffersizes must be a power of 2 */

#define txbufSIZE	16
#define rxbufSIZE	16

#define TMASK		(txbufSIZE-1)
#define RMASK		(rxbufSIZE-1)

volatile unsigned char txbuf[txbufSIZE];
volatile unsigned char rxbuf[rxbufSIZE];

volatile unsigned char tx_in;
volatile unsigned char tx_out;

volatile unsigned char rx_in;
volatile unsigned char rx_out;

SIGNAL(SIG_UART_RECV) {
	unsigned char c;
	
	if (inp(UCSRA) & (BV(FE)|BV(DOR)|BV(PE))) {
		c=inp(UDR);
		return;
	}
	
	c = inp(UDR);

	rxbuf[rx_in & RMASK] = c;
	rx_in++;
}

SIGNAL(SIG_UART_DATA) {
	if(tx_in != tx_out) {
		outp(txbuf[tx_out & TMASK], UDR);
		tx_out++;	
	}
	else {
		UCSRB &= ~(1<<UDRIE);
	}
}

char txbuflen(void) {
	return(tx_in - tx_out);
}

int UART_putchar(char c) {
	/* Fills the transmit buffer, if it is full wait */
	while((txbufSIZE - txbuflen()) <= 2);
	
	/* Add data to the transmit buffer, enable TXCIE */
	txbuf[tx_in & TMASK] = c;
	tx_in++;
	
	UCSRB |= (1<<UDRIE);			// Enable UDR empty interrupt
	
	return(0);
}

char rxbuflen(void) {
	return(rx_in - rx_out);
}

int UART_getchar(void) {
	unsigned char c;

	//while(rxbuflen() == 0);
	if (rxbuflen()==0)
		return(0);
	
	c = rxbuf[rx_out & RMASK];
	rx_out++;
	
	return(c);
}

unsigned char calcParity(unsigned char c) {
	switch (c) {
		case 'n': return 0;
		case 'e': return 2;
		case 'o': return 3;	
		default: return 0;		
	}	
}

unsigned char calcStop( unsigned char c) {
	if (c == 0)
		return 0;
		
	return c-1;
}

unsigned char calcDataLen(unsigned char c) {
	if (c < 53)
		return 3;
		
	return c-53;
}

unsigned int calcBaud(unsigned int baud) {
	switch (baud) {
	/*	case 12: return 766;
		case 24: return 383;
		case 48: return 191;
		case 96: return 95;
		case 144: return 63;
		case 192: return 47;
		case 288: return 31;
		case 384: return 23;
		case 576: return 15;
		case 768: return 11;
		case 1152: return 7;
		case 2304: return 3;
		default: return 95;*/
		case 12: return 414;
		case 24: return 207;
		case 48: return 103;
		case 96: return 51;
		case 192: return 25;
		default: return 51;
	}	
}

void disableReceiver(void) {
	UCSRB &= ~(1<<RXEN);
}

void enableReceiver(void) {
	UCSRB |= (1<<RXEN);
}

void openUART (unsigned int baud,  unsigned char parity, unsigned char datalen, unsigned char stop) {
	
	cli();
	
	baud = calcBaud(baud);
	
	UBRRL = baud & 0xFF;
	UBRRH = (baud>>8)&0xFF;
	
	UCSRB = (1<<RXCIE)|(1<<TXEN)|(1<<RXEN);
	
	UCSRC = ((calcParity(parity)<<4)&0x30) | (calcStop(stop)<<3&0x80) | ((calcDataLen(datalen)<<1)&0x06);
	
	fdevopen(UART_putchar, UART_getchar, 0);
	sei();			
}


