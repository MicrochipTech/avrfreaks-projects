//************************************************************************
// T6963.H
//
// LCD Gr��e und Hardwaredefinitionen
//
// holger.klabunde@t-online.de
// http://home.t-online.de/home/holger.klabunde/homepage.htm
// 11.01.2003
// Compiler AVR-GCC 3.2
//************************************************************************
#ifndef t6963_h
#define t6963_h

#include <avr/pgmspace.h>


#define LCD_WIDTH	240  //Display Breite
#define LCD_HEIGHT	64   //Display H�he

// !!! only use ONE of the definitions below !!!
#define PIXPERBYTE_6 //pin FONT of the display connected to +5V
                      //undef this if you use 8x8 builtin font of display
                
//#define PIXPERBYTE_8  //pin FONT of the display connected to GROUND
                      //undef this if you use 6x8 builtin font of display

#ifdef PIXPERBYTE_6       // 6 bits per character for builtin font
 #define PIXPERBYTE    6  // than also 6 pixel per byte for graphic
#endif

#ifdef PIXPERBYTE_8      // 8 bits per character for builtin font
 #define PIXPERBYTE    8 // than also 8 pixel per byte for graphic
#endif

#define BYTES_PER_ROW   LCD_WIDTH / PIXPERBYTE     // how many bytes per row on screen
#define DISPLAYBYTES    BYTES_PER_ROW * LCD_HEIGHT // how many bytes for a screen

#define T_BASE  0 	//begin of textarea
#define T_END   T_BASE + ( BYTES_PER_ROW * LCD_HEIGHT / 8 ) //end of textarea

#define G_BASE  0x0200            	// base address of first screen
#define G_END  	G_BASE+DISPLAYBYTES-1   // end adress of first screen
#define G_BASE1 G_BASE+DISPLAYBYTES     // base address of 2nd screen
#define G_END1 	G_BASE1+DISPLAYBYTES-1  // end adress of 2nd screen


//PORTC ist der Datenport
#define INIT_CONTROL_PINS() { DDRD|=0xF0; } //control pins to output

#define DATA_DIR_IN()  DDRB&=0xF0;DDRC&=0xF0; // set io-pins to inputs
#define DATA_DIR_OUT() DDRB|=0x0F;DDRC|=0x0F; // set io-pins to outputs

#define READ_DATA()    ((PINB&0x0F)|((PINC&0x0F)<<4))	  // read PINC, ! NOT ! PORTC
#define WRITE_DATA(a)  PORTB=(a&0x0F);(PORTC=(a>>4)&0x0F);//PORTB=(a); // write to data port

#define WR_ON()  sbi(PORTD,4); //PA6
#define WR_OFF() cbi(PORTD,4);

#define RD_ON()  sbi(PORTD,5); //PA7
#define RD_OFF() cbi(PORTD,5);

#define CE_ON()  sbi(PORTD,6); //PD4
#define CE_OFF() cbi(PORTD,6);

#define CTRL()   sbi(PORTD,7); //PD5 => A0 => C/D = 1
#define DATA()   cbi(PORTD,7); //       A0 => C/D = 0

//Prototypes
extern unsigned char ReadDisplay(void);
extern void WriteData1(unsigned char, unsigned char);
extern void WriteData2(unsigned int, unsigned char);
extern void WriteData(unsigned char dat);
extern void WriteCommand(unsigned char command);
extern void SetPosition(unsigned char xpos, unsigned char ypos);
extern void DisplayOn(void);
extern void ClearScreen(void);
extern void ClearTextScreen(void);
extern void ClearGScreen(unsigned int begin, unsigned int end);
extern void FillScreen(void);
extern unsigned char ConvertText(unsigned char ch);
extern void LCDText(char *txt, unsigned char xpos, unsigned char ypos);
extern void LCDText_P(const prog_char *txt, unsigned char xpos, unsigned char ypos);

extern void LCDChar(unsigned char ch, unsigned char xpos, unsigned char ypos);
extern void setCursor( unsigned char xpos, unsigned char ypos);

extern void CursorON(void);
extern void CursorOFF(void);
extern void initBlackCol(unsigned int col);

#endif // t6963_h
