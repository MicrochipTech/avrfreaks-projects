//************************************************************************
// T6963.C
// LowLevel Routinen f�r LCD-Displays mit T6963
// Getestet mit AVR/ATMega bis 8MHz.
//
// Der Nullpunkt des Displays liegt oben,links. F�r unten rechts
// m�ssen dann zus�tzliche Umrechnungen stattfinden.
//
// Mit SetPixel hat man den Grundstein f�r alle
// erdenklichen Zeichenroutinen:
// Linien, Rechtecke, Kreise, F�llen, Muster
//
// holger.klabunde@t-online.de
// http://home.t-online.de/home/holger.klabunde/homepage.htm
// 11.01.2003
// Compiler AVR-GCC 3.2
//************************************************************************
#include <avr/io.h>

#include "T6963.h"


void CheckBusy(void)
{
	unsigned char by;

 	DATA_DIR_IN(); //DatenPort auf Eingang zum lesen
 	CTRL();    //Status Register lesen

 	do {
   		CE_OFF();
   		RD_OFF();
   		by=READ_DATA(); //Status lesen
   		RD_ON();
   		CE_ON();
  	} while((by & 3) != 3);

 	DATA();   //Zur�ck auf DisplayDaten schreiben
}


void WriteCTRL(unsigned char dat)
{
	DATA_DIR_OUT(); //DatenPort auf Ausgang zum schreiben
 	CTRL();     //Commando schreiben vorbereiten
 	WRITE_DATA(dat); //Daten zum Commando

 	CE_OFF();
 	WR_OFF();
 	WR_ON();
 	CE_ON();

 	DATA();   //Zur�ck auf DisplayDaten schreiben
}

void WriteData1(unsigned char dat, unsigned char command)
{
 	WriteData(dat); //Daten schreiben
 	WriteCommand(command); //Kommando schreiben
}

void WriteData2(unsigned int dat, unsigned char command)
{
	WriteData((unsigned char)(dat&0xFF)); //Daten schreiben
	WriteData((unsigned char)(dat>>8)); //Daten schreiben
	WriteCommand(command); //Kommando schreiben
}

void WriteData(unsigned char dat)
{
 	CheckBusy(); //StatusBits STA0,1 checken

 	DATA_DIR_OUT(); //DatenPort auf Ausgang zum schreiben
 	DATA();     //DisplayDaten schreiben vorbereiten
 	WRITE_DATA(dat); //Daten auf den Port

 	CE_OFF();
 	WR_OFF();
 	WR_ON();
 	CE_ON();
}


//Kommandobyte schreiben
void WriteCommand(unsigned char command)
{
 	CheckBusy(); //StatusBits STA0,1 checken
 	WriteCTRL(command); //Kommando schreiben
}


void DisplayOn(void)
{
	unsigned int i;
	INIT_CONTROL_PINS(); //set WR,CE,RD,C/D to outputs
 
 	WR_ON();
 	CE_ON();
 	RD_ON();
 	DATA();

 	DATA_DIR_OUT(); //DatenPort auf Ausgang zum schreiben
 
 	for (i=0; i<0xFFFF; i++)
 		asm volatile ("nop");
 
	//Write text home address=0x0000
 	WriteData2(T_BASE,0x40);

	//Write graphic home address
 	WriteData2(G_BASE,0x42);

	//Text area column set= Setze Textspalten 
 	WriteData2(BYTES_PER_ROW,0x41);

	//Graphics area column set in Bytes !!!
 	WriteData2(BYTES_PER_ROW,0x43);

	//set display mode = OR
 	WriteCommand(0x84);

	//Text and graphic display !!

 
 	WriteCommand(0x9F); //9C
 	
 	WriteCommand(0xA7);

	ClearGScreen(G_BASE,G_END1);
 	ClearScreen();
}


// Zeichen von Windows nach T6963 konvertieren
unsigned char ConvertText(unsigned char ch)
{
	unsigned char tmp;

 	tmp=ch;

	//Die case-Werte sind bezogen auf den SystemFont !!!
 	switch(ch)
  	{
   		case 196: tmp=0x6E; break; // �
   		case 228: tmp=0x64; break; // �
   		case 214: tmp=0x79; break; // �
   		case 246: tmp=0x74; break; // �
   		case 220: tmp=0x7A; break; // �
   		case 252: tmp=0x61; break; // �
   		case 223: tmp=223; break; // �
   		default: tmp-=0x20; break;
  	}

 	return tmp;
}


void setCursor( unsigned char xpos, unsigned char ypos) {
	WriteData2(xpos|ypos<<8,0x21);	
}

void LCDChar(unsigned char ch, unsigned char xpos, unsigned char ypos)
{
	WriteData2(xpos+(BYTES_PER_ROW)*ypos,0x24);
	//WriteData2(xpos|ypos<<8,0x21);
   	WriteData1(ConvertText(ch),0xC0);
}


// Text horizontal schreiben
void LCDText(char *txt, unsigned char xpos, unsigned char ypos)
{
	char ps;

	//Zeiger auf neue Textposition
 
 	WriteData2(xpos+(BYTES_PER_ROW)*ypos,0x24);
 	while((ps = *txt)) //Solange Zeichen gr��er 0x00
  	{
   		txt++; //N�chstes Zeichen
   		if (ps == 0) break; //Raus wenn Zeichen gleich 0
   		ps=ConvertText(ps); //�bersetzungstabelle aufrufen
   		WriteData1(ps,0xC0); //Write ps, Auto Inkrement
  	}
}

void LCDText_P(const prog_char *txt, unsigned char xpos, unsigned char ypos)
{
	char ps;

	//Zeiger auf neue Textposition
 
 	WriteData2(xpos+(BYTES_PER_ROW)*ypos,0x24);
 	while((ps = PRG_RDB(txt))) //Solange Zeichen gr��er 0x00
  	{
   		txt++; //N�chstes Zeichen
   		if (ps == 0) break; //Raus wenn Zeichen gleich 0
   		ps=ConvertText(ps); //�bersetzungstabelle aufrufen
   		WriteData1(ps,0xC0); //Write ps, Auto Inkrement
  	}
}

// Kompletten TextBildschirm l�schen
void ClearTextScreen(void)
{
 	int i;

	//Write text home address
	//Set address pointer = Text home
 	WriteData2(T_BASE,0x24);

	//ClearText RAM
 	for(i=0; i<(BYTES_PER_ROW * LCD_HEIGHT/8); i++) WriteData1(0x00,0xC0);
 
 	WriteData2(0,0x24);
 	WriteData2(0,0x21);
}


// L�sche Bereich im Grafikschirm
void ClearGScreen(unsigned int begin, unsigned int end)
{
 	unsigned int i;

 	WriteData2(begin,0x24); //Setze Startadresse des zu l�schenden Bereiches

 	for(i=begin; i<=end; i++)
 		WriteData1(0x00,0xC0);	
}

void initBlackCol(unsigned int col) {
 	unsigned int i;

 	WriteData2(G_BASE+BYTES_PER_ROW*col,0x24); //Setze Startadresse des zu l�schenden Bereiches

 	for(i=0; i<BYTES_PER_ROW; i++) {
 		WriteData1(0x05,0xC0);	
 	}		
 	WriteData2(G_BASE,0x24);
 	
}

//L�scht den TextBildschirm, den Grafikschirm und setzt den
//Grafikcursor auf 0,0
void ClearScreen(void)
{
 	//ClearGScreen(G_BASE,G_END1);
 	ClearTextScreen();
}


void CursorON(void) {
	WriteCommand(0x9F);		
}

void CursorOFF(void) {
	WriteCommand(0x9D);		
}
