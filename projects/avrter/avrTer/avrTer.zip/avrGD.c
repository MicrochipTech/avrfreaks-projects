#include <stdio.h>
#include <string.h>
#include <avr/pgmspace.h>

#include "T6963.h"
#include "serial.h"
#include "config.h"
#include "kb.h"

void delay(unsigned int time) {
	unsigned long j;
	
	for (j=0; j<time*10; j++)
		asm volatile ("nop");	
}

static unsigned char __attribute__ ((progmem)) LCDIntro[6][40] = {   
{"                      ____  ____  ____ \0"},
{"   __  _    _  ____  (_  _)( ___)(  _ \\\0"},
{"  /__\\( \\  / )(  _ \\   )(   )__)  )   /\0"},
{" /(__)\\\\ \\/ /  )   /  (__) (____)(_)\\_)\0"},
{"(__)(__)\\  /  (_)\\_)                   \0"},
{"         \\/                            \0"}
};

void showHelp(void) {
	ClearScreen();
	CursorOFF();
	LCDText_P (PSTR("avrTer | Help         Fl�ry Tobias, 2004"),0,0);
	
	LCDText_P (PSTR("F2  -> Serial Setup"),0,2);
	LCDText_P (PSTR("F11 -> enable Receiver"),0,3);
	LCDText_P (PSTR("F12 -> disable Receiver"),0,4);
	LCDText_P (PSTR("DEL -> clear Screen"),0,5);
	
	LCDText_P(PSTR("Press ENTER to continue"),0,7);

	while (getKBchar()!=13);
}

void getKBConfig(void) {
	unsigned char tmp[14];
	unsigned char i=0, c=0;

	initBlackCol(0);
	
	while (c == 0) {
		ClearScreen();
		LCDText_P (PSTR("avrTer | Configure Serial Interface"),0,0);
		LCDText_P (PSTR("Serial Setting: (e.g.: 9600,n,8,1)"),0,2);
		LCDText_P (PSTR("Format: Baudrate, Parity, Len, StopBits"),0,3);
		LCDText_P (PSTR("Enter Here: "),0, 5);
		CursorON();
		
		setCursor(12,5);
		
		c = 0;		
		
		for (i=0; i<13; i++) {
			setCursor(12+i,5);
			while ((tmp[i] = getKBchar())==0);
			
			if (tmp[i] == 8) break;

			LCDChar(tmp[i],12+i,5);
					
			if (tmp[i] == 13) {
				tmp[i] = 0;
				c = 1;
				break;
			}
		}	
	}
	
	strcpy(CONFIG.settings, tmp);
}

void getConfig(void) {
	unsigned int baud=0;
	unsigned char parity, datalen, stopb;
		
	if (readConfig()!=0xAA) {	
		getKBConfig();
	}
	
	while (sscanf(CONFIG.settings,"%u,%c,%c,%c",&baud, &parity, &datalen,&stopb)!=4) {
		getKBConfig();
	}
	
	safeConfig();
	openUART(baud/100,parity,datalen,stopb);
	ClearScreen();
	CursorOFF();	
}

void reConfig(void) {
	unsigned int baud=0;
	unsigned char parity, datalen, stopb;
		
	getKBConfig();

	while (sscanf(CONFIG.settings,"%u,%c,%c,%c",&baud, &parity, &datalen,&stopb)!=4) {
		getKBConfig();
	}	
	
	safeConfig();
	openUART(baud/100,parity,datalen,stopb);
	ClearScreen();
	CursorOFF();			
}

void printStatus(void) {
	LCDText_P(PSTR("avrTer |                 | F1: HELP"),0,0);
	LCDText(CONFIG.settings,9,0);	
	
	if (bit_is_set(UCSRB, RXEN)) 
		LCDChar('>',22,0);
	else
		LCDChar('x',22,0);
}

int main(void) {
	unsigned char xpos=0, ypos=1, tmp;
	unsigned int i;
	unsigned char tmpl[40];
	
	DisplayOn();
	ClearScreen();
	
	CursorOFF();

	initKB();
	
	for (i=0; i<6; i++) {
		strcpy_P(tmpl,LCDIntro[i]);
		LCDText(tmpl,0,i+1);
	}
	
	for (i=0; i<100; i++)
		delay(10000);
	
	getConfig();
			
	initBlackCol(0);			
	ClearScreen();
	printStatus();
	setCursor(0,1);
	CursorON();

	while (1) {

		tmp = getchar();

		if (tmp == 0) {
			
			tmp = getKBchar();	
			
			if (tmp == 8)
				continue;
				
			if (tmp == 0) {
				
				switch (getEXTchar()) {
					case 0:		// NO KEY PRESSED
						break;
					case F1:
						disableReceiver();
						showHelp();
						ClearScreen();
						CursorON();
						xpos=0;
						ypos=1;
						setCursor(xpos, ypos);					
						enableReceiver();
						printStatus();	
						break;
					case F2:
						disableReceiver();
						reConfig();
						CursorON();
						xpos=0;
						ypos=1;
						setCursor(xpos, ypos);						
						enableReceiver();
						printStatus();

						break;	
					case F11:
						enableReceiver();
						printStatus();
						break;
					case F12:
						disableReceiver();
						printStatus();
						break;
					case DEL:
						ClearScreen();
						CursorON();
						xpos=0;
						ypos=1;
						setCursor(xpos, ypos);
						printStatus();					
						break;
				}	
				continue;
			}
				
			if (tmp == 10 || tmp == 13) {
				putchar(10);
				putchar(13);	
			} else putchar(tmp);
		} 
		
		if (xpos == 0 && ypos == 1) {
			ClearScreen();
			printStatus();
		}
			
		if (tmp != 10 && tmp != 13) {
			//if (tmp < 0x09) continue;
			LCDChar(tmp,xpos,ypos);
			xpos++;
		} else {
			ypos++;
			xpos = 0;		
		}
			
		if (xpos > 39) {
			xpos = 0;
			ypos++;
		}
		
		if (ypos > 7) {
			ypos = 1;
			xpos = 0;
		}
		
		setCursor(xpos, ypos);
	}
	
	for (;;);
	return 0;	
}
