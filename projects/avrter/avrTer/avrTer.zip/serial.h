#ifndef ___SERIAL_H
#define ___SERIAl_H

/*
int UART_putchar(char c);
int UART_getchar(void); */

void disableReceiver(void);
void enableReceiver(void);

void openUART (unsigned int baud,  unsigned char parity, unsigned char datalen, unsigned char stop);

#endif
