#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>

#include <stdio.h>

#include "kb.h"
#include "kb_codes.h"
#include "T6963.h"


#define KB_BUFF_SIZE 	16
#define KB_MASK		(KB_BUFF_SIZE-1)


#define IS_SHIFT 1
#define IS_EXT	 2
#define IS_BRK	 3

#define BREAKE 0xF0
#define LSHIFT 0x12
#define RSHIFT 0x59

#define EXTENDED 0xE0

volatile unsigned char  type=0,shift=0, altgr=0;
volatile unsigned char edge, bitcount;


unsigned int kb_buf[KB_BUFF_SIZE];

unsigned char kb_in, kb_out;


void initKB(void)
{
    outp(0x02, MCUCR);                      // INT0 interrupt on falling edge
    outp(0x40, GIMSK);                      // enable external int0
    edge = 0;                               // 0 = falling edge  1 = rising edge
    bitcount = 11;
    
    cbi (DDRD, 2);
    cbi (DDRD, 3);

   
    kb_in = 0;
    kb_out = 0;
    
    type = 0;
    sei();
}

/* signal handler for external interrupt int0 */
SIGNAL(SIG_INTERRUPT0)
{
    static unsigned char data;                // Holds the received scan code
	
    if (!edge)                                // Routine entered at falling edge
    {
        if(bitcount < 11 && bitcount > 2)    // Bit 3 to 10 is data. Parity bit,
        {                                    // start and stop bits are ignored.
            data = (data >> 1);
            if(bit_is_set(PIND,PD3)) data = data | 0x80;
        }
        outp(0x03, MCUCR);                  // Set interrupt on rising edge
        edge = 1;
    }
    else
    {                                       // Routine entered at rising edge
        outp(0x02, MCUCR);                      // Set interrupt on falling edge
        edge = 0;
        if(--bitcount == 0)                    // All bits received
        {
            scanCode(data);
            bitcount = 11;
        }
    }

}


void scanCode(unsigned char code) {
	unsigned char tmp=0xFF,i=0;

	switch (code) {
		case EXTENDED: 
			type = IS_EXT; 
			break;
		case LSHIFT:
		case RSHIFT: 
			if (type != IS_BRK)
				shift = IS_SHIFT;
			else {
				shift=0;
				type=0;	
			}
			
			break;
		case BREAKE:			
			type = IS_BRK; 
			break; 
		
		default:
			switch (type) {
				case IS_EXT:
					if (code == 0x11) {
						altgr = 1;
						type = 0;
						break;	
					}
					
					i=0;
					while ((tmp = PRG_RDB(&kb_extended[i][0])) != 0) {
						if (tmp == code) {
							kbPutBuffer(0,PRG_RDB(&kb_extended[i][1]));
							break;
						}
						i++;
					}	

					type = 0;				
					break;
				
				case IS_BRK: 
					if (code == 0x11)
						altgr = 0;
						
					type = 0;
					break;
				
				default:
					i=0;
					
					if (altgr == 1) {
						while ((tmp = PRG_RDB(&kb_altgr[i][0])) != 0) {
							if (tmp == code) {
								kbPutBuffer(PRG_RDB(&kb_altgr[i][1]),0);
								break;
							}
							i++;
						}						
						//altgr = 0;	
						break;
					}
					
					if (shift != 0) {
						while ((tmp = PRG_RDB(&kb_shift[i][0])) != 0) {
							if (tmp == code) {
								kbPutBuffer(PRG_RDB(&kb_shift[i][1]),0);
								break;
							}
							i++;
						}	
	
					} else {
						while ((tmp = PRG_RDB(&kb_normal[i][0])) != 0) {
							if (tmp == code) {
								if (i<=11)
									kbPutBuffer(0,PRG_RDB(&kb_normal[i][1]));
								else
									kbPutBuffer(PRG_RDB(&kb_normal[i][1]),0);
								break;
							}
							i++;
						}
					}
					type = 0;					
			}
	}
}

unsigned char kbbuflen(void) {
	return(kb_in - kb_out);
}
	
void kbPutBuffer(unsigned char code, unsigned char ext) {

	kb_buf[kb_in & KB_MASK] = ((ext<<8)&0xFF00) | code;
	kb_in++;	
}

unsigned char kbGetBuffer(void) {
	unsigned char c;
	
	if (kbbuflen()==0)
		return(0);

	c = (kb_buf[kb_out & KB_MASK] & 0xFF);
	
	if (c!=0)
		kb_out++;
	return c;	
}

unsigned char kbGetExt(void) {
	unsigned char c;
	
	if (kbbuflen()==0)
		return(0);

	c = ((kb_buf[kb_out & KB_MASK]>>8)&0xFF);
	if (c!=0)
		kb_out++;
	return c;	
}

unsigned char getKBchar(void)
{
	return kbGetBuffer();	
}

unsigned char getEXTchar(void)
{
	return kbGetExt();	
}

