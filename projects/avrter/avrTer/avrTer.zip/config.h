#ifndef ___CONFIG_H
#define ___CONFIG_H


struct {
	unsigned char dummy;
	unsigned char settings[14];
} CONFIG;

unsigned char safeConfig(void);
unsigned char readConfig(void);
unsigned int getConfigBaud(void);

#endif
