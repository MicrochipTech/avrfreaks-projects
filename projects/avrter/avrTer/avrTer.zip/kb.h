#ifndef ___KB_H
#define ___KB_H


#define F1 		1
#define F2 		2
#define F3 		3
#define F4 		4
#define F5 		5
#define F6 		6
#define F7 		7
#define F8 		8
#define F9 		9
#define F10 		10
#define F11 		11
#define F12 		12


#define KEY_UP		15	
#define KEY_DOWN	16
#define KEY_LEFT	17
#define KEY_RIGHT	18

#define INS		20
#define DEL		21



unsigned char kbbuflen(void);
void kbPutBuffer(unsigned char code, unsigned char ext);

unsigned char kbGetBuffer(void);
unsigned char kbGetExt(void);

unsigned char getEXTchar(void);
unsigned char getKBchar(void);
void initKB(void);
void scanCode(unsigned char code);

#endif
