#include <avr/eeprom.h> 

#include "config.h"


unsigned char safeConfig(void) {
	//while (!eeprom_is_ready());
	CONFIG.dummy = 0xAA;
	
	loop_until_bit_is_clear(EECR, EEWE);
	eeprom_write_block (&CONFIG, 0, sizeof(CONFIG));
	return 0;	
}

unsigned char readConfig(void) {
	//while (!eeprom_is_ready());
	loop_until_bit_is_clear(EECR, EEWE);
	eeprom_read_block (&CONFIG, 0, sizeof(CONFIG));
	return CONFIG.dummy;
}


