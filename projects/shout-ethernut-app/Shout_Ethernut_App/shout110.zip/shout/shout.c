/*
 * Copyright (C) 2002 by egnite Software GmbH. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by egnite Software GmbH
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY EGNITE SOFTWARE GMBH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL EGNITE
 * SOFTWARE GMBH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.ethernut.de/
 * -
 * This work is based on Netuner, which is
 *
 * Copyright (c) 2002 by Michael Stegen / Stegen Electronics
 *
 */

/*
 * $Log$
 */

#include <stdlib.h>
#include <string.h>
//#include <interrupt.h>
#include <eeprom.h>

#include <dev/nicrtl.h>
#include <dev/uartavr.h>
#include <dev/vs1001k.h>
#include <dev/irqreg.h>

#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/print.h>
#include <sys/kprint.h>


#include <netinet/tcp.h>
#include <netinet/sostream.h>
#include <arpa/inet.h>
#include <net/route.h>

#include <fs/uromfs.h>
#include <pro/httpd.h>

#ifdef __GNUC__
#ifdef __AVR_ATmega128__
/*
 * Temporary fix for broken routines in GCC.
 */
#include <io.h>

#define wdt_reset() __asm__ __volatile__ ("wdr")

#define wdt_enable(timeout)                \
    __asm__ __volatile__ (                 \
        "in __tmp_reg__, __SREG__"  "\n\t" \
        "cli"                       "\n\t" \
        "wdr"                       "\n\t" \
        "out %1, %0"                "\n\t" \
        "out %1, %0"                "\n\t" \
        "out __SREG__, __tmp_reg__" "\n\t" \
        : /* no outputs */                 \
        : "r" (timeout | BV(WDE) | BV(WDCE)), \
          "I" _SFR_IO_ADDR(WDTCR)        \
        : "r0"                             \
)

#define wdt_disable()                      \
    __asm__ __volatile__ (                 \
        "in __tmp_reg__, __SREG__"  "\n\t" \
        "cli"                       "\n\t" \
        "wdr"                       "\n\t" \
        "out %1, %0"                "\n\t" \
        "out %1, __zero_reg__"      "\n\t" \
        "out __SREG__, __tmp_reg__" "\n\t" \
        : /* no outputs */                 \
        : "r" (BV(WDCE) | BV(WDE)),        \
          "I" _SFR_IO_ADDR(WDTCR)        \
        : "r0"                             \
        )
#else
#include <wdt.h>
#endif

#else   /* ICCAVR */

#define wdt_reset() _WDR()

void wdt_enable(u_char timeout)
{
    asm("in R0, 0x3F");
    asm("ori R16, 0x18");
    asm("cli");                      
    asm("wdr");                      
    asm("out 0x21, R16");               
    asm("out 0x21, R16");               
    asm("out 0x3F, R0");
}

void wdt_disable(void)
{
    asm("in R0, 0x3F");
    asm("clr R1");
    asm("ldi R16, 0x18");
    asm("cli");                      
    asm("wdr");                      
    asm("out 0x21, R16");               
    asm("out 0x21, R1");     
    asm("out 0x3F, R0");
}
#endif

/*!
 * \addtogroup xgShout
 */
/*@{*/

/*
 * Modify these.
 */
static u_char my_mac[] = { 0x00,0x06,0x98,0x00,0x00,0x00 };
#define MY_IP           "0.0.0.0"
#define MY_MASK         "255.255.255.0"
#define MY_GATE         "192.168.192.3"
#define DNSSERVERIP     "192.168.192.2"


static u_short mp3bufsiz = 12288;
static u_short tcpbufsiz = 4288;
static u_short mss = 536; /* 536..1460*/
static u_long to = 5000;

typedef struct {
    u_char *rs_name;
    u_char *rs_host;
    u_char *rs_url;
    u_short rs_port;
} RADIOSTATION;

/*!
 * \brief Pre-configured radio stations.
 */
RADIOSTATION station[] = {
    { "None", "0.0.0.0", "", 0 },
    { "Virgin", "212.187.204.62", "/", 80 },
    { "Electracks", "66.28.164.32", "/", 6390 },
    { "DH Net", "205.188.234.38", "/", 8030 },
    { "Cable Live", "62.25.96.7", "/", 8080 },
    { "9412", "205.188.234.34", "/", 8054 },
    { "70s Rock Stream", "66.250.21.19", "/", 8000 },
    { "WOLF FM", "205.188.209.193", "/stream/1028", 80 },
    { "WOLF FM", "205.188.234.34", "/", 8020 },
    { "Beethoven", "205.188.234.38", "/", 8012 },
    { "Paradise", "209.133.50.6", "/", 8080 },
    { "BlueFish", "66.216.66.164", "/", 8006 },
    { "Radio 1", "62.118.255.5", "/", 9000 },
    { "MIBN1", "216.234.109.21", "/", 8000 },
    { "ChibiMAK", "12.250.136.53", "/", 8000 },
    { "idobi", "209.220.233.87", "/", 18002 },
    { "Smooth Jazz", "205.188.209.193", "/stream/1020", 80 },
    { "Digital-Realm", "205.188.234.34", "/", 8010 }
};

static u_char rsidx = 0;
static u_char reset_pending = 0;

static u_char *radio_name;
static u_char *radio_genre;
static u_char *radio_url;

ROMENTRY *romEntryList;

static prog_char html_head[] = "<html><head><meta http-equiv=\"refresh\" content=\"10\">\r\n"
                        "<title>Ethernut Radio Control</title></head>";
static prog_char html_body_start[] = "<body bgcolor=\"#000000\" link=\"#FFFFFF\" "
        "vlink=\"#FFFFFF\" text=\"#FFFFFF\" alink=\"#FFFFFF\"><br>"
        "<font face=\"Verdana, Arial, Helvetica, sans-serif\">";
static prog_char html_body_end[] = "</body></html>";
static prog_char html_playing_start[] = "<font color=\"#FFCC00\"><h2>Playing</h2>";
static prog_char html_playing_end[] = "</font><br><br>";
static prog_char html_list[] = "<h2>Select a Station</h2>";

/*!
 * \brief Ethernut CGI function.
 *
 * Displays the the currently playing station and a list
 * of stations to choose from.
 */
int RadioControl(NUTDEVICE *sostream, REQUEST *req)
{
    u_char i;
    u_char sel = rsidx;

    NutHttpSendHeaderTop(sostream, req, 200, "Ok");
    NutHttpSendHeaderBot(sostream, "text/html", -1);

    if(req->req_query) {
        sel = (u_char)atoi(req->req_query);
        if(sel != rsidx) {
            eeprom_wb(512, sel);
            reset_pending = 1;
        }
    }
    NutPrintString_P(sostream, html_head);
    NutPrintString_P(sostream, html_body_start);
    NutPrintString_P(sostream, html_playing_start);
    if(radio_name) 
        NutPrintString(sostream, radio_name);
    NutPrintString(sostream, "<br>");
    if(radio_genre)
        NutPrintString(sostream, radio_genre);
    NutPrintString(sostream, "<br>");
    if(radio_url)
        NutPrintFormat(sostream, "<a href=\"%s\">%s</a>", radio_url, radio_url);
    NutPrintString_P(sostream, html_playing_end);

    NutPrintString_P(sostream, html_list);
    for(i = 0; i < sizeof(station) / sizeof(RADIOSTATION); i++)
        if(i != sel)
            NutPrintFormat(sostream, "<a href=\"radio.cgi?%u\">%s</a><br>\r\n", i, station[i].rs_name);
    NutPrintString_P(sostream, html_body_end);
    
    return 0;
}

/*!
 * \brief Process a single HTTP request.
 *
 * This routine performs the whole cycle of a HTTP request.
 *
 * - Creating a socket.
 * - Listening on the defined port.
 * - Processing the request.
 * - Closing the socket.
 */
void Service(void)
{
    TCPSOCKET *sock;        /* TCP socket pointer. */
    NUTDEVICE *sostream;    /* Virtual stream device. */
    u_short webbufsiz = 1024;

    /*
     * Let the Nut/OS library create a TCP socket for us.
     */
    if((sock = NutTcpCreateSocket()) != 0) {

        if(NutTcpSetSockOpt(sock, SO_RCVBUF, &webbufsiz, sizeof(webbufsiz))) 
            NutPrintString(0, "Sockopt rxbuf failed\r\n");

        /*
         * Listen on the port defined in webport.h.
         */
        if(NutTcpAccept(sock, 80) == 0) {
            while(NutHeapAvailable() < 4096)
                NutSleep(200);

            /*
             * Create a stream device from the socket.
             */
            if((sostream = NutSoStreamCreate(sock)) != 0) {
            
                /*
                 * Process http request and destroy stream
                 * device when done.
                 */
                NutHttpProcessRequest(sostream);
                NutSoStreamDestroy(sostream);
            }
        }

        /*
         * Close the socket.
         */
        NutTcpCloseSocket(sock);
    }
}

/*! \fn ServiceThread(void *arg)
 * \brief Background thread to process HTTP requests.
 *
 * This thread calls Service() in an endless loop.
 */
THREAD(ServiceThread, arg)
{
    NutRegisterCgi("radio.cgi", RadioControl);

    /*
     * Loop endless for connections.
     */
    for(;;) 
        Service();
}

/*!
 * \brief Process header from server.
 */
int ProcessHeader(TCPSOCKET *sock)
{
    int rc;
    NUTDEVICE *sostream = NutSoStreamCreate(sock);
    u_char *line = NutHeapAlloc(256);

    /*
     * Send the HTTP request.
     */
    NutPrintFormat(sostream, "GET %s HTTP/1.0\r\n"
                             "Host: %s\r\n", station[rsidx].rs_url, station[rsidx].rs_host);
    NutPrintString(sostream, "User-Agent: WinampMPEG/2.7\r\n"
                             "Accept: */*\r\n"
                             "Connection: close\r\n\r\n");
    NutPrintFlush(sostream);
       
    if(radio_name) {
        NutHeapFree(radio_name);
        radio_name = 0;
    }
    if(radio_genre) {
        NutHeapFree(radio_genre);
        radio_name = 0;
    }
    if(radio_url) {
        NutHeapFree(radio_url);
        radio_name = 0;
    }

    /*
     * Receive the HTTP header.
     */
    for(;;) {
        if((rc = NutDeviceGetLine(sostream, line, 256)) < 0)
            break;
        if(rc == 0)
            break;
        NutPrintString(0, line);
        NutPrintString(0, "\r\n");
        if(strncmp(line, "icy-name:", 9) == 0) {
            if(radio_name == 0) {
                radio_name = NutHeapAlloc(strlen(line + 9) + 1);
                strcpy(radio_name, line + 9);
            }
        }
        if(strncmp(line, "icy-genre:", 10) == 0) {
            if(radio_genre == 0) {
                radio_genre = NutHeapAlloc(strlen(line + 10) + 1);
                strcpy(radio_genre, line + 10);
            }
        }
        if(strncmp(line, "icy-url:", 8) == 0) {
            if(radio_url == 0) {
                radio_url = NutHeapAlloc(strlen(line + 8) + 1);
                strcpy(radio_url, line + 8);
            }
        }

    }

    /*
     * We don't need the stream device anymore.
     * This will discard some MP3 data too, but
     * who cares.
     */
    NutSoStreamDestroy(sostream);

    NutHeapFree(line);

    return 0;
}

/*! \fn NutMain(void *arg)
 * \brief Main application routine. 
 *
 * Nut/OS automatically calls this entry after initialization.
 */
THREAD(NutMain, arg)
{
    TCPSOCKET *sock;
    u_short rbytes;
    int got;
    u_char connected = 0;
    u_char *dataptr;

    /*
     * Initialize the UART device.
     */
    {
        u_long baud = 115200;
        NutDeviceIOCtl(0, UART_SETSPEED, &baud);
        outp(BV(RXEN) | BV(TXEN), UCR);
        NutPrintString(0, "\r\nEthernut Shoutcast Client 1.1.0\r\n");
    }
    
    /*
     * Initialize the Ethernet device.
     */
    NutRegisterDevice(&devEth0, 0x8300, 5);
    /* Avoid ImageCraft Error */
    {
        u_long my_ip = inet_addr(MY_IP);
        u_long my_mask = inet_addr(MY_MASK);
	    NutNetIfConfig("eth0", my_mac, my_ip, my_mask);
    }
    NutIpRouteAdd(0, 0, inet_addr(MY_GATE), &devEth0);
    
    /*
     * Initialize the MP3 device.
     */
    VsPlayerInit();
    VsPlayerReset(0);
    VsBufferInit(mp3bufsiz);

    NutThreadCreate("serv", ServiceThread, 0, 512);

    eeprom_read_block(&rsidx, 512, 1);
    if(rsidx > sizeof(station) / sizeof(RADIOSTATION))
        rsidx = 0;

    /*
     * Now loop endless for connections.
     */
    wdt_reset();
    wdt_enable(7);

    for(;;) {
        u_long station_ip = 0;
        int rc;

        /*
         * Create a socket and set the socket options. Note,
         * that segment sizes above 536 may result in
         * fragmented packets. Remember, that Ethernut doesn't 
         * support TCP fragmentation.
         */
        sock = NutTcpCreateSocket();
        if(NutTcpSetSockOpt(sock, TCP_MAXSEG, &mss, sizeof(mss)))
            NutPrintString(0, "Sockopt MSS failed\r\n");
        if(NutTcpSetSockOpt(sock, SO_RCVTIMEO, &to, sizeof(to))) 
            NutPrintString(0, "Sockopt TO failed\r\n");
        if(NutTcpSetSockOpt(sock, SO_RCVBUF, &tcpbufsiz, sizeof(tcpbufsiz))) 
            NutPrintString(0, "Sockopt rxbuf failed\r\n");
        
        /*
         * Determine the server's IP address. Wait until
         * this is a vailid IP.
         */
        while(station_ip == 0) {
            if((station_ip = inet_addr(station[rsidx].rs_host)) != 0 && station_ip != -1)
                break;
            while(!reset_pending) {
                wdt_reset();
                NutSleep(500);
            }
        }

        /*
         * Now connect to the radio station.
         */
        wdt_disable();
        NutPrintFormat(0, "Connecting %s...", inet_ntoa(station_ip));
        if((rc = NutTcpConnect(sock, station_ip, station[rsidx].rs_port)) != 0) {
            NutPrintFormat(0, "failed with error %d\r\n", NutTcpError(sock));
            NutTcpCloseSocket(sock);
            NutSleep(2000);
            if(!reset_pending)
                continue;
        }
       	wdt_reset();
        wdt_enable(7);

        /*
         * Process header from server.
         */
        if(ProcessHeader(sock))
            continue;
        
        VsBufferReset();

        /*
         * This inner loop transfers MP3 data from the
         * network interface to the decoder.
         */
        connected = 1;
        while(connected) {
            dataptr = VsBufferRequest(&rbytes);
            while(rbytes) {
                wdt_reset();
                if((got = NutTcpReceive(sock, dataptr, rbytes)) <= 0) {
                    connected = 0;
                    break;
                }
                dataptr = VsBufferAcknowledge(got);
                rbytes -= got;

                NutThreadYield();
                if(reset_pending)
                    connected = 0;
                if(connected)
                    VsPlayerKick();
            }	 
            if(reset_pending)
                connected = 0;
            if(connected)
                VsPlayerKick();
            NutThreadYield();
        }
        NutTcpCloseSocket(sock);

        NutPrintString(0, "Reset\r\n");
        if(reset_pending) {
        	wdt_reset();
	        wdt_enable(7);
            for(;;);
        }
    }
}

/*@}*/
