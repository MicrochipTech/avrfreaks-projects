/***********************************************************************
Content: Test for Hitachi 44780 based 1 or 2 line Text LCD displays.
Last modified: 28.05.2003
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
***********************************************************************/

/***********************************************************************
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/

/***********************************************************************
This example:
In this example we have connected the LCD display to PORTB using PINS
0 to 5, and PINS 6 and 7 to two switches. The switch should be connected
from the PIN to GND. Important: Connect the LCD R/W to GND. We don't 
read from it, and saving us a PIN here :-)
The display in use here is an 24 chars * 2 lines.
***********************************************************************/


/***********************************************************************
Includes
***********************************************************************/
#include <io2313.h>
#include <macros.h>
#include "tlcd.h"


/***********************************************************************
Global vars
***********************************************************************/
unsigned char menu;
unsigned char menu_last;


/***********************************************************************
Main
***********************************************************************/
void main(void)
{
  tlcd_init();
  tlcd_cls();
  tlcd_goto(1,1);
  tlcd_write_string("Selected:");
  tlcd_goto(1,2);
  tlcd_write_string("AVR @ www.baso.no");

  menu = 49;
  menu_last = 0;
 
  while(1) 
  {
	// Check switch 1 and loop until depressed, increment of menu counter.
	if ((LCDPIN & SW1) == 0)
	{ 
      while ((LCDPIN & SW1) == 0);
	  if (menu < 57) menu++; else menu = 49;
	}
	// Check switch 2 and loop until depressed, decrement of menu counter.
	if ((LCDPIN & SW2) == 0)
	{ 
      while ((LCDPIN & SW2) == 0);
	  if (menu > 49) menu--; else menu = 57;
	}
	// If menu counter has changed, update LCD
	if (menu != menu_last)
	{
	  tlcd_goto(10,1);
      tlcd_write_byte(DATA,menu);
	  menu_last = menu;
	}
  }
}  



