/***********************************************************************
Content: Library for Hitachi 44780 based 1 or 2 line Text LCD displays.
Last modified: 28.05.2003
Copyrights: Free to use, free to change, free to delete :-)
Compiler: ImageCraft AVR
Written by: Knut Baardsen @ Baardsen Software, Norway
Updates: http://www.baso.no
***********************************************************************/

/***********************************************************************
This software is provided "as is"; Without warranties either express or
implied, including any warranty regarding merchantability, fitness for 
a particular purpose or noninfringement. 
In no event shall Baardsen Software or its suppliers be liable for any 
special,indirect,incidential or concequential damages resulting from 
the use or inability to use this software.
***********************************************************************/


/***********************************************************************
Includes
***********************************************************************/
#include <io2313.h>
#include "tlcd.h"


/***********************************************************************
Clears all text.
***********************************************************************/
void tlcd_cls()
{
  tlcd_write_byte(CTRL,0x01);
  tlcd_delay(50);
}


/***********************************************************************
Goto specified column and line. 1,1 is the upper left corner.
***********************************************************************/
void tlcd_goto(unsigned char column, unsigned char line)
{
  unsigned char addr;
  line--;
  column--;
  addr = (line * 64) + column;
  tlcd_write_byte(CTRL, addr | 0x80);
}


/***********************************************************************
Write strings to the display. Set position with tlcd_goto first.
Text will wrap if to long to show on one line.
***********************************************************************/
void tlcd_write_string(char *ptr)
{
  while (*ptr != 0x00) tlcd_write_byte(DATA,*ptr++);
}


/***********************************************************************
Write a control or data byte to the display. Control: 1=Ctrl, 0=Data
If data (control=0) set position with lcd_goto first.
Since the LCD is driven in 4-bit modus, we write the MSB nibble first
and the the LSB nibble.
***********************************************************************/
void tlcd_write_byte(unsigned char control, unsigned char byte)
{
  if ((byte & 0x80) == 0x80) LCDPORT |= DB7; else LCDPORT &= ~DB7;
  if ((byte & 0x40) == 0x40) LCDPORT |= DB6; else LCDPORT &= ~DB6;
  if ((byte & 0x20) == 0x20) LCDPORT |= DB5; else LCDPORT &= ~DB5;
  if ((byte & 0x10) == 0x10) LCDPORT |= DB4; else LCDPORT &= ~DB4;
  if (control == 1) LCDPORT |= RS;  else LCDPORT &= ~RS;
  LCDPORT |= ENABLE;
  LCDPORT &= ~ENABLE;
  if ((byte & 0x08) == 0x08) LCDPORT |= DB7; else LCDPORT &= ~DB7;	
  if ((byte & 0x04) == 0x04) LCDPORT |= DB6; else LCDPORT &= ~DB6;
  if ((byte & 0x02) == 0x02) LCDPORT |= DB5; else LCDPORT &= ~DB5;
  if ((byte & 0x01) == 0x01) LCDPORT |= DB4; else LCDPORT &= ~DB4;
  if (control == 1) LCDPORT |= RS; else LCDPORT &= ~RS;
  LCDPORT |= ENABLE;
  LCDPORT &= ~ENABLE;
  tlcd_delay(2);
}


/***********************************************************************
Makes a variable delay
Use the DELAY define to adjust for MCU clock. 
***********************************************************************/
void tlcd_delay(int loops)
{
  int i,j;
  for (i=0;i<loops;i++)
  {
    for (j=1; j<DELAY; j++);
    asm("WDR");
  }
}


/***********************************************************************
Set up selected port and initialize the LCD controller in 4-bit modus.  
***********************************************************************/
void tlcd_init(void)
{
LCDPORT = 0x00;
LCDDDR = 0b00111111;      
tlcd_delay(350);
LCDPORT = (DB6 + DB7); 
LCDPORT |= ENABLE;
LCDPORT &= ~ENABLE;
tlcd_delay(100);
LCDPORT |= ENABLE;
LCDPORT &= ~ENABLE;
tlcd_delay(100);
LCDPORT |= ENABLE;
LCDPORT &= ~ENABLE;
tlcd_delay(100);
LCDPORT = DB6;                 
LCDPORT |= ENABLE;
LCDPORT &= ~ENABLE;
tlcd_delay(100);
tlcd_write_byte(CTRL,0x28);
tlcd_write_byte(CTRL,0x0c);
tlcd_write_byte(CTRL,0x01);
tlcd_delay(100);
tlcd_write_byte(CTRL,0x06);
tlcd_delay(10);
}

