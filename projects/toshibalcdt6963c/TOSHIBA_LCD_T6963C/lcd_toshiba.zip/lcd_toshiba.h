#ifndef  __lcd_tashiba_included
#define __lcd_tashiba_included

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TOSHIBA T6963C 											    //
//	Base library											    //
//													    //
//	compile with GNU GCC-AVR									    //
//													    //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * Copyright (C) 2001 by Marc Wetzel. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by Marc R. Wetzel
 *    and his contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY MARC WETZEL AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL MARC WETZEL
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * 
 */

// we use ports...
#undef USE_DATABUS
//#define USE_DATABUS 1

// Frequency (used in Delay)

#define FREQUENZ    36864

// Misc. defines

#define BIT(a)          (1<<a)
#define SETBIT(a,b)     a|=(1<<b)
#define CLRBIT(a,b)     a&=~(1<<b)


// this defines describe your lcd's capabilities

#define BYTES_PER_LINE 20
#define TXT_LINE_COUNT 6
#define GFX_LINE_COUNT 48
#define TXT_START_ADRESS 0x000
#define GFX_START_ADRESS 0x100


// my preiffered mode, defined here

#define LMG_ORMODE   0x80

// if using databus, define your mapping here

#define LCD_ADR 0xC000
#define LCD_CMD  1
#define LCD_DATA 0

// if using ports, define your mapping here

#define CONTROL PORTC
#define DDR_CONTROL DDRC 
#define DATEN	PORTA
#define DDR_DATEN DDRA
#define PIN_DATEN PINA


// if using ports, define your controlport bit mapping here

#define CLR_WRITE(a) CLRBIT(a,3)
#define SET_WRITE(a) SETBIT(a,3)

#define CLR_READ(a)  CLRBIT(a,2)
#define SET_READ(a)  SETBIT(a,2)

#define CLR_CS(a)    CLRBIT(a,1)
#define SET_CS(a)    SETBIT(a,1)

#define SET_CONTROL(a) SETBIT(a,0)
#define SET_DATA(a)    CLRBIT(a,0)



#ifdef USE_DATABUS

///////////////////////////////////////////////////////////////////
// Disabled due to problems with databus ! 

void _write_control(u_char a);
void _write_data(u_char a);
u_char _read_control(void);
u_char _read_data(void);
// u_char *base = (u_char *)(LCD_ADR+LCD_DATA);

#else

void _write_control( u_char a);
void _write_data(u_char a);
u_char _read_control(void);

#endif


void TOSHIBA_status_check(void);
void TOSHIBA_status_check2 ( void );
void TOSHIBA_write_u_char(u_char code,u_char wert);
void TOSHIBA_write_word(u_char code,int wert);
void TOSHIBA_init (u_char txt_or_gfx);
void lcd_clrscr(void);
void lcd_gotoxy(u_char x,u_char y);
void lcd_printchar(u_char ch);
void lcd_printstring(u_char *str);
void lcd_printstringxy(u_char x,u_char y, u_char *str);

#endif
