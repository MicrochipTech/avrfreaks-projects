//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TOSHIBA T6963C 											    //
//	Base library											    //
//													    //
//	compile with GNU GCC-AVR									    //
//													    //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * Copyright (C) 2001 by Marc Wetzel. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by Marc R. Wetzel
 *    and his contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY MARC WETZEL AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL MARC WETZEL
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * 
 */


#include <io.h>
#include <sys/types.h>
#include "lcd_toshiba.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tool routines

void Delay(long hsec) {
  unsigned long d;
  for (d=(FREQUENZ/8)*hsec;d--;) ;
//		asm volatile("nop\n\t"::);
                          
}  

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// BASE FUNCTIONS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////




#ifdef USE_DATABUS
///////////////////////////////////////////////////////////////////
// Problems with databus, sometimes works, mostly not! 
void _write_control( u_char a) {
	volatile u_char *base = (u_char *)(LCD_ADR+LCD_CMD);
	
	*base = a;
}

void _write_data( u_char a) {
	volatile u_char *base = (u_char *)(LCD_ADR+LCD_DATA);
	
	*base = a;
	*base = a;
}

u_char _read_control(void) {
	volatile u_char *base = (u_char *)(LCD_ADR+LCD_CMD);
	
	u_char a;
	a = *base;
	a = *base;
	return 	(a);
}

u_char _read_data(void) {
volatile u_char *base = (u_char *)(LCD_ADR+LCD_DATA);
	u_char a;
	a = *base;
	a = *base;
	return 	(a);
}
///////////////////////////////////////////////////////////////////
#else

void _write_control( u_char a) {
   u_char status=0;

   SET_READ(status);        // simulating the databus protocol
   CLR_WRITE(status);
   SET_CONTROL(status);
   SET_CS(status);          //
   
   outp(status,CONTROL);   
   outp(a,DATEN);           // Daten schreiben

   CLR_CS(status);
   outp(status,CONTROL);   
   SET_WRITE(status);
   outp(status,CONTROL);   
   SET_CS(status);
   outp(status,CONTROL);
}

void _write_data( u_char a) {
   u_char status=0;

   SET_READ(status);        // bits in ruhezustand
   CLR_WRITE(status);
   SET_DATA(status);
   SET_CS(status);          //
   outp(status,CONTROL);

   outp(a,DATEN);

   CLR_CS(status);
   outp(status,CONTROL);   
   SET_WRITE(status);
   outp(status,CONTROL);   
   SET_CS(status);
   outp(status,CONTROL);
}

u_char _read_control(void) {
   u_char a,status=0;
   
   outp(0,DATEN);
   outp(0,DDR_DATEN);

   CLR_READ(status);        // bits in ruhezustand
   SET_WRITE(status);
   SET_CONTROL(status);
   SET_CS(status);          //
   outp(status,CONTROL);
   
   CLR_CS(status);
   outp(status,CONTROL);
   asm volatile("nop\n\t"::);
   asm volatile("nop\n\t"::);
   asm volatile("nop\n\t"::);
   a=inp(PIN_DATEN);               // Daten LESEN

   SET_READ(status);
   SET_CS(status);
   outp(status,CONTROL);

   outp(0xff,DDR_DATEN);
   
   return a;
}


#endif



void TOSHIBA_status_check(void) {
int i=0;
  while ((_read_control() & 0x03) != 0x03) {i++; if (i>1000) {break;}}
}

void TOSHIBA_status_check2 ( void ) {
int i=0;
  while ((_read_control() & 0x08) != 0x08) {i++; if (i>10) { break;}}
}

void TOSHIBA_write_char(u_char code,u_char wert) {
  TOSHIBA_status_check();
  _write_data(wert);
  TOSHIBA_status_check();
  _write_control(code);
}

void TOSHIBA_write_word(u_char code,int wert) {
  TOSHIBA_status_check();
  _write_data(wert&0x00ff);
  TOSHIBA_status_check();
  _write_data((wert&0xff00)>>8);
  TOSHIBA_status_check();
  _write_control(code);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LIBRARY FUNCTIONS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////


void TOSHIBA_init (u_char txt_or_gfx) {    
 // u_int i;
/*
 * Disable external Data/Adress Bus 
 * if we are using the port mapping
 */
 
#ifndef USE_DATABUS 
  outp(0, MCUCR);
  
  // Set DATEN port to output
  outp(0,DATEN);
  outp(0xff,DDR_DATEN);
  //outp(0x0,DDR_CONTROL); always output
#endif


  Delay(30);
  TOSHIBA_write_word(0x42,GFX_START_ADRESS);  // GFX Homeadress
  Delay(30);
  TOSHIBA_write_word(0x43,BYTES_PER_LINE);    // 16/20 bytes per line in gfx mode
  Delay(30);
  TOSHIBA_write_word(0x40,TXT_START_ADRESS);  // Text Homeadress
  Delay(30);
  TOSHIBA_write_word(0x41,BYTES_PER_LINE);    // Text bytecount per line
  Delay(30);
  _write_control(txt_or_gfx);                 // OR mode
  Delay(30);
  _write_control(0xA7);
  Delay(30);
  TOSHIBA_write_word(0x21,0);
  Delay(30);
  TOSHIBA_write_word(0x22,0);
  Delay(30);
  _write_control(0x9e - 2);
  Delay(30);

  lcd_clrscr();

}

void lcd_clrscr(void)
{
  u_int i;
  		
  TOSHIBA_write_word(0x24,0);                 // gotoxy 0/0
  Delay(30);
  for (i=0;i<60*128;i++)
    TOSHIBA_write_char(0xc0,0);
  TOSHIBA_write_word(0x24,0);
}

void lcd_gotoxy(u_char x,u_char y)
{
  TOSHIBA_write_word(0x24,y*BYTES_PER_LINE+x);                 
}

void lcd_printchar(u_char ch) {
  TOSHIBA_write_char(0xc0,ch-0x20);	// fonttable has offset: -0x20
}

void lcd_printstring(u_char *str)
{
  while(*str)
    lcd_printchar(*str++);
}

void lcd_printstringxy(u_char x,u_char y, u_char *str)
{
  lcd_gotoxy(x,y);
  lcd_printstring(str);		
}	


