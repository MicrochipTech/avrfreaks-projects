SEOS (Simple Embedded Operating System)
Version 1.0.0

For more information go to:
http://www.dftpd.com/embedded.php
