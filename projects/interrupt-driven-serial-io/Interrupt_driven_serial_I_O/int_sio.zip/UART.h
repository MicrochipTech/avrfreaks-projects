int UART_putchar(char c);
int UART_getchar(void);

void UART_first_init(void);
