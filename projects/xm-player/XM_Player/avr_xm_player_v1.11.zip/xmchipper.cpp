/*
  xmchipper - XM file converter for AVR XM Player
  Copyright (c) 2002-2003 by Douglas Lundholm

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <memory.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <time.h>

//xm properties
#define MAX_CHANNELS	32
#define MAX_ROWS		256
#define MAX_INSTRUMENTS	64
#define MAX_SAMPLES		16

//compact xm properties
#define CHIP_CHANNELS	4
#define CHIP_MAX_INSTRUMENTS	16
#define CHIP_MAX_NOTE	107

#define XM_KEY_OFF		97
#define CHIP_KEY_OFF	109
#define NOTE_NONE		0xFF

//match xmplayer.asm
#define PACKBIT_HASBITS			7
#define PACKBIT_NOTE_FOLLOWS	0
#define PACKBIT_INST_FOLLOWS	1
#define PACKBIT_FX_FOLLOWS		2
#define PACKBIT_VOL_FOLLOWS		3
#define SFLAG_LOOP_ON	5


typedef unsigned char byte;
typedef signed char sbyte;

struct rowch
{
	byte	note;
	byte	instrument;
	byte	volcol;
	byte	fx_type;
	byte	fx_data;
};
struct fullrow
{
	rowch	ch[MAX_CHANNELS];
};
struct pattern
{
	int		header_len;
	byte	packtype;
	int		num_rows;
	int		data_size;
	fullrow	*row;	//[MAX_ROWS];
};
struct sample
{
	int		length;
	int		loop_start;
	int		loop_length;
	byte	volume;
	byte	finetune;
	byte	type;
	byte	panning;
	sbyte	relnote;
	byte	reserved;
	char	name[22+1];
	byte	*realdata;
};
struct instr
{
	int		size;
	char	name[22+1];
	byte	type;
	int		samples_in_instr;
	int		sample_hdr_size;
	byte	sample_num_note[96];
	byte	envpt_vol[48];
	byte	envpt_pan[48];
	byte	num_volpts;
	byte	num_panpts;
	byte	vol_sustpt;
	byte	vol_loop_startpt;
	byte	vol_loop_endpt;
	byte	pan_sustpt;
	byte	pan_loop_startpt;
	byte	pan_loop_endpt;
	byte	vol_type;
	byte	pan_type;
	byte	vib_type;
	byte	vib_sweep;
	byte	vib_depth;
	byte	vib_rate;
	int		vol_fadeout;
	byte	reserved[2];
	sample	smp[MAX_SAMPLES];
};
struct module
{
	char	id_text[17+1];
	char	modname[20+1];
	byte	id;
	char	tracker[20+1];
	int		tracker_ver;
	int		header_size;
	int		song_length;
	int		loop_restart;
	int		num_channels;
	int		num_patterns;
	int		num_instruments;
	int		freqtable_flag;
	int		start_speed;
	int		start_bpm;
	byte	patternTable[256];
	pattern pat[256];
	instr	ins[MAX_INSTRUMENTS];
	//
	bool	writeChannel[MAX_CHANNELS];
};

bool ReadModule		(module *xm, fstream *file);
bool WriteChipHeader(module *xm, fstream *file);
bool WriteChipData	(module *xm, fstream *file);
bool WriteByteBlock (byte *block, int len, fstream *file);

void main(int argc, char *argv[])
{
	printf("xmchipper v0.54\nCopyright (c) 2002-2003 by Douglas Lundholm\n");

	//help
	if ( argc <= 1)
	{
		printf("Usage: xmchipper file.xm\n");
		return;
	}

	//get file paths
	char filePath[512], outHeader[512], outData[512];
	sprintf(filePath, argv[1]);
	sprintf(outHeader, "%s.header.inc", argv[1]);
	sprintf(outData, "%s.data.inc", argv[1]);

	//read module
	printf("Loading module %s ...\n", filePath);
	module *xm = (module*)calloc(sizeof(module),1); //new module;
//	memset(xm, 0, sizeof(module));
	fstream file;

	file.open(filePath, ios::in | ios::nocreate | ios::binary);
	if (file.fail())
	{
		printf("ERROR: Couldn't open file %s\n", filePath);
		return;
	}
	if (!ReadModule(xm, &file))
	{
		printf("ERROR: ReadModule failed\n");
		return;
	}
	file.close();
	
	//ask which channels to write
	if (xm->num_channels <= CHIP_CHANNELS)
	{
		xm->writeChannel[0] = xm->writeChannel[1] = xm->writeChannel[2] = xm->writeChannel[3] = true;
	}
	else
	{
		printf("Too many channels in module. Only %d can be included.\n", CHIP_CHANNELS);
		int used = 0;
		for (int c = 0; c < xm->num_channels; c++)
		{
			printf("Use channel #%d (y/n)? ", c);
			if (getch() == 'y')
			{
				printf("y\n");
				xm->writeChannel[c] = true;
				used++;
				if (used == CHIP_CHANNELS)
					break;
			}
			else
				printf("n\n");
		}
	}

	//generate include files
	printf("Chipping module...\n");
	file.open(outHeader, ios::out);
	if (file.fail())
	{
		printf("ERROR: Couldn't open file %s\n", outHeader);
		return;
	}
	if (!WriteChipHeader(xm, &file))
		return;
	file.close();
	printf("Wrote %s\n", outHeader);
	file.open(outData, ios::out);
	if (file.fail())
	{
		printf("ERROR: Couldn't open file %s\n", outData);
		return;
	}
	if (!WriteChipData(xm, &file))
		return;
	file.close();
	printf("Wrote %s\n", outData);

	//unload dynamic data
	int i,j;
	for (i = 0; i < xm->num_patterns; i++)
//		delete [] xm->pat[i].row;
		free(xm->pat[i].row);
	for (i = 0; i < xm->num_instruments; i++)
	{
		for (j = 0; j < xm->ins[i].samples_in_instr; j++)
		{
			if (xm->ins[i].smp[j].realdata == NULL)
				continue;
//			delete [] xm->ins[i].smp[j].reldata;
			free(xm->ins[i].smp[j].realdata);
		}
	}
	free(xm);
//	delete xm;
}

bool ReadModule(module *xm, fstream *file)
{
	int i, j, k;

	//module
	file->read(xm->id_text, 17);
	file->read(xm->modname, 20);
	printf("Module name: %s\n", xm->modname);
	file->read((char*)&xm->id, 1);
	file->read(xm->tracker, 20);
	file->read((char*)&xm->tracker_ver, 2);
	file->read((char*)&xm->header_size, 4);
	file->read((char*)&xm->song_length, 2);
	file->read((char*)&xm->loop_restart, 2);
	file->read((char*)&xm->num_channels, 2);
	file->read((char*)&xm->num_patterns, 2);
	file->read((char*)&xm->num_instruments, 2);
	file->read((char*)&xm->freqtable_flag, 2);
	file->read((char*)&xm->start_speed, 2);
	file->read((char*)&xm->start_bpm, 2);
	file->read((char*)xm->patternTable, 256);

	//patterns
	for (i = 0; i < xm->num_patterns; i++)
	{
		pattern *pat = &xm->pat[i];
		file->read((char*)&pat->header_len, 4);
		file->read((char*)&pat->packtype, 1);
		file->read((char*)&pat->num_rows, 2);
		file->read((char*)&pat->data_size, 2);

		pat->row = (fullrow*)calloc(pat->num_rows*sizeof(fullrow), 1); //new fullrow[pat->num_rows];
//		memset(pat->row, 0, pat->num_rows * sizeof(fullrow));

		for (j = 0; j < pat->num_rows; j++)
		{
			fullrow *row = &pat->row[j];
			for (k = 0; k < xm->num_channels; k++)
			{
				row->ch[k].note = NOTE_NONE;	//so we see when no note was given (note can be 0)
				byte packbits = file->get();
				if (packbits & 0x80)
				{
					if (packbits & (1<<0))
						row->ch[k].note = file->get();
					if (packbits & (1<<1))
						row->ch[k].instrument = file->get();
					if (packbits & (1<<2))
						row->ch[k].volcol = file->get();
					if (packbits & (1<<3))
						row->ch[k].fx_type = file->get();
					if (packbits & (1<<4))
						row->ch[k].fx_data = file->get();
				}
				else
				{
					row->ch[k].note = packbits;
					row->ch[k].instrument = file->get();
					row->ch[k].volcol = file->get();
					row->ch[k].fx_type = file->get();
					row->ch[k].fx_data = file->get();
				}
			}
		}
	}

	//instruments
	for (i = 0; i < xm->num_instruments; i++)
	{
		instr *ins = &xm->ins[i];
		int dummy = file->tellg();
		file->read((char*)&ins->size, 4);
		file->read(ins->name, 22);
		printf("Instr #%d name: %s\n", i, ins->name);
		file->read((char*)&ins->type, 1);
		file->read((char*)&ins->samples_in_instr, 2);
		if (ins->samples_in_instr <= 0)
			continue;
		file->read((char*)&ins->sample_hdr_size, 4);
		file->read((char*)ins->sample_num_note, 96);
		file->read((char*)ins->envpt_vol, 48);
		file->read((char*)ins->envpt_pan, 48);
		file->read((char*)&ins->num_volpts, 1);
		file->read((char*)&ins->num_panpts, 1);
		file->read((char*)&ins->vol_sustpt, 1);
		file->read((char*)&ins->vol_loop_startpt, 1);
		file->read((char*)&ins->vol_loop_endpt, 1);
		file->read((char*)&ins->pan_sustpt, 1);
		file->read((char*)&ins->pan_loop_startpt, 1);
		file->read((char*)&ins->pan_loop_endpt, 1);
		file->read((char*)&ins->vol_type, 1);
		file->read((char*)&ins->pan_type, 1);
		file->read((char*)&ins->vib_type, 1);
		file->read((char*)&ins->vib_sweep, 1);
		file->read((char*)&ins->vib_depth, 1);
		file->read((char*)&ins->vib_rate, 1);
		file->read((char*)&ins->vol_fadeout, 2);
		file->read((char*)ins->reserved, 2);

		file->seekg(dummy + ins->size);

		//samples
		for (j = 0; j < ins->samples_in_instr; j++)
		{
			sample *smp = &ins->smp[j];
			file->read((char*)&smp->length, 4);
			file->read((char*)&smp->loop_start, 4);
			file->read((char*)&smp->loop_length, 4);
			file->read((char*)&smp->volume, 1);
			file->read((char*)&smp->finetune, 1);
			file->read((char*)&smp->type, 1);
			if (smp->type & 16)
			{
				printf("16 bit samples not supported!");
				return false;
			}
			file->read((char*)&smp->panning, 1);
			file->read((char*)&smp->relnote, 1);
			file->read((char*)&smp->reserved, 1);
			file->read(smp->name, 22);
		}
		for (j = 0; j < ins->samples_in_instr; j++)
		{
			sample *smp = &ins->smp[j];
			if (!smp->length)
				continue;
//			smp->reldata = (sbyte*)calloc(smp->length*sizeof(sbyte), 1); //new sbyte[smp->length];
//			file->read((char*)smp->reldata, smp->length);
			smp->realdata = (byte*)calloc(smp->length*sizeof(byte), 1);
			int lastval = 0, newval;
			for (k = 0; k < smp->length; k++)
			{
				newval = lastval + file->get();
//				if (newval < -128 || newval > 127)
//					printf("ERROR: sample value out of range\n");
				smp->realdata[k] = (byte)newval;
				lastval = newval;//smp->realdata[k];
			}
		}
	}

	return true;
}

bool WriteChipHeader(module *xm, fstream *file)
{
	//check module compatibility
/*?	if (xm->num_instruments > CHIP_MAX_INSTRUMENTS)
	{
		printf("ERROR: Only up to 16 instruments are supported\n");
		return false;
	}
*/
	//write header
	char datebuf[128], timebuf[128];
	*file << "; AVR XM Player Contracted eXtended Module [Header]\n";
	*file << "; " << xm->modname << "\n";
	*file << "; Generated: " << _strdate(datebuf) << " " << _strtime(timebuf) << "\n";
	*file << "\n";
	*file << ".equ NUM_PATTERNS = "			<< xm->num_patterns << "\n";
	*file << ".equ PATTERNTABLE_LENGTH = "	<< xm->song_length << "\n";
	*file << ".equ NUM_INSTRUMENTS = "		<< xm->num_instruments << "\n";
	*file << "\n";
	*file << ".equ START_BPM = "			<< xm->start_bpm << "\n";
	*file << ".equ START_SPEED = "			<< xm->start_speed << "\n";
	*file << "\n";
	*file << ".equ START_PATTERN = "		<< int(xm->patternTable[0]) << "\n";
	*file << ".equ REPEAT_PATTERN = "		<< int(xm->loop_restart) << "\n";

	return true;
}

bool WriteChipData	(module *xm, fstream *file)
{
	bool warnedVolCol = false, warnedFx = false;

	int i, j, k;
	char numConv[32];

	char datebuf[128], timebuf[128];
	*file << "; AVR XM Player Contracted eXtended Module [Data]\n";
	*file << "; " << xm->modname << "\n";
	*file << "; Generated: " << _strdate(datebuf) << " " << _strtime(timebuf) << "\n";
	*file << "\n";

	//pattern table
	*file << "PatternTable:\n";
	WriteByteBlock(xm->patternTable, xm->song_length, file);
	*file << "\n";

	//pattern addresses
	*file << "PatternData:\n";
	for (i = 0; i < xm->num_patterns; i++)
	{
		sprintf(numConv, "%.2x", i);
		*file << "\t.dw\t\tPattern" << numConv << "<<1\n";
	}
	//patterns
	for (i = 0; i < xm->num_patterns; i++)
	{
		//address
		if(i == int(xm->patternTable[0]))
			*file << "StartPattern:\n";
		sprintf(numConv, "%.2x", i);
		*file << "Pattern" << numConv << ":\n";
		
		//generate byte block
		pattern *pat = &xm->pat[i];
		byte *block = (byte*)calloc(1+pat->num_rows*CHIP_CHANNELS*5, sizeof(byte)); //new byte[1 + pat->num_rows*CHIP_CHANNELS*5];
		int bpos = 0;
		block[bpos++] = pat->num_rows;

		byte lastInstr[MAX_CHANNELS];
		for (j = 0; j < MAX_CHANNELS; j++)
			lastInstr[j] = 0xFF;	//force instrument change
		
		for (j = 0; j < pat->num_rows; j++)
		{
			for (k = 0; k < xm->num_channels; k++)
			{
				if (!xm->writeChannel[k])
					continue;
				rowch *r = &pat->row[j].ch[k];
				//check compatibility
				if (r->volcol && (r->volcol < 0x10 || r->volcol > 0x50) && !warnedVolCol)
				{
					printf("WARNING: Only set volume effect in volume column currently supported\n");
					warnedVolCol = true;
				}
				if (r->fx_type && !warnedFx)
				{
					printf("WARNING: Only arpeggio effect currently supported\n");
					warnedFx = true;
				}
				//what to write?
				byte packbits = 1<<PACKBIT_HASBITS;
				if (r->note != NOTE_NONE)
					packbits |= 1<<PACKBIT_NOTE_FOLLOWS;
				if (r->instrument != 0 && r->instrument != lastInstr[k])	//skips inserting instrument if same
				{
					packbits |= 1<<PACKBIT_INST_FOLLOWS;
					lastInstr[k] = r->instrument;
				}
				if (r->volcol != 0)
					packbits |= 1<<PACKBIT_VOL_FOLLOWS;
				else if (r->fx_type == 0x0c)	//insert vol effect as VolCol
				{
					packbits |= 1<<PACKBIT_VOL_FOLLOWS;
					r->volcol = r->fx_data + 0x10;	//make compatible
				}
				if (r->fx_data != 0 && r->fx_type == 0)	//insert arpeggio effect
					packbits |= 1<<PACKBIT_FX_FOLLOWS;
				//get realnote
				int realnote = CHIP_KEY_OFF;
				if (r->note != NOTE_NONE)
				{
					int relnote = 0;
					if (lastInstr[k] != 0xFF)
						relnote = xm->ins[lastInstr[k]-1].smp[0].relnote;
					realnote = int(r->note) + relnote;
					if		(r->note == XM_KEY_OFF)
						realnote = CHIP_KEY_OFF;
					else if (realnote > CHIP_MAX_NOTE)
					{
						printf("WARNING: note value exceeds %d\n", CHIP_MAX_NOTE);
						realnote = CHIP_MAX_NOTE;
					}
					else if (realnote < 0)
					{
						printf("WARNING: negative note value\n");
						realnote = 0;
					}
				}
				//write it
				if (packbits == ((1<<PACKBIT_HASBITS) | (1<<PACKBIT_NOTE_FOLLOWS) | (1<<PACKBIT_INST_FOLLOWS) | (1<<PACKBIT_VOL_FOLLOWS) | (1<<PACKBIT_FX_FOLLOWS)))
				{	//write all
					block[bpos++] = (byte)realnote;
					block[bpos++] = r->instrument-1;
					block[bpos++] = r->volcol;
					block[bpos++] = r->fx_data;
				}
				else
				{	//write specific
					block[bpos++] = packbits;
					if (packbits & (1<<PACKBIT_NOTE_FOLLOWS))
						block[bpos++] = (byte)realnote;
					if (packbits & (1<<PACKBIT_INST_FOLLOWS))
						block[bpos++] = r->instrument-1;
					if (packbits & (1<<PACKBIT_VOL_FOLLOWS))
						block[bpos++] = r->volcol;
					if (packbits & (1<<PACKBIT_FX_FOLLOWS))
						block[bpos++] = r->fx_data;
				}
			}
		}

		//write block
		WriteByteBlock(block, bpos, file);
//		file->flush();
		free(block);//delete [] block;
	}
	*file << "\n";

	//sample addresses
	*file << "SampleData:\n";
	for (i = 0; i < xm->num_instruments; i++)
	{
		sprintf(numConv, "%.2x", i);
		*file << "\t.dw\t\tSample" << numConv << "<<1\n";
	}
	//samples
	for (i = 0; i < xm->num_instruments; i++)
	{
		//address
		sprintf(numConv, "%.2x", i);
		*file << "Sample" << numConv << ":\n";
		
		//check compatibility
		instr *ins = &xm->ins[i];
		if (!ins->samples_in_instr)
			continue;	//empty instrument
		if (ins->samples_in_instr > 1)
			printf("WARNING: Only one sample per instrument supported\n");
		if (ins->vol_fadeout)
			printf("WARNING: Instrument fadeout currently not supported\n");
		if (ins->smp[0].finetune)
			printf("WARNING: Instrument finetune not supported\n");

		//loop?
		sample *smp = &ins->smp[0];
		int startpos = 0, endpos = smp->length;
		bool loop = false;
		bool pingpong = false;
		if		((ins->smp[0].type & 3) == 1)
		{	//straight loop
			startpos = smp->loop_start;
			endpos = startpos + smp->loop_length;
			loop = true;
		}
		else if	((ins->smp[0].type & 3) == 2)
		{	//pingpong loop
			startpos = smp->loop_start;
			endpos = startpos + smp->loop_length;
			loop = true; pingpong = true;
		}
		int length = endpos-startpos;

		//generate byte block
		byte *block = (byte*)calloc(length*2, sizeof(byte));
		int bpos = 0;
		block[bpos++] = loop ? 1<<SFLAG_LOOP_ON : 0;	//add sample flag
		for (j = startpos; j < endpos; j++)
			block[bpos++] = smp->realdata[j];
		if (pingpong)
		{	//write a flipped copy of the sample
			for (j = endpos-2; j > 0; j--)
				block[bpos++] = smp->realdata[j];
		}

		//write length
		*file << "\t.dw\t\t" << bpos-1 << "\n";

		//write block
		WriteByteBlock(block, bpos, file);
		free(block);
	}

	return true;
}

#define BYTES_PER_ROW 8
bool WriteByteBlock (byte *block, int len, fstream *file)
{
	char numConv[16];
	int b = 0;
	for (int i = 0; i < len; i++)
	{
		if (b == 0)
			*file << "\t.db\t\t";
		sprintf(numConv, "0x%.2x", int(block[i]));
		*file << numConv;
		b++;
		if (i+1 == len)
		{
			if (len & 1)
				*file << ",0\n";
			else
				*file << "\n";
		}
		else if (b == BYTES_PER_ROW)
		{
			*file << "\n";
			b = 0;
		}
		else
			*file << ",";
	}
	return true;
}
