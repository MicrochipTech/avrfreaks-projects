                       AVR XM Player v1.11
           Copyright (c) 2002-2003 by Douglas Lundholm


This package contains source code and conversion tools for playing
XM (eXtended Module) music using an Atmel AVR 8-bit microcontroller.
This was originally created as part of an aternative platform (or
"oldskool") demo called Cellulose that was released at Dreamhack
Winter 2002.

This source code is released in the hope that it will be a useful base
for more fully featured XM players and other AVR-based music projects.
I especially hope to see someone make a small portable XM player that
fetches tunes from compact flash. Just think of the amount of music it
could contain!

The player is loaded into the microcontroller flash memory together
with the music data in a more compact XM format. The conversion of XM
files to compact assembler include files is done using xmchipper.exe.
The player is originally set up for an 8 MHz oscillator and playback
at 22050 samples/second, but can easily be adjusted in the code.

For XM playing & editing I recommend e.g. Skale Tracker: www.skale.org

Note that this is my first big assembler project, so everything is
heavily commented. Because of some weird behaviour in AVR Studio 3.53
concerning the order of equates, it might not assemble that good in
other versions of AVR Studio. Please notify me if you find that that
is the case.

Hardware requirements
���������������������
- ATmega163 or compatible containing:
  - 16-bit timer with output compare
  - 512 bytes RAM or more
  - 16 kB flash or more recommended (the player takes 1 kB, the rest is
    for XM data)
- 3.69 MHz or faster oscillator for 11 kHz or higher sample rate
  (8 MHz is good for 22 kHz sample rate, and so on)
- Sound conversion and output, such as:
  - 8-bit parallel Digital-to-Analog Converter
  - Preferably an amplifier
  - Speaker (for example an old PC speaker)

An example hardware implementation which uses a speaker for output (the
Cellulose project) can be found here:
http://www.tapir.nu/files/cellulose_platform.pdf

Another example which outputs to a TV via SCART (also for a demo,
called Quantum Chromodynamics) can be found here:
http://www.tapir.nu/files/TV_console.pdf

Featured:
���������
- Playback of raw sound samples at 108 different speeds corresponding
  to XM notes
- Four channels
- Sample looping
- Sample ping-pong looping (not tested)
- Key-off note (stops playing on channel)
- Relative note support in instrument
- Arpeggio effect (#0)
- Volume adjustment using volume column or volume effect (#C)
- Looping of playback to Repeat Pattern (turn on/off in code)
- Buffer for 256 output samples
- Start signal sensing (turn on/off in code)

Not featured: (some things are easily added, others are not)
�������������
- Instrument volume setting, fadeout
- Envelopes
- Any effects (including volume column effects) other than Arpeggio
  and Set Volume
- Adjusting of BPM and Speed during playback
- 16-bit samples
- Instrument finetuning
- Panning (output is monophonic)

License
�������
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License. See license.txt.

About
�����
Programming and design by Douglas Lundholm, douglas@tapir.nu
For updates etc. visit www.tapir.nu
Thanks to Flare for releasing source code to their Flare XM Player (it
helped me understand how XMs are to be played).
