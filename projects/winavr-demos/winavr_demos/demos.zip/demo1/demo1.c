/*
  Title:          example file for winavr
  Author:         G. de Jonge
  e-mail:         gdjonge@inn.nl
  date:           06-MAR-2003
  Software:       WinAVR
  Hardware:       STK500
  Target:         AT89S2313
  License:        GPL ( see README file )
  Notes:
*/

/*
   This example flashes the leds on port B
*/

/* the general include files */
#include <avr/io.h>
#include <inttypes.h>   /* We use the standard defined types,        */
                        /* so we don't need to define them ourselves */


/* extra definitions */
#define VERSION 0.1    /* This one is not neccessary but easy for   */
                       /* maintenance */


/* function prototypes */
int main(void);
void delay(uint16_t);
void longdelay(uint16_t);



/* The main application */
int main()
{
/* initialise the components we want to use */
  DDRB = 0xFF;    /* We put port B pins in output mode */
  PORTB = 0xFF;   /* put all leds in off state */

/* The main loop */
  while (1)
  {
    PORTB = 0x00;    /* set all leds to on  */
    longdelay(400);  /* wait some time      */
    PORTB = 0xFF;    /* set all leds to off */
    longdelay(400);  /* wait some time      */
  }
  return(0);
}


void delay(uint16_t us)
/*
  This delay loop takes about 1.35 usec for each loop
  with a 3.69 MHz clock
*/
{
  while (us--);
}

void longdelay(uint16_t ms)
{
  while (ms--) delay(800);
}

