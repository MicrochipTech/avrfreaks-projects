/*
  Title:          example file for winavr
  Author:         G. de Jonge
  e-mail:         gdjonge@inn.nl
  date:           12-MAR-2003
  Software:       WinAVR
  Hardware:       STK500
  Target:         AT89S2313
  Notes:
*/

/*
  Some theory:
  Normally clock signals have about the same time period for high as for low
      |----|    |----|    |----|    |----|
  ----|    |----|    |----|    |----|    |----
  This is also called a duty cycle of 50%

  PWM (pulse wide modulation) means that we can controle the duty cycle.
  So we could generate a signal with a duty cycle of 25%
      |--|      |--|      |--|      |--|
  ----|  |------|  |------|  |------|  |------
  or 75%
      |------|  |------|  |------|  |------|
  ----|      |--|      |--|      |--|      |--

  There are several applications for use of a PWM, but a very simply one
  is controlling the brightness of a led.

How is this all implemented in the AVR.

this is implemented through timer 1 with help of the PWM11 and PWM10 bits and
the COM1A1 and COM1A0 bits in TCCR1A and the OCR1

in PWM mode timer/counter 1 will count up to a maximum value and when it reaches
it will start counting down to zero.
every time the counter value reaches the value that is written in OCR1 it will
toggle the OC1 pin (PB3). By changing the value in OCR1 one can change
the duty cycle

Check the PDF's for more information

This program is tested on an STK500 with an 9.216 MHz external clock
so if the the led seems to blink use an other prescaler (lower)

*/


/* the general include files */
#include <avr/io.h>
#include <inttypes.h>

/* the application specific include files */


/* extra definitions */
#define VERSION 1.0
#define FCPU 9216000 /* 9.216 MHz clock */


/* function prototypes */
int main(void);
void wait10ms(void);
void wait500ms(void);



/* The main application */
int main()
{
  uint16_t ocrval = 0x00FE;

  DDRD = 0x00;       /* Set port D as input               */
  PORTD = 0xFF;      /* with the pull-up resistors active */

  DDRB = 0xFF;       /* Set port B as output              */
  PORTB = 0xFF;      /* set the leds off                  */

  /*  We set the PWM to maximum duty cycle                */
  OCR1 = ocrval;
  /* We tell that we want use PWM for timer 1             */
  /* with a 8 bit resolution                              */
  TCCR1A = _BV(COM1A1) | _BV(COM1A0) | _BV(PWM10);
  /* We use a prescaler of CK256                          */
  /* use a prescaler of CK64 if the led starts to blink   */
  TCCR1B = _BV(CS12);

  while (1)
  {
    wait500ms();                              /* we wait about 1/2 sec          */
    if (~PIND & (1 << PD0))                   /* first we check switch 0        */
    {                                         /* if it's one we                 */
      wait10ms();                             /* wait about 10 mS to debounce   */
      if (~PIND & (1 << PD0))                 /* if it's still active           */
      {
        if ( (--ocrval)== 0) ocrval++;        /* we decrease the duty cycle     */
                                              /* we make sure it stays above 0% */
        OCR1 = ocrval;                        /* and write a new duty cycle to  */
      }                                       /* timer 1                        */
    } else if (~PIND & (1 << PD1))            /* if switch 0 wasn't active  we  */
    {                                         /* check switch 1                 */
      wait10ms();                             /* debounce the switch            */
      if (~PIND & (1 << PD1))                 /* and check again                */
      {
        if ( (++ocrval) == 0x00FF) ocrval--;  /* increase the duty cycle and    */
                                              /* and make sure it stays below   */
                                              /* maximum                        */
        OCR1 = ocrval;                        /* and write the new value        */
      }
    }
  }
  return(0);
}


/* extra functions */

void wait10ms()
{
  uint8_t i, j;
  for (i = 0; i < 150; i++)
    for (j = 0; j < 200; j++) ;
}


void wait500ms()
{
  uint8_t i;
  for (i = 0; i < 50; i++) wait10ms();
}


/* ---- end of file ---- */

