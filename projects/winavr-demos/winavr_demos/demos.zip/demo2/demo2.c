/*
  Title:          example file for winavr
  Author:         G. de Jonge
  e-mail:         gdjonge@inn.nl
  date:           06-MAR-2003
  Software:       WinAVR
  Hardware:       STK500
  Target:         AT89S2313
  License:        GPL ( see README file )
  Notes:
*/



/*
  This program toggles the leds on port B when the key on port D pin 0
  is pressed.
*/


/* the general include files */
#include <avr/io.h>
#include <inttypes.h>

/* extra definitions */
#define VERSION 0.1

/* function prototypes */
int main(void);



/* The main application */
int main()
{
/*local variables */
  uint8_t i, j;

/* initialise the components we want to use */
  DDRB = 0xFF;    /* We put port B pins in output mode */
  PORTB = 0xFF;   /* put all leds in off state */

  DDRD = 0x00;    /* We put port D pins in input mode */
  PORTD = 0xFF;   /* we activate the internal pull-up resistors */

/* The main loop */
  while (1)
  {
  /* wait until the key is pressed */
  while (PIND & 0x01) ;
  /* Now we wait about 15 ms to debounce the key
     Note that this type of delay depend heavily on the processor
     clock. If you change the processor clock you also have to recalculate
     the values of i and j.
  */
  for (i = 0; i < 70; i++)
    /* 1 loop takes about 0.2 mSec */
    for (j = 0; j < 255; j++) ;
  /* If the key still is pressed */
  if ( !( PIND & 0x01) )
  {
    PORTB = ~PORTB;
  }
  /* Now we wait until the key is released */
  while ( !(PIND & 0x01) );
  }
  return(0);
}

/* ---- end of file ---- */

