/*
  Title:          example file for winavr
  Author:         G. de Jonge
  e-mail:         gdjonge@inn.nl
  date:           06-MAR-2003
  Software:       WinAVR
  Hardware:       STK500
  Target:         AT89S2313
  License:        GPL ( see README file )
  Notes:
*/



/*

*/

/* the general include files */
#include <avr/io.h>
#include <inttypes.h>

/* extra definitions */
#define VERSION 0.1
#define FCPU    9216000L
#define BAUD    9600L


/* function prototypes */
int main(void);



/* The main application */
int main()
{
  /*local variables */
  uint8_t temp;

/* initialise the components we want to use */
  DDRB = 0xFF;    /* We put port B pins in output mode */
  PORTB = 0xFF;   /* put all leds in off state */

  DDRD = 0xFE;    /* */
  PORTD = 0xFF;   /* */
  UCR = (1 << TXEN) | (1 << RXEN);
  UBRR = (FCPU / (BAUD * 16L)) - 1;
  USR = 0x00;

/* The main loop */
  while (1)
  {
    /* wait until a character is received */
    while ( !(USR & (1 << RXC))) ;

    temp = UDR;        /* read the character */
    PORTB = ~temp;      /* and write it to the leds */

    /* Now we wait until the transmit buffer is empty */
    while ( !(USR & (1 << UDRE))) ;

    UDR = temp;  /* and send the character back */
  }
  return(0);
}

