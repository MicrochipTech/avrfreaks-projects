/*** Magnetic Card Reader Controller ******************************************
 *	
 *	File Name	: mcrc.c
 *			  
 *	Description	: Converts the clock & data output from a magnetic card
 *				  reader (in this case the MR5) into keypresses, which
 *				  are sent to the PC via the parallel port. An application
 *				  on the PC receives the data and types it (by emulating the
 *				  keyboard)
 *			  
 *	Author		: Muhammad J. A. Galadima (mjag17@yahoo.com)
 *			  
 *	Created		: 2004 / 08 / 14
 *			  
 *	Revised		: 2004 / 08 / 31
 *			  
 *	Version		: 2.0
 *			  
 *	Target MCU	: AT90S8515
 *	
 *	
 *	
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version 2
 *	of the License, or (at your option) any later version.
 *	
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *	
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software Foundation, 
 *	Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *	
 *****************************************************************************/


#include <inttypes.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>

#define beep(c) ({beep_cnt = c; PORTD &= ~_BV(0);})

#define PC_DATA_I	4
#define PC_DATA_O	5
#define pcclr(x)	(PORTD &= ~_BV(x))
#define pcset(x)	(PORTD |= _BV(x))
#define pcget(x)	(PIND & _BV(x))				// returns current DEVICE SET value of pin

#define LED_OFF		(PORTC |= (_BV(0)|_BV(1)))
#define LED_ON		(PORTC &= ~(_BV(0)|_BV(1)))

#define MCR_DATA	1
#define mcrGetData	(PIND & _BV(MCR_DATA))		// returns current DEVICE SET value of pin

#define OBUFSZ 8

uint8_t beep_cnt;

uint8_t obuf[OBUFSZ+2];	// +frame bytes
uint8_t tbuf;
uint8_t bitcnt;
uint8_t card_in;
uint8_t lrc;
uint8_t parity;

uint8_t last_key;
uint8_t last_key_c;
uint8_t current_buffer;

uint8_t kbuf_loc;
uint8_t pc_bit;

uint8_t delay_cnt;		// declare here & avoid xtra lag in delay routine

uint8_t pwm_loop;
uint8_t pwm_ptr;
uint8_t pwm_ramp;
uint8_t pwm_dir;
uint8_t pwm_delay;
#define PWM_RAMP_H	0XFF	// highest brightness value
#define PWM_RAMP_L	0X09	// lowest brightness value
#define PWM_DELAY	0XFF	// how long to stay low for



/*** delay ***********************************************************************************************
 *	Delay a set amount of clocks
 ********************************************************************************************************/
void delay(uint8_t time) {
	for(delay_cnt=0; delay_cnt<time; delay_cnt++)
		asm("nop"::);
}
// delay


/*** pc_init *********************************************************************************************
 *	Set up variables used in pc comms
 ********************************************************************************************************/
void pc_init(uint8_t size) {
	uint8_t i;
	
	kbuf_loc = size+2;			// framing
	
	for(i=OBUFSZ; i>0; i--)	// shift data, space for frame
		obuf[i] = obuf[i-1];	// 
	
	obuf[kbuf_loc-1] = 0xF5;	// start frame
	obuf[0] = 0xAF;				// end frame
	
	pc_bit = 8;					//	1 more than max value; decremented before 1st use
}
// pc_init


/*** OCF1A ***********************************************************************************************
 *	Interrupt on timer 0 overflow
 *	Occurs every ~40uS (keyboard clock time)
 ********************************************************************************************************/
SIGNAL(SIG_OUTPUT_COMPARE1A) {
	pwm_ptr++;
	if(pwm_ptr == pwm_loop)
		LED_OFF;
	if(pwm_ptr == 0x00)
		LED_ON;
	
}
//


/*** INTERRUPT0 ******************************************************************************************
 *	Interrupt falling edge of INT0 (PD2) i.e. mcr clock input
 ********************************************************************************************************/
SIGNAL(SIG_INTERRUPT0) {
	uint8_t data;
	
	data = PIND & _BV(MCR_DATA);
	tbuf >>= 1;
	if(data == 0) {											// inverted
		tbuf |= _BV(4);
		
		if(card_in == 1) {										// inc 1's count in this bit place
			lrc ^= _BV(bitcnt);
			parity++;
		}
	}
	
	bitcnt++;
	
	if((card_in == 0) && (tbuf == 0x0B)) {					// 0b01011 --> start sentinel
		card_in = 1;											// indicate valid data / card present
		
		tbuf	= 0;
		bitcnt	= 0;
		lrc		= 0x0B;
		parity	= 0;
	}
	else if((bitcnt == 5) && card_in) {						// when a complete digit is read
		if((card_in == 1) && ((tbuf == 0) || (!(parity&0x01)) )) {
		 // incase end sentinel isn't present, end on zeros / parity error
			card_in = 0;										// invalid data / card not present; clear
		}
		else if((card_in == 1) && (tbuf == 0x1F))	{		// end sentinel (shouldn't that be 0x0F?
			card_in = 2;										// 
		}
		else if(card_in == 1) {								// valid data or LRC
			for(data=(OBUFSZ-1); data>0; data--)				// 
				obuf[data] = obuf[data-1];						// 
			obuf[0] = tbuf;										// shift data
		}
		else if(card_in == 2) {								// LRC byte read, end card read
			card_in = 0;										// indicate card end (no more data should be read)
			
			// generate LRC parity
			lrc |= _BV(4);
			for(data=0; data<4; data++) {
				if(lrc & _BV(data))
					lrc ^= _BV(4);
			}
			
			if(lrc == tbuf) {								// if LRCs match, read was successful; send code to keybd port
				beep(33);
				pc_init(OBUFSZ);
			}
		}
		
		tbuf	= 0;
		bitcnt	= 0;
		parity	= 0;
	}
}
// SIG_INTERRUPT0


/*** INTERRUPT1 ******************************************************************************************
 *	Interrupt falling edge of INT1 (PD3) i.e. par.port clock input
 ********************************************************************************************************/
SIGNAL(SIG_INTERRUPT1) {
	if( (pc_bit>0) || (kbuf_loc>0) ) {		// if there is data in the output buffer, send next bit
		pc_bit--;
		
		if(obuf[kbuf_loc] & _BV(pc_bit)) {
			pcset(PC_DATA_O);
		}
		else {
			pcclr(PC_DATA_O);
		}
		
		if((pc_bit == 0) && (kbuf_loc > 0)) {
			pc_bit = 8;
			kbuf_loc--;
		}
	}
	else
		pcclr(PC_DATA_O);
}
// SIG_INTERRUPT1


/*** T0V0 ************************************************************************************************
 *	Interrupt on timer 0 overflow
 *	Occurs every ~10mS@8MHz (not critical: debounce time)
 ********************************************************************************************************/
SIGNAL(SIG_OVERFLOW0) {
	// pwm
	if(pwm_loop == PWM_RAMP_H)
		pwm_dir = 0x00;
	else if(pwm_loop == PWM_RAMP_L)
		pwm_dir = 0x01;
	
	if(pwm_dir == 1) {
		if((pwm_loop == PWM_RAMP_L) && (pwm_delay < PWM_DELAY))
			pwm_delay++;
		else if(pwm_delay == PWM_DELAY) {
			pwm_delay = 0;
			pwm_loop++;
		}
		else
			pwm_loop++;
	}
	else {
		pwm_loop--;
	}
	
	
	// buzzer
	if(beep_cnt)
		beep_cnt--;
	else
		PORTD |= _BV(0);						// de-activate buzzer after timeout
}
// SIG_OVERFLOW0


/*** io_init *********************************************************************************************
 *	Initialize timer and pins
 ********************************************************************************************************/
void io_init(void) {
	DDRA = 0xFF;		// 
	PORTA = 0x00;		// unused
	
	DDRB = 0xFF;		// 
	PORTB = 0x00;		// unused
	
	DDRC = 0xFF;		// output (leds)
	PORTC = 0xF7;		// all high except PC3, to indicate BAT running
	
	DDRD = 0xE1;		// 1110 0001
						// 0 / O / Buzzer + green LED
						// 1 / I / mr5 data
						// 2 / I / mr5 clock (int0)
						// 3 / I / par clock (int1)
						// 4 / I / par data in	(for future use)
						// 5 / O / par data out
						// 6 / O / 
						// 7 / O / 
	PORTD = 0x18;		// 0001 1000
	
	
	MCUCR = _BV(ISC01) | _BV(ISC11);	// INT0 & INT1 trigger on falling edge
	GIMSK = _BV(INT0) | _BV(INT1);		// enable INT0 & INT1 interrupt
	
	TIMSK = _BV(TOIE0) | _BV(OCIE1A);	// enable TIMER 0 OVERFLOW interrupt, TIMER 1 compare match interupt
	TCCR0 = _BV(CS02);					// set timer0 prescaler to CK/256
	OCR1A = 255;						// 40us timeout
	TCCR1B = _BV(CTC1) | _BV(CS10);	// clear timer1 on compare1a match, set timer0 prescaler to CK/1
	
	
	pwm_loop = 50;
	
	
	beep_cnt = 0;
	current_buffer = OBUFSZ-1;
	bitcnt = 0;
	card_in = 0;
	lrc = 0;
	parity = 0;
	
	
	beep(5);
	uint16_t i;
	for(i=0; i<7000; i++)				//need to delay 500~700mS
		delay(255);
	PORTC = 0xFF;						// turn off LED (indicate BAT complete)
	
	
	// allow interrupts
	sei();
}
// io_init

int main(void) {
	io_init();
	
	for (;;) {
	}
}
//