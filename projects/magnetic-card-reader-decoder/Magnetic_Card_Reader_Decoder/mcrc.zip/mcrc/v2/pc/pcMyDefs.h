#define UC_CLK		(1<<0)
#define UC_DATAOUT	(1<<1)
#define UC_DATAIN	(1<<4)
