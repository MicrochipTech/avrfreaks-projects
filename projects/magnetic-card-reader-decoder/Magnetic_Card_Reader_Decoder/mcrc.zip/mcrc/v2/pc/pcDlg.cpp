/*** Magnetic Card Reader Controller ******************************************
 *	
 *	File Name	: pcDlg.cpp
 *			  
 *	Description	: Receives data from the mcrc board and types it to the
 *				  currently active window
 *			  
 *	Author		: Muhammad J. A. Galadima (mjag17@yahoo.com)
 *			  
 *	Created		: 2004 / 08 / 26
 *			  
 *	Revised		: 2004 / 08 / 31
 *			  
 *	Version		: 1.0
 *			  
 *	
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version 2
 *	of the License, or (at your option) any later version.
 *	
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *	
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software Foundation, 
 *	Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *	
 *****************************************************************************/
// pcDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pc.h"
#include "pcDlg.h"
#include "dlportio.h"
#include "pcMyDefs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CpcDlg dialog



CpcDlg::CpcDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CpcDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CpcDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CpcDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CpcDlg message handlers

BOOL CpcDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	baseAddr = 0x378;
	SetTimer(0, 1, NULL);	// set timer0 to 1ms
	SetTimer(1, 5000, NULL);	// set timer0 to 1ms
	DlPortWritePortUchar(baseAddr, 0xFF);	// set all outputs high (power supply)

	m_Valid = 0;
	m_BitCnt = 0;
	pre_buffer = 0;
	buffer = 0;

	theApp.m_pMainDlg->CloseWindow();	// minimize this window

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CpcDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CpcDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CpcDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CpcDlg::OnTimer(UINT nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == 0) {
		BYTE dataPort = DlPortReadPortUchar(baseAddr);		// what is currently being output
		BYTE statusPort = DlPortReadPortUchar(baseAddr+1);	// what is currently on the input

		dataPort ^= UC_CLK;							// invert clock pin
		DlPortWritePortUchar(baseAddr, dataPort);	// output current clock state (and data, if any)

		if(dataPort & UC_CLK) {	// only do work on high clock
			pre_buffer <<= 1;
			if((statusPort & UC_DATAIN) != 0)	// input check input data
				pre_buffer |= 1;

			if(m_Valid == 1)	//
				m_BitCnt++;		// just a check

			if(m_BitCnt > 72) {	// probable error.. false start or missed stop
				m_BitCnt = 0;
				m_Valid = 0;
			}
			else if( ((pre_buffer & 0xFF) == 0xF5) && (m_Valid == 0) ) {	// start condition
				m_Valid = 1;
			}
			else if( ((pre_buffer & 0xFF) == 0xAF) && (m_Valid == 1) ) {	// stop condition
				CString retVal;
				proc(retVal);	// process keys, send to keyboard, trap error code

				//m_LastValue = retVal;

				UpdateData(FALSE);
				SetTimer(1, 3000, NULL);	// three second delay before clearing output

				// clear input buffer and other vars
				buffer = 0;
				m_BitCnt = 0;
				m_Valid = 0;
				pre_buffer = 0;
			}
			else if(m_Valid == 1) {											// data
				buffer <<= 1;
				if(pre_buffer & (1<<7))
					buffer |= 1;
			}

		}
		else {	// clock is low... do nothing
		}
	}
	else if(nIDEvent == 1) {
		KillTimer(1);
		//m_LastValue.Empty();
		UpdateData(FALSE);
	}

	CDialog::OnTimer(nIDEvent);
}

// data read from MCRC; process it here (test for validity, act upon it)
int CpcDlg::proc(CString retVal)
{
	char i, data[8];
	for(i=7; i>=0; i--) {		// shift data into array (for easier access)
		data[i] = 0;
		data[i] |= (buffer>>(i*8)) & 0xFF;
	}

	// do error check (parity)
	unsigned char j, parity=0;
	for(i=0; i<8; i++) {
		for(j=0; j<4; j++) {
			if( data[i] & (1<<j) )
				parity++;
		}
		if( (parity & 1) ^ ((data[i]>>4) & 1) )		// if true, parity match -- even (0) <> parity set (1), odd (1) <> parity clr (0)
			parity &= 1<<7;		// clear parity, preseve mismatches from last bytes (if any)
		else	// if both are set or both are clear, parity error
			parity = 1<<7;
	}

	if(parity) {	// if there's a parity error, return with an error code
		retVal = "Parity Error!";
		return(1);
	}

	// simulate keypresses
	for(i=7; i>=0; i--) {
		keybd_event((data[i]&0x0F) + 0x30, 0x45, 0, 0);
		keybd_event((data[i]&0x0F) + 0x30, 0x45, KEYEVENTF_KEYUP, 0);
	}

	retVal.Format("%d%d%d%d%d%d%d%d",
		data[7], data[6], data[5], data[4], data[3], data[2], data[1], data[0]);
	return 0;	// no errors
}
