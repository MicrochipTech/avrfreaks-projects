/*** Magnetic Card Reader Controller ******************************************
 *	
 *	File Name	: mcrc.c
 *			  
 *	Description	: Converts the clock & data output from a magnetic card
 *				  reader (in this case the MR5) into keypresses, which
 *				  are sent to the PC via the PS/2 keyboard port
 *			  
 *	Author		: Muhammad J. A. Galadima (mjag17@yahoo.com)
 *			  
 *	Created		: 2004 / 08 / 14
 *			  
 *	Revised		: 2004 / 08 / 23
 *			  
 *	Version		: 1.0
 *			  
 *	Target MCU	: AT90S8515
 *	
 *	
 *	
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version 2
 *	of the License, or (at your option) any later version.
 *	
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *	
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software Foundation, 
 *	Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *	
 *****************************************************************************/


#include <inttypes.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/pgmspace.h>



#define beep(c) ({beep_cnt = c; PORTD &= ~_BV(0);})

#define OBUFSZ 8
#define IBUFSZ 2

#define ps2clr(x)	({DDRA |= _BV(x); PORTA &= ~_BV(x);})
#define ps2set(x)	({PORTA |= _BV(x); DDRA &= ~_BV(x);})
#define ps2get(x)	(PORTA & _BV(x))				// returns current DEVICE SET value of pin
#define ps2rd(x)	({ps2set(x); PINA & _BV(x);})	// returns current status of pin
#define KB_CLK	0
#define KB_DATA	1
#define PS2AUTOBREAK	_BV(0)
#define PS2TRANSLATE	_BV(1)


#define F_OSC	8000000
//3686400
#define t_40us	255
//((F_OSC * 35) / 1000000)
#define t_10us	((F_OSC * 10) / 1000000)
#define t_05us	((F_OSC * 05) / 1000000)

uint8_t beep_cnt;

uint8_t obuf[OBUFSZ];
uint8_t ibuf[IBUFSZ];
uint8_t tbuf;
uint8_t bitcnt;
uint8_t card_in;
uint8_t lrc;
uint8_t parity;

uint8_t last_key;
uint8_t last_key_c;
uint8_t current_buffer;

// look up table for keyboard emulator 0-9                     00    01    02    03    04     05    06    07    08    09
static unsigned char __attribute__ ((progmem)) keys[] = { 0x45, 0x16, 0x1E, 0x26, 0x25, 0x2E, 0x36, 0x3D, 0x3E, 0x46};
int8_t kbuf_loc;
uint8_t ps2byte;
uint8_t ps2bit;
uint8_t rts;
uint8_t ps2ctrl;

uint8_t delay_cnt;		// declare here & avoid xtra lag in delay routine

uint8_t pwm_loop;
uint8_t pwm_ptr;
uint8_t pwm_ramp;
uint8_t pwm_dir;
uint8_t pwm_delay;
#define PWM_RAMP_H	0XFF	// highest brightness value
#define PWM_RAMP_L	0X09	// lowest brightness value
#define PWM_DELAY	0XFF	// how long to stay low for



void io_init(void);




/*** delay ***********************************************************************************************
 *	Delay a set amount of clocks
 ********************************************************************************************************/
void delay(uint8_t time) {
	for(delay_cnt=0; delay_cnt<time; delay_cnt++)
		asm("nop"::);
}
// delay


/*** ps2init *********************************************************************************************
 *	Set up variables used in ps2 comms
 ********************************************************************************************************/
void ps2init(uint8_t size) {
	TCCR1B &= ~_BV(CS10);	// set timer0 prescaler to 0 (disable)
	
	kbuf_loc = size-1;
	ps2byte = 0;
	if(ps2ctrl & PS2AUTOBREAK)
		ps2byte = 2;
	ps2bit = 11;			//	1 more than max value; decremented before 1st use
	
	TCCR1B |= _BV(CS10);	// set timer0 prescaler to CK/1 (enable)
}
// ps2init


/*** ps2send ***********************************************************************************************
 *	Send 1 bit (represented by [ps2bit,ps2byte,kbuf_loc]) to ps2
 *	
 *	value in obuf[] is used to indicate which key/scancode is sent
 ********************************************************************************************************/
void ps2send(void) {
	// ... get our current key obuf location (0-[OBUFSZ-1]), byte location (0-2 ie. KEY/0xF0/KEY)
	// and bit location (0-7, in each data byte)
	if((ps2bit == 0) && (ps2byte || kbuf_loc)) {
		if(ps2byte == 0) {		// .: kbuf_loc > 0
			kbuf_loc--;
			ps2byte = 3;	// 1 more than max value; decremented before 1st use
		}
		ps2byte--;
		ps2bit = 11;		// 1 more than max value; decremented before 1st use
	}
	ps2bit--;
	
	
	uint8_t data=0;
	
	// ...figure out next bit... frame bit...
	if(ps2bit == 10) {					// first bit of this frame; send start bit (0)
		parity = 0;
	}
	else if(ps2bit == 1) {				// parity bit
		if(!(parity & 0x01))
			data = 1;
	}
	else if(ps2bit == 0) {				// stop bit (1)
		data = 1;
	}
	// ...or data bit...
	else if(ps2byte == 1) {
		// send 0xF0 (release code), calculate parity
		data = (0xF0 << (ps2bit-2)) & 0x80;
	}
	else if((ps2byte == 2) || (ps2byte == 0))  {
		// send obuf[kbuf_loc], calculate parity
		if(ps2ctrl & PS2TRANSLATE)
			data = (pgm_read_byte(keys + (obuf[kbuf_loc] & 0x0F) ) << (ps2bit-2)) & 0x80;
		else
			data = (obuf[kbuf_loc] << (ps2bit-2)) & 0x80;
		 //		0x0F --> ignore parity bit in obuf
		 //		(OBUFSZ-1) --> array is 0<->(OBUFSZ-1); top byte is byte0
		 //		(OBUFSZ-1)-kbuf_loc --> invert
	}
	
	if(data)
		parity++;
	
	// wait till not inhibited
	while(!ps2rd(KB_CLK));
	
	// ...put data on ps2 port...
	if(data)
		ps2set(KB_DATA);
	else
		ps2clr(KB_DATA);
	
	delay(t_05us);
	ps2clr(KB_CLK);
}
// ps2send


/*** OCF1A ***********************************************************************************************
 *	Interrupt on timer 0 overflow
 *	Occurs every ~40uS (keyboard clock time)
 ********************************************************************************************************/
SIGNAL(SIG_OUTPUT_COMPARE1A) {
	pwm_ptr++;
	if(pwm_ptr == pwm_loop)
		PORTC |= _BV(1);
	if(pwm_ptr == 0x00)
		PORTC &= ~_BV(1);

	if( ((ps2bit>0)||(ps2byte>0)||(kbuf_loc>0)) && !rts ) {
	 // if any of these is above 0, then there is at least 1 bit waiting to be shifted out
		if(ps2get(KB_CLK)) {			// if clock pin set high, output next bit to data pin
			ps2send();	// shift out 1 bit of scancode[obuf[key_loc]] represented by (ps2bit,ps2byte,kbuf_loc)
		}
		else {	// if clock pin low
			ps2set(KB_CLK);
		}
	}
	else if((kbuf_loc == 0) && !rts) {
		kbuf_loc--;			// set to -1 so that this loop only occurs once
		
//		ps2ctrl = 0;		// reset ps2ctrl
		
		ps2set(KB_CLK);		// release clk
		delay(t_05us);
		ps2set(KB_DATA);	// release data
	}
	// check if host wants to send data
	else if(!ps2rd(KB_CLK) && !rts) {			// check for inhibit (pre-RTS)
		rts = 1;
	}
	else if((rts == 1) && !ps2rd(KB_DATA) && ps2rd(KB_CLK)) {	// rts detected
		// set RTS
		rts = 0;
		for(ps2bit=(IBUFSZ-1); ps2bit>0; ps2bit--)
			ibuf[ps2bit] = ibuf[ps2bit-1];
		ibuf[0] = 0;
		
		// read data from host
		for(ps2bit=0; ps2bit<8; ps2bit++) {
			ps2clr(KB_CLK);
			delay(t_40us);
			ps2set(KB_CLK);
			delay(t_40us);
			if(ps2rd(KB_DATA))
				ibuf[0] |= _BV(ps2bit);
		}
		ps2clr(KB_CLK);
		delay(t_40us);
		ps2set(KB_CLK);
		delay(t_40us);		// parity
		
		ps2clr(KB_CLK);
		delay(t_40us);
		ps2set(KB_CLK);
		delay(t_40us);		// stop
		
		ps2clr(KB_DATA);
		delay(t_05us);
		ps2clr(KB_CLK);
		delay(t_40us);
		ps2set(KB_CLK);
		delay(t_05us);
		ps2set(KB_DATA);	// ACK
		
		
		ps2ctrl = 0;		// no translation, no auto-send key release
		
		// send ACK (0xFA) or other appropriate response
		switch(ibuf[0]) {
			case 0xEE: {			// echo
				obuf[0] = 0xEE;		// reply echo
				ps2init(1);
				
				break;
			}
			case 0xFF: {			// reset device
//				obuf[0] = 0xFA;		// reply ACK
//				ps2init(1);
				
				cli();				// disable interrupts
				io_init();			// reset (interrupts enabled in here)
				
				break;
			}
			case 0xF2: {			// get ID
				obuf[2] = 0xFA;		// reply ACK
				obuf[1] = 0xAB;		// keybd ID
				obuf[0] = 0x83;		// keybd ID
				ps2init(3);
				
				break;
			}
			default: {				// check ibuf[1], it may be a command and ibuf[0] its supplementary data
				switch(ibuf[1]) {
					case 0xED: {
						// switch on/off corresponding LED on the stk500
						//PORTC = ~ibuf[0];	 // caps,num,scroll (2,1,0)
						
						beep(10);
						
						obuf[0] = 0xFA;
						ps2init(1);
						
						break;
					}
					default: {				// if not trappped above, give default response (ACK)
						obuf[0] = 0xFA;	
						ps2init(1);
						
						break;
					}
				}
				break;
			}
		}
	}
	else if((rts == 1) && ps2rd(KB_DATA) && ps2rd(KB_CLK)) {	// this is when rts never makes it to 2
		rts = 0;
	}

}
//


/*** INTERRUPT0 ******************************************************************************************
 *	Interrupt falling edge of INT0 (PD2) i.e. clock input
 ********************************************************************************************************/
SIGNAL(SIG_INTERRUPT0) {
	uint8_t data;
	
	
	data = PIND & _BV(3);
	tbuf >>= 1;
	if(data == 0) {											// inverted
		tbuf |= _BV(4);
		
		if(card_in == 1) {										// inc 1's count in this bit place
			lrc ^= _BV(bitcnt);
			parity++;
		}
	}
	
	bitcnt++;
	
	if((card_in == 0) && (tbuf == 0x0B)) {					// 0b01011 --> start sentinel
		card_in = 1;											// indicate valid data / card present
		
		tbuf	= 0;
		bitcnt	= 0;
		lrc		= 0x0B;
		parity	= 0;
	}
	else if((bitcnt == 5) && card_in) {						// when a complete digit is read
		if((card_in == 1) && ((tbuf == 0) || (!(parity&0x01)) )) {
		 // incase end sentinel isn't present, end on zeros / parity error
			card_in = 0;										// invalid data / card not present; clear
		}
		else if((card_in == 1) && (tbuf == 0x1F))	{		// end sentinel (shouldn't that be 0x0F?
			card_in = 2;										// 
		}
		else if(card_in == 1) {								// valid data or LRC
			for(data=(OBUFSZ-1); data>0; data--)				// 
				obuf[data] = obuf[data-1];						// 
			obuf[0] = tbuf;										// shift data
		}
		else if(card_in == 2) {								// LRC byte read, end card read
			card_in = 0;										// indicate card end (no more data should be read)
			
			// generate LRC parity
			lrc |= _BV(4);
			for(data=0; data<4; data++) {
				if(lrc & _BV(data))
					lrc ^= _BV(4);
			}
			
			if(lrc == tbuf) {								// if LRCs match, read was successful; send code to keybd port
				beep(33);
				ps2ctrl = PS2AUTOBREAK | PS2TRANSLATE;		// automatically send 0xF0 + 0xKEY after each key (default release sequence)
				ps2init(OBUFSZ);							// dump contents of obuf to ps2
			}
		}
		
		tbuf	= 0;
		bitcnt	= 0;
		parity	= 0;
	}
}
// SIG_INTERRUPT0


/*** T0V0 ************************************************************************************************
 *	Interrupt on timer 0 overflow
 *	Occurs every ~10mS@8MHz (not critical: debounce time)
 ********************************************************************************************************/
SIGNAL(SIG_OVERFLOW0) {
	// pwm
	if(pwm_loop == PWM_RAMP_H)
		pwm_dir = 0x00;
	else if(pwm_loop == PWM_RAMP_L)
		pwm_dir = 0x01;
	
	if(pwm_dir == 1) {
		if((pwm_loop == PWM_RAMP_L) && (pwm_delay < PWM_DELAY))
			pwm_delay++;
		else if(pwm_delay == PWM_DELAY) {
			pwm_delay = 0;
			pwm_loop++;
		}
		else
			pwm_loop++;
	}
	else {
		pwm_loop--;
	}
	
	
	// buzzer
	if(beep_cnt)
		beep_cnt--;
	else
		PORTD |= _BV(0);						// de-activate buzzer after timeout
	
/*	
	// scan stk500 keys
	uint8_t key = ~PINB;
	
	if(key) {
		if(key != last_key) {					// button(s) pressed
			last_key_c = 1;
			last_key = key;
		}
		else if(last_key_c < 3)
			last_key_c++;
		else if(last_key_c == 3) {				// last_key contains currently pressed button(s)
			
			if(last_key & _BV(0)) {			// display current_byte on LEDs, select next obuf as current_byte
				if(current_buffer > 0)
					current_buffer--;
				
				PORTC = ~obuf[current_buffer];
			}
			
			else if(last_key & _BV(1)) {			// reset current_byte to 24 (left edge)
				current_buffer = OBUFSZ-1;
				PORTC = ~obuf[current_buffer];
			}
			
			else if(last_key & _BV(2)) {
				if(current_buffer > 0)
					current_buffer--;
				
				PORTC = ~ibuf[current_buffer];
			}
			
			else if(last_key & _BV(3)) {
				current_buffer = IBUFSZ-1;
				PORTC = ~ibuf[current_buffer];
			}
			
			else if(last_key & _BV(4)) {
				obuf[2] = 0x58;		//
				obuf[1] = 0xF0;		//
				obuf[0] = 0x58;		// CAPS
				
				ps2ctrl = 0;
				ps2init(3);
			}
			
			else if(last_key & _BV(5)) {
				obuf[5] = 0x3A;		// m
				obuf[4] = 0x3B;		// j
				obuf[3] = 0x1C;		// a
				obuf[2] = 0x34;		// g
				obuf[1] = 0x16;		// 1
				obuf[0] = 0x3D;		// 7
				
				ps2ctrl = PS2AUTOBREAK;
				ps2init(6);
			}
			
			else if(last_key & _BV(6)) {	// test keyboard emulation by writing a 5
				obuf[3] = 8;		// 8 is the first bit, assuming normal card read
				obuf[0] = 1;		// 8 is the first bit, assuming normal card read
				
				ps2ctrl = PS2AUTOBREAK | PS2TRANSLATE;
				ps2init(4);
			}
			
			else if(last_key & _BV(7)) {			// reset obuf, clock (bit) count, and current_buffer
				for(current_buffer=0; current_buffer<OBUFSZ; current_buffer++)
					obuf[current_buffer] = 0;
				current_buffer = OBUFSZ-1;
				PORTC = 0xFF;
			}
			
			last_key_c = 4;							// so that 'if(last_key_c==3)' is not repeated
		}
	}
	else {
		last_key_c = 0;
		last_key = 0;
	}
*/
}
// SIG_OVERFLOW0


/*** io_init *********************************************************************************************
 *	Initialize timer and pins
 ********************************************************************************************************/
void io_init(void) {
//	DDRA = 0xFE;		// 1111 1100 -- 2 inputs (keybd emulation)
	DDRA = 0xFC;		// 1111 1100 -- 2 inputs (keybd emulation)
	PORTA = 0x03;		// high (pull-ups on)
						// PA0 - clk	in
						// PA1 - data	out
/*	
	DDRB = 0x00;		// input (keys)
	PORTB = 0x00;		// pullups off
*/	
	DDRB = 0xFF;		// output (unused)
	PORTB = 0x00;		// low
	
	DDRC = 0xFF;		// output (leds)
	PORTC = 0xFD;		// all high except PC1, to indicate BAT running
	
	DDRD = 0xF3;		// 1111 0011
						// 0 / O / Buzzer + green LED
						// 1 /   / 
						// 2 / I / clock (int0)
						// 3 / I / data
						// 4 /   / 
						// 5 /   / 
						// 6 /   / 
						// 7 /   / 
	PORTD = 0x01;		// all low / pull-ups off, except PD0 which is active low
	
	
	MCUCR = _BV(ISC01);					// INT0 trigger on falling edge
	GIMSK = _BV(INT0);					// enable INT0 interrupt
	
	TIMSK = _BV(TOIE0) | _BV(OCIE1A);	// enable TIMER 0 OVERFLOW interrupt, TIMER 1 compare match interupt
	TCCR0 = _BV(CS02);					// set timer0 prescaler to CK/256
//	TCCR0 = _BV(CS01) | _BV(CS00);		// set timer0 prescaler to CK/64
	OCR1A = t_40us;						// 40us timeout
	TCCR1B = _BV(CTC1) | _BV(CS10);	// clear timer1 on compare1a match, set timer0 prescaler to CK/1
	
	
	pwm_loop = 50;
	
	
	beep_cnt = 0;
	current_buffer = OBUFSZ-1;
	bitcnt = 0;
	card_in = 0;
	lrc = 0;
	parity = 0;
	
	
	beep(10);
	uint16_t i;
	for(i=0; i<7000; i++)		//need to delay 500~700mS
		delay(255);
	PORTC = 0xFF;		// turn off LED (indicate BAT complete)
	
	
	// allow interrupts
	sei();
	
	
	obuf[2] = 0xAA;		// self test passed
	obuf[1] = 0xAB;		// keybd ID
	obuf[0] = 0x83;		// keybd ID
	ps2init(3);
}
// io_init

int main(void) {
	io_init();
	
	for (;;) {
//		while(!ps2rd(KB_CLK)) {
			// count
//		}
	}
}
//