This project was built to read magnetic cards into the PC by
emulating the keyboard.
	
v1	Uses the PS/2 port and direct keyboard emulation. This worked 
	on all the desktops I tried but only on some of the laptops
	(in particular it didn't work on the laptops that the demo
	was to be done with). Not sure what was going wrong so I
	decided to try a different approach (v2). If you find out
	what I was doing wrong please let me know.

v2	Uses the parallel port and a driver application to receive the
	data and emulate the keyboard. The photos shows a USB receptacle
	not in the schematic: my makeshift power supply. (As for the
	quality, my phones' camera leaves much to be desired ;)
	For direct port access under WinNT (nt/2k/xp), a driver called
	PortIO was used.
