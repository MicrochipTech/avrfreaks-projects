The Midi Exiter is a closed product. It is far from perfect, but I choose
to start anew than trying to improve this setup.
Some of the reasons are: 
- usage of hard to get/expensive components.
  The main input device is a rotary encoder used as jog wheel. This is
  fun to make from an old mouse, but is rather bulky. And no fun at all
  to make a second one.
- display is fully static and therefore quite power hungry.
  The previous display was an LCD (2x40) but this was considered too large.
  The current dual 7-segment displays are compact, a lot faster but use
  a lot of power. This could be multiplexed, but I didn't want to clutter the
  design with code for this. The next project was planned with a numeric LCD 
  display.
- If the new design would fail for some reason, the current one would still 
  be there, instead of being demolished for parts.
- The new design will contain three LFO's instead of one and more paramaters
  to be calculated so I wanted more processing power.

Other documents in this package. 

The other files are mainly the web page I planned for this project. The file
midiexitersource.txt contains some extra comment on the source. The 015 files
were the last version using the LCD display. The 034/035 files are the final 
version.

Fred Jan Kraan
fjkraan@xs4all.nl
20031222

--------
Addendum:
The main picture on the web page was clarified a bit and a picture of the 
rotary encoder added. The information is also available at:
http://www.xs4all.nl/~fjkraan/digaud/mexiter

FJK, 20031225
