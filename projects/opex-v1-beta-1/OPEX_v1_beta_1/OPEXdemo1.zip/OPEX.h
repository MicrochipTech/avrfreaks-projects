// OPEX.h
// (C) 2004 Steve Childress stevech@san.rr.com

#ifndef __AVR_ATmega32__
#define __AVR_ATmega32__
#endif

#define USEMYMALLOC 1	// malloc's source code tweaked

#ifndef _OPEX_H_
#define _OPEX_H_

#include <inttypes.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <wdt.h>
#include <sleep.h>
#include <Interrupt.h>
#include <sig-avr.h>
#include <pgmspace.h>
#include <string.h>

#include <setjmp.h>
#include <delay.h>
#include <eeprom.h>




////////////////////////////////////////////////////////////
// Types
typedef unsigned char BYTE;

typedef struct time_date_node {  // must be ordered highest to lowest
	unsigned char	year;	
	unsigned char	month;
	unsigned char	day;
	unsigned char	hour;
	unsigned char 	minute;
	unsigned char	second;
	unsigned char	tick;
	unsigned char	weekday;	// 0..6 this is not used in time comparisons
} DATE_TIME ;

// SCHEDULER TASK STATE
typedef struct func_state_node {
	struct func_state_node *next;					// linked list
	DATE_TIME when;									// DATE AND TIME when this task is to run
	BYTE state;
	void *pinfo;									// any 16 bits of user data
	size_t *malloc_list;								// list of malloc'd memory
	char *name;										// string name (RAM data)
	void (*funcp) ( struct func_state_node *me);	// address of C function to run
	BYTE *flags;									// pointer to 8 flag bits
	BYTE flagmask;									// flag mask
}  OPEX_TCB ;





//////////////////////////////////////////////////////////////////
// scheduler globals

#define OPEX_sched_FLAGBIT_SERIAL_RECEIVED_ANY 0	// bit number in sched flags
#define OPEX_sched_FLAGBIT_SERIAL_RECEIVED_CR 1		// bit number in sched flags

extern  DATE_TIME time;				// see Timerv1.c
extern	BYTE TicksPerSecond;		// see AVR_Dependent
extern	int8_t GMT_offset_standard;	// see daylightSaving.c
extern	int8_t GMT_offset_now;		// see daylightSaving.c

extern  jmp_buf OPEX_sched_jmp;			// state save for OPEX_sched_quit()
extern	unsigned int _stack_watch;		// see Timerv1.c
extern	int num_com_blocks;			// see OPEXserial.c
extern  BYTE OPEX_sched_flags;			// see OPEX.c


//////////////////////////////////////////////////////////////////
// functions  in OPEX.c

// OPEX_sched_new, below, says:
	//   is a function returning a pointer to a OPEX_TCB structure
	//   is passed a pointer to a function who's argument is a pointer to a OPEX_TCB
OPEX_TCB	*	OPEX_sched_new( void (*funcp)(OPEX_TCB *), char *);
	
void		OPEX_sched_start(void);
void		OPEX_sched_kill(OPEX_TCB *);
void		OPEX_sched_quit(void);
void 		OPEX_sched_add(OPEX_TCB *);
void		OPEX_sched_make_pending(OPEX_TCB *);
void		OPEX_sched_setIdleFunc( void(*funcp) );
void		OPEX_sched_resched(OPEX_TCB *, BYTE, BYTE, BYTE, BYTE, BYTE);
void		OPEX_sched_schedAt(OPEX_TCB *, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE);
void		OPEX_sched_now(OPEX_TCB *);
void 		OPEX_sched_on_flag(BYTE *, BYTE);
void 		OPEX_sched_change_flag(BYTE *, BYTE, BYTE);			
OPEX_TCB *	OPEX_sched_get_named(char *);
OPEX_TCB *	OPEX_sched_queue_remove(OPEX_TCB **, OPEX_TCB *);
void 		OPEX_sched_queue_append(OPEX_TCB **, OPEX_TCB *);
void 		OPEX_sched_queue_insert_head(OPEX_TCB **, OPEX_TCB *);
void 		OPEX_sched_time_changed(void);
char *		OPEX_malloc(OPEX_TCB *, int);
void		OPEX_free(OPEX_TCB *, char *);

//////////////////////////////////////////////////
// Functions in OPEXutils.c
void OPEX_sched_showQitem(OPEX_TCB *, char *, char);
void OPEX_sched_showQ(char *, BYTE); 
void OPEX_sched_show_mem(char *, unsigned int);
void OPEX_sched_showQitem(OPEX_TCB *, char *, char);
	
//////////////////////////////////////////////////
// functions in dateTime.c
void OPEX_init_dateTime(void);
void OPEX_format_date_time(char *,  DATE_TIME *);
void OPEX_format_date(char *,   DATE_TIME *);
void OPEX_format_time(char *,   DATE_TIME *);
 
int  OPEX_compare_dt(DATE_TIME *, DATE_TIME *);
void OPEX_date_add(DATE_TIME *, BYTE, BYTE, BYTE, BYTE, BYTE);
void OPEX_now(DATE_TIME *);
void OPEX_date_stuff(DATE_TIME *, BYTE,BYTE,BYTE,BYTE,BYTE,BYTE,BYTE);
int  OPEX_DayOfWeek( int nYear, int nMonth, int nDay);
 
//////////////////////////////////////////////////
// functions in OPEX serial I/O support
void OPEX_com_init(void);
void OPEX_putc(BYTE);
void OPEX_puts(char *);
void OPEX_puts_P(char *);
void OPEX_putline(char *);
void OPEX_putline_P(char *);
void OPEX_nl(void);

int  OPEX_getc(unsigned char *);
int  OPEX_gets(char *, int, BYTE);
int  OPEX_peek(char *, BYTE);
int	 OPEX_txbuf_unused(void);
int  OPEX_txbuf_used(void);
	
/////////////////////////////////////////////
void OPEX_timer_ISR(void);	// user program's ISR calls this
void OPEX_com_rx_ISR(BYTE);		// user program's ISR calls this
void OPEX_com_tx_ISR(void);		// user program's ISR calls this

/////////////////////////////////////////////////////
// functions in daylightSaving.c
void OPEX_daylight_saving_changes_at(BYTE, DATE_TIME *);
int  OPEX_is_daylight_saving(void);
int  OPEX_daylight_saving_adjust(void);
	
/////////////////////////////////////////////////////
// functions in OPEX_AVR_dependent
void avr_setjmp(void);
void serial_init(void);
void serial_stop(void);			// user program supplied function
void serial_change_txIE(BYTE);	// user program supplied function
int  serial_get_txIE(void);		// user program supplied function
void serial_tx_put(BYTE);		// user program supplied function
void change_IE(BYTE state);

void save_date(void);	// EEPROM access
int  restore_date(void);
	
#endif
