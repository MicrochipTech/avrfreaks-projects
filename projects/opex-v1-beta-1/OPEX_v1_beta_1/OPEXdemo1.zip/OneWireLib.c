//////////////////
// OneWireLib.c
// (C) 2004 Steve Childress stevech@san.rr.com
// NOTE: the test function at the bottom of this file can be 
//       omitted from the compilation of this library.

#include "OPEX.h"

// Define which bit on which port is one-wire
#define IODDR 	DDRA
#define OUTPORT PORTA
#define INPORT  PINA
#define IOBIT 	7
#define IOBITMASK 0x80



// this math works for CPU clocks 1MHz or more
// CPU clock at 6MHz  so  1/f = 0.16uSec = 160 nsec
// 8MHz  = 125ns
// 10Mhz = 100ns
// 16MHz = 62ns
const int xCLOCKS_PER_USEC = 1000 / 160; 	// 1000 nSec = 1uSec

#define FALSE 0
#define TRUE 1

extern char StringBuf1[];

// Externally useful routines
int 	OWReset(void);	// TRUE if device(s) detected
void	OWFamilySelect(unsigned char family_code);
int 	OWFirst(void);	
int 	OWNext(void);
int 	OWVerify(void);

// internal OW routines
int 	OWSearch(void);
void 	OWTargetSetup(unsigned char family_code);
void 	OWFamilySkipSetup(void);

void 	OWWriteByte(unsigned char byte_value);
void 	OWWriteBit(unsigned char bit_value);
unsigned char OWReadBit(void);
unsigned char docrc8(unsigned char value);


////////////////////////
// Static
// global search state
unsigned char ROM_NO[8];
int LastDiscrepancy;
int LastFamilyDiscrepancy;
int LastDeviceFlag;
unsigned char crc8;



/////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------
// I/O PORT FUNCTIONS FOR ONE WIRE
//--------------------------------------------------------------------------


//--------------------------------------------------------------------------
// Reset the 1-Wire bus and return the presence of any device
// Reset is a 0 on the bus for at least 480uSec
// RETURN: state = 0 if no devices detected	
////////////////////////////////////////////////
int OWReset(void)
{
	register unsigned int n;
	int ret = 0;
		
	// create 480uSec reset pulse with CPU looping (oh my)
	n = (xCLOCKS_PER_USEC * 480) / 3;	// compile-time math
	sbi(IODDR, IOBIT);			// output mode
	cbi(OUTPORT, IOBIT);  		// begin the reset, 0 to the bu
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	sbi(OUTPORT, IOBIT); 	// unreset
	cbi(IODDR, IOBIT);		// pin is an input

	// now expect a presence pulse created by any connected 1-wire chip
	n = 0;
	while ((INPORT & IOBITMASK) == 0)  // should go hi after RC chargeup, a few uSec
		if (++n == 0)
			goto err0;
	n = 0;
	while ((INPORT & IOBITMASK) != 0)   // within 60uSec bus should go low, presence pulse
		if (++n == 0)
			goto err0;
	n = 0;
	while ((INPORT & IOBITMASK) == 0)   // should go hi at end of 60-240us presence pulse
		if (++n == 0)
			goto err0;
	ret = 1;
err0:
	return(ret);	
}



//--------------------------------------------------------------------------
// Send 8 bits of data to the 1-Wire bus
//
void OWWriteByte(unsigned char byte_value)
{
	BYTE i;
	
	sbi(IODDR, IOBIT);	// output mode
	cli();		// takes about 600 uSec for this loop
	for (i = 1; i != 0; i <<= 1)
		OWWriteBit( (byte_value & i) != 0 );
	sei();
}
//--------------------------------------------------------------------------
// Send 1 bit of data to the 1-Wire bus
//
void OWWriteBit(unsigned char bit_value)
{
	int n;
	BYTE ie;
		
	ie = SREG & 0x80;
	cli();
	
	sbi(IODDR, IOBIT);	// output mode
	cbi(OUTPORT, IOBIT);		// start bit cell
	n = (xCLOCKS_PER_USEC * 2) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	if (bit_value)
		sbi(OUTPORT, IOBIT);	// sending a 1
	n = (xCLOCKS_PER_USEC * 70) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	sbi(OUTPORT, IOBIT);
	n = (xCLOCKS_PER_USEC * 4) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	if (ie)
		sei(); 
}
//--------------------------------------------------------------------------
// Read 1 bit of data from the 1-Wire bus
// Return 1 : bit read is 1
// 0 : bit read is 0
//
unsigned char OWReadBit()
{
	BYTE b, ie;
	register int n;

	ie = SREG & 0x80;
	cli();
	
	sbi(IODDR, IOBIT);			// make output
	cbi(OUTPORT, IOBIT);		// start bit cell
	n = (xCLOCKS_PER_USEC * 10) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	sbi(OUTPORT, IOBIT);		// for pull up
	cbi(IODDR, IOBIT);			// make input
	n = (xCLOCKS_PER_USEC * 5) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	b = INPORT & IOBITMASK;	// sample data
	n = (xCLOCKS_PER_USEC * 60) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	sbi(IODDR, IOBIT);			// make output, port bit is 1
	n = (xCLOCKS_PER_USEC * 10) / 3;	// compile-time math
	while (--n)				//  delay, 3 clocks per loop iteration
		;
	if (ie)
		sei();		
	return(b != 0);	
}
//--------------------------------------------------------------------------
unsigned char OWReadByte(void)
{
	BYTE i, b = 0;
	
	cli();
	for (i = 8; i != 0; --i)  {
		b >>= 1;
		if (OWReadBit() != 0)
			b |= 0x80;
	}	
	sei();
	return b;
}
//////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------
// Find the 'first' devices on the 1-Wire bus
// Return TRUE : device found, ROM number in ROM_NO buffer
// FALSE : no device present
//
int OWFirst(void)
{
	// reset the search state
	LastDiscrepancy = 0;
	LastDeviceFlag = FALSE;
	LastFamilyDiscrepancy = 0;
	return(OWSearch());
}

//--------------------------------------------------------------------------
// Find the 'next' devices on the 1-Wire bus
// Return TRUE : device found, ROM number in ROM_NO buffer
// FALSE : device not found, end of search
//
int OWNext(void)
{
	// leave the search state alone
	return(OWSearch());
}

//--------------------------------------------------------------------------
// Perform the 1-Wire Search Algorithm on the 1-Wire bus using the existing
// search state.
// Return TRUE : device found, ROM number in ROM_NO buffer
// FALSE : device not found, end of search
//
int OWSearch(void)
{
	unsigned char id_bit_number;
	unsigned char id_bit, cmp_id_bit;
	unsigned char rom_byte_mask, search_direction;
	int last_zero, rom_byte_number, search_result;

	// initialize for search
	id_bit_number = 1;
	last_zero = 0;
	rom_byte_number = 0;
	rom_byte_mask = 1;
	search_result = 0;
	crc8 = 0;
	
	// if the last call was not the last one
	if (!LastDeviceFlag)  {
		// 1-Wire reset
		if (!OWReset())  {		// <<< do a bus reset
			// reset the search
			LastDiscrepancy = 0;
			LastDeviceFlag = FALSE;
			LastFamilyDiscrepancy = 0;
			//OPEX_putline_P(PSTR("OWReset err"));
			return FALSE;
		}

		// issue the search command
		OWWriteByte(0xF0);

		// loop to do the search
		do  {
			// read a bit and its complement
			id_bit = OWReadBit();
			cmp_id_bit = OWReadBit();
			// check for no devices on 1-wire
			if ((id_bit == 1) && (cmp_id_bit == 1))	// means no response from bus
				break;
			else  {
				// all devices coupled have 0 or 1
				if (id_bit != cmp_id_bit)
					search_direction = id_bit; // bit write value for search
				else  {
					// if this discrepancy if before the Last Discrepancy
					// on a previous next then pick the same as last time
					if (id_bit_number < LastDiscrepancy)
						search_direction = ((ROM_NO[rom_byte_number] & rom_byte_mask) > 0);
					else
						// if equal to last pick 1, if not then pick 0
						search_direction = (id_bit_number == LastDiscrepancy);
					// if 0 was picked then record its position in LastZero
					if (search_direction == 0)  {
						last_zero = id_bit_number;
						// check for Last discrepancy in family
						if (last_zero < 9)
							LastFamilyDiscrepancy = last_zero;
					}
				}
				// set or clear the bit in the ROM byte rom_byte_number
				// with mask rom_byte_mask
				if (search_direction == 1)
					ROM_NO[rom_byte_number] |= rom_byte_mask;
				else
					ROM_NO[rom_byte_number] &= ~rom_byte_mask;
				// serial number search direction write bit
				OWWriteBit(search_direction);
				// increment the byte counter id_bit_number
				// and shift the mask rom_byte_mask
				id_bit_number++;
				rom_byte_mask <<= 1;
				// if the mask is 0 then go to new SerialNum byte rom_byte_number and reset mask
				if (rom_byte_mask == 0)  {
					docrc8(ROM_NO[rom_byte_number]); // accumulate the CRC
					rom_byte_number++;
					rom_byte_mask = 1;
				}
			}
		}
		while(rom_byte_number < 8); // loop until through all ROM bytes 0-7
	
		if (crc8 != 0)
			OPEX_putline_P(PSTR("OW crc err"));
		// if the search was successful then
		if (!((id_bit_number < 65) || (crc8 != 0)))  {
			// search successful so set LastDiscrepancy,LastDeviceFlag,search_result
			LastDiscrepancy = last_zero;
			// check for last device
			if (LastDiscrepancy == 0)
				LastDeviceFlag = TRUE;
			search_result = TRUE;
		}
	}
	
	// if no device found then reset counters so next 'search' will be like a first
	if (!search_result || !ROM_NO[0])
	{
		LastDiscrepancy = 0;
		LastDeviceFlag = FALSE;
		LastFamilyDiscrepancy = 0;
		search_result = FALSE;
	}
	return search_result;
}
	
	
	
	
	//--------------------------------------------------------------------------
	// Verify the device with the ROM number in ROM_NO buffer is present.
	// Return TRUE : device verified present
	// FALSE : device not present
	//
int OWVerify(void)
{
	unsigned char rom_backup[8];
	int i,rslt,ld_backup,ldf_backup,lfd_backup;
	
	// keep a backup copy of the current state
	for (i = 0; i < 8; i++)
		rom_backup[i] = ROM_NO[i];
	ld_backup = LastDiscrepancy;
	ldf_backup = LastDeviceFlag;
	lfd_backup = LastFamilyDiscrepancy;
	// set search to find the same device
	LastDiscrepancy = 64;
	LastDeviceFlag = FALSE;
	if (OWSearch())
		{
		// check if same device found
		rslt = TRUE;
		for (i = 0; i < 8; i++)
		{
		if (rom_backup[i] != ROM_NO[i])
			{
			rslt = FALSE;
			break;
			}
		}
	}
	else
		rslt = FALSE;

	// restore the search state
	for (i = 0; i < 8; i++)
		ROM_NO[i] = rom_backup[i];
	LastDiscrepancy = ld_backup;
	LastDeviceFlag = ldf_backup;
	LastFamilyDiscrepancy = lfd_backup;
	// return the result of the verify
	return rslt;
}


	//--------------------------------------------------------------------------
	// Setup the search to find the device type 'family_code' on the next call
	// to OWNext() if it is present.
	//
void OWTargetSetup(unsigned char family_code)
{
	int i;
	
	// set the search state to find SearchFamily type devices
	ROM_NO[0] = family_code;
	for (i = 1; i < 8; i++)
		ROM_NO[i] = 0;
	LastDiscrepancy = 64;
	LastFamilyDiscrepancy = 0;
	LastDeviceFlag = FALSE;
}

//////////////////////////////////////////////
void OWFamilySelect(unsigned char family_code)
{
	OWTargetSetup(family_code);	
}

	//--------------------------------------------------------------------------
	// Setup the search to skip the current device type on the next call
	// to OWNext().
	//
void OWFamilySkipSetup()
{
	// set the Last discrepancy to last family discrepancy
	LastDiscrepancy = LastFamilyDiscrepancy;
	LastFamilyDiscrepancy = 0;
	// check for end of list
	if (LastDiscrepancy == 0)
		LastDeviceFlag = TRUE;
}


static unsigned char dscrc_table[] = {
0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
157,195, 33,127,252,162, 64, 30, 95, 1,227,189, 62, 96,130,220,
35,125,159,193, 66, 28,254,160,225,191, 93, 3,128,222, 60, 98,
190,224, 2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89, 7,
219,133,103, 57,186,228, 6, 88, 25, 71,165,251,120, 38,196,154,
101, 59,217,135, 4, 90,184,230,167,249, 27, 69,198,152,122, 36,
248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91, 5,231,185,
140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
202,148,118, 40,171,245, 23, 73, 8, 86,180,234,105, 55,213,139,
87, 9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53};

//--------------------------------------------------------------------------
// Calculate the CRC8 of the byte value provided with the current
// global 'crc8' value.
// Returns current global crc8 value
//
unsigned char docrc8(unsigned char value)
{
	crc8 = dscrc_table[crc8 ^ value];
	return crc8;
}



#if 1 // make 0 to kill this test code

////////////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------
// One wire library test program

// print one ROM ID
void OW_test_show_found(void)
{
	int i;
	
	for (i = 7; i >= 0; i--)  {
		sprintf_P(StringBuf1, PSTR("%02X"), (int)ROM_NO[i]);
		OPEX_puts(StringBuf1);
	}
}


///////////////////////////////////////////////////////

void OW_test_main(OPEX_TCB *me)
{
	unsigned char onew_data[8];
	int rslt, cnt;
	BYTE t, fam = 0x10;
	union {
		int n;
		BYTE b[2];
	} temperature;


	switch (me->state)  {
		case 0:
			// find ALL devices
			OPEX_putline_P(PSTR("FIND ALL"));
			rslt = OWFirst();
		
			while (rslt)  {
				OW_test_show_found();
				OPEX_nl();
				rslt = OWNext();
			}
	
			OWReset();
			OWWriteByte(0xcc);	// skip ROM, send to all devices
			OWWriteByte(0x44);	// tell all DS1820's to convert
			
			me->state = 1;
			OPEX_sched_resched(me, 0, 0, 0, 1, 0); // run afer conversion delay >750msec
			break;
	
	case 1:	
		fam = 0x10;		// DS1820 chip family code
		sprintf_P(StringBuf1, PSTR("TEST FAMILY %02X"), (int)fam);
		OPEX_putline(StringBuf1);
		OWTargetSetup(fam);
		
		cnt = 0;
		rslt = OWFirst();
		while (rslt)  {
			// check for incorrect type
			if (ROM_NO[0] != fam)
				break;
	 			 		
			OWWriteByte(0xBE);			// read scratchpad command	
			for (t = 0; t <= 7; ++t)
				onew_data[t] = OWReadByte();
					
			temperature.b[0] = onew_data[0];
			temperature.b[1] = onew_data[1];
	
			// temperature LSB is 2**-1.   			
			if (temperature.n >= 0)  // positive 
				t = (temperature.n & 1) ? 5 : 0;
			else					// negative
				t = (temperature.n & 1) ? 0 : 5;		
			sprintf_P(StringBuf1, PSTR("#%2d: %d.%d C"), ++cnt, temperature.n/2, (int)t);
			OPEX_puts(StringBuf1);
	
			temperature.n = ((18 * temperature.n) / 10) + (32*2);  // mul by 10*1.8 divide by 10 add scaled 32
			if (temperature.n >= 0)		// positive 
				t = (temperature.n & 1) ? 5 : 0;
			else						// negative 
				t = (temperature.n & 1) ? 0 : 5;
	
			sprintf_P(StringBuf1, PSTR("  %d.%d F "), temperature.n/2, (int)t);			
			OPEX_puts(StringBuf1);
	
			for (t = 0; t <= 7; ++t)  {
				sprintf_P(StringBuf1, PSTR("%02X "), (int)onew_data[t]);
				OPEX_puts(StringBuf1);
			}			
			OW_test_show_found();
			OPEX_nl();
			rslt = OWNext();
		}
	}
	OPEX_sched_quit();
}

#endif
