//////////////////////////////////////////////////////////////////
//
// OPEXutils.c
// (C) 2004 Steve Childress stevech@san.rr.com

#include "OPEX.h"

extern OPEX_TCB *schedQ, *flagwaitQ;   // in OPEX.c
extern int num_com_blocks; 	// in OPEXserial.c
//////////////////////////////////////
// Print one OPEX_TCB item
void OPEX_sched_showQitem(OPEX_TCB *f, char *p, char showflags)
{
	
	if (f != NULL)  {
		OPEX_format_date_time(p, &f->when);
		OPEX_puts(p);
		sprintf_P(p, PSTR( " %-12s@0x%X  "), f->name, (unsigned int)f);
		OPEX_puts(p);
		sprintf_P(p, PSTR("state=0x%X info=0x%X"), (unsigned int)f->state, (unsigned int)f->pinfo);
		OPEX_puts(p);
		if (showflags)  {
			sprintf_P(p, PSTR(" flags@ 0x%X=0x%X mask:0x%X"), 
					(unsigned int)f->flags, (unsigned int)*f->flags, (unsigned int)f->flagmask);
			OPEX_puts(p);
		}
		OPEX_nl();
	}
}

//////////////////////////////////////
// display members of a given scheduler queue
void OPEX_sched_showQ1(OPEX_TCB **q, char *p, char brief, char showflags)
{
	OPEX_TCB *f;		// queue head
	BYTE n = 1;
	
	if (!brief)
		OPEX_nl();
	f = *q;	// the active func is not in the queue
	while (f != NULL)  {
		if (brief)  {
			OPEX_puts(f->name);
			OPEX_putc(' ');
		}
		else  {
			sprintf_P(p, PSTR("%2d: "), (int)n);
			OPEX_puts(p);
			OPEX_sched_showQitem(f, p, showflags);
		}
		++n;
		f = f->next;
	}
}

//////////////////////////////////////
// Print the scheduler queues
void OPEX_sched_showQ(char *p, BYTE brief) 
{
	
	OPEX_nl();
	OPEX_format_date_time(p, &time);
	OPEX_puts(p);
	sprintf_P(p, PSTR(" DST=%d GMT offset std: %d GMT offset_now: %d"), 
			(int)OPEX_is_daylight_saving(), (int)GMT_offset_standard, (int)GMT_offset_now);
	OPEX_putline(p);
	

	// this queue cannot change in an ISR	
	OPEX_puts_P(PSTR("schedQ:  "));
	OPEX_sched_showQ1(&schedQ, p, brief, 0);		// the main queue
	if (brief)
		OPEX_nl();
	
	// the following queue cannot change due to an ISR.
	OPEX_puts_P(PSTR("flagwaitQ:  "));  // the flag queue
	OPEX_sched_showQ1(&flagwaitQ, p, brief, 0);		// the main queue
	if (brief)
		OPEX_nl();	
}


extern char *brkval;
extern struct freelist *flp;
struct freelist {
	size_t sz;
	struct freelist *nx;
};
//////////////////////////////////////
// Printmemory usage info
void OPEX_sched_show_mem(char *p, unsigned int ram)
{
    unsigned int n, sp_lowest;
	struct freelist *fl; 
	
    
    cli();
    // copy an ISR-volatile variable
    sp_lowest = _stack_watch;   // the clock ISR notes lowest SP addr seen
    sei();
    
 	sprintf_P(p, PSTR("unused: %d stack depth max: %d, SP lowest: 0x%X malloc next: 0x%X \r\nfree list: "),
		sp_lowest - (unsigned int)brkval, ram - sp_lowest, sp_lowest, brkval);
	OPEX_puts(p);
	fl = flp;
	n = 0;
	while (fl)  {
		sprintf_P(p, PSTR("%dAT0x%X, "), fl->sz, (unsigned int)fl);
		OPEX_puts(p);
		n += fl->sz;
		fl = fl->nx;
	}
	sprintf_P(p, PSTR(" Total:%d, \n\rnum_serial_blocks:%d"), n, num_com_blocks);
	OPEX_putline(p);	
}


