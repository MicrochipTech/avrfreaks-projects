(c) 2004, Steve Childress stevech@san.rr.com

OPEX files (alphabetical order)

Compiled with WinAVR (GCC) using the Atman IDE (www.atmanecl.com). 

AVRdependent.c 	- code needed by OPEX but which is AVR chip dependent

OPEXdemo1.aws 	- project file for for AtmanAVR which is an  IDE for WinAVR/GCC (www.atmanecl.com)

demo1_opex.c 	- demonstration program
DS1820.c 	- Dallas 1-Wire application code used in demo1_opex.c
echonow.bat	- windows batch file to format and send date/time to OPEXdemo1.c program
MyMalloc.c 	- slightly modified malloc function for WinAVR
OneWireLib.c 	- Dallas 1-Wire library code used in demo1_opex.c
OPEX.c 		- the kernel/scheduler
OPEX.h 		- universal .h 
OPEXdateTime.c 	- date and time functions
OPEXdaylightSaving.c - administer daylight saving for US and some other countries
OPEXserial.c 	- buffered serial I/O. Low level I/O is in AVRdependent.c
OPEXtimer.c 	- timer interrupt processing. Low level I/O isAVRdependent.c
OPEXutils.c 	- non-essential utility functions

suggestion: use this superb freeware terminal program:
http://bray.velenje.cx/avr/terminal/