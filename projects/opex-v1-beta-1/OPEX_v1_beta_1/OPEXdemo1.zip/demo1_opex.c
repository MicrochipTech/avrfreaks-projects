///////////////////////////////
// demo1_opex.c
// (C) 2004 Steve Childress stevech@san.rr.com
// See main(), below. It begins here.

#include "OPEX.h"
void OW_test_main(OPEX_TCB *);
						
void DS1820(OPEX_TCB *);

extern OPEX_TCB *schedQ, *flagwaitQ, *pendingQ;
extern  unsigned int _stack_watch;	// see Timerv1.c
						
// for the ATmega32
#define JMPBOOT "jmp 0x3c00"  	// boot in mega32

/////////////////////////////////////////////////////////////////////////////



void usart_init(void);
void io_init(void);
void timer_init(void);
	
///////////////////////////////////
char StringBuf1[128];	// global scratch buffer for string work
BYTE reporting;			// flag
BYTE mcusr;				// MCUSR at startup



//////////////////////////////////////
// LED blinker
void led_toggle(BYTE bitmask)
{
	PORTC ^= bitmask;	// PORTC has some LEDs
}



//////////////////////////////////////////////////
// the idle task. see OPEX_sched_setIdleFunc(&idle), below
// 
void idle(void)
{
	static unsigned long idlex;
	static BYTE idlemark_sec;
	
	//if (reporting)  {
		if (idlemark_sec != time.second)  {
			idlemark_sec = time.second;
			OPEX_format_time(StringBuf1, &time); 
			OPEX_puts(StringBuf1);
			sprintf_P(StringBuf1, PSTR(" calls per second to idle() = %lu "), idlex);
			OPEX_putline(StringBuf1);
			idlex = 0;
		}
		else  {
			++idlex;  // a long
		}
	//}
}


/////////////////////////////////////
//  debug tool. print report on OPEX_TCB passed
void report(OPEX_TCB *f)
{
	if (reporting)  {
		if (f != NULL)  {
			OPEX_format_time(StringBuf1,  &time);	// show current time
			OPEX_puts(StringBuf1);
			OPEX_sched_showQitem(f, StringBuf1, 0);			// show function status
		}	
	}
}

/// SCHEDULED ///////////////////////
// A task to display task queue then quit
void task_showQ(OPEX_TCB *me)
{
	int n;
	
	n = (unsigned int)me->pinfo;  // parent task can set this flag
	OPEX_sched_show_mem(StringBuf1, RAMEND);  // memory statistics (RAMEND is in io.h of AVR includes
	OPEX_sched_showQ(StringBuf1, (BYTE)n);  // do the command
	OPEX_sched_quit();	
}


// SCHEDULED ///////////////////////////////////////////////
// This task schedules itself to run the next time time changes
//  to/from daylight saving.
// If time is changed via host command, this prog is resched to run right now.
void OPEX_sched_showQitem(OPEX_TCB *f, char *p, char showflags);

void DST_monitor(OPEX_TCB *me)
{
	int dst;
	
	if (OPEX_daylight_saving_adjust())  	// possibly adjust time of day
		OPEX_sched_time_changed();		// time did change, tell scheduler 

	dst = OPEX_is_daylight_saving();		// get current DST status 1 = DST, 0 = Standard
	me->state = dst; 				// just FYI

	OPEX_sched_showQitem(me, StringBuf1, 1);
	
	// now determine when to run this again
	
	OPEX_daylight_saving_changes_at(0, &me->when); // get ending DST date for DST this year
	// run this only if not now in DST. In DST, the next time to run was set in the code above
	if (!dst)  {  // not in DST now
		--me->when.hour;		// DST ends at 1AM standard time
		if (OPEX_compare_dt(&time, &me->when) >= 0)	{	// if date/time is >= end of DST		
			++me->when.year;						// so no more DST this year
			OPEX_daylight_saving_changes_at(1, &me->when); // get starting date for DST NEXT year
		}
		else
			OPEX_daylight_saving_changes_at(1, &me->when); // get starting date for DST this year			
	}
	
	OPEX_sched_showQitem(me, StringBuf1, 1);
	// The next desired time for this task to run is in the OPEX_TCB (*me)
}
	
// SCHEDULED ///////////////////////////////////////////////
// spawn a task to do a brief mode display of the scheduler's queues
// thus, task0 will appear in the queue.
// reschedule myself to run again later
void task0(OPEX_TCB *me)
{
	OPEX_TCB *f;
	
	report(me);
	if ((f = OPEX_sched_new(&task_showQ, NULL)) != NULL)  // schedule this to run then quit
		f->pinfo = (void *)1; // set flag = brief mode
	OPEX_sched_resched(me, 0, 0, 0, 15, 0);  // run me again later
}

// SCHEDULED ///////////////////////////////////////////////
void task1(OPEX_TCB *me)
{

	led_toggle(1);	// toggle LED every second
	report(me);
	OPEX_sched_now(me);		// get current time
	me->when.tick = 0;	// tick could be non-zero if this ran a little late
	OPEX_date_add( &me->when, 0, 0, 0, 1, 0);  // run again in one second
}


// SCHEDULED ///////////////////////////////////////////////
void task2(OPEX_TCB *me)
{
	led_toggle(2);		// toggle LED eacah time run
	report(me);
	//now(&me->when);
	me->when.tick = 0;  // not really needed, but shows if tardy
	OPEX_date_add(&me->when, 0, 0, 0, rand() % 10, 0);  // random seconds mod 10 later
	me->when.tick = TicksPerSecond/2;  // on the half second
}


// SCHEDULED ///////////////////////////////////////////////
// each time this runs, it creates a new task then quits.

char task3name[10];
BYTE task3num;

void task3(OPEX_TCB *me)
{
	OPEX_TCB *f;
	char oldname[sizeof(task3name)];
	
	led_toggle(4); // toggle LED eacah time run
	//report(me);
	//OPEX_sched_showQ(StringBuf1);
	memcpy(oldname, me->name, sizeof(oldname));  // get copy of old task name
	sprintf_P(task3name, PSTR("TASK3-%d"), (int)(++task3num));
	f = OPEX_sched_new(&task3, task3name);  // make a new task
	f->when.tick = 0; // not really needed, but shows if tardy
	//                    days hrs mins secs ticks
	OPEX_sched_resched(f, 0,   0,  0,   5,   0);  // change when it will first run
	sprintf_P(StringBuf1, PSTR("%s Quitting, %s started"), oldname, f->name);
	OPEX_putline(StringBuf1);
	OPEX_sched_quit();		// abandon this task
}

struct MYINFO  {		// used by task3
		BYTE status;
		DATE_TIME mark;
	};

// SCHEDULED ///////////////////////////////////////////////
// first time run, this task adds a user data structure on
// the OPEX_TCB.
// Each time it's run thereafer, it shows the noted time and
// an incrementing state counter
// the user data also carries a counter called "state" which is shown.

void task4(OPEX_TCB *me)
{
	struct MYINFO *myinfo;  // lotta stack space for this
	
	led_toggle(8); // toggle LED eacah time run
	
	if (me->pinfo == 0)  {  // check if first time called since instantiated
		myinfo = (void *) OPEX_malloc(me, sizeof(struct MYINFO));  // get added user memory space			
		////myinfo = (void *) malloc(sizeof(struct MYINFO));  // get added user memory space
		me->pinfo = myinfo;
		myinfo->status = 0;	// initialize the state counter of this instance
		OPEX_now(&myinfo->mark);	// remember when I first ran
		////OPEX_sched_malloc(me, 32); // get some RAM, to test OPEX_sched_free, ignore return
	}
	report(me);		// show that I ran
	myinfo = me->pinfo;
	
	// print out my name, state counter, and date/time of the "first ran at mark"	
	sprintf(StringBuf1, "%s status=%d mark: ", me->name, (int)(myinfo->status++));
	OPEX_puts(StringBuf1);
	OPEX_format_date_time(StringBuf1, &myinfo->mark);
	OPEX_putline(StringBuf1);

	// reschedule me to run later
	OPEX_sched_now(me);  // get current time and add some to it
	OPEX_date_add( &me->when, 0, 0, 0, 30, TicksPerSecond/2);  // again in x seconds and 1/2 sec)
}


// SCHEDULED ///////////////////////////////////////////////
BYTE task5count = 0;

void task5(OPEX_TCB *me)
{
	OPEX_TCB *f;
	
	led_toggle(0x10); // toggle LED eacah time run
	report(me);
	if (task5count == 0)  {
		while (task5count < 3)   { 
			f = OPEX_sched_new(&task5, "Task5x");
			f->pinfo = (void *) (int) task5count;
			OPEX_sched_resched(f, 0, 0, 0, 5+task5count, 0); // run n seconds from now
			++task5count;
		}
	}
	else  {
		task5count--;
		OPEX_sched_quit();
	}		
	OPEX_sched_resched(me, 0, 0, 0, 30, 0);
}


// SCHEDULED ///////////////////////////////////////////////
// this runs once per clock tick, unless the serial port is blocking
// due to buffer full oun output from other tasks.
// every 2 seconds worth of ticks, it reports. So check time between reports = 2sec
void task6(OPEX_TCB *me)
{
	static BYTE task6n;
	
	led_toggle(0x20); 	// toggle LED eacah time run
	OPEX_sched_resched(me, 0, 0, 0, 0, 1);
	if (--task6n == 0)  {
		task6n = TicksPerSecond*2;	 
		report(me);
	}
}

// SCHEDULED ///////////////////////////////////////////////
// runs when odd numbered bits in "task7_flags" change; 
// the serial port monitor task toggles that flag when digits 0-7 come in from serial port.
BYTE task7_flags;
void task7(OPEX_TCB *me)
{
	report(me);
	sprintf_P(StringBuf1, PSTR("%s: flags are now 0x%X"), me->name, task7_flags);
	OPEX_putline(StringBuf1);
	OPEX_sched_on_flag(&task7_flags, 0xAA); // run this code again when certain bits change
}

////// SCHEDULED /////////////	
// poll I/O bit for change in state, and debounce it assuming it's a pushbutton switch.
// Assume no interrupt is possible for this I/O, so must use polling.
//  This also shows how to avoid additional static variables
// And, this is done as a finite state machine
#define task8bitno 0
void task8(OPEX_TCB *me)
{
	BYTE b, n;
		
	b = PINA & (1<<task8bitno); // get I/O bit state
		
	n = TicksPerSecond/8;	// default clock ticks to when this run again
	switch ((int)me->pinfo)  {  // finite state machine
		case 0:
			cbi(DDRA,  task8bitno); 	// make this bit an input
			sbi(PORTA, task8bitno); 	// enable the pull-up resistor
			me->pinfo = (void *)1; // am initialized, set finite state machine
			break;
		case 1:
			me->flagmask = b;	// note the state of the I/O pin
			me->pinfo = (void *)2;		// wait for a change of state
			break;
		case 2:
			if (me->flagmask != b)     { // has I/O bit changed state?
				me->pinfo = (void *)3;		// yes, check again soon for continued same bit
				n = 1; // faster poll now
			}
			break;
		case 3:
			OPEX_puts(me->name);		// display taskname
			if (me->flagmask != b)	{  // still in changed state?
				sprintf_P(StringBuf1, PSTR(" PORTA bit changed 0x%X"), b);
				OPEX_putline(StringBuf1);
				me->flagmask = b;		// note new state
				me->pinfo = (void *)2;	// look for another change in bit
			}
			else  {
				OPEX_putline(" PORTA glitch ignored");
				me->pinfo = (void *)2;	// ignore too brief state change
				break;
			}
	}					
	OPEX_sched_resched(me, 0, 0, 0, 0, n); // run again in x clock ticks
}


////// SCHEDULED /////////////	
// poll I/O bit for change in state, and debounce it assuming it's a pushbutton switch.
// This task does the state machine as in Task 8 but by changing function pointers
//  instead of the method in task8.

#define task9bitno 1

void task9A(OPEX_TCB *);	// forward reference declarations
void task9B(OPEX_TCB *);
// state: initialize 
void task9(OPEX_TCB *me)
{
	// initialize port
	cbi(DDRA,  task9bitno); 	// make this bit an input
	sbi(PORTA, task9bitno); 	// enable the pull-up resistor
	me->state = (PINA & (1<<task9bitno)); 	// retain I/O bit state
	me->funcp = &task9A;		// change state
	OPEX_sched_resched(me, 0, 0, 0, 0, 1); // run next state on next tick
}
///////////////////////
// state: periodic poll and look for change on I/O bit
void task9A(OPEX_TCB *me)
{
	BYTE b;	
	
	b = (PINA & (1<<task9bitno)); 	// get I/O bit state
	if (b != me->state) {  		// has bit changed yet?
		me->funcp = &task9B;  	// yes, change state
		OPEX_sched_resched(me, 0, 0, 0, 0, 1); // run next state on next tick
	}
	else // bit is unchanged
		OPEX_sched_resched(me, 0, 0, 0, 0, TicksPerSecond/8); // run task9A again leisurely rate
}
///////////////////////
// state: if bit is same as prior to delay from state 9A, it's changed.
//        if bit is different than prior to delay, it was a debounce glitch
void task9B(OPEX_TCB *me)
{
	BYTE b;
	
	b = (PINA & (1<<task9bitno));	// get the I/O
	OPEX_puts(me->name); // display taskname
	if (b != me->state)  { // is bit still changed?
		me->state = b; 	// retain I/O bit state
		sprintf_P(StringBuf1, PSTR(" PORTA bit changed 0x%X"), b);
		OPEX_putline(StringBuf1);
	}
	else  {
		OPEX_putline(" PORTA glitch ignored");
		OPEX_sched_resched(me, 0, 0, 0, 0, 8); // run task9A again more leisurely rate
	}
	me->funcp = &task9A;  // next state is
	OPEX_sched_resched(me, 0, 0, 0, 0, TicksPerSecond/8); // run task9A again more leisurely rate
}

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//// Scheduled /////
void show_named_task(OPEX_TCB *me)
{
	char taskname[32];
		
	if (me->pinfo == NULL)  { // NULL if this was just launched
		me->pinfo = (void *)1;
		OPEX_sched_on_flag(&OPEX_sched_flags, (1<<OPEX_sched_FLAGBIT_SERIAL_RECEIVED_CR) );  // run this func again when another nl comes in
	}
	else  {
		OPEX_puts_P(PSTR("find named task: "));
		OPEX_putline(taskname);
		if (OPEX_gets(taskname, sizeof(taskname), 0) > 1)	// if not an empty line
			report(OPEX_sched_get_named(taskname));
		OPEX_sched_quit();
	}
}



// SCHEDULED ///////////////////////////////////////////////
// monitor the serial port incoming for a 1 char cmd
// this one looks ever second or so for a certain char
//
// This task runs each time a single character arrives on the serial port.
// when a particular character arrives, via the switch statement below,
// various actions are taken.
// when a 'd' is received, the task for the function host_cmd2() is launched, then this task quits.
// The host_cmd2() task sleeps until a carriage return comes in, signifying the end of the d command's 
// data has arrived. Then the d command (set date/time) is processed. Then this command, host_cmd1() is
// relaunched by host_cmd2();
// This technique yields non-blocking I/O and assures fast executing, without polling.
//
void host_cmd1(OPEX_TCB *me)
{
	void host_cmd2(OPEX_TCB *);  // declare  reference to this function
	void echotest(OPEX_TCB *);  // ditto
		
	OPEX_TCB *f, *f1;
	char c[1];
	BYTE b;	
	
	
	//report(me);
	
	while(OPEX_peek(c, 0) != 0)   {  // inspect all newly arrived chars
		// input the char and take action
		OPEX_getc(c);	// get from FIFO (peekc above said there's >=1 chars waiting)
		switch (c[0])  {
			case '$':  		// jump to bootstrap code 
					//save_date();
					OPEX_putline_P(PSTR(JMPBOOT));
					while (serial_get_txIE());	// let serial output finish
						;
					cli();
					asm(JMPBOOT);
					break;
			case 'd':  // host set date command. Give the serial port to the command processor
						// this will read the rest of the command line, up to a CR
					OPEX_sched_new(&host_cmd2, "host_cmd2"); // do the command
					OPEX_sched_quit();  // stop checking chars, host_cmd2 will restart me
					break;  // never gets here
			case 'e': // echo serial test
					OPEX_sched_new(&echotest, "echotest2"); // do the command
					OPEX_sched_quit();  // stop checking chars, host_cmd2 will restart me
					break;  // never gets here				
			case 'K':	// kill all tasks
					while (flagwaitQ != NULL) //kill those in this queue
						OPEX_sched_kill(flagwaitQ);
					f = schedQ;		// kill all but me in the sched time sorted queue
					f = f->next; // skip this task (me)
					while (f)  {
						f1 = f->next;  
						OPEX_sched_kill(f);
						f = f1;
					}
					OPEX_sched_quit();  // now I quit
					break;					
			case 'k':  // kill all tasks except this one
					while (flagwaitQ != NULL) 
						OPEX_sched_kill(flagwaitQ);
					f = schedQ;  // kill all but me in the sched time sorted queue
					f = f->next; // // skip this task (me)
					while (f)  {
						f1 = f->next;  
						OPEX_sched_kill(f);
						f = f1;
					}
					break;  // leave me running
			case 'm':
					sprintf_P(StringBuf1, PSTR("Startup MCUSR=0x%X"), mcusr);
					OPEX_putline(StringBuf1);
					OPEX_sched_show_mem(StringBuf1, RAMEND); // do the command
					break;	
			case 'n':
					OPEX_sched_new(&show_named_task, NULL);
					break;
			case 'q':  // brief  display
					f = OPEX_sched_new(&task_showQ, NULL); // do the command as a separate task, NULL name
					f->pinfo = (void *)1; // set brief mode flag
					break;
			case 'Q':  // verbose display
					f = OPEX_sched_new(&task_showQ, NULL); // do the command as a separate task, NULL name
					f->pinfo = NULL; // set brief mode flag
					//OPEX_sched_showQ(StringBuf1, 0);  // do the command
					break;
			case 'r':  // toggle reporting of task executions on/off
					reporting ^= 1;
					break;
			case 't': // test daylight savings (US times, change if EU)
					if (OPEX_is_daylight_saving())  {
						cli();
						OPEX_daylight_saving_changes_at(0, &time); // get ending DST date for DST this year
						--time.hour; time.minute = 59; time.second = 30;  // just before that time
						sei();
					}
					else {
						cli();
						OPEX_daylight_saving_changes_at(1, &time); // get starting DST date for DST this year
						--time.hour; time.minute = 59; time.second = 30;  // just before that time
						sei();
					}
					OPEX_daylight_saving_adjust();
					OPEX_sched_time_changed();  // inform all tasks of change - also gets dst monitor task 
					break;
			case 'x':
					OPEX_sched_new(&OW_test_main, "OW_Test");
					break;
			case 'y':
					OPEX_sched_new(&DS1820, "DS1820");
					break;		
			case '0':  // these toggle flag bits for test7
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
					b = (BYTE) (c[0] & 7);  // key typed is the binary bit #
					// for digit b (0 to 7) received, toggle flag bit b
					// task 7 runs when any odd bit # changes (task 7's mask is 0xAA)
					//				  flag pointer, bit number,  new value
					OPEX_sched_change_flag( &task7_flags, b, ( (task7_flags & (1 << b)) ) ? 0 : 1 );
					break;			
			default:
					break;					
		}  // switch
	}  // while
	// run this func again later when a character arrives on serial port
	OPEX_sched_on_flag(&OPEX_sched_flags, (1<<OPEX_sched_FLAGBIT_SERIAL_RECEIVED_ANY) );
}





// SCHEDULED ///////////////////////////////////////////////
//    Parse the received string and set the date/time or just print same. Then quit.
//
void host_cmd2(OPEX_TCB *me)			
{
	int mo, d, y, h, m, s, gmt_offset;

	if ( (OPEX_sched_flags & (1<<OPEX_sched_FLAGBIT_SERIAL_RECEIVED_CR)) == 0)
		// wait for CR received flag to come on, or it may already be on
		OPEX_sched_on_flag(&OPEX_sched_flags, (1<<OPEX_sched_FLAGBIT_SERIAL_RECEIVED_CR) ); 
	 	// the above OPEX call does not return, it reschedules this function upon receipt of CR
	 	
	// ??? this has a possible race condition with the ISR
	OPEX_sched_flags &= ~(1<<OPEX_sched_FLAGBIT_SERIAL_RECEIVED_CR); 
		
	// read in a line of text which has arrived with a CR
	d = OPEX_gets(StringBuf1, 63, 0);	// get line of text from serial port, no wait, clears the flag bit
 	// process the received line of text
	if (strlen(StringBuf1) >1)  { 
		if (sscanf_P(StringBuf1, PSTR("%d %3s %d/%d/%d %d:%d:%d"), // valid format?
						&gmt_offset, &StringBuf1, &d, &mo, &y, &h, &m, &s) == 8) 
			{ 
			y %= 100; // oh well, assume century 20xx
			GMT_offset_standard = (int8_t)gmt_offset; // <<< offset for STANDARD time, no matter DST
			OPEX_date_stuff(&time, (BYTE)y, (BYTE)d, (BYTE)mo, (BYTE)h, (BYTE)m, (BYTE)s , 0);
			save_date();	// save to EEPROM
			OPEX_daylight_saving_adjust();
			OPEX_sched_time_changed();  // inform all tasks of change - also gets dst monitor task
			}
		else  { // invalid format
			sprintf_P(StringBuf1, PSTR("Err, e.g.:-8 Sun mm/dd/yy hh:mm:ss"));
			OPEX_putline(StringBuf1);
		}  
	}
	OPEX_sched_new(&host_cmd1, "host_cmd1");  // restart single char cmd processor
	OPEX_sched_quit();
} 


// Echo line of test to serial port - test/demo
// see 'e' command in host_cmd1
void echotest(OPEX_TCB *me)
{
	switch (me->state)  {
		case 0:
			OPEX_putline_P(PSTR("Enter text and CR - not echoed"));	
			me->state = 1;	
			OPEX_sched_on_flag(&OPEX_sched_flags, (1<<OPEX_sched_FLAGBIT_SERIAL_RECEIVED_CR) );			
			// the above line of code causes this func to run again when CR is received
			break; // never gets here
		case 1:
			OPEX_gets(StringBuf1, 63, 0); // get string, no wait
			OPEX_putline(StringBuf1);
			OPEX_sched_new(&host_cmd1, "host_cmd1");  // restart single char cmd processor
			OPEX_sched_quit();
	}
}


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/// MAIN ///
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////


int main(void)
{
	char *p;

	
	mcusr = MCUSR;  // retain cause of reset
	MCUSR = 0;		// reset causes
	
	io_init();		// see AVR_dependent for these...
	timer_init();
	serial_init();
	
	OPEX_com_init();		// init OPEX serial I/O
	
	//Global interrupt enable
	sei();
	OPEX_putline_P(PSTR("\r\nRESET"));
	
	OPEX_init_dateTime();	// set OPEX date and time defaults

	reporting = 1;

	// top level 
	for ( ;; )  {
		_stack_watch = 0xffff;
		// initialization - 
		while (OPEX_getc(StringBuf1) != 0)  // purge left over serial data if any
			;
		OPEX_putline_P(PSTR("\r\n\nLaunching"));

		OPEX_sched_setIdleFunc(&idle);		// establish an idle user task
		
		// launch recurring tasks (the if expressions are in case one fails to launch due to malloc()
		// non of these execute until all are launched	
		if ( 
					(OPEX_sched_new(&DST_monitor, (p = "DST")) == NULL)
				||	(OPEX_sched_new(&host_cmd1, (p = "Host_Cmd1")) == NULL)
				||	(OPEX_sched_new(&task0, (p = "TASK0")) == NULL)
				||	(OPEX_sched_new(&task1, (p = "TASK1")) == NULL)   
				||	(OPEX_sched_new(&task2, (p = "TASK2")) == NULL)  
				||	(OPEX_sched_new(&task3, (p = "TASK3")) == NULL)   
				||	(OPEX_sched_new(&task4, (p = "TASK4")) == NULL) 	
				||	(OPEX_sched_new(&task5, (p = "TASK5")) == NULL) 	
				||	(OPEX_sched_new(&task6, (p = "TASK6")) == NULL) 
				||	(OPEX_sched_new(&task7, (p = "TASK7")) == NULL)
				||	(OPEX_sched_new(&task8, (p = "TASK8")) == NULL)
				||	(OPEX_sched_new(&task9, (p = "TASK9")) == NULL)
				//||	(OPEX_sched_new(&DS1820, (p = "DS1820")) == NULL)
			)
		  	{
				sprintf_P(StringBuf1, PSTR("OPEX_sched_new err on %s"), p);
				OPEX_putline(StringBuf1);
			}
		else  { // all launched successfully, so start scheduler
			OPEX_putline_P(PSTR("Starting Scheduler") );
			OPEX_sched_start();	// returns when all tasks quit, just start up again	
			OPEX_putline_P(PSTR("Scheduler returned!") );
		}
	}
}

