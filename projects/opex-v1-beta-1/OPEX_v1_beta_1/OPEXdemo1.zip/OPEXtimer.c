//OPEXTimer.c  source file for the M32 Timers
// (C) 2004 Steve Childress stevech@san.rr.com

#include "OPEX.h"


/////////////////////////////////////////////////////////////////////////////
//
//const unsigned char MAX_DAY[] PROGMEM = { /* return max day for a given month */
//        0,31,28,31,30,31,30,31,31,30,31,30,31 }; // indexed 1..12
//const unsigned char MAX_DAYLEAP[] PROGMEM = { /* return max day for a given month */
//        0,31,28,31,30,31,30,31,31,30,31,30,31 }; // indexed 1..12
        
const unsigned char __attribute__((progmem)) MAX_DAY[13] = { /* return max day for a given month */
        0,31,28,31,30,31,30,31,31,30,31,30,31 }; // indexed 1..12
const unsigned char __attribute__((progmem)) MAX_DAYLEAP[13] = { /* return max day for a given month */
        0,31,29,31,30,31,30,31,31,30,31,30,31 }; // indexed 1..12


DATE_TIME time;		// KEEP CURRENT DATE/TIME HERE	

unsigned int _stack_watch = 0xffff;



// (mega32 Timer2 interrupt (normally, 128 per second.)
// maintain time and date.
void OPEX_timer_ISR(void)
{    
    // SP, below, is the AVR chip's stack pointer 
    if ( (unsigned int)(SP) < _stack_watch)	// note smallest SP value, until reset by someone else
    	_stack_watch = (unsigned int)(SP);
    		
	if(++time.tick >= TicksPerSecond)  { // TicksPerSecond is in AVR_Dependent.c
		time.tick = 0;                                            
		if(++time.second > 59)	{	// count up seconds
			time.second = 0;		// enough for a minute?
			if(++time.minute > 59)	{
				time.minute = 0;	// enough minutes for an hour?
				if(++time.hour > 23)	{
					time.weekday = (time.weekday+1) &  7;  // advance weekday #                    
					time.hour = 0;	// enough hours for a day?
					if((time.year & 3) != 0)  {  // leap year ignore 2099?
						if(++time.day > PRG_RDB(&MAX_DAY[time.month]))  {	 // 1..12
							time.day = 1;	// enough days for this month?
							if(++time.month > 12)	{
								time.month = 1;	// another year gone by..
								++time.year;
							}
						}
					}
					else  {
						if(++time.day > PRG_RDB(&MAX_DAYLEAP[time.month]))	{   // 1..12
							time.day = 1;	// enough days for this month?
							if(++time.month > 12)	{
								time.month = 1;	// another year gone by..
								++time.year;
							}
						}
					}
				}
			}
		}
	}	
}






