struct targetTable {
	Char	idAvr910;		// Device ID for AVR910 programmer
	Char	idStk500;		// Device ID for STK500 programmer

	Char	sig0;			// signature byte 0 (1 of 3)
	Char	sig1;			// signature byte 1 (2 of 3)
	Char	sig2;			// signature byte 2 (3 of 3)

	Char	rev;			// Device revision

	UInt32	flashSize;		// FLASH memory
	UInt16	eepromSize;		// EEPROM memory

	Char	fuseBytes;		// Number of fuse bytes
	Char	lockBytes;		// Number of lock bytes

	Char	serFProg;		// (internal) Serial fuse programming support
	Char	serLProg;		// (internal) Serial lockbit programming support
	Char	serFLRead;		// (internal) Serial fuse/lockbit reading support
	Char	commonLFR;		// (internal) Indicates if lockbits and fuses are combined on read
	Char	serMemProg;		// (internal) Serial memory progr. support

	UInt16	pageSize;		// Flash page size
	Char	eepromPageSize;		// Eeprom page size (extended parameter)

	Char	selfTimed;		// True if all instructions are self timed
	Char	fullPar;		// True if part has full parallel interface
	Char	polling;		// True if polling can be used during SPI access

	Char	fPol;			// Flash poll value
	Char	ePol1;			// Eeprom poll value 1
	Char	ePol2;			// Eeprom poll value 2

	Char*	name;			// Device name

	Char	signalPAGEL;		// Position of PAGEL signal (0xD7 by default)
	Char	signalBS2;		// Position of BS2 signal (0xA0 by default)
};

// !> fallback device code festlegen? wenn, dann "unknown" device dafür nehmen und entspr. device codes dort eintragen

const struct targetTable TargetsTable[] = {
//	  Id#1  Id#2  Sig0  Sig1  Sig2 Rv  FSize   ESize FB LB SerFP  SerLP  SerFLR CLFR   SerMP  PS   EPS SelfT  FulPar Poll   FPoll EPol1 EPol2 Name           PAGEL BS2
	{ 0x00, 0x00, 0x1e, 0xff, 0xff, 0, 0,      0,    0, 0, false, false, false, false, false, 0,   0,  false, false, false, 0x00, 0x00, 0x00, "none",   0x00, 0x00},
	{ 0x55, 0x12, 0x1e, 0x90, 0x05, 1, 1024,   64,   1, 1, true,  true,  true,  false, true,  0,   0,  true,  false, true,  0xFF, 0xFF, 0xFF, "ATtiny12",    0xD7, 0xA0},
	{ 0x56, 0x15, 0x1e, 0x90, 0x06, 1, 1024,   64,   1, 1, true,  true,  true,  false, true,  0,   0,  true,  false, true,  0xFF, 0xFF, 0xFF, "ATtiny15",    0xD7, 0xA0},

	{ 0x5e, 0x21, 0x1e, 0x91, 0x09, 1, 2048,   128,  2, 1, true,  true,  true,  false, true,  32,  4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATtiny26",    0xD7, 0xA0},

	{ 0x13, 0x33, 0x1e, 0x90, 0x01, 4, 1024,   64,   1, 1, false, true,  false, true,  true,  0,   0,  false, true,  true,  0xFF, 0x00, 0xFF, "AT90S1200",   0xD7, 0xA0},

	{ 0x20, 0x40, 0x1e, 0x91, 0x01, 1, 2048,   128,  1, 1, false, true,  false, true,  true,  0,   0,  false, true,  true,  0x7F, 0x80, 0x7F, "AT90S2313",   0xD7, 0xA0},
	{ 0x48, 0x41, 0x1e, 0x91, 0x02, 1, 2048,   128,  1, 1, true,  true,  true,  true,  true,  0,   0,  false, false, true,  0xFF, 0x00, 0xFF, "AT90S2323",   0xD7, 0xA0},
	{ 0x34, 0x42, 0x1e, 0x91, 0x05, 1, 2048,   128,  1, 1, true,  true,  true,  false, true,  0,   0,  false, true,  true,  0xFF, 0x00, 0xFF, "AT90S2333",   0xD7, 0xA0},
	{ 0x4c, 0x43, 0x1e, 0x91, 0x03, 1, 2048,   128,  1, 1, true,  true,  true,  true,  true,  0,   0,  false, false, true,  0xFF, 0x00, 0xFF, "AT90S2343",   0xD7, 0xA0},

	{ 0x28, 0x50, 0x1e, 0x92, 0x01, 1, 4096,   256,  1, 1, false, true,  false, true,  true,  0,   0,  false, true,  true,  0x7F, 0x80, 0x7F, "AT90S4414",   0xD7, 0xA0},
	{ 0x30, 0x51, 0x1e, 0x92, 0x03, 1, 4096,   128,  1, 1, true,  true,  true,  false, true,  0,   0,  false, true,  true,  0xFF, 0x00, 0xFF, "AT90S4433",   0xD7, 0xA0},
	{ 0x6c, 0x52, 0x1e, 0x92, 0x02, 1, 4096,   256,  1, 1, true,  true,  true,  true,  true,  0,   0,  false, true,  true,  0xFF, 0x00, 0xFF, "AT90S4434",   0xD7, 0xA0},

	{ 0x38, 0x60, 0x1e, 0x93, 0x01, 1, 8192,   256,  1, 1, false, true,  false, true,  true,  0,   0,  false, true,  true,  0x7F, 0x80, 0x7F, "AT90S8515",   0xD7, 0xA0},
	{ 0x68, 0x61, 0x1e, 0x93, 0x03, 1, 8192,   512,  1, 1, true,  true,  true,  true,  true,  0,   0,  false, true,  true,  0xFF, 0x00, 0xFF, "AT90S8535",   0xD7, 0xA0},

	{ 0x76, 0x70, 0x1e, 0x93, 0x07, 1, 8192,   512,  2, 1, true,  true,  true,  false, true,  64,  4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega8",     0xD7, 0xA0},
	{ 0x3a, 0x63, 0x1e, 0x93, 0x06, 1, 8192,   512,  2, 1, true,  true,  true,  false, true,  64,  4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega8515",  0xD7, 0xA0},
	{ 0xff, 0x64, 0x1e, 0x93, 0x08, 1, 8192,   512,  2, 1, true,  true,  true,  false, true,  64,  4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega8535",  0xD7, 0xA0},

	{ 0x60, 0x80, 0x1e, 0x94, 0x01, 1, 16384,  512,  1, 1, true,  true,  true,  false, true,  128, 0,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega161",   0xD7, 0xA0},
	{ 0xff, 0x83, 0x1e, 0x94, 0x04, 1, 16384,  512,  3, 1, true,  true,  true,  false, true,  128, 4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega162",   0xD7, 0xA0},
	{ 0x64, 0x81, 0x1e, 0x94, 0x02, 1, 16384,  512,  2, 1, true,  true,  true,  false, true,  128, 0,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega163",   0xD7, 0xA0},
	{ 0x74, 0x82, 0x1e, 0x94, 0x03, 1, 16384,  512,  2, 1, true,  true,  true,  false, true,  128, 4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega16",    0xD7, 0xA0},
	{ 0xff, 0x84, 0x1e, 0x94, 0x05, 1, 16384,  512,  3, 1, true,  true,  true,  false, true,  128, 4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega169",   0xD7, 0xA0},

	{ 0xff, 0x90, 0x1e, 0x95, 0x01, 1, 32768,  1024, 2, 1, true,  true,  true,  false, true,  128, 0,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega323",   0xD7, 0xA0},
	{ 0x72, 0x91, 0x1e, 0x95, 0x02, 1, 32768,  1024, 2, 1, true,  true,  true,  false, true,  128, 4,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega32",    0xD7, 0xA0},

	{ 0x41, 0xb1, 0x1e, 0x97, 0x01, 1, 131072, 4096, 1, 1, true,  true,  true,  false, true,  256, 0,  false, true,  false, 0x00, 0x00, 0x00, "ATmega103",   0xA0, 0xD7},
	{ 0x43, 0xb2, 0x1e, 0x97, 0x02, 1, 131072, 4096, 3, 1, true,  true,  true,  false, true,  256, 8,  true,  true,  true,  0xFF, 0xFF, 0xFF, "ATmega128",   0xD7, 0xA0},
};
