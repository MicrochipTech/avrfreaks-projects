/*
* PalmAVR - AVR In-System-Programming solution for Palm OS.
* Copyright (C) 2004  Mark Haemmerling <palmavr@emcad.de>
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*

DEVELOPMENT NOTES
=================

At first, sorry for the completely inconsistent naming of variables etc.
Not my style, actually. But I guess I was confused by the caps naming in the Palm SDK.

TODO (see notes tagged with "!>" in the source)
----

0.4.0:
- use progress dialogs
- save/load more stuff in prefs struct
- smallicon resource
- at ident, if NumImages == 1, bring up an alert in which the user can decide between verify or cancel
- protect upload/download/verify against missing device memory segment (TargetsTable.sizeX > 0)
- (?) at device selection, offer only target memories which are available on this device (rom segment size > 0)

NEW GUI PLANNED:
- main screen with several sections: Upload, Download, Verify + Identify, Fuse editor
- selection of name or database comes up as separate dialog window (always with previous selection which is also saved as pref data)
- dialog windows during ISP operations with more info: Uploading ... bytes in page mode. Page size: ... bytes. Image name: ... ...% complete.
- cancel button for ISP dialogs! -> basically exits with failure return code

*/

#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>
#include <Core/System/MemoryMgr.h>

#include "palmavr.h"
#include "stk500/command.h"
#include "targets.h"

#define countof(a)		(sizeof(a)/sizeof(a[0]))

#define SERIAL_TIMEOUT		(1.0 * SysTicksPerSecond()) // in ticks (usually 100 per second)
#define ROM_VERSION_REQUIRED	(0x03000000) // requires Palm OS 3.x or later
#define PROGTYPES		(3)

#define	KILOBYTE		(1024)

#define UPDATE_INTV		(25) // time between progress display updates (in ticks)

#define MAX_DB			(64) // max. number of databases displayed

#define MAX_SYNC_TRY		(33) // !> FIX... should not be greater than 33

#define FLASH_INIT		((Char) 0xff) // initial flash rom value (always 0xff)

const UInt32 typeImageFlash	= 'ImFl';
const UInt32 typeImageEeprom	= 'ImEe';
const UInt32 myCreator		= 'pAVR';
const UInt16 myPrefsVer		= 0x0001;
const UInt16 PrefsID 		= 'UI';

static Char dbTriggerText[64];
static Char targetTriggerText[64];

const UInt32 SerialIntf[]	= { serPortCradleRS232Port, sysFileCVirtIrComm, sysFileCVirtRfComm };

static Char sendBuffer[300]; // !> use real maxsize (256 page size + other cooked data)
static Char rcvBuffer[300]; // !> use real maxsize (256 page size + other cooked data)

struct prefs {
	UInt16 progType;
	UInt16 progIntf;
	UInt16 progBaud;
	UInt16 segment;
};

struct imageList {
	UInt16 card;
	LocalID db;
	Char name[32];
} ImagesList[MAX_DB];

Char ProgInfoString[PROGTYPES][32];

UInt16 SupportedTargets[PROGTYPES][countof(TargetsTable)]; // this will be filled with supported device codes
UInt16 NumSupportedTargets[PROGTYPES];

UInt16 NumImages = 0;

const UInt32 BaudRates[] = { 9600, 19200, 38400, 57600, 115200 }; // if you change this, don't forget to adapt the list in the rcp file!

UInt32 AutoAddr; // holds auto-incr address
Boolean AutoAddrSupp; // does programmer support auto address incrementation?

void SetListTriggerName(UInt16 ListID, UInt16 TriggerID) {
	UInt16 item;
	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ListID));
	ControlType* triggerP =	FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, TriggerID));

	item = LstGetSelection(list);

	if (item != noListSelection) {
		CtlSetLabel(triggerP, LstGetSelectionText(list, LstGetSelection(list)));
	}
}

/*
void SetDownloadImageName(Char* name) {
	FormPtr frm = FrmGetFormPtr(MainForm);
	FieldPtr imageNameFldP = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImageDownloadName));
	MemHandle imageNameH;
	MemPtr imageNameP;

	imageNameH = FldGetTextHandle(imageNameFldP);
	imageNameP = MemHandleLock(imageNameH);
//	StrCopy(imageNameP, name);
	StrPrintF(imageNameP, "DEBUG TEST");
	MemHandleUnlock(imageNameH);
	FldDrawField(imageNameFldP);
}
*/

void SerialFlush(UInt16 port) {
	SrmSendFlush(port);
	SrmReceiveFlush(port, 0);
}

UInt16 SerialOpen(UInt32 speed, UInt32 intf) {
	UInt16 port;

	if (SrmOpen(intf, speed, &port) == errNone) {
		if (intf == sysFileCVirtIrComm) { // explicitly enable IrDA transceiver
			SerialFlush(port);
			SrmControl(port, srmCtlIrDAEnable, NULL, NULL);
		}
		return port;
	}
	FrmAlert(AlertSerOpen);
	return 0;
}

void SerialClose(UInt16 port) {
	SrmClose(port);
}

void SetLabel(UInt16 formID, UInt16 labelID, Char *text) { // !> option to avoid complete redraw (if new string is definitely not shorter - saves time!)
	FormPtr frm = FrmGetFormPtr(formID);
	UInt16 labelIdx = FrmGetObjectIndex(frm, labelID);

	FrmHideObject(frm, labelIdx);
	FrmCopyLabel(frm, labelID, text);
	FrmShowObject(frm, labelIdx);
}

UInt32 GetBaudrate() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	UInt16 sel = LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgBaud)));

	if (sel == noListSelection) return 0;
	else return BaudRates[sel];
}

UInt16 GetCurrentIntf() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	return LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgIntf)));
}

UInt16 GetCurrentDatabase() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	return LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList)));
}

UInt16 GetCurrentTarget() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	return LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsList)));
}

UInt16 GetCurrentMemory() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	return LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainMemoryList)));
}

UInt16 GetCurrentProgType() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	return LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgType)));
}

UInt16 GetTargetTableIndexByDevCode(Char code) {
	UInt16 idx;
	
	for (idx = 0; idx < countof(TargetsTable); idx++) {
		if (TargetsTable[idx].idAvr910 == code) return idx;
	}
	return 0; // on index 0 there is a placeholder telling the user that this code is unknown
}

UInt16 GetSupportedTargetIndexBySignature(UInt16 ProgType, Char* sig) {
	UInt16 idx;
	
	for (idx = 0; idx < NumSupportedTargets[ProgType]; idx++) {
		if ((TargetsTable[SupportedTargets[ProgType][idx]].sig0 == sig[0]) && (TargetsTable[SupportedTargets[ProgType][idx]].sig1 == sig[1]) && (TargetsTable[SupportedTargets[ProgType][idx]].sig2 == sig[2])) return idx;
	}
	return 0; // on index 0 there is a placeholder telling the user that this code is unknown
}

void SetProgInfo() {
	UInt16 ProgType = GetCurrentProgType();
		
	if ((ProgType != noListSelection) && ProgInfoString[ProgType][0]) {
		SetLabel(MainForm, MainProgInfo, ProgInfoString[ProgType]);
	} else {
		SetLabel(MainForm, MainProgInfo, "[not available]");
	}
}

void ListDatabasesSetTrigger() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList));
	ControlType* triggerP =	FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesTrigger));
	UInt16 item = GetCurrentDatabase();
	if (GetCurrentMemory() != noListSelection) {
		if (item == noListSelection) {
			if (NumImages == 0) {
				StrPrintF(dbTriggerText, "[no ROM image available]");
			} else if (NumImages == 1) {
				StrPrintF(dbTriggerText, "[1 ROM image available]");
			} else {
				StrPrintF(dbTriggerText, "[%u ROM images available]", NumImages);
			}
			CtlSetLabel(triggerP, dbTriggerText);
		} else {
			CtlSetLabel(triggerP, LstGetSelectionText(list, item));
		}
	} else {
		CtlSetLabel(triggerP, "[select memory segment first]");
	}
}

void ListDatabases() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList));
	UInt16 mem = GetCurrentMemory();
	
	static Char* ptr[MAX_DB]; // pointers to strings (arrays of Char)
	
	DmSearchStateType state; 
	Boolean latestVer = false; 
	UInt16 card; 
	LocalID currentDB = 0; 
	Err theErr;
	UInt32 dbType = 0;

	if (mem == 0)		dbType = typeImageFlash;
	else if (mem == 1)	dbType = typeImageEeprom;
	
	NumImages = 0;
	if (dbType) {
		theErr = DmGetNextDatabaseByTypeCreator(true, &state, dbType, myCreator, latestVer, &card, &currentDB); 
		while (!theErr && currentDB && (NumImages < MAX_DB)) {
			ImagesList[NumImages].card = card;
			ImagesList[NumImages].db = currentDB;
			ptr[NumImages] = ImagesList[NumImages].name;
			DmDatabaseInfo(ImagesList[NumImages].card, ImagesList[NumImages].db, ptr[NumImages], NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
			NumImages++;
			theErr = DmGetNextDatabaseByTypeCreator(false, &state, dbType, myCreator, latestVer, &card, &currentDB);
		}
	}
	LstSetListChoices(list, ptr, NumImages);
	ListDatabasesSetTrigger();
}

void ListTargetsSetTrigger() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsList));
	ControlType* triggerP =	FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsTrigger));
	UInt16 ProgType = GetCurrentProgType();
	UInt16 item = LstGetSelection(list);
	
	if (ProgType == noListSelection) {
		StrPrintF(targetTriggerText, "[select programmer first]");
		CtlSetLabel(triggerP, targetTriggerText);
	} else {
		if (item == noListSelection) {
			if (NumSupportedTargets[ProgType] == 0) {
				StrPrintF(targetTriggerText, "[no list available]");
			} else if (NumSupportedTargets[ProgType] == 1) {
				StrPrintF(targetTriggerText, "[1 device supported]");
			} else {
				StrPrintF(targetTriggerText, "[%u devices supported]", NumSupportedTargets[ProgType]);
			}
			CtlSetLabel(triggerP, targetTriggerText);
		} else {
			CtlSetLabel(triggerP, LstGetSelectionText(list, item));
		}
	}
}

void ListTargets() {
	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsList));
	
	UInt16 ProgType = GetCurrentProgType();
	UInt16 num = 0;
	Char code;
	
	static Char* ptr[countof(SupportedTargets[ProgType])]; // pointers to strings (arrays of Char)

	if (ProgType != noListSelection) {
		for (num = 0; num < NumSupportedTargets[ProgType]; num++) {
			ptr[num] = TargetsTable[SupportedTargets[ProgType][num]].name;
		}
		LstSetListChoices(list, ptr, num);
	}
	ListTargetsSetTrigger();
}

Boolean SerialReceiveByte(UInt16 port, Char* byte) {
	// receives one byte from serial port
	Err err;
	Char buffer;
	
	SrmReceive(port, &buffer, 1, SERIAL_TIMEOUT, &err);
	if (byte != NULL) *byte = buffer;
	if (err != errNone) {
		if (err == serErrTimeOut) FrmAlert(AlertSerTimeout);
		else if (err == serErrLineErr) FrmAlert(AlertSerLineErr);
		else FrmAlert(AlertSerUnknown);
		return false;
	} else return true;
}

Boolean SerialReceiveBuffer(UInt16 port, Char* buffer, UInt16 size) {
	// receives a buffer of specified length from serial port
	Err err;
	
	SrmReceive(port, buffer, size, SERIAL_TIMEOUT, &err);
	if (err != errNone) {
		if (err == serErrTimeOut) FrmAlert(AlertSerTimeout);
		else if (err == serErrLineErr) FrmAlert(AlertSerLineErr);
		else FrmAlert(AlertSerUnknown);
		return false;
	} else return true;
}

Boolean SerialReceiveExpect(UInt16 port, Char byte) {
	// returns failure whenever the char could not be received or an unexpected char was received
	Char buffer;
	
	if (SerialReceiveByte(port, &buffer)) {
		if (buffer == byte) return true;
		FrmAlert(AlertSerUnexpected);
	}
	return false;
}

void SerialSendByte(UInt16 port, Char byte) { // !> add a success feedback
	// sends one byte to serial port
	Err err;
	SrmSend(port, &byte, 1, &err);
}

void SerialSendBuffer(UInt16 port, Char* buffer, UInt16 size) { // !> add a success feedback
	// sends a buffer to serial port
	Err err;
	SrmSend(port, buffer, size, &err);
}

Boolean IspSync(UInt16 port, UInt16 ProgType) {
	Boolean success = false;
	UInt16 count = 0;
	Char rcv;
	
	switch (ProgType) {
	case PROG_STK500:
	case PROG_AVRISP:
		for (;;) {
			Char buffer[] = { Cmnd_STK_GET_SYNC, Sync_CRC_EOP };
			SrmSendFlush(port);
			SrmReceiveFlush(port, 0);
			SerialSendBuffer(port, buffer, sizeof(buffer));
			if (SerialReceiveByte(port, &rcv)) {
				if (rcv == Resp_STK_INSYNC) {
					if (SerialReceiveByte(port, &rcv)) {
						if (rcv == Resp_STK_OK) {
							success = true;
							break;
						}
					} else break;
				}
			} else break; // cancel at timeout or i/o problem
			count++;
			if (count >= MAX_SYNC_TRY) { FrmAlert(AlertMaxSyncTries); break; }
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}	

Boolean Stk500SendReceive(UInt16 port, UInt16 ProgType, UInt16 sendLen, UInt16 rcvLen) {
	Boolean success = false;
	UInt16 i;
	Char rcv;
	UInt16 try = 0;

	for (;;) {
		sendBuffer[sendLen] = Sync_CRC_EOP;
		SerialSendBuffer(port, sendBuffer, sendLen+1);
		if (SerialReceiveByte(port, &rcv)) {
			if (rcv == Resp_STK_INSYNC) {
				if (!SerialReceiveBuffer(port, rcvBuffer, rcvLen)) break;
				if (SerialReceiveByte(port, &rcv)) {
					if (rcv == Resp_STK_OK) {
						success = true;
						break;
					}
				} else break;
			}
		} else break;
		if ((!success) && (!IspSync(port, ProgType))) break; // cancel if resync failed
		try++;
		if (try >= MAX_SYNC_TRY) {
			FrmAlert(AlertMaxSyncTries);
			break;
		}
	};

	return success;
}

Boolean IspReportAutoIncr(UInt16 port, UInt16 ProgType, Boolean* autoIncr) {
	// reports if programmer supports auto address incrementation
	Boolean success = false;
	Char rcv;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'a');
		if (SerialReceiveByte(port, &rcv)) {
			*autoIncr = (rcv == 'Y');
			success = true;
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		// this makes no sense, anyway... the STK500 always supports auto-incr.
		// there is no documentation what is returned if auto-incr is NOT supported. so what is this all about?
		sendBuffer[0] = Cmnd_STK_CHECK_AUTOINC;
		success = Stk500SendReceive(port, ProgType, 1, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspProgModeEnter(UInt16 port, UInt16 ProgType) {
	// enter programming mode
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		if (IspReportAutoIncr(port, ProgType, &AutoAddrSupp)) {
			AutoAddr = -1; // programmer does not reset address at entering prog. mode. so we init with invalid value which will result in sending the address before the first action
			SerialSendByte(port, 'P');
			if (SerialReceiveExpect(port, 13)) success = true;
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_ENTER_PROGMODE;
		success = Stk500SendReceive(port, ProgType, 1, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspProgModeLeave(UInt16 port, UInt16 ProgType) {
	// leave programming mode
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'L');
		if (SerialReceiveExpect(port, 13)) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_LEAVE_PROGMODE;
		success = Stk500SendReceive(port, ProgType, 1, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspGetSoftwareIdent(UInt16 port, UInt16 ProgType, Char* buffer) {
	// gets 7char software identifier (buffer must be sized 7 chars)
	Boolean success = false;
	UInt16 i;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'S');
		for (i = 0; i < 7; i++) {
			if (!SerialReceiveByte(port, buffer+i)) break;
		}
		if (i == 7) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_GET_SIGN_ON;
		if (success = Stk500SendReceive(port, ProgType, 1, 7)) {
			for (i = 0; i < 7; i++) buffer[i] = rcvBuffer[i];
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspGetSupportedTargets(UInt16 port, UInt16 ProgType) {
	// gets list of device codes supported by the programmer. saves as target table indexes
	Boolean success = false;
	Char byte;
	UInt16 idx;

	switch (ProgType) {
	case PROG_AVR910:
		NumSupportedTargets[PROG_AVR910] = 0;
		SerialSendByte(port, 't');
		do {
			success = SerialReceiveByte(port, &byte);
			if (byte) {
				if (NumSupportedTargets[PROG_AVR910] < countof(SupportedTargets[PROG_AVR910])) {
					idx = GetTargetTableIndexByDevCode(byte);
					if (idx) {
						SupportedTargets[PROG_AVR910][NumSupportedTargets[PROG_AVR910]] = idx;
						NumSupportedTargets[PROG_AVR910]++;
					}
				}
			}
		} while ((success) && (byte));
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		success = true;
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspGetSoftwareVersion(UInt16 port, UInt16 ProgType, Char* string) {
	// gets major/minor software version
	Boolean success = false;
	Char major, minor;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'V');
		if (
			SerialReceiveByte(port, &major) &&
			SerialReceiveByte(port, &minor)
		) {
			StrPrintF(string, "%c.%c", major & 0xff, minor & 0xff);
			success = true;
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_GET_PARAMETER;
		sendBuffer[1] = Parm_STK_SW_MAJOR;
		if (Stk500SendReceive(port, ProgType, 2, 1)) {
			major = rcvBuffer[0];
			sendBuffer[0] = Cmnd_STK_GET_PARAMETER;
			sendBuffer[1] = Parm_STK_SW_MINOR;
			if (Stk500SendReceive(port, ProgType, 2, 1)) {
				minor = rcvBuffer[0];
				StrPrintF(string, "%u.%u", major & 0xff, minor & 0xff);
				success = true;
			}
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspGetHardwareVersion(UInt16 port, UInt16 ProgType, Char* string) {
	// gets major/minor hardware version
	Boolean success = false;
	Char major, minor;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'v');
		if (
			SerialReceiveByte(port, &major) &&
			SerialReceiveByte(port, &minor)
		) {
			StrPrintF(string, "%c.%c", major & 0xff, minor & 0xff);
			success = true;
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_GET_PARAMETER;
		sendBuffer[1] = Parm_STK_HW_VER;
		if (Stk500SendReceive(port, ProgType, 2, 1)) {
			major = rcvBuffer[0];
			StrPrintF(string, "%u", major & 0xff);
			success = true;
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspSetAddress(UInt16 port, UInt16 ProgType, UInt16 address) {
	// sets 16bit address
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		if ((AutoAddrSupp) && (AutoAddr == address)) {
			success = true;
		} else {
			SerialSendByte(port, 'A');
			SerialSendByte(port, (address >> 8));
			SerialSendByte(port, (address & 0xff));
			if (SerialReceiveExpect(port, 13)) {
				if (AutoAddrSupp) AutoAddr = address;
				success = true;
			}
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_LOAD_ADDRESS;
		sendBuffer[1] = (address & 0xff);
		sendBuffer[2] = (address >> 8);
		success = Stk500SendReceive(port, ProgType, 3, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspWriteProgmemWord(UInt16 port, UInt16 ProgType, UInt8 hi, UInt8 lo) {
	// writes word of program memory to current address
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'c');
		SerialSendByte(port, lo);
		if (SerialReceiveExpect(port, 13)) {
			SerialSendByte(port, 'C');
			SerialSendByte(port, hi);
			if (SerialReceiveExpect(port, 13)) {
				if (AutoAddrSupp) AutoAddr++; // the programmer counts up one address when writing the high byte
				success = true;
			}
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_PROG_FLASH;
		sendBuffer[1] = lo;
		sendBuffer[2] = hi;
		success = Stk500SendReceive(port, ProgType, 3, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspPageFlush(UInt16 port, UInt16 ProgType) {
	// issues page write to the flash rom
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'm');
		if (SerialReceiveExpect(port, 13)) success = true;
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspReadProgmemWord(UInt16 port, UInt16 ProgType, Char* hi, Char* lo) {
	// reads data from progmem, expects word as reply (depends on memory type!)
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'R');
		success = (
			SerialReceiveByte(port, hi) &&
			SerialReceiveByte(port, lo)
		);
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_READ_FLASH;
		if (success = Stk500SendReceive(port, ProgType, 1, 2)) {
			*hi = rcvBuffer[1];
			*lo = rcvBuffer[0];
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspWriteProgmemPage(UInt16 port, UInt16 ProgType, UInt8* buffer, UInt32 bufferSize, UInt16 pageSize, UInt16 page) {
	// writes a complete page into flash rom
	Boolean success = false;
	UInt32 startAddr = pageSize * page;
	UInt16 i;

	switch (ProgType) {
	case PROG_AVR910:
		for (i = 0; i < pageSize; i += 2) {
			if (success = IspSetAddress(port, ProgType, (startAddr + i) >> 1)) {
				if ((startAddr + i) < bufferSize) success = (
					IspWriteProgmemWord(port, ProgType, buffer[startAddr + i + 1], buffer[startAddr + i])
				); else success = (
					IspWriteProgmemWord(port, ProgType, FLASH_INIT, FLASH_INIT)
				);
			}
			if (!success) break;
		}
		if (success) success = (
			IspSetAddress(port, ProgType, startAddr >> 1) &&
			IspPageFlush(port, ProgType)
		);
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		// !> take care not to exceed the buffer size in the stk500!!
		if (IspSetAddress(port, ProgType, startAddr >> 1)) {
			sendBuffer[0] = Cmnd_STK_PROG_PAGE;
			sendBuffer[1] = (pageSize >> 8);
			sendBuffer[2] = (pageSize & 0xff);
			sendBuffer[3] = 'F'; // flash
			for (i = 0; i < pageSize; i++) {
				if ((startAddr + i) < bufferSize) sendBuffer[4 + i] = buffer[startAddr + i];
				else sendBuffer[4 + i] = FLASH_INIT;
			}
			success = Stk500SendReceive(port, ProgType, 4 + pageSize, 0);
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspReadProgmemPage(UInt16 port, UInt16 ProgType, UInt8* buffer, UInt16 pageSize, UInt16 page) {
	// reads a complete page from flash rom
	// caution: writes directly to buffer starting at buffer[0], without adding page offset!
	Boolean success = false;
	UInt32 startAddr = pageSize * page;
	UInt16 i;

	switch (ProgType) {
	case PROG_AVR910:
		for (i = 0; i < pageSize; i += 2) {
			success = (
				IspSetAddress(port, ProgType, (startAddr + i) >> 1) &&
				IspReadProgmemWord(port, ProgType, buffer + i + 1, buffer + i)
			);
			if (!success) break;
		}
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		// !> take care not to exceed the buffer size in the stk500!!
		if (IspSetAddress(port, ProgType, startAddr >> 1)) {
			sendBuffer[0] = Cmnd_STK_READ_PAGE;
			sendBuffer[1] = (pageSize >> 8);
			sendBuffer[2] = (pageSize & 0xff);
			sendBuffer[3] = 'F'; // flash
			success = Stk500SendReceive(port, ProgType, 4, pageSize);
			for (i = 0; i < pageSize; i++) buffer[i] = rcvBuffer[i];
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspWriteDatamem(UInt16 port, UInt16 ProgType, UInt8 byte) {
	// writes one byte to data memory
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'D');
		SerialSendByte(port, byte);
		if (SerialReceiveExpect(port, 13)) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_PROG_DATA;
		sendBuffer[1] = byte;
		success = Stk500SendReceive(port, ProgType, 2, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

inline Boolean IspReadDatamem(UInt16 port, UInt16 ProgType, UInt8* byte) {
	// reads one byte from data memory
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'd');
		if (
			SerialReceiveByte(port, byte)
		) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_READ_DATA;
		if (success = Stk500SendReceive(port, ProgType, 1, 1)) {
			*byte = rcvBuffer[0];
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspChipErase(UInt16 port, UInt16 ProgType) {
	// issues a chip erase
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'e');
		if (SerialReceiveExpect(port, 13)) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_CHIP_ERASE;
		success = Stk500SendReceive(port, ProgType, 1, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspSelectDeviceType(UInt16 port, UInt16 ProgType, UInt16 type) {
	// selects the device type in the programmer (must be issued before entering programming mode)
	Boolean success = false;
	
	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 'T');
		SerialSendByte(port, TargetsTable[SupportedTargets[PROG_AVR910][type]].idAvr910);
		if (SerialReceiveExpect(port, 13)) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0]  = Cmnd_STK_SET_DEVICE;
		sendBuffer[1]  = TargetsTable[SupportedTargets[ProgType][type]].idStk500;
		sendBuffer[2]  = TargetsTable[SupportedTargets[ProgType][type]].rev;
		sendBuffer[3]  = 0; // parallel high-voltage and serial mode supported
		sendBuffer[4]  = TargetsTable[SupportedTargets[ProgType][type]].fullPar;
		sendBuffer[5]  = TargetsTable[SupportedTargets[ProgType][type]].polling;
		sendBuffer[6]  = TargetsTable[SupportedTargets[ProgType][type]].selfTimed;
		sendBuffer[7]  = TargetsTable[SupportedTargets[ProgType][type]].lockBytes;
		sendBuffer[8]  = TargetsTable[SupportedTargets[ProgType][type]].fuseBytes;
		sendBuffer[9]  = TargetsTable[SupportedTargets[ProgType][type]].fPol;
		sendBuffer[10] = TargetsTable[SupportedTargets[ProgType][type]].fPol;
		sendBuffer[11] = TargetsTable[SupportedTargets[ProgType][type]].ePol1;
		sendBuffer[12] = TargetsTable[SupportedTargets[ProgType][type]].ePol2;
		sendBuffer[13] = TargetsTable[SupportedTargets[ProgType][type]].pageSize >> 8;
		sendBuffer[14] = TargetsTable[SupportedTargets[ProgType][type]].pageSize & 0xff;
		sendBuffer[15] = TargetsTable[SupportedTargets[ProgType][type]].eepromSize >> 8;
		sendBuffer[16] = TargetsTable[SupportedTargets[ProgType][type]].eepromSize & 0xff;
		sendBuffer[17] = ((UInt32) TargetsTable[SupportedTargets[ProgType][type]].flashSize >> 24) & 0xff;
		sendBuffer[18] = ((UInt32) TargetsTable[SupportedTargets[ProgType][type]].flashSize >> 16) & 0xff;
		sendBuffer[19] = (TargetsTable[SupportedTargets[ProgType][type]].flashSize >> 8) & 0xff;
		sendBuffer[20] = TargetsTable[SupportedTargets[ProgType][type]].flashSize & 0xff;
		success = Stk500SendReceive(port, ProgType, 21, 0);
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}
	return success;
}

Boolean IspReadSignature(UInt16 port, UInt16 ProgType, Char* sig) {
	// reads 3-byte signature code from target (sig must be sized 3 chars)
	Boolean success = false;

	switch (ProgType) {
	case PROG_AVR910:
		SerialSendByte(port, 's');
		if (
			SerialReceiveByte(port, sig+2) &&
			SerialReceiveByte(port, sig+1) &&
			SerialReceiveByte(port, sig+0)
		) success = true;
		break;
	case PROG_STK500:
	case PROG_AVRISP:
		sendBuffer[0] = Cmnd_STK_READ_SIGN;
		if (success = Stk500SendReceive(port, ProgType, 1, 3)) {
			sig[0] = rcvBuffer[0];
			sig[1] = rcvBuffer[1];
			sig[2] = rcvBuffer[2];
		}
		break;
	default:
		FrmAlert(AlertISPNotSupported);
		break;
	}

	if ((success) && ((sig[0] == (Char) 0xff) && (sig[1] == (Char) 0xff) && (sig[2] == (Char) 0xff))) {
		FrmAlert(AlertNoAVR);
		success = false;
	}

	return success;
}

Boolean ProgrammerDetect() { // !> programmer type and baudrate auto detection? maybe, after a warning
	UInt32 baud = GetBaudrate();
	UInt16 intf = GetCurrentIntf();
	UInt16 ProgType = GetCurrentProgType();
	Char type;
	Char ident[8];
	UInt16 port;
	Char swStr[8], hwStr[8];
	Boolean success = false;

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!baud) { FrmAlert(AlertNoBaudSel); return; }
	
	port = SerialOpen(baud, SerialIntf[intf]);
	if (port) {
		SetLabel(MainForm, MainStatus0, "Detecting programmer...");
		SetLabel(MainForm, MainStatus1, "");
		if (
			IspGetSoftwareIdent(port, ProgType, ident) &&
			IspGetSoftwareVersion(port, ProgType, swStr) &&
			IspGetHardwareVersion(port, ProgType, hwStr) &&
			IspGetSupportedTargets(port, ProgType)
		) {
			ident[7] = 0; // manually add terminator char for StrPrintF
			StrPrintF(ProgInfoString[ProgType], "%s (SW %s, HW %s)", ident, swStr, hwStr);
			SetProgInfo();
			SetLabel(MainForm, MainStatus0, "Success:");
			SetLabel(MainForm, MainStatus1, "Programmer detected.");
			ListTargets();
			success = true;
		} else {
			SetLabel(MainForm, MainStatus0, "Error:");
			SetLabel(MainForm, MainStatus1, "Programmer not detected.");
		}
		SerialClose(port);
	}
	return success;
}

Boolean TargetDetect() {
	UInt32 baud = GetBaudrate();
	UInt16 intf = GetCurrentIntf();
	UInt16 ProgType = GetCurrentProgType();
	UInt16 targetIdx = GetCurrentTarget();
	UInt16 port;
	Boolean success = false;

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!baud) { FrmAlert(AlertNoBaudSel); return; }
	if (ProgType == PROG_AVR910) if (!ProgrammerDetect()) return; // get list from programmer first

	port = SerialOpen(baud, SerialIntf[intf]);
	if (port) {
		Char sig[3];
		Char type;
		if (targetIdx == noListSelection)	type = 0; // if no target already selected, use first in list
		else 					type = targetIdx;
		SetLabel(MainForm, MainStatus0, "Detecting target...");
		SetLabel(MainForm, MainStatus1, "");
		if (
			IspSelectDeviceType(port, ProgType, type) &&
			IspProgModeEnter(port, ProgType) &&
			IspReadSignature(port, ProgType, sig) &&
			IspProgModeLeave(port, ProgType)
		) {
			UInt16 idx;
			FormPtr frm = FrmGetFormPtr(MainForm);
			ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsList));
			idx = GetSupportedTargetIndexBySignature(ProgType, sig);
			if (idx) {
				LstSetSelection(list, idx);
				SetLabel(MainForm, MainStatus0, "Success:");
				SetLabel(MainForm, MainStatus1, "Detected supported target.");
				success = true;
			} else {
				LstSetSelection(list, noListSelection);
				SetLabel(MainForm, MainStatus0, "Failed:");
				SetLabel(MainForm, MainStatus1, "Target not identified.");
			}
			ListTargets();
		} else {
			SetLabel(MainForm, MainStatus0, "Error:");
			SetLabel(MainForm, MainStatus1, "No target detected.");
		}
		SerialClose(port);
	}
	return success;
}

void ProgramChipErase() {
	UInt16 targetIdx;
	UInt16 ProgType = GetCurrentProgType();
	UInt16 intf = GetCurrentIntf();

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!GetBaudrate()) { FrmAlert(AlertNoBaudSel); return; }
	if (GetCurrentTarget() == noListSelection) if (!((FrmAlert(AlertNoTargetSel) == 0) && TargetDetect())) return;

	targetIdx = GetCurrentTarget();
	if (FrmAlert(AlertConfirmChipErase) == 0) {
		Boolean success = false;
		UInt16 port;
		port = SerialOpen(GetBaudrate(), SerialIntf[intf]);
		if (port) {
			SetLabel(MainForm, MainStatus0, "Target Chip Erase...");
			SetLabel(MainForm, MainStatus1, "");
			success = (
				IspSelectDeviceType(port, ProgType, targetIdx) &&
				IspProgModeEnter(port, ProgType) &&
				IspChipErase(port, ProgType) &&
				IspProgModeLeave(port, ProgType)
			);
			if (success) {
				SetLabel(MainForm, MainStatus0, "Success:");
				SetLabel(MainForm, MainStatus1, "Chip erased.");
			} else {
				SetLabel(MainForm, MainStatus0, "Error:");
				SetLabel(MainForm, MainStatus1, "Chip erase failed.");
			}
			SerialClose(port);
		}
	}
}	

void ProgramReadSignature() {
	UInt16 ProgType = GetCurrentProgType();
	UInt16 intf = GetCurrentIntf();
	UInt16 targetIdx = GetCurrentTarget();
	UInt16 port;
	UInt32 sigDisplay;
	void* sigP;

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!GetBaudrate()) { FrmAlert(AlertNoBaudSel); return; }
	if ((ProgType == PROG_AVR910) && (targetIdx == noListSelection)) if (!ProgrammerDetect()) return; // get list from programmer first

	port = SerialOpen(GetBaudrate(), SerialIntf[intf]);
	if (port) {
		Char sig[3];
		Char type;
		if (targetIdx == noListSelection)	type = 0; // if no target already selected, use first in list
		else 					type = targetIdx;
		SetLabel(MainForm, MainStatus0, "Reading device signature...");
		SetLabel(MainForm, MainStatus1, "");
		if (
			IspSelectDeviceType(port, ProgType, type) &&
			IspProgModeEnter(port, ProgType) &&
			IspReadSignature(port, ProgType, sig) &&
			IspProgModeLeave(port, ProgType)
		) {
			Char progress[64];
			Char sigStr[7];
			SetLabel(MainForm, MainStatus0, "Success:");
			StrPrintF(progress, "%4x%4x%4x", sig[0], sig[1], sig[2]); // temporarily store the hex values
			sigStr[0] = progress[2]; // now write the hex data into sigStr. this is so unbelievably dirty, but
			sigStr[1] = progress[3]; // i tried to get StrPrintF() output a Char in hexadecimal format with only 2 numbers, without success ;(
			sigStr[2] = progress[6];
			sigStr[3] = progress[7];
			sigStr[4] = progress[10];
			sigStr[5] = progress[11];
			sigStr[6] = 0;
			StrPrintF(progress, "Target device signature: 0x%s", sigStr);
			SetLabel(MainForm, MainStatus1, progress);
		} else {
			SetLabel(MainForm, MainStatus0, "Error:");
			SetLabel(MainForm, MainStatus1, "Signature reading failed.");
		}
		SerialClose(port);
	}
}	

void ImageDelete() {
	// delete currently selected image db
	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList));

	UInt16 item = GetCurrentDatabase();
	
	if (item != noListSelection) {
		if (FrmAlert(AlertConfirmDelete) == 0) {
			Err err;
			if ((err = DmDeleteDatabase(ImagesList[item].card, ImagesList[item].db)) == errNone) {
				LstSetSelection(list, noListSelection);
				ListDatabases();
				SetLabel(MainForm, MainStatus0, "Success:");
				SetLabel(MainForm, MainStatus1, "ROM image database removed.");
			} else {
				SetLabel(MainForm, MainStatus0, "Error:");
				SetLabel(MainForm, MainStatus1, "Could not remove ROM image database.");
			}
		}
	} else FrmAlert(AlertNoDbSel);
}

void ImageDownload() {
	// download image and store as image db
	UInt16 ProgType = GetCurrentProgType();
	UInt16 intf = GetCurrentIntf();

	FormPtr frm = FrmGetFormPtr(MainForm);
	FieldPtr field = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImageDownloadName));
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList));

	UInt16 targetIdx;
	UInt16 mem = GetCurrentMemory();

	UInt16 card = 0;
	UInt32 imageSize;
	UInt32 imageSizeCrop = 0;
	UInt16 recIdx = 0;
	
	Char* dbName = FldGetTextPtr(field);
	Char progress[64];
	UInt32 dbType = 0;
	UInt16 pageSize;
	
	Boolean overwrite = false;

	if (mem == 0)		dbType = typeImageFlash;
	else if (mem == 1)	dbType = typeImageEeprom;

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!GetBaudrate()) { FrmAlert(AlertNoBaudSel); return; }
	if (GetCurrentTarget() == noListSelection) if (!((FrmAlert(AlertNoTargetSel) == 0) && TargetDetect())) return;
	if (!dbType) { FrmAlert(AlertNoMemorySel); return; }

	targetIdx = GetCurrentTarget();
	pageSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].pageSize;

	if (mem == 0) imageSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].flashSize;
	else if (mem == 1) imageSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].eepromSize;
	else imageSize = 0;
	
	if (!imageSize) { FrmAlert(AlertNoSuchROM); return; }

	if (StrLen(dbName) > 0) { // if string is not empty
		Boolean success = false;
		Char* image;
		LocalID dbID;
		DmOpenRef dbRef;
		MemHandle h;
		UInt16 port;
		image = MemPtrNew(imageSize);

		if (dbID = DmFindDatabase(card, dbName)) {
			UInt32 crid;
			UInt32 typeid;
			DmDatabaseInfo(card, dbID, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, &typeid, &crid);
			if ((crid == myCreator) && ((typeid == typeImageFlash) || (typeid == typeImageEeprom))) {
				if (FrmAlert(AlertConfirmOverwrite) == 0) overwrite = true;
				else return; // !> find a better way to cancel operation
			} else {
				FrmAlert(AlertNotOurDB);
				return;
			}
		}

		port = SerialOpen(GetBaudrate(), SerialIntf[intf]);
		if (port) {
			SetLabel(MainForm, MainStatus0, "Download ROM image:");
			SetLabel(MainForm, MainStatus1, "Init...");
			success = (
				IspSelectDeviceType(port, ProgType, targetIdx) &&
				IspProgModeEnter(port, ProgType)
			);
			if (success) {
				UInt32 addr;
				Char hi, lo;
				Char byte;
				UInt32 ticks = TimGetTicks();
				UInt32 lastUpdate = ticks;
				UInt32 timer;
				for (addr = 0; addr < imageSize; addr++) {
					if ((timer = TimGetTicks()) >= (lastUpdate + UPDATE_INTV)) {
						lastUpdate = timer;
						StrPrintF(progress, "A:%lu, I:%lu, T:%lu...", addr, imageSizeCrop, imageSize);
						SetLabel(MainForm, MainStatus1, progress);
					}
					if (mem == 0) { // flash
						if (pageSize) { // page mode
							if (!(addr % pageSize)) { // at page boundary
								UInt16 i;
								success = IspReadProgmemPage(port, ProgType, image + addr, pageSize, addr/pageSize);
								if (!success) break;
							}
						} else {
							if (!(addr & 1)) { // word mode
								success = ( // needed only once per word!
									IspSetAddress(port, ProgType, addr >> 1) &&
									IspReadProgmemWord(port, ProgType, &hi, &lo)
								);
								if (!success) break;
							}
							if (addr & 1) image[addr] = hi; else image[addr] = lo;
						}
						if (image[addr] != (Char) FLASH_INIT) imageSizeCrop = addr+1;
					} else if (mem == 1) { // eeprom
						success = (
							IspSetAddress(port, ProgType, addr) &&
							IspReadDatamem(port, ProgType, &byte)
						);
						if (!success) break;
						imageSizeCrop = addr+1;
						image[addr] = byte;
					}
				}
				if (success) {
					ticks = TimGetTicks() - ticks;
					SetLabel(MainForm, MainStatus1, "Finish...");
					if (success) success = IspProgModeLeave(port, ProgType);
					SetLabel(MainForm, MainStatus0, "Success: Download complete.");
					StrPrintF(progress, "I:%lu, T:%lu, %lu B/s.", imageSizeCrop, imageSize, (UInt32) (imageSize*SysTicksPerSecond()) / ticks);
					SetLabel(MainForm, MainStatus1, progress);
				}
			}
			SerialClose(port);
			if (success) {
				if (overwrite) DmDeleteDatabase(card, DmFindDatabase(card, dbName));
				DmCreateDatabase(card, dbName, myCreator, dbType, false);
				dbRef = DmOpenDatabase(card, DmFindDatabase(card, dbName), dmModeWrite);
				h = DmNewRecord(dbRef, &recIdx, imageSizeCrop+4);
				if (h) {
					Char* recP;
					recP = MemHandleLock(h);
					DmWrite(recP, 0, &imageSizeCrop, sizeof(imageSizeCrop));
					DmWrite(recP, 4, image, imageSizeCrop);
					MemPtrFree(image);
					MemHandleUnlock(h);
					if (DmReleaseRecord(dbRef, recIdx, false) != errNone) FrmAlert(AlertDebugNotImpl);
				}
				DmCloseDatabase(dbRef);
				LstSetSelection(list, 0);
				ListDatabases();
			} else {
				SetLabel(MainForm, MainStatus0, "Error:");
				SetLabel(MainForm, MainStatus1, "Download failed.");
			}
		}
	} else {
		FrmAlert(AlertNoImageName);
	}
}

void ImageProgram() {
	// upload currently selected image to AVR
	UInt16 ProgType = GetCurrentProgType();
	UInt16 intf = GetCurrentIntf();

	UInt16 item = GetCurrentDatabase();
	MemHandle h = NULL;
	Char* data = NULL;
	UInt32 imageSize = 0;
	DmOpenRef dbRef = 0;
	Err errP;
	UInt16 port;
	UInt16 targetIdx;
	UInt16 mem = GetCurrentMemory();
	Char progress[64];
	UInt16 pageSize;
	UInt32 targetSize;
	UInt16 step = 1; // default: byte by byte

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!GetBaudrate()) { FrmAlert(AlertNoBaudSel); return; }
	if (GetCurrentTarget() == noListSelection) if (!((FrmAlert(AlertNoTargetSel) == 0) && TargetDetect())) return;
	if (mem == noListSelection) { FrmAlert(AlertNoMemorySel); return; }
	if (item == noListSelection) { FrmAlert(AlertNoDbSel); return; }

	targetIdx = GetCurrentTarget();
	pageSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].pageSize;

	if (mem == 0) {
		targetSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].flashSize;
		if (pageSize)	step = pageSize;
		else		step = 2; // word by word
	} else if (mem == 1) {
		targetSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].eepromSize;
	} else targetSize = 0;

	if (!targetSize) { FrmAlert(AlertNoSuchROM); return; }
	
	dbRef = DmOpenDatabase(ImagesList[item].card, ImagesList[item].db, dmModeReadOnly);
	if (dbRef) {
		h = DmQueryRecord(dbRef, 0); // get handle to first record
		if (h) {
			data = MemHandleLock(h);
			if (data) {
				Boolean success = false;
				imageSize = *((UInt32*)data);

				if (imageSize <= targetSize) {
					if (FrmAlert(AlertConfirmUpload) == 0) {
						port = SerialOpen(GetBaudrate(), SerialIntf[intf]);
						if (port) {
							SetLabel(MainForm, MainStatus0, "Upload ROM image:");
							SetLabel(MainForm, MainStatus1, "Init...");
							success = (
								IspSelectDeviceType(port, ProgType, targetIdx) &&
								IspProgModeEnter(port, ProgType)
							);
							if (success && (mem == 0)) success = (
								IspChipErase(port, ProgType) &&
								IspProgModeLeave(port, ProgType) &&
								IspProgModeEnter(port, ProgType)
							);
							if (success) {
								UInt32 addr;
								UInt32 ticks = TimGetTicks();
								UInt32 lastUpdate = 0;
								UInt32 timer;
								for (addr = 0; addr < imageSize; addr += step) {
									if ((timer = TimGetTicks()) >= (lastUpdate + UPDATE_INTV)) {
										lastUpdate = timer;
										StrPrintF(progress, "A:%lu, I:%lu...", addr, imageSize);
										SetLabel(MainForm, MainStatus1, progress);
									}
									if (mem == 0) { // flash
										if (step > 2) {
											success = IspWriteProgmemPage(port, ProgType, data+4, imageSize, step, addr/step);
										} else {
											success = (
												IspSetAddress(port, ProgType, addr >> 1) &&
												IspWriteProgmemWord(port, ProgType, data[addr+5], data[addr+4])
											);
										}
									} else if (mem == 1) { // eeprom
										success = (
											IspSetAddress(port, ProgType, addr) &&
											IspWriteDatamem(port, ProgType, data[addr+4])
										);
									}
									if (!success) break;
								}
								ticks = TimGetTicks() - ticks;
								SetLabel(MainForm, MainStatus1, "Finish...");
								if (success && IspProgModeLeave(port, ProgType)) {
									// upload completed successfully
									SetLabel(MainForm, MainStatus0, "Success: Upload complete.");
									StrPrintF(progress, "I:%lu, %lu B/s.", imageSize, (UInt32) (imageSize*SysTicksPerSecond()) / ticks);
									SetLabel(MainForm, MainStatus1, progress);
								}
							}
							if (!success) {
								SetLabel(MainForm, MainStatus0, "Error:");
								SetLabel(MainForm, MainStatus1, "Upload failed.");
							}
							MemHandleUnlock(h);
							SerialClose(port);
						}
					}
				} else {
					FrmAlert(AlertImageTooLarge);
				}
			}
		} else {
			FrmAlert(AlertNoRecord);
		}
		DmCloseDatabase(dbRef);
	}
}

void ImageVerify() {
	// verify currently selected image with the one in the AVR
	UInt16 ProgType = GetCurrentProgType();
	UInt16 intf = GetCurrentIntf();

	UInt16 item = GetCurrentDatabase();
	MemHandle h = NULL;
	Char* data = NULL;
	UInt32 imageSize = 0;
	DmOpenRef dbRef = 0;
	Err errP;
	UInt16 targetIdx;
	UInt16 mem = GetCurrentMemory();
	UInt32 targetSize;
	Char progress[64];
	UInt16 pageSize;

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!GetBaudrate()) { FrmAlert(AlertNoBaudSel); return; }
	if (GetCurrentTarget() == noListSelection) if (!((FrmAlert(AlertNoTargetSel) == 0) && TargetDetect())) return;
	if (mem == noListSelection) { FrmAlert(AlertNoMemorySel); return; }
	if (item == noListSelection) { FrmAlert(AlertNoDbSel); return; }

	targetIdx = GetCurrentTarget();
	pageSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].pageSize;

	if (mem == 0) targetSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].flashSize;
	else if (mem == 1) targetSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].eepromSize;
	else targetSize = 0;

	if (!targetSize) { FrmAlert(AlertNoSuchROM); return; }

	dbRef = DmOpenDatabase(ImagesList[item].card, ImagesList[item].db, dmModeReadOnly);
	if (dbRef) {
		h = DmQueryRecord(dbRef, 0); // get handle to first record
		if (h) {
			data = MemHandleLock(h);
			if (data) {
				Boolean success = false;
				UInt16 port;
				imageSize = *((UInt32*)data);
				if (imageSize <= targetSize) {
					port = SerialOpen(GetBaudrate(), SerialIntf[intf]);
					if (port) {
						SetLabel(MainForm, MainStatus0, "Verify ROM image:");
						SetLabel(MainForm, MainStatus1, "Init...");
						success = (
							IspSelectDeviceType(port, ProgType, targetIdx) &&
							IspProgModeEnter(port, ProgType)
						);
						if (success) {
							UInt32 addr;
							Char hi, lo;
							Char byte;
							Boolean equal = true;
							UInt32 ticks = TimGetTicks();
							UInt32 lastUpdate = ticks;
							UInt32 timer;
							UInt32 verifySize = targetSize;
							UInt32 equalSize = 0;
							Char pageData[pageSize];
							for (addr = 0; addr < verifySize; addr++) {
								if ((timer = TimGetTicks()) >= (lastUpdate + UPDATE_INTV)) {
									lastUpdate = timer;
									StrPrintF(progress, "A:%lu, I:%lu, T:%lu...", addr, imageSize, targetSize);
									SetLabel(MainForm, MainStatus1, progress);
								}
								if (mem == 0) { // flash
									if (pageSize) { // page mode
										if (!(addr % pageSize)) { // at page boundary
											success = IspReadProgmemPage(port, ProgType, pageData, pageSize, addr/pageSize);
											if (!success) break;
										}
										byte = pageData[addr % pageSize];
									} else {
										if (!(addr & 1)) { // word mode
											success = ( // needed only once per word!
												IspSetAddress(port, ProgType, addr >> 1) &&
												IspReadProgmemWord(port, ProgType, &hi, &lo)
											);
											if (!success) break;
										}
										if (addr & 1) byte = hi; else byte = lo;
									}
								} else if (mem == 1) { // eeprom
									success = (
										IspSetAddress(port, ProgType, addr) &&
										IspReadDatamem(port, ProgType, &byte)
									);
									if (!success) break;
								}
								if (addr < imageSize) { // within image data, compare with data
									if (byte != data[addr+4]) {
										equal = false;
										equalSize = addr;
										break;
									}
								} else { // out of image data, compare with flash rom init value 0xff
									if (byte != FLASH_INIT) {
										equal = false;
										equalSize = addr;
										break;
									}
								}
							}
							ticks = TimGetTicks() - ticks;
							SetLabel(MainForm, MainStatus1, "Finish...");
							if (success) success = IspProgModeLeave(port, ProgType);
	
							if (equal) {
								SetLabel(MainForm, MainStatus0, "Success: Full verify complete.");
								StrPrintF(progress, "T:%lu, %lu B/s.", targetSize, (UInt32) (targetSize*SysTicksPerSecond()) / ticks);
							} else if (equalSize < imageSize) {
								SetLabel(MainForm, MainStatus0, "Failed: Images not identical.");
								StrPrintF(progress, "Difference at A:%lu.", equalSize);
							} else {
								SetLabel(MainForm, MainStatus0, "Success: Partial verify complete.");
								StrPrintF(progress, "I:%lu, %lu B/s.", imageSize, (UInt32) (equalSize*SysTicksPerSecond()) / ticks);
							}
							SetLabel(MainForm, MainStatus1, progress);
						}
						if (!success) {
							SetLabel(MainForm, MainStatus0, "Error:");
							SetLabel(MainForm, MainStatus1, "Verify failed.");
						}
						MemHandleUnlock(h);
						SerialClose(port);
					}
				} else {
					FrmAlert(AlertImageTooLarge);
				}
			}
		} else {
			FrmAlert(AlertNoRecord);
		}
		DmCloseDatabase(dbRef);
	}
}

void ImageIdentify() {
	// download image and compare it against all available images
	UInt16 ProgType = GetCurrentProgType();
	UInt16 intf = GetCurrentIntf();

	FormPtr frm = FrmGetFormPtr(MainForm);
	ListPtr list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList));

	UInt16 targetIdx;
	UInt16 mem = GetCurrentMemory();

	UInt16 card = 0;
	UInt32 targetSize;
	UInt32 targetSizeCrop = 0;
	UInt16 recIdx = 0;
	UInt16 pageSize;
	
	Char progress[64];
	UInt32 dbType = 0;
	
	if (mem == 0)		dbType = typeImageFlash;
	else if (mem == 1)	dbType = typeImageEeprom;

	if (ProgType == noListSelection) { FrmAlert(AlertNoProgTypeSel); return; }
	if (intf == noListSelection) { FrmAlert(AlertNoProgIntfSel); return; }
	if (!GetBaudrate()) { FrmAlert(AlertNoBaudSel); return; }
	if (GetCurrentTarget() == noListSelection) if (!((FrmAlert(AlertNoTargetSel) == 0) && TargetDetect())) return;
	if (!dbType) { FrmAlert(AlertNoMemorySel); return; }

	targetIdx = GetCurrentTarget();
	pageSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].pageSize;

	if (mem == 0) targetSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].flashSize;
	else if (mem == 1) targetSize = TargetsTable[SupportedTargets[ProgType][targetIdx]].eepromSize;
	else targetSize = 0;
	
	if (!targetSize) { FrmAlert(AlertNoSuchROM); return; }

	if (NumImages) {
		Boolean success = false;
		Char* image;
		LocalID dbID;
		DmOpenRef dbRef;
		MemHandle h;
		UInt16 port;
		image = MemPtrNew(targetSize);

		port = SerialOpen(GetBaudrate(), SerialIntf[intf]);
		if (port) {
			SetLabel(MainForm, MainStatus0, "Identify ROM image:");
			SetLabel(MainForm, MainStatus1, "Init...");
			success = (
				IspSelectDeviceType(port, ProgType, targetIdx) &&
				IspProgModeEnter(port, ProgType)
			);
			if (success) {
				UInt32 addr;
				Char hi, lo;
				Char byte;
				UInt32 lastUpdate = TimGetTicks();
				UInt32 timer;
				
				for (addr = 0; addr < targetSize; addr++) {
					if ((timer = TimGetTicks()) >= (lastUpdate + UPDATE_INTV)) {
						lastUpdate = timer;
						StrPrintF(progress, "A:%lu, I:%lu, T:%lu...", addr, targetSizeCrop, targetSize);
						SetLabel(MainForm, MainStatus1, progress);
					}
					if (mem == 0) { // flash
						if (pageSize) { // page mode
							if (!(addr % pageSize)) { // at page boundary
								UInt16 i;
								success = IspReadProgmemPage(port, ProgType, image + addr, pageSize, addr/pageSize);
								if (!success) break;
							}
						} else {
							if (!(addr & 1)) { // word mode
								success = ( // needed only once per word!
									IspSetAddress(port, ProgType, addr >> 1) &&
									IspReadProgmemWord(port, ProgType, &hi, &lo)
								);
								if (!success) break;
							}
							if (addr & 1) image[addr] = hi; else image[addr] = lo;
						}
						if (image[addr] != FLASH_INIT) targetSizeCrop = addr+1;
					} else if (mem == 1) { // eeprom
						success = (
							IspSetAddress(port, ProgType, addr) &&
							IspReadDatamem(port, ProgType, &byte)
						);
						if (!success) break;
						targetSizeCrop = addr+1;
						image[addr] = byte;
					}
				}
			}
			if (success) success = IspProgModeLeave(port, ProgType);
			SerialClose(port);
			if (success) {
				UInt16 idx;
				Boolean equal;
				Boolean full = true; // indicates if verify is in full or partial mode
				for (idx = 0; idx < NumImages; idx++) {
					equal = true;
					StrPrintF(progress, "Compare: (full) %u of %u...", idx+1, NumImages);
					SetLabel(MainForm, MainStatus1, progress);
					dbRef = DmOpenDatabase(ImagesList[idx].card, ImagesList[idx].db, dmModeReadOnly);
					if (dbRef) {
						h = DmQueryRecord(dbRef, 0); // get handle to first record
						if (h) {
							Char* data = MemHandleLock(h);
							if (data) {
								UInt32 imageSize = *((UInt32*)data);
								if ((imageSize <= targetSize) && (imageSize >= targetSizeCrop)) { // DB data is at least cropped size, but not more than segment size
									UInt32 addr;
									Char byte;
									for (addr = 0; addr < targetSize; addr++) {
										if (addr < imageSize)	byte = data[addr+4];
										else			byte = FLASH_INIT;
										if (image[addr] != byte) { // bytes differ
											equal = false;
											break;
										}
									}
								} else equal = false;
								MemHandleUnlock(h);
							}
						}
						DmCloseDatabase(dbRef);
					}
					if (equal) break;
				}
				if (!equal) {
					full = false;
					for (idx = 0; idx < NumImages; idx++) {
						equal = true;
						StrPrintF(progress, "Compare: (partial) %u of %u...", idx+1, NumImages);
						SetLabel(MainForm, MainStatus1, progress);
						dbRef = DmOpenDatabase(ImagesList[idx].card, ImagesList[idx].db, dmModeReadOnly);
						if (dbRef) {
							h = DmQueryRecord(dbRef, 0); // get handle to first record
							if (h) {
								Char* data = MemHandleLock(h);
								if (data) {
									UInt32 imageSize = *((UInt32*)data);
									if (imageSize < targetSizeCrop) { // DB data is smaller than cropped size
										UInt32 addr;
										for (addr = 0; addr < imageSize; addr++) {
											if (data[addr+4] != image[addr]) { // bytes differ
												equal = false;
												break;
											}
										}
									} else equal = false;
									MemHandleUnlock(h);
								}
							}
							DmCloseDatabase(dbRef);
						}
						if (equal) break;
					}
				}
				if (equal) {
					if (full) 	SetLabel(MainForm, MainStatus0, "Success: Full identify complete.");
					else		SetLabel(MainForm, MainStatus0, "Success: Partial identify complete.");
					SetLabel(MainForm, MainStatus1, "ROM image database selected.");
					LstSetSelection(list, idx);
					ListDatabasesSetTrigger();
				} else {
					SetLabel(MainForm, MainStatus0, "Failed:");
					SetLabel(MainForm, MainStatus1, "Target image not identified.");
					LstSetSelection(list, noListSelection);
					ListDatabasesSetTrigger();
				}
			} else {
				SetLabel(MainForm, MainStatus0, "Error:");
				SetLabel(MainForm, MainStatus1, "Identify failed.");
			}
		}
	} else {
		FrmAlert(AlertNoImage);
	}
}

static Boolean MainFormHandleEvent(EventPtr event) {
	Boolean handled = false;
   	Err err;
	FormPtr frm;
	Int16 PrefsVer;
	struct prefs PrefsData;
	UInt16 PrefsSize;
	MemHandle oldH, imageNameH;
	MemPtr imageNameP;
	FieldPtr imageNameFldP;
	
	switch (event->eType) {
		case frmOpenEvent:
			FrmDrawForm(FrmGetActiveForm());

			WinDrawLine(XLINEINDENT, YBLOCK2-YLINEOFFSET, 159-XLINEINDENT, YBLOCK2-YLINEOFFSET);
			WinDrawLine(XLINEINDENT, YBLOCK3-YLINEOFFSET, 159-XLINEINDENT, YBLOCK3-YLINEOFFSET);
			WinDrawLine(XLINEINDENT, YBLOCK1-YLINEOFFSET, 159-XLINEINDENT, YBLOCK1-YLINEOFFSET);
			WinDrawLine(XLINEINDENT, YBLOCK5-YLINEOFFSET, 159-XLINEINDENT, YBLOCK5-YLINEOFFSET);
			
			frm = FrmGetFormPtr(MainForm);

			// try to retrieve app prefs
			// check size of the saved prefs struct
			PrefsSize = 0;
	    		PrefsVer = PrefGetAppPreferences(myCreator, PrefsID, NULL, &PrefsSize, false);
			if ((PrefsSize == sizeof(PrefsData)) && (PrefsVer == myPrefsVer)) {
				// same version, use existing prefs data
		    		PrefGetAppPreferences(myCreator, PrefsID, &PrefsData, &PrefsSize, false);
				SetLabel(MainForm, MainStatus1, "Preferences restored.");
			} else {
				PrefsData.progType = noListSelection;
				PrefsData.progIntf = noListSelection;
				PrefsData.progBaud = noListSelection;
				PrefsData.segment = noListSelection;
				SetLabel(MainForm, MainStatus1, "Preferences initialised.");
			}

			LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgType)), PrefsData.progType);
			LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgIntf)), PrefsData.progIntf);
			LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgBaud)), PrefsData.progBaud);
			LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainMemoryList)), PrefsData.segment);
			LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsList)), noListSelection);
			LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList)), noListSelection);

			SetListTriggerName(MainProgType, MainProgTypeTrigger);
			SetListTriggerName(MainProgIntf, MainProgIntfTrigger);
			SetListTriggerName(MainProgBaud, MainProgBaudTrigger);
			SetListTriggerName(MainMemoryList, MainMemoryTrigger);
			
			ListTargets();
			ListDatabases();

			imageNameH = MemHandleNew(33); // 32 chars for DB name + termination
			imageNameP = MemHandleLock(imageNameH);
			((Char*) imageNameP)[0] = 0; // empty string
			MemHandleUnlock(imageNameH);

			imageNameFldP = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImageDownloadName));
			oldH = FldGetTextHandle(imageNameFldP);
			FldSetTextHandle(imageNameFldP, imageNameH);
			FldDrawField(imageNameFldP);
			if (oldH != NULL) MemHandleFree(oldH);
			
			handled = true;
			break;
	
		case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID) {
				case MainImageDelete:
					ImageDelete();
					handled = true;
					break;
					
				case MainImageVerify:
					ImageVerify();
					handled = true;
					break;
					
				case MainImageDownload:
					ImageDownload();
					handled = true;
					break;
					
				case MainImageProgram:
					ImageProgram();
					handled = true;
					break;
					
				case MainImageIdentify:
					ImageIdentify();
					handled = true;
					break;
					
				case MainDetect:
					ProgrammerDetect();
					handled = true;
					break;
					
				case MainTargetDetect:
					TargetDetect();
					handled = true;
					break;
					
				default:
					break;
			}

		case popSelectEvent:
			switch (event->data.popSelect.listID) {
				case MainMemoryList:
					frm = FrmGetFormPtr(MainForm);
					LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainImagesList)), noListSelection);
					ListDatabases();
					break;
				case MainProgType:
					frm = FrmGetFormPtr(MainForm);
					LstSetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainTargetsList)), noListSelection);
					ListTargets();
					SetProgInfo();
					break;
				default:
					break;
			}

			switch (event->data.popSelect.controlID) {
				case MainImagesTrigger:
					ListDatabasesSetTrigger(); // !> only redraw trigger label, make special function
					break;

				case MainTargetsTrigger:
					ListTargetsSetTrigger(); // !> only redraw trigger label, make special function
					break;

				default:
					break;
			}
			break;

		default:
			break;
    }

    return handled;
}

static Boolean AppHandleEvent(EventPtr event) {
	FormPtr frm;
	Int formId;
	Boolean handled = false;
	
	if (event->eType == frmLoadEvent) {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		switch (formId) {
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
	} else if (event->eType == menuEvent) {
		MenuEraseStatus(NULL);
		switch (event->data.menu.itemID) {
			case MenuAbout:
				FrmAlert(AboutAlert);
				handled = true;
				break;
			    
			case MenuChipErase:
				ProgramChipErase();
				handled = true;
				break;
			    
			case MenuDownload:
				ImageDownload();
				handled = true;
				break;
			    
			case MenuUpload:
				ImageProgram();
				handled = true;
				break;
			    
			case MenuDelete:
				ImageDelete();
				handled = true;
				break;
			    
			case MenuVerify:
				ImageVerify();
				handled = true;
				break;
			    
			case MenuIdentify:
				ImageIdentify();
				handled = true;
				break;
			    
			case MenuDetectProgrammer:
				ProgrammerDetect();
				handled = true;
				break;
			    
			case MenuDetectTarget:
				TargetDetect();
				handled = true;
				break;
			    
			case MenuSignature:
				ProgramReadSignature();
				handled = true;
				break;
			    
			default:
				break;
		}
	}
	
	return handled;
}

static Err AppStart() {
	Err retcode = 0;
	UInt16 idx;

	NumSupportedTargets[PROG_AVR910] = 0; // must be loaded from programmer first
	NumSupportedTargets[PROG_STK500] = 0; // build now:
	for (idx = 1; idx < countof(TargetsTable); idx++) {
		if (NumSupportedTargets[PROG_STK500] < countof(SupportedTargets[PROG_STK500])) {
			SupportedTargets[PROG_STK500][NumSupportedTargets[PROG_STK500]] = idx;
			NumSupportedTargets[PROG_STK500]++;
		}
	}
	NumSupportedTargets[PROG_AVRISP] = 0; // build now:
	for (idx = 1; idx < countof(TargetsTable); idx++) {
		if (NumSupportedTargets[PROG_AVRISP] < countof(SupportedTargets[PROG_AVRISP])) {
			SupportedTargets[PROG_AVRISP][NumSupportedTargets[PROG_AVRISP]] = idx;
			NumSupportedTargets[PROG_AVRISP]++;
		}
	}
	for (idx = 0; idx < countof(ProgInfoString); idx++) {
		ProgInfoString[idx][0] = 0; // terminate string
	}

	FrmGotoForm(MainForm);
	
	return retcode;
}

static void AppEventLoop(void) {
	EventType event;
	Err error;

	do {
		EvtGetEvent(&event, 100);

		if (SysHandleEvent(&event)) continue;
			
		if (MenuHandleEvent((void *)0, &event, &error)) continue;

		if (AppHandleEvent(&event)) continue;

		FrmDispatchEvent(&event);
	} while (event.eType != appStopEvent);
}

static Err AppStop() {
	Err retcode = errNone;

	struct prefs PrefsData;
	FormPtr frm = FrmGetFormPtr(MainForm);
	
	PrefsData.progType = LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgType)));
	PrefsData.progIntf = LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgIntf)));
	PrefsData.progBaud = LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainProgBaud)));
	PrefsData.segment = LstGetSelection(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainMemoryList)));

	PrefSetAppPreferences(myCreator, PrefsID, myPrefsVer, &PrefsData, sizeof(PrefsData), false);
	
	FrmCloseAllForms();

	return retcode;
}

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags) {
	UInt32 rom;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &rom); // check OS rev.
	if (rom < ROM_VERSION_REQUIRED) {
		FrmAlert(RomIncompatibleAlert);
		return(sysErrRomIncompatible);
	}

	if (cmd == sysAppLaunchCmdNormalLaunch) {
		Err retcode;

		if ((retcode = AppStart()) != 0) {
			ErrAlert(retcode);
			return(retcode);
		}
		AppEventLoop();
		if ((retcode = AppStop()) != 0) {
			ErrAlert(retcode);
			return(retcode);
		}
	}

	return 0;
}

// EOF
