/*
* PalmAVR - AVR In-System-Programming solution for Palm OS.
* Copyright (C) 2004  Mark Haemmerling <palmavr@emcad.de>
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define YBLOCK1				(47)
#define YBLOCK2				(74)
#define YBLOCK3				(YBLOCK2+31)
#define YBLOCK4				(19)
#define YBLOCK5				(136)

#define XLINEINDENT			(0)
#define YLINEOFFSET			(2)

// list indexes of programmer type list entries
#define PROG_AVR910			0
#define PROG_STK500			1
#define PROG_AVRISP			2

#define MAX_HEIGHT_IMAGES		8
#define MAX_HEIGHT_TARGETS		14

#define MainForm			1000
#define	MainMenu			1001

#define MenuAbout			1100
#define MenuUpload			1101
#define MenuDownload			1102
#define MenuVerify			1103
#define MenuDelete			1104
#define MenuChipErase			1105
#define MenuDetectProgrammer		1106
#define MenuSignature			1107
#define MenuDetectTarget		1108
#define MenuIdentify			1109

#define MainImagesList			2003
#define	MainImageProgram		2004
#define	MainImageVerify			2005
#define	MainImageDownload		2006
#define	MainImageDelete			2007
#define MainImageDownloadName		2008
#define	MainProgBaudTrigger		2009
#define	MainProgBaud			2010
#define MainDetect			2011
#define MainImagesTrigger		2012
#define MainProgInfo			2013
#define MainTargetsTrigger		2014
#define MainTargetsList			2015
#define MainMemoryTrigger		2016
#define MainMemoryList			2017
#define MainTargetDetect		2018
#define MainImageIdentify		2019
#define MainProgTypeTrigger		2020
#define MainProgType			2021
#define MainProgIntfTrigger		2022
#define MainProgIntf			2023
#define MainStatus0			2024
#define MainStatus1			2025
#define MainStatus2			2026

#define AlertNoTargetSel		3100
#define AlertNoDbSel			3101
#define AlertNoBaudSel			3102
#define AlertNoRecord			3103
#define AlertNoImageName		3104
#define AlertNoMemorySel		3105
#define	AlertNoSuchROM			3106
#define AlertImageTooLarge		3107
#define AlertSerTimeout			3108
#define AlertSerOpen			3109
#define AlertSerUnexpected		3110
#define AlertNotOurDB			3111
#define AlertNoAVR			3112
#define AlertNoImage			3113
#define AlertNoProgTypeSel		3114
#define AlertISPNotSupported		3115
#define AlertSyncErr			3116
#define AlertMaxSyncTries		3117
#define AlertNoProgIntfSel		3118
#define AlertSerUnknown			3119
#define AlertSerLineErr			3120

#define AlertConfirmDelete		3200
#define AlertConfirmUpload		3201
#define AlertConfirmChipErase		3202
#define AlertConfirmOverwrite		3203

#define AlertDebugSuccess		3900
#define AlertDebugNotImpl		3901

#define	AboutAlert			3000
#define	RomIncompatibleAlert		3001
#define	ErrorAlert			3002
