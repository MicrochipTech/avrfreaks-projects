#include <avr/io.h>
#include "twi_i2c.h"
#define TWI_FREQ_KHZ 100ul       // 100 kHz
//for 4MHz crystal
#define TWI_PRESCALER_VALUE 1
#define TWI_PRESCALER    ((0<<TWPS1)|(0<<TWPS0))
//TWBR=(F_CPU/TWI_FREQ_HZ-16)/(2*TWI_PRESCALER_VALUE)
#define TWI_TWBR (F_CPU/1000l/TWI_FREQ_KHZ-16)/(2*TWI_PRESCALER_VALUE)
#if ((TWI_TWBR > 255)||(TWI_TWBR<10))
#error "Make TWI_PRESCALER_VALUE larger/smaller!"
#endif




void TWI_Init(void)
{
// Initialize TWI clock
TWSR = TWI_PRESCALER;
TWBR = TWI_TWBR;
// Load data register with default content; release SDA
TWDR = 0xff;
// Enable TWI peripheral with interrupt disabled
TWCR = (0<<TWINT)|(0<<TWEA)|(0<<TWSTA)|(0<<TWSTO)|(0<<TWWC)|(1<<TWEN)|(0<<TWIE);
}
void TWI_SendByte(uint8_t TWIAddress, uint8_t TWIData)
{
	TWI_Start();
	TWDR=TWIAddress;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while (!(TWCR&(1<<TWINT)));//wait for TWINT flag set
	if ((TWSR&0xF8)!=TW_MT_SLA_ACK)
		{
		//error; debug if needed
		}
	TWDR=TWIData;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while (!(TWCR&(1<<TWINT)));//wait for TWINT flag set
	if ((TWSR&0xF8)!=TW_MT_DATA_ACK)
		{
		//error; debug if needed
		}
	TWI_Stop();
}
uint8_t TWI_ReceiveByte(uint8_t TWIAddress)
{
	return 0;
}
void TWI_Start(void)
{
	TWCR=(1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while (!(TWCR&(1<<TWINT)));//wait for TWINT flag set
	if ((TWSR&0xF8)!=TW_START)
		{
		//error; debug if needed
		}
	
}
void TWI_Stop(void)
{
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
}
