#ifndef TWI_i2c_H
#define TWI_i2c_H
#include <compat/twi.h>


void TWI_Init(void);
void TWI_SendByte(uint8_t TWIAddress, uint8_t TWIData);
uint8_t TWI_ReceiveByte(uint8_t TWIAddress);
void TWI_Start(void);
void TWI_Stop(void); 

#endif
