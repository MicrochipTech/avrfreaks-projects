/*****************************************************
Project : TDA7313
Version : v1.0
Date    : 2007.08.08
Author  : www.scienceprog.com
Comments: Atmega8 program that controls TDA7313 audio processor
Chip type           : ATmega8
Program type        : Application
Clock frequency     : 4,000000 MHz
This code is distributed under the GNU Public License
which can be found at http://www.gnu.org/licenses/gpl.txt
*****************************************************/

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>

#include "lcd_lib.h"
#include "twi_i2c.h"
#define TDA7313_addr 0x88
#define C_PORT PORTC
#define C_PIN PINC
#define DC_PORT DDRC
#define M_PORT PORTB
#define M_PIN PINB
#define DM_PORT DDRB
#define VPP 0//PORTA
#define VMM 1//PORTA
#define UP  2//PORTA
#define DOWN 3//PORTA
#define MUTE 0//PORTB
//EEPROM locations for restoring state
#define E_VOLUME 0
#define E_LF 1
#define E_RF 2
#define E_LR 3
#define E_RR 4
#define E_ch 5
#define E_BASS 6
#define E_TREBLE 7
#define E_INIT 8
//intervals of parameters
#define MinVolume 	0x3F//-78,75dB
#define MaxVolume 	0x00//0dB
#define StepVolume 	0x01//1.25dB

#define MinLF 	0x9F//-38.75dB
#define MaxLF 	0x80//0dB
#define StepLF 	0x01//1.25dB

#define MinRF 	0xBF//MUTE
#define MaxRF 	0xA0//0dB
#define StepRF 	0x01//1.25dB

#define MinLR 	0xDF//MUTE
#define MaxLR 	0xC0//0dB
#define StepLR 	0x01//1.25dB

#define MinRR 	0xFF//MUTE
#define MaxRR 	0xE0//0dB
#define StepRR 	0x01//1.25dB

#define MinBASS 	0x60//-14dB
#define MaxBASS 	0x68//14dB
#define BASS1 		0x67//0dB
#define BASS2		0x6F//0dB
#define BASS3		0x68//14dB
#define StepBASS 	0x01//2dB

#define MinTreble 	0x70//-14dB
#define MaxTreble 	0x78//14dB
#define TREBLE1 	0x77//0dB
#define TREBLE2		0x7F//0dB
#define TREBLE3		0x78//0dB
#define StepTreble	0x01//2dB

#define MinCh 	0x00//ch1
#define MaxCh 	0x02//ch3 (ch4 not included as it is internal)
#define StepCh 	0x01//
#define Laudness 2// bit 2 must be OR'ed
#define MinchG  0x18// must be OR'ed
#define MaxchG  0x00// must be OR'ed
#define StepchG 0x08//0b1000

#define MN_No 9// number of menu items

//Menu Strings in flash
const uint8_t MN000[] PROGMEM="     Volume     \0";
//menu 1
const uint8_t MN100[] PROGMEM="      BASS      \0";
//menu 2
const uint8_t MN200[] PROGMEM="     Treble     \0";
//menu 3
const uint8_t MN300[] PROGMEM="  Audio Switch  \0";
//menu 4
const uint8_t MN400[] PROGMEM="   Input gain   \0";
//menu 5
const uint8_t MN500[] PROGMEM="   Speaker LF   \0";
//menu 6
const uint8_t MN600[] PROGMEM="   Speaker RF   \0";
//menu 7
const uint8_t MN700[] PROGMEM="   Speaker LR   \0";
//menu 8
const uint8_t MN800[] PROGMEM="   Speaker RR   \0";

//Strings
const uint8_t MN101[] PROGMEM="MT\0";	//indicates Mute
const uint8_t MN102[] PROGMEM="LD\0";	//indicates Laudness
const uint8_t MN301[] PROGMEM="    Input1    \0";	//Indicates channel1
const uint8_t MN302[] PROGMEM="    Input2    \0";	//Indicates channel2
const uint8_t MN303[] PROGMEM="    Input3    \0";	//Indicates channel3
const uint8_t MNClr2Ch[] PROGMEM="  \0";//Clear Line
const uint8_t TOEEPROM[] PROGMEM="Saving Settings\0";//Clear Line
//Arrays of pointers to menu strings stored in flash
const uint8_t *MENU[] ={
		MN000,	//
		MN100,	//menu 1 string
		MN200,	//menu 2 string
		MN300,	//menu 3 string
		MN400,	//menu 4 string
		MN500,	
		MN600,
		MN700,
		MN800
		};
//channels
const uint8_t *CHANNELS[] ={
		MN301,
		MN302,
		MN303
};
const uint8_t Intervals[] PROGMEM=
{
	MinVolume, MaxVolume, StepVolume,	//
	MinBASS, MaxBASS, StepBASS,			//
	MinTreble, MaxTreble, StepTreble,	//
	MinCh, MaxCh, StepCh,				//
	MinchG, MaxchG, StepchG,			//
	MinLF, MaxLF, StepLF,				//
	MinRF, MaxRF, StepRF,				//	
	MinLR, MaxLR, StepLR,				//
	MinRR, MaxRR, StepRR				//
};




//variables to control TDA7313
struct state{
	uint8_t value[9];//array holds all current values
	uint8_t LD;		//1 if laudness ON; 0 - if Off
	uint8_t MT;		//1 if Mute ON; 0 if OFF
	uint8_t menu_No;
}ST;
uint16_t Flag=0;
void Timer0_init(void)
{
	TCNT0=0x00;
	TCCR0|=(1<<CS02); //prescaller 256 ~122 interrupts/s
	TIMSK|=(1<<TOV0);//Enable Timer0 Overflow interrupts
	sei();
} 
//Initial menu


void Menu_Init(void)
{
 	ST.menu_No=0;
	LCDclr();
	CopyStringtoLCD(MENU[(ST.menu_No)], 0, 0 );
	//CopyStringtoLCD(MNpm, 0, 1 );
	LCDGotoXY(0, 1);
	//LCDprogressBar(((MinVolume-MaxVolume)-ST.volume), MinVolume-MaxVolume, 14);
	LCDsendChar(6);
	LCDprogressBar(((uint8_t)MinVolume-ST.value[0]), MinVolume, 14);
	LCDsendChar(7);
	//send defauls parameters to TDA1313 from eeprom
	//send ST.value[0..8], except [4]
	TWI_SendByte(TDA7313_addr, ST.value[0]);
	TWI_SendByte(TDA7313_addr, ST.value[1]);
	TWI_SendByte(TDA7313_addr, ST.value[2]);
	TWI_SendByte(TDA7313_addr, ST.value[3]);
	TWI_SendByte(TDA7313_addr, ST.value[5]);
	TWI_SendByte(TDA7313_addr, ST.value[6]);
	TWI_SendByte(TDA7313_addr, ST.value[7]);
	TWI_SendByte(TDA7313_addr, ST.value[8]);
}


ISR(TIMER0_OVF_vect)
{
	uint8_t Min, Max, Step;//define interval values
	//set parameter intervals
	Min=pgm_read_byte(&Intervals[ST.menu_No*3+0]);
	Max=pgm_read_byte(&Intervals[ST.menu_No*3+1]);
	Step=pgm_read_byte(&Intervals[ST.menu_No*3+2]);
	//if button UP pressed
	if ((bit_is_clear(C_PIN, UP))&&(ST.MT==0))
	{
		if (ST.menu_No<(MN_No-1))
		{ 
			ST.menu_No++;
		}
		else
		{
			ST.menu_No=0;
		}
		//Display menu item
		CopyStringtoLCD(MENU[ST.menu_No], 0, 0 );
		LCDGotoXY(0, 1);
		LCDsendChar(6);
		if(ST.menu_No==0)//volume
			{
			if(ST.MT==1)
				{
					//show MT
					CopyStringtoLCD(MN101, 1, 0 );
				}
				else
					{
						//clear MT
						CopyStringtoLCD(MNClr2Ch, 1, 0 );
					}
			if(ST.LD==1)
				{
					//show LD
					CopyStringtoLCD(MN102, 13, 0 );
				}
				else
					{
						//clear LD
						CopyStringtoLCD(MNClr2Ch, 13, 0 );
					}
				LCDGotoXY(1, 1);	
				LCDprogressBar((MinVolume-ST.value[ST.menu_No]), MinVolume, 14);
			}
			else if (ST.menu_No==1)//bass
				{
					if(ST.value[ST.menu_No]<=BASS1)
						{
							LCDprogressBar((ST.value[ST.menu_No]&0x0F), (BASS2&0x0F), 14);
						}
						else
							{
								LCDprogressBar(((BASS2-ST.value[ST.menu_No]+BASS3)&0x0F), (BASS2&0x0F), 14);
							}
				}
				else if (ST.menu_No==2)//treble
					{
						if(ST.value[ST.menu_No]<=TREBLE1)
							{
								LCDprogressBar((ST.value[ST.menu_No]&0x0F), (TREBLE2&0x0F), 14);
							}
							else
								{
									LCDprogressBar(((TREBLE2-ST.value[ST.menu_No]+TREBLE3)&0x0F), (TREBLE2&0x0F), 14);
								}
					}
					else if (ST.menu_No==3)//if channel select
						{
							CopyStringtoLCD(CHANNELS[(ST.value[ST.menu_No]&0b00000011)], 1, 1 );
						}
						else if (ST.menu_No==4)//channel gain
							{
								LCDprogressBar((MinchG-ST.value[ST.menu_No]), MinchG, 14);
							}
							else
								{
									LCDprogressBar(((((ST.value[ST.menu_No]&0xE0)|(MinLF&0x1F))-ST.value[ST.menu_No])&0x1F), (((ST.value[ST.menu_No]&0xE0)|(MinLF&0x1F))&0x1F), 14);
								}
								
		LCDsendChar(7);		
		//wait for button release
		loop_until_bit_is_set(C_PIN, UP);
	}
	
		//if button UP pressed
	if ((bit_is_clear(C_PIN, DOWN))&&(ST.MT==0))
	{
		if (ST.menu_No==0)
		{ 
			ST.menu_No=MN_No-1;
		}
		else
		{
			ST.menu_No--;
		}
		//Display menu item
		CopyStringtoLCD(MENU[ST.menu_No], 0, 0 );
		LCDGotoXY(0, 1);
		LCDsendChar(6);
		if(ST.menu_No==0)//volume
			{
			if(ST.MT==1)
				{
					//show MT
					CopyStringtoLCD(MN101, 1, 0 );
				}
				else
					{
						//clear MT
						CopyStringtoLCD(MNClr2Ch, 1, 0 );
					}
			if(ST.LD==1)
				{
					//show LD
					CopyStringtoLCD(MN102, 13, 0 );
				}
				else
					{
						//clear LD
						CopyStringtoLCD(MNClr2Ch, 13, 0 );
					}
				LCDGotoXY(1, 1);
				LCDprogressBar((MinVolume-ST.value[ST.menu_No]), MinVolume, 14);
			}
			else if (ST.menu_No==1)//bass
				{
					if(ST.value[ST.menu_No]<=BASS1)
						{
							LCDprogressBar((ST.value[ST.menu_No]&0x0F), (BASS2&0x0F), 14);
						}
						else
							{
								LCDprogressBar(((BASS2-ST.value[ST.menu_No]+BASS3)&0x0F), (BASS2&0x0F), 14);
							}
				}
				else if (ST.menu_No==2)//treble
					{
						if(ST.value[ST.menu_No]<=TREBLE1)
							{
								LCDprogressBar((ST.value[ST.menu_No]&0x0F), (TREBLE2&0x0F), 14);
							}
							else
								{
									LCDprogressBar(((TREBLE2-ST.value[ST.menu_No]+TREBLE3)&0x0F), (TREBLE2&0x0F), 14);
								}
					}
					else if (ST.menu_No==3)//if channel select
						{
							CopyStringtoLCD(CHANNELS[(ST.value[ST.menu_No]&0b00000011)], 1, 1 );
						}
						else if (ST.menu_No==4)//channel gain
							{
								LCDprogressBar((MinchG-ST.value[ST.menu_No]), MinchG, 14);
							}
							else
								{
									LCDprogressBar(((((ST.value[ST.menu_No]&0xE0)|(MinLF&0x1F))-ST.value[ST.menu_No])&0x1F), (((ST.value[ST.menu_No]&0xE0)|(MinLF&0x1F))&0x1F), 14);
								}
								
		LCDsendChar(7);	
		//wait for button release
		loop_until_bit_is_set(C_PIN, DOWN);
	}
	if ((bit_is_clear(C_PIN, VPP))&&(ST.MT==0))
	{
	do{
		if (ST.menu_No==1)//bass
			{
				if(ST.value[ST.menu_No]<BASS1)
				{
					ST.value[ST.menu_No]+=Step;
					LCDGotoXY(0, 1);
					LCDsendChar(6);
					LCDprogressBar((ST.value[ST.menu_No]&0x0F), (BASS2&0x0F), 14);
					LCDsendChar(7);	
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
				}
				else if((ST.value[ST.menu_No]==BASS1))//attention!!!
				{
					ST.value[ST.menu_No]=BASS2;
					LCDGotoXY(0, 1);
					LCDsendChar(6);
					LCDprogressBar(((BASS2-ST.value[ST.menu_No]+BASS3)&0x0F), (BASS2&0x0F), 14);
					LCDsendChar(7);	
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
				}
				else if(((ST.value[ST.menu_No])>BASS3)&&((ST.value[ST.menu_No])<=BASS2))
					{
						ST.value[ST.menu_No]-=Step;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar(((BASS2-ST.value[ST.menu_No]+BASS3)&0x0F), (BASS2&0x0F), 14);
						LCDsendChar(7);	
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
				else 
				{
					ST.value[ST.menu_No]=BASS3;
					LCDGotoXY(0, 1);
					LCDsendChar(6);
					LCDprogressBar(((BASS2-ST.value[ST.menu_No]+BASS3)&0x0F), (BASS2&0x0F), 14);
					LCDsendChar(7);	
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
				}
			}
			else if (ST.menu_No==2)//treble
				{
					if(ST.value[ST.menu_No]<TREBLE1)
					{
						ST.value[ST.menu_No]+=Step;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar((ST.value[ST.menu_No]&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
					else if((ST.value[ST.menu_No]==TREBLE1))//attention!!!
					{
						ST.value[ST.menu_No]=TREBLE2;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar(((TREBLE2-ST.value[ST.menu_No]+TREBLE3)&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
					else if(((ST.value[ST.menu_No])>TREBLE3)&&((ST.value[ST.menu_No])<=TREBLE2))
					{
						ST.value[ST.menu_No]-=Step;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar(((TREBLE2-ST.value[ST.menu_No]+TREBLE3)&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
					else 
					{
						ST.value[ST.menu_No]=TREBLE3;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar(((TREBLE2-ST.value[ST.menu_No]+TREBLE3)&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
				}
				else if (ST.menu_No==3)//if channel select
					{
						if((ST.value[ST.menu_No]&0b00000011)<MaxCh)
							{
								ST.value[ST.menu_No]+=StepCh;
								LCDGotoXY(0, 1);
								LCDsendChar(6);
								CopyStringtoLCD(CHANNELS[(ST.value[ST.menu_No]&0b00000011)], 1, 1 );
								LCDsendChar(7);	
								TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
							}
							else
								{
									ST.value[ST.menu_No]=(ST.value[ST.menu_No]&0b11111100)|MinCh;
									LCDGotoXY(0, 1);
									LCDsendChar(6);
									CopyStringtoLCD(CHANNELS[(ST.value[ST.menu_No]&0b00000011)], 1, 1 );
									LCDsendChar(7);
									TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
								}
					}
					else if (ST.menu_No==4)//channel gain
						{
							if(ST.value[ST.menu_No]>Max)
								{
									ST.value[ST.menu_No]-=Step;
									LCDGotoXY(0, 1);
									LCDsendChar(6);
									LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
									LCDsendChar(7);
									ST.value[ST.menu_No-1]=(ST.value[ST.menu_No-1]&0b11000111)|ST.value[ST.menu_No];
									//twi send ST.value[ST.menu_No-1]
									TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No-1]);
								}
								else
									{
										ST.value[ST.menu_No]=Max;
										LCDGotoXY(0, 1);
										LCDsendChar(6);
										LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
										LCDsendChar(7);
										ST.value[ST.menu_No-1]=(ST.value[ST.menu_No-1]&0b11000111)|ST.value[ST.menu_No];
										//twi send ST.value[ST.menu_No-1]	
										TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No-1]);
									}
						}
						else if (ST.menu_No==0)//volume
							{
								if((ST.value[ST.menu_No]<=Min)&&((ST.value[ST.menu_No]>Max)))//Min means bigger  number
									{
										ST.value[ST.menu_No]-=Step;
										LCDGotoXY(0, 1);
										LCDsendChar(6);
										LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
										LCDsendChar(7);
										//--------send ST.value[ST.menu_No] to AD7313 wia TWI
										TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
									
									}
									else if (ST.value[ST.menu_No]==Max)
										{
											ST.value[ST.menu_No]=Max;
											LCDGotoXY(0, 1);
											LCDsendChar(6);
											LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
											LCDsendChar(7);
											//--------send ST.value[ST.menu_No] to AD7313 wia TWI
											TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
										}
							}
						else
							{
								if((ST.value[ST.menu_No]<=Min)&&((ST.value[ST.menu_No]>Max)))//Min means bigger  number
									{
										ST.value[ST.menu_No]-=Step;
										LCDGotoXY(0, 1);
										LCDsendChar(6);
										LCDprogressBar(((Min-ST.value[ST.menu_No])&0x1F), (Min&0x1F), 14);
										LCDsendChar(7);
										//--------send ST.value[ST.menu_No] to AD7313 wia TWI
										TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
									
									}
									else if (ST.value[ST.menu_No]==Max)
										{
											ST.value[ST.menu_No]=Max;
											LCDGotoXY(0, 1);
											LCDsendChar(6);
											LCDprogressBar(((Min-ST.value[ST.menu_No])&0x1F), (Min&0x1F), 14);
											LCDsendChar(7);
											//--------send ST.value[ST.menu_No] to AD7313 wia TWI
											TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
										}
							}
		Flag=0;//reset flag
		//wait for button release
		}
		while(bit_is_clear(C_PIN, VPP));
	}
	if ((bit_is_clear(C_PIN, VMM))&&(ST.MT==0))
	{
	do{
		if (ST.menu_No==1)//bass
			{
				if((ST.value[ST.menu_No]<BASS2)&&((ST.value[ST.menu_No]>=BASS3)))
				{
					ST.value[ST.menu_No]+=Step;
					LCDGotoXY(0, 1);
					LCDsendChar(6);
					LCDprogressBar(((BASS2-ST.value[ST.menu_No]+BASS3)&0x0F), (BASS2&0x0F), 14);
					LCDsendChar(7);	
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
				}
				else if((ST.value[ST.menu_No]==BASS2))//attention!!!
				{
					ST.value[ST.menu_No]=BASS1;
					LCDGotoXY(0, 1);
					LCDsendChar(6);
					LCDprogressBar((ST.value[ST.menu_No]&0x0F), (BASS2&0x0F), 14);
					LCDsendChar(7);	
					//send to twi
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
				}
				else if((ST.value[ST.menu_No]<=BASS1)&&((ST.value[ST.menu_No]>MinBASS)))
					{
						ST.value[ST.menu_No]-=Step;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar((ST.value[ST.menu_No]&0x0F), (BASS2&0x0F), 14);
						LCDsendChar(7);	
						//send to twi
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
				else 
				{
					ST.value[ST.menu_No]=MinBASS;
					LCDGotoXY(0, 1);
					LCDsendChar(6);
					LCDprogressBar((ST.value[ST.menu_No]&0x0F), (BASS2&0x0F), 14);
					LCDsendChar(7);	
					//send to twi
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
				}	
			}
			else if (ST.menu_No==2)//treble
				{
					if((ST.value[ST.menu_No]<TREBLE2)&&((ST.value[ST.menu_No]>=TREBLE3)))
					{
						ST.value[ST.menu_No]+=Step;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar(((TREBLE2-ST.value[ST.menu_No]+TREBLE3)&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						//send to twi
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
					else if((ST.value[ST.menu_No]==TREBLE2))//attention!!!
					{
						ST.value[ST.menu_No]=TREBLE1;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar((ST.value[ST.menu_No]&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						//send to twi
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
					else if((ST.value[ST.menu_No]<=TREBLE1)&&((ST.value[ST.menu_No]>MinTreble)))
					{
						ST.value[ST.menu_No]-=Step;
						LCDGotoXY(0, 1);
						LCDsendChar(6);
						LCDprogressBar((ST.value[ST.menu_No]&0x0F), (TREBLE2&0x0F), 14);
						LCDsendChar(7);	
						//send to twi
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
					}
					else 
						{
							ST.value[ST.menu_No]=MinTreble;
							LCDGotoXY(0, 1);
							LCDsendChar(6);
							LCDprogressBar((ST.value[ST.menu_No]&0x0F), (TREBLE2&0x0F), 14);
							LCDsendChar(7);	
							//send to twi
							TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
						}
				}
				else if (ST.menu_No==3)//if channel select
					{
						if((ST.value[ST.menu_No]&0b00000011)>MinCh)
							{
								ST.value[ST.menu_No]-=StepCh;
								LCDGotoXY(0, 1);
								LCDsendChar(6);
								CopyStringtoLCD(CHANNELS[(ST.value[ST.menu_No]&0b00000011)], 1, 1 );
								LCDsendChar(7);	
								//send to twi
								TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
							}
							else
								{
									ST.value[ST.menu_No]=(ST.value[ST.menu_No]&0b11111100)|MaxCh;
									LCDGotoXY(0, 1);
									LCDsendChar(6);
									CopyStringtoLCD(CHANNELS[(ST.value[ST.menu_No]&0b00000011)], 1, 1 );
									LCDsendChar(7);
									//send to twi
									TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
								}
					}
					else if (ST.menu_No==4)//channel gain
						{
							if(ST.value[ST.menu_No]<Min)
								{
									ST.value[ST.menu_No]+=Step;
									LCDGotoXY(0, 1);
									LCDsendChar(6);
									LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
									LCDsendChar(7);
									ST.value[ST.menu_No-1]=(ST.value[ST.menu_No-1]&0b11000111)|ST.value[ST.menu_No];
									//twi send ST.value[ST.menu_No-1]	
									TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No-1]);
								}
								else
									{
										ST.value[ST.menu_No]=Min;
										LCDGotoXY(0, 1);
										LCDsendChar(6);
										LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
										LCDsendChar(7);
										ST.value[ST.menu_No-1]=(ST.value[ST.menu_No-1]&0b11000111)|ST.value[ST.menu_No];
										//twi send ST.value[ST.menu_No-1]	
										TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No-1]);
									}	
						}
						else if (ST.menu_No==0)//volume
							{
							if((ST.value[ST.menu_No]>=Max)&&((ST.value[ST.menu_No]<Min)))
								{
									ST.value[ST.menu_No]+=Step;
									LCDGotoXY(0, 1);
									LCDsendChar(6);
									LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
									LCDsendChar(7);
									//--------send ST.value[ST.menu_No] to AD7313 wia TWI
									TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
								}
								else if (ST.value[ST.menu_No]==Min)
									{
										ST.value[ST.menu_No]=Min;
										LCDGotoXY(0, 1);
										LCDsendChar(6);
										LCDprogressBar((Min-ST.value[ST.menu_No]), Min, 14);
										LCDsendChar(7);
										//--------send ST.value[ST.menu_No] to AD7313 wia TWI
										TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
									}
							}
						else
							{
							if((ST.value[ST.menu_No]>=Max)&&((ST.value[ST.menu_No]<Min)))
								{
									ST.value[ST.menu_No]+=Step;
									LCDGotoXY(0, 1);
									LCDsendChar(6);
									LCDprogressBar(((Min-ST.value[ST.menu_No])&0x1F), (Min&0x1F), 14);
									LCDsendChar(7);
									//--------send ST.value[ST.menu_No] to AD7313 wia TWI
									TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
								}
								else if (ST.value[ST.menu_No]==Min)
									{
										ST.value[ST.menu_No]=Min;
										LCDGotoXY(0, 1);
										LCDsendChar(6);
										LCDprogressBar(((Min-ST.value[ST.menu_No])&0x1F), (Min&0x1F), 14);
										LCDsendChar(7);
										//--------send ST.value[ST.menu_No] to AD7313 wia TWI
										TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No]);
									}
							}		
		Flag=0;//reset flag
		//wait for button release
		}
		while(bit_is_clear(C_PIN, VMM));
	}
	if (bit_is_clear(M_PIN, MUTE))
	{
		
		if(ST.menu_No==0)//volume
			{
			//Mute volume
			if(ST.MT==0)
				{
					ST.MT=1;
					CopyStringtoLCD(MN101, 1, 0 );
					//send MUTE to speaker atenuators
					// if mute other control operations are unawailable until un-Mute
					/*
					Mute LF=0b10011111
					Mute RF=0b10111111
					Mute LR=0b11011111
					Mute RR=0b11111111
					*/
					TWI_SendByte(TDA7313_addr, 0b10011111);
					TWI_SendByte(TDA7313_addr, 0b10111111);
					TWI_SendByte(TDA7313_addr, 0b11011111);
					TWI_SendByte(TDA7313_addr, 0b11111111);
				}
				else
					{
						ST.MT=0;
						CopyStringtoLCD(MNClr2Ch, 1, 0 );
						//restore old speaker ateniuator values
						/* send TWI:
							ST.value[5]
							ST.value[6]
							ST.value[7]
							ST.value[8]
							
						*/
						TWI_SendByte(TDA7313_addr, ST.value[5]);
						TWI_SendByte(TDA7313_addr, ST.value[6]);
						TWI_SendByte(TDA7313_addr, ST.value[7]);
						TWI_SendByte(TDA7313_addr, ST.value[8]);
						//
					}
					
			}
		else if (ST.menu_No==4)
			{
			//Set Laudness for current channel
			if(ST.LD==0)
				{
					ST.LD=1;
					CopyStringtoLCD(MN102, 14, 0 );
					ST.value[ST.menu_No-1]|=Laudness;
					TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No-1]);
				}
				else
					{
						ST.LD=0;
						CopyStringtoLCD(MNClr2Ch, 14, 0 );
						ST.value[ST.menu_No-1]&=~Laudness;
						//send  (ST.value[3] AND ~Laudness)
						TWI_SendByte(TDA7313_addr, ST.value[ST.menu_No-1]);
					}
			}
		Flag=0;//reset flag
		//wait for button release
		loop_until_bit_is_set(M_PIN, MUTE);
	}
if (Flag>1220)	
	//only on check after 10s menu inactivity
	Flag=1221;
	else Flag++;
if (Flag==1220)//after some menu inactivity ~10s
	{
		//save parameters to EEPROM if changed
		// first checks if value is changed
		//if not  - write operation isn't performed
		//this reduces EEPROM writecycles
		CopyStringtoLCD(TOEEPROM, 1, 0 );
		if (ST.value[0]!=eeprom_read_byte((uint8_t*)E_VOLUME))
			eeprom_write_byte((uint8_t*)E_VOLUME,ST.value[0]);//save Volume
		if (ST.value[5]!=eeprom_read_byte((uint8_t*)E_LF))
			eeprom_write_byte((uint8_t*)E_LF,ST.value[5]);//0dB
		if (ST.value[6]!=eeprom_read_byte((uint8_t*)E_RF))
			eeprom_write_byte((uint8_t*)E_RF,ST.value[6]);//0dB
		if (ST.value[7]!=eeprom_read_byte((uint8_t*)E_LR))
			eeprom_write_byte((uint8_t*)E_LR,ST.value[7]);//0dB
		if (ST.value[8]!=eeprom_read_byte((uint8_t*)E_RR))
			eeprom_write_byte((uint8_t*)E_RR,ST.value[8]);//0dB
		if (ST.value[3]!=eeprom_read_byte((uint8_t*)E_ch))
			eeprom_write_byte((uint8_t*)E_ch,ST.value[3]);//save channel
		if (ST.value[1]!=eeprom_read_byte((uint8_t*)E_BASS))
			eeprom_write_byte((uint8_t*)E_BASS,ST.value[1]);//save BASS
		if (ST.value[2]!=eeprom_read_byte((uint8_t*)E_TREBLE))
			eeprom_write_byte((uint8_t*)E_TREBLE,ST.value[2]);//Treble
			//defaulting to Volume menu
		ST.menu_No=0;
		CopyStringtoLCD(MENU[ST.menu_No], 0, 0 );
		LCDGotoXY(0, 1);
		LCDsendChar(6);
		if(ST.MT==1)
			{
				//show MT
				CopyStringtoLCD(MN101, 1, 0 );
			}
			else
				{
					//clear MT
					CopyStringtoLCD(MNClr2Ch, 1, 0 );
				}
		if(ST.LD==1)
			{
				//show LD
				CopyStringtoLCD(MN102, 13, 0 );
			}
			else
				{
					//clear LD
					CopyStringtoLCD(MNClr2Ch, 13, 0 );
				}
		LCDGotoXY(1, 1);	
		LCDprogressBar((MinVolume-ST.value[ST.menu_No]), MinVolume, 14);
		LCDsendChar(7);	
		Flag++;
	}
}



void main_init(void)
{

//---------initialize LCD-----------------
LCDinit();
//----------init TWI----------------------
TWI_Init();
//------EEPROM initial values-------------
if (eeprom_read_byte((uint8_t*)E_INIT)!='T')
{
eeprom_write_byte((uint8_t*)E_VOLUME,0x0F);//0dB
eeprom_write_byte((uint8_t*)E_LF,0x80);//0dB
eeprom_write_byte((uint8_t*)E_RF,0xA0);//0dB
eeprom_write_byte((uint8_t*)E_LR,0xC0);//0dB
eeprom_write_byte((uint8_t*)E_RR,0xE0);//0dB
eeprom_write_byte((uint8_t*)E_ch,0x58);//ch1 0dB, Laudness OFF
eeprom_write_byte((uint8_t*)E_BASS,0x6F);//0dB
eeprom_write_byte((uint8_t*)E_TREBLE,0x7f);//0dB
eeprom_write_byte((uint8_t*)E_INIT,'T');//marks once that eeprom init is done
//once this procedure is held, no more initialization is performed
}

//--------Restore values from EEPROM------
ST.value[0]=eeprom_read_byte((uint8_t*)E_VOLUME);
ST.value[1]=eeprom_read_byte((uint8_t*)E_BASS);
ST.value[2]=eeprom_read_byte((uint8_t*)E_TREBLE);
ST.value[3]=eeprom_read_byte((uint8_t*)E_ch);
ST.value[4]= ST.value[3]&0b00011000;//restore gain
ST.LD=ST.value[3]&0b00000100;//restore Laudness
ST.MT=0;//default Mute OFF
ST.value[5]=eeprom_read_byte((uint8_t*)E_LF);
ST.value[6]=eeprom_read_byte((uint8_t*)E_RF);
ST.value[7]=eeprom_read_byte((uint8_t*)E_LR);
ST.value[8]=eeprom_read_byte((uint8_t*)E_RR);

//---------Buttons init-------------------
//PORTA pins as input
DC_PORT|=(0<<VPP)|(0<<VMM)|(0<<UP)|(0<<DOWN);
//PORTA internal pullups
C_PORT|=(1<<VPP)|(1<<VMM)|(1<<UP)|(1<<DOWN);
//PORTB pins as input
DM_PORT|=(0<<MUTE);
//PORTB internal pullups
M_PORT|=(1<<MUTE);

//----------Menu Init----------------
Menu_Init();
//---------Timer0 Init----------------------

Timer0_init();
}

int main(void)
{
	main_init();
	while(1) {
		};

}


