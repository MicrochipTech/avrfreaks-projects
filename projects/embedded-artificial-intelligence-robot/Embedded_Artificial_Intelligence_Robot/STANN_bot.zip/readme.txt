Embedded Artificial Intelligence Robot

This project was my entry into the "Intel International Science and Engineering Fair" in 2003 as a 
member of team Canada.

For this project I won a third place award in the engineering catagory.

THe final report is really everything, and it makes reference to the appendixes provided in the folders.

Hopefully you found this project useful, and if so feel free to e-mail me at:

c_oflynn@yahoo.com or
coflynn@newae.com

or visit http://www.newae.com