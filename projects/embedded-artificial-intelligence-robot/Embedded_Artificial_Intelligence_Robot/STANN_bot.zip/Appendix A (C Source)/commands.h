/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*
Included by the three boards, has the addresses and commands of all of them
*/

//Commands
#define COMMAND_START_TRACKING		0x0f
#define COMMAND_TRACK_POS				0x10
#define COMMAND_GET_POS					0x11
#define COMMAND_ULTRASONIC				0x1f


//Board Addresses
#define VFD1_ADDRESS						0x0a
#define MOTORL_ADDRESS					0x0b
#define MOTORR_ADDRESS					0x0c
#define SENSOR_ADDRESS					0x02
