/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/* CMUCam communications control. Communicates with CMUCam to provide object
tracking. */

#define CAMERA_OK				0
#define CAMERA_FAILED     	1


/* Inits the various systems used to track the object, including the
stepper motor, ADC, and CMUcam. Note that whatever colour is in the camera's
window (held infront of it) will be tracked. So first hold the object you want
tracked infront of the camera, then call this function. You can recall this
function if you want, it will just reinitilize everything including the tracked
colour

Returns CAMERA_OK if the CMUcam was there, CAMERA_FAILED if the CMUcam didn't
respond properly (if at all)*/
unsigned char                          init_tracking_system
	(
   void
   );

/*tracks the object a certain number of times, held in "number_of_times_to_track"
One "track" means moving the stepper motor once (or sometimes twice, depends).

Returns CAMERA_OK if no errors detected, CAMERA_FAILED if the camera times out.
The object colour that is tracked is the colour that is infront of the camera
when init_tracking_system() is called.
*/
unsigned char									track_object
	(
   unsigned int				number_of_times_to_track
   );

/*
Returns the location of the object tracked. It relies on both the sensor on the
stepper shaft AND the CMUCam's location of the object.

Return value will be between 0 to about 350, if return is negative some error
occured.
*/

int												get_object_position
	(
   void
   );