/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/* Stepper motor control routines */

#define STEP_PORT		PORTD
#define STEP_DDR		DDRD

/* Connections are:
STEP_PORT.4 = BLACK
STEP_PORT.5 = GREEN
STEP_PORT.6 = RED
STEP_PORT.7 = BLUE
*/

#include <avr/IO.h>
#include "step_motor.h"

//Define the normal stepper motor pattern
const	unsigned char		step_pattern[4] = {0x50, 0x60, 0xA0, 0x90};

//Set up stepper motor port... you could actually just use an inline macro
//for this, but its more flexible this way
void												init_step_motor
	(
   void
   )
   {
   STEP_DDR = STEP_DDR | 0xF0;
   return;
   }

//step the motor ONCE in the clockwise direction
void												step_clockwise_one
	(
   void
   )
   {
   static unsigned char		motor_position = 0;

   if (motor_position > 3)
   	{
      motor_position = 0;
      }
   STEP_PORT = (STEP_PORT & 0x0F) | step_pattern[motor_position];

   motor_position++;

   return;
   }

//step the motor ONCE in the counter-clockwise direction
void												step_counterclockwise_one
	(
   void
   )
   {
   static unsigned char		motor_position = 0;

   if (motor_position > 3)
   	{
      motor_position = 3;
      }
   STEP_PORT = (STEP_PORT & 0x0F) | step_pattern[motor_position];

   motor_position--;

   return;
   }

//unbrake the motor, which removes all power from it letting it sping freely
//without resistance
void												unbrake_stepper_motor
	(
   void
   )
   {
   STEP_PORT = STEP_PORT & 0x0F;
   return;
   }            
