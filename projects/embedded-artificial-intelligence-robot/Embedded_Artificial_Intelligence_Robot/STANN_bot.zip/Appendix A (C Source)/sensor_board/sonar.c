/*****************************************************************************
This is a piece of software designed to be used with a Polaroid SONAR module
from one of thier camera's that use ultrasonics to focus. Thier are two types of
units, one has a nice round transducer and one has a smaller square transducer.
This code should probably work for both of them.

Interrupts are NOT used, as the timer counts pretty slow (1024 prescale) the
interrupts don't really add any accuracy, but they do add size to the code and
are less portable. Plus they chew up a lot of hardware resources (you might want
them for something else).

If your version of AVR-GCC doesn't store stuff in the avr\ directory, change
<avr\interrupt.h> to <interrupt.h>, same thing with io.h

Designed for AtMega8 controller, probably would work with others. If it doesn't
compile with them, I guess it doesn't work as is!

This code written by Colin O'Flynn, e-mail me at c_oflynn@yahoo.com or
coflynn@newae.com if you have questions, comments, or found my project useful!
Note: I am aware that this really isn't SONAR as it is above-ground... but its
just an easy word to use...

Version: 				1.01 --changed to use Timer0 (less accurate though!)
Last Modification:	March 20, 2003
Note: Tab stops set to 3 in my coding environment

This file should have come with a schematic that shows you how to connect the
modified polaroid board up, with the modification from www.robotprojects.com

Hardware used:
3x		Port pins
1x		Timer0
******************************************************************************/

#include <avr\io.h>
//need some macros (cli() basically)
#include <avr\interrupt.h>

//Where to connect signal that allows you to power up transducer (active high)
#define TRIGGER_PORT		PORTC
#define TRIGGER_DDR		DDRC
#define TRIGGER_PIN		3

//Where to connect "Pulse Sent" input (active high)
#define TRANS_PORT_IN   PINC
#define TRANS_DDR       DDRC
#define TRANS_PIN       2

//Where to connect "Echo" input (active high)
#define ECHO_PORT_IN		PINC
#define ECHO_DDR 			DDRC
#define ECHO_PIN        1

//start timer1 with prescale
#define start_timer0()	(TCCR0 = 1<<CS02 | 1<<CS00)
//stop timer1
#define stop_timer0()	(TCCR0 = 0)

//How long we wait for the transducer to respond before declaring that its not
//responding
#define SONIC_TIMEOUT	65000

/* Setup sonar ports used and timer1 */
void                                   init_sonar
	(
   void
   )
   {
	//setup sonar port
	TRIGGER_DDR |= 1<<TRIGGER_PIN;
   TRANS_DDR &= ~(1<<TRANS_DDR);
   ECHO_DDR &= ~(1<<ECHO_DDR);

   //don't use any of the fancy features
   TCCR0 = 0;

   //stop timer0
   stop_timer0();

   return;
   }

/*Get the distance to an object. It returns something in the range of 1 to
30000, (maybe higher). As it so happens by pure luck if your processor speed happens
to be around 4 MHz the returned distance is roughly in CM. Though if you want
accuracy you will have to multiply the returned value by a calibration factor!!

IMPORTANT: If this thing returns 0, it means that it never received a response
from the transducer, so it timed out.

Do *NOT* call this routine in a loop with no delay, the ultrasonics need some
down-time to recover!!!! Exact time delay not really important, experiment
around until you find one that is reliable */
unsigned int									get_distance_to_object
	(
   void
   )
   {
   //timeout counter
   unsigned int				counter;

   init_sonar();

   //stop TIMER0
   stop_timer0();

   //reset TIMER0
   TCNT0 = 0;

   //ping ultrasonic transducer
   TRIGGER_PORT |= 1<<TRIGGER_PIN;

   //clear timeout counter
   counter = 0;

   //wait for transmit to go high
   while ((TRANS_PORT_IN & 1<<TRANS_PIN) != 1<<TRANS_PIN)
   	{
      counter++;
      //check if the unit has timed out
      if (counter == SONIC_TIMEOUT)
      	{
         //power down SONAR box
		   TRIGGER_PORT &= ~(1<<TRIGGER_PIN);
         return 0;
         }
      }

   //start counting time until echo returns
   start_timer0();

   //clear timeout counter
  	counter = 0;

   //wait for echo
   while ((ECHO_PORT_IN & 1<<ECHO_PIN) != 1<<ECHO_PIN)
   	{
      counter++;
      //check if the unit has timed out
      if (counter == SONIC_TIMEOUT)
      	{
         //power down SONAR box
		   TRIGGER_PORT &= ~(1<<TRIGGER_PIN);
         return 0;
         }
      }

   //stop timer from counting
   stop_timer0();

   //power down SONAR box
   TRIGGER_PORT &= ~(1<<TRIGGER_PIN);

   return TCNT0;
   }
