
/* Setup sonar ports used and timer0. Note: try to call this as early as
possible to preven sonar ports from floating */
void                                   init_sonar
	(
   void
   );


/*Get the distance to an object. It returns something in the range of 1 to
30000, (maybe higher). As it so happens by pure luck if your processor speed happens
to be around 4 MHz the returned distance is roughly in CM. Though if you want
accuracy you will have to multiply the returned value by a calibration factor!!

IMPORTANT: If this thing returns 0, it means that it never received a response
from the transducer, so it timed out.

Do *NOT* call this routine in a loop with no delay, the ultrasonics need some
down-time to recover!!!! Exact time delay not really important, experiment
around until you find one that is reliable */
unsigned int									get_distance_to_object
	(
   void
   );






