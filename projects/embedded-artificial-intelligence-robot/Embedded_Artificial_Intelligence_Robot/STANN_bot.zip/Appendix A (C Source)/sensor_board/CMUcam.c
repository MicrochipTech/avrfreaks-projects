/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/* CMUCam communications control. Communicates with CMUCam to provide object
tracking. */

#include <avr/IO.h>

#include <avr/delay.h>

#include "CMUcam.h"
#include "step_motor.h"
#include "uart.h"

#define COMMAND_OK         0
#define COMMAND_FAILED     1
#define CAMERA_NOT_READY   2
#define TIMEOUT_CMU        3
#define LOCK_FAILED			4

#define CLOCKWISE				0
#define COUNTERCLOCKWISE	1

//these two (X_LOWER_LIMIT and X_UPPER_LIMIT) decide when the object is no
//longer centered, and the stepper motor must be moved
#define X_LOWER_LIMIT								 	57
#define X_UPPER_LIMIT								 	60

//how high must CONFIDENCE be for thier to be a trusted lock. If there is a lot
//of false locks try increasing this value.
#define TRUSTED_LOCK										20

//how far clockwise can the motor go before ripping the wires out. the value
//is compared to the voltage measured on the Honeywell M22S (variable resistor),
//and will range between 0 to 255
#define CLOCKWISE_END_OF_TRAVEL_LIMIT           70
//same as CLOCKWISE_END_OF_TRAVEL_LIMIT, except counter-clockwise
#define COUNTERCLOCKWISE_END_OF_TRAVEL_LIMIT    230

//the sync byte the CMU cam uses in binary mode to preccede each byte
#define SYNC_CMU_CAM										255


//Reset the CMUcam, returns CAMERA_OK or CAMERA_FAILED
unsigned char									init_CMU_cam
	(
   void
   );

/*Send a command to the CMUcam, returns COMMAND_OK, COMMAND_FAILED,
CAMERA_NOT_READY, or TIMEOUT_CMU. COMMAND_OK means the camera send an ACK
back. COMMAND_FAILED means the camera send a NCK back, CAMERA_NOT_READY means
the camera did something unexpected, TIMEOUT_CMU means the CMUcam didn't respond.

use like this:
send_command_to_CMUcam ("TW\r", 3);
*/
unsigned char									send_command_to_CMUcam
	(
   char							command[],
   unsigned char				command_length_in_bytes
   );

/*Get the CMU prompt, the ':' by hitting it with \r until it responds with :

Returns COMMAND_OK or TIMEOUT_CMU. This function is used in send_command_to_CMUcam
and init_CMU_cam so you shouldn't need it */
unsigned char									get_CMU_prompt
	(
   void
   );

//Reset the CMUcam, returns CAMERA_OK or CAMERA_FAILED
unsigned char									init_CMU_cam
	(
   void
   )
   {
   char							data;

   //setup UART0
   init_uart0();

   //get CMU prompt
   get_CMU_prompt();

   //output reset command
   output_ch_0('r');
   output_ch_0('s');
   output_ch_0('\r');

   //wait for response
   if (input_ch_w_timeout_0(&data, 50000) != BYTE_REC)
   	{
      return TIMEOUT_CMU;
      }

   //check if camera was sending ACK
   if (data == 'A')
   	{
      return CAMERA_OK;
      }
   else
   	{
      return CAMERA_FAILED;
      }

   }

/*Send a command to the CMUcam, returns COMMAND_OK, COMMAND_FAILED,
CAMERA_NOT_READY, or TIMEOUT_CMU. COMMAND_OK means the camera send an ACK
back. COMMAND_FAILED means the camera send a NCK back, CAMERA_NOT_READY means
the camera did something unexpected, TIMEOUT_CMU means the CMUcam didn't respond.

use like this:
send_command_to_CMUcam ("TW\r", 3);
Be sure to add the \r to generate a return, as this subroutine doesn't do that.
Remeber that \r counts as 1 character...
*/
unsigned char									send_command_to_CMUcam
	(
   char				command[],
   unsigned char				command_length_in_bytes
   )
   {
   unsigned char				command_bytes_sent = 0;
   char							data;

   //get the command prompt
   if (get_CMU_prompt() != COMMAND_OK)
   	{
      return TIMEOUT_CMU;
      }

   //send the command
   while (command_bytes_sent != command_length_in_bytes)
   	{
      output_ch_0(command[command_bytes_sent]);
      command_bytes_sent++;
      }

   if (input_ch_w_timeout_0(&data, 20000) == BYTE_REC)
   	{
      //looks like camera is sending "ACK"
      if (data == 'A')
      	{
         return COMMAND_OK;
         }
      //something else happened...
      else
      	{
         return COMMAND_FAILED;
         }
      }
   //camera not responding
   else
   	{
      return TIMEOUT_CMU;
      }

   }

/*Get the CMU prompt, the ':' by hitting it with \r and see if it responds
with the ':' character

Returns COMMAND_OK or TIMEOUT_CMU. This function is used in send_command_to_CMUcam
and init_CMU_cam so you shouldn't need it */
unsigned char									get_CMU_prompt
	(
   void
   )
   {
   char							data;

   //output a return
   output_ch_0('\r');

   //sort though the input until we get either a : or a timeout, as the CMUcam
   //can respond with an ACK after the return
   while (input_ch_w_timeout_0(&data, 40000) == BYTE_REC && data != ':')
   	{
      continue;
      }

   //check if the : was received
   if (data == ':')
   	{
      return COMMAND_OK;
      }

   //no :, camera timed out
   return TIMEOUT_CMU;
   }


/* Inits the various systems used to track the object, including the
stepper motor, ADC, and CMUcam. Note that whatever colour is in the camera's
window (held infront of it) will be tracked. So first hold the object you want
tracked infront of the camera, then call this function. You can recall this
function if you want, it will just reinitilize everything including the tracked
colour

Returns CAMERA_OK if the CMUcam was there, CAMERA_FAILED if the CMUcam didn't
respond properly (if at all)*/
unsigned char                          init_tracking_system
	(
   void
   )
   {
   //initilize stepper motor
   init_step_motor();
   //step motor once to lock it in
   step_counterclockwise_one();


   //set PINC.0 to input
   DDRC &= ~(1);

   //initilize ADC
   //set ADC to use internal ref
   ADMUX = (1<<REFS1) | (1<<REFS0);

   //left shift ADC register, meaning we just use it as an 8-bit ADC as the
   //stepper motor only has 200 steps/rev, so no point going above 8 bit feedback
   ADMUX |= (1<<ADLAR);

   //set to use ADC channel 0
   ADMUX &= ~(1<<MUX0 | 1<<MUX1 | 1<<MUX2 | 1<<MUX3);

   //set ADC divider to 32, so ADC clock lies somewhere in 100-250 KHz
   ADCSRA |= (1<<ADPS2) | (1<<ADPS0);

  	//enable ADC
   ADCSRA |= (1<<ADEN);

   //enable free running mode
   ADCSRA |= (1<<ADFR);

   //start free running mode
   ADCSRA |= (1<<ADSC);
   //to read value in ADC, just read ADCH which has a 0-255 value

   
   if (init_CMU_cam() != CAMERA_OK)
   	{
      return CAMERA_FAILED;
      }

   if (send_command_to_CMUcam("RM 1\r", 5) != COMMAND_OK)
   	{
      return CAMERA_FAILED;
      }

   if (send_command_to_CMUcam("MM 1\r", 5) != COMMAND_OK)
   	{
      return CAMERA_FAILED;
      }

   if (send_command_to_CMUcam("TW\r", 3) != COMMAND_OK)
   	{
      return CAMERA_FAILED;
      }

   return CAMERA_OK;
   }

/*tracks the object a certain number of times, held in "number_of_times_to_track"
One "track" means moving the stepper motor once (or sometimes twice, depends).

Returns CAMERA_OK if no errors detected, CAMERA_FAILED if the camera times out.
The object colour that is tracked is the colour that is infront of the camera
when init_tracking_system() is called.
*/
unsigned char									track_object
	(
   unsigned int				number_of_times_to_track
   )
   {

   unsigned char				databyte;
   unsigned char				x_centermass;
   unsigned char				y_centermass;
   unsigned char           confidence;
   static unsigned char	 	direction;
   unsigned char				counter;

   while (number_of_times_to_track != 0)
   	{

   	databyte = 0;

      //wait for the "SYNC" byte from the CMU_CAM
   	while (databyte != SYNC_CMU_CAM)
   		{
        	if (input_ch_w_timeout_0(&databyte, 60000) != BYTE_REC)
         	{
            return CAMERA_FAILED;
            }

      	}

   	//recieve useless 'M'
      if (input_ch_w_timeout_0(&databyte, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED;
         }

   	//recieve X coords of center of mass
      if (input_ch_w_timeout_0(&x_centermass, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED;
         }

   	//recieve Y coords of center of mass
      if (input_ch_w_timeout_0(&y_centermass, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED;
         }

   	//recieve 5 unused databytes
      for (counter = 5; counter != 0; counter--)
   		{
      	if (input_ch_w_timeout_0(&databyte, 50000) != BYTE_REC)
        		{
         	return CAMERA_FAILED;
         	}
         }


   	//recieve confidence
      if (input_ch_w_timeout_0(&confidence, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED;
         }

      //if the object's X value is lower than the LOWER LIMIT and the lock is
      //good, move the stepper motor
   	if (x_centermass < X_LOWER_LIMIT && confidence > TRUSTED_LOCK)
			{
      	step_counterclockwise_one();
      	direction = COUNTERCLOCKWISE;
      	}

      //if the object's X value is higer than the HIGER LIMIT and the lock is
      //good, move the stepper motor
   	if (x_centermass > X_UPPER_LIMIT && confidence > TRUSTED_LOCK)
   		{
      	step_clockwise_one();
      	direction = CLOCKWISE;
      	}

      //if the stepper motor is moving too far and going to rip the wires out
      //reverse direction
   	if (ADCH < CLOCKWISE_END_OF_TRAVEL_LIMIT)
   		{
      	step_counterclockwise_one();
      	direction = COUNTERCLOCKWISE;
      	}

      //if the stepper motor is moving too far and going to rip the wires out
      //reverse direction
   	if (ADCH > COUNTERCLOCKWISE_END_OF_TRAVEL_LIMIT)
   		{
      	step_clockwise_one();
      	direction = CLOCKWISE;

      	}


      //if we lost the lock than just keep moving the stepper motor the last
      //direction it was moving, as that is probably where the object is
   	if (confidence < TRUSTED_LOCK)
   		{
      	if (direction == COUNTERCLOCKWISE)
      		{
         	step_counterclockwise_one();
         	}
      	else
      		{
         	step_clockwise_one();
         	}
      	}

      number_of_times_to_track--;

      }

	return CAMERA_OK;
   }

/*
Returns the location of the object tracked. It relies on both the sensor on the
stepper shaft AND the CMUCam's location of the object.

Return value will be between 0 to about 350, if return is negative some error
occured.
*/

int												get_object_position
	(
   void
   )
   {
   unsigned char				databyte;
   unsigned char				x_centermass;
   unsigned char				y_centermass;
   unsigned char           confidence;
   unsigned char				counter;

   databyte = 0;

		//wait for the "SYNC" byte from the CMU_CAM
   	while (databyte != SYNC_CMU_CAM)
   		{
        	if (input_ch_w_timeout_0(&databyte, 60000) != BYTE_REC)
         	{
            return CAMERA_FAILED - 10;
            }

      	}

   	//recieve useless 'M'
      if (input_ch_w_timeout_0(&databyte, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED - 10;
         }

   	//recieve X coords of center of mass
      if (input_ch_w_timeout_0(&x_centermass, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED - 10;
         }

   	//recieve Y coords of center of mass
      if (input_ch_w_timeout_0(&y_centermass, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED - 10;
         }

   	//recieve 5 unused databytes
      for (counter = 5; counter != 0; counter--)
   		{
      	if (input_ch_w_timeout_0(&databyte, 50000) != BYTE_REC)
        		{
         	return CAMERA_FAILED - 10;
         	}
         }


   	//recieve confidence
      if (input_ch_w_timeout_0(&confidence, 50000) != BYTE_REC)
        	{
         return CAMERA_FAILED - 10;
         }

   //check if confidence is to low, return that to mean 'lock failed'
   if (confidence < TRUSTED_LOCK)
   	{
      return LOCK_FAILED - 10;
      }

   //return absolute position of object
   return (x_centermass + ADCH);
   }





	

