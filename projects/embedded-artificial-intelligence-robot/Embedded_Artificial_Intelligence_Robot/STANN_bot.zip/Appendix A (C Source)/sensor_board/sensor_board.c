/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/* Includes routines that go on the sensor board that communicates with the
CMUCam and SONAR */

#include <avr\io.h>
#include <avr\interrupt.h>
#include <avr\signal.h>

#include <avr\delay.h>

//include the commands for the bus
#include "..\commands.h"

//include UART routines
#include "uart.h"

//include CMUCam control
#include "CMUCam.h"

//include SONAR control
#include "sonar.h"

void												send_data
	(
   unsigned char				data
   );

#define PIN_DATA_BUS				PINB
#define PORT_DATA_BUS			PORTB
#define DDR_DATA_BUS				DDRB

#define PIN_CONTROL_BUS			PINC
#define PORT_CONTROL_BUS		PORTC
#define DDR_CONTROL_BUS			DDRC
#define CONTROL_BUS_RW_BIT		4
#define CONTROL_BUS_CLK_BIT	5

#define INT_DDR					DDRD
#define INT0_NEWDATA_BIT		2
#define INT1_DATASNT_BIT 		3
#define PIN_DATASNT				PIND

#define MAX_DATA_BUFFER			10

//global variables
volatile unsigned char		track_object_var;
//data send buffer
volatile unsigned char		data_to_send[MAX_DATA_BUFFER];

//data send pointer to last piece of data that was written to buffer but has
//yet to be sent
volatile unsigned char		data_counter = 0;

//data send pointer to last piece of data that was sent
volatile unsigned char		data_counter_2 = 0;

int												main
	(
   void
   )
   {


   //load the proper frequency to the OSCCAL register that knocks the clock
   //into around 7.3728Mhz
   OSCCAL = 0xA0;

   //enable SONAR
   init_sonar();

   //enable UART
   init_uart0();

   //setup the data_bus to be input
   DDR_DATA_BUS = 0x00;

   //setup some pins in the control_port to be outputs
   DDR_CONTROL_BUS |= (1<<CONTROL_BUS_RW_BIT) | (1<<CONTROL_BUS_CLK_BIT);

   //setup those pins to be low
   PORT_CONTROL_BUS &= ~(1<<CONTROL_BUS_RW_BIT) | (1<<CONTROL_BUS_CLK_BIT);

   //INT0 + INT1 is input
   INT_DDR &= ~(1<<INT0_NEWDATA_BIT | 1<<INT1_DATASNT_BIT);

   //enable INT0 on RISING edge
   MCUCR |= (1<<ISC01 | 1<<ISC00);
   GICR |= 1<<INT0;

   //enable INT1 on RISING edge
   MCUCR |= (1<<ISC11 | 1<<ISC10);
   GICR |= 1<<INT1;

   //enable interrupts
   sei();

	//make sure camera doesn't track yet
   track_object_var = 0x00;


   //start looping, turning on the camera tracking if needed
   while(1){
      if (track_object_var == 0xFF)
      	{

         //can't have track routine interrupted
         cli();
         //track object for 10 steps
         track_object(10);
         //enable interrupts
         sei();
         //wait some cycles for a few interrupts to occur
         _delay_loop_1(3);
         }
      }



   return 1;
   }

/* Send the data in the argument to the StannBus, at whatever address is currently
on the bus. */
void												send_data
	(
   unsigned char				data
   )
   {

   //use next address location
   data_counter++;

   //check for overflow
   if(data_counter > (MAX_DATA_BUFFER - 1))
   	{
      data_counter = 0;
      }

   //store data to send
   data_to_send[data_counter] = data;

   //set RW to W, the ball is now in Interrupt 1's court
	PORT_CONTROL_BUS |= 1<<CONTROL_BUS_RW_BIT;

   return;
   }


/*int0 rising edge interrupt. This will go HIGH when new data can be used on
the databus and decoded for a command....*/
SIGNAL(SIG_INTERRUPT0)
   {
   int							object_pos;
	if(PIN_DATA_BUS == COMMAND_START_TRACKING)
   	{
      //inititilize the tracking system, lock onto colour
		init_tracking_system();

      //tell camera to track the object
      track_object_var = 0xFF;

      return;
      }
   else if (PIN_DATA_BUS == COMMAND_TRACK_POS)
   	{
      //tell camera to track the object
      track_object_var = 0xFF;

      return;
      }
   else if (PIN_DATA_BUS == COMMAND_GET_POS)
   	{

		object_pos = get_object_position();

      send_data((unsigned char)object_pos);
      send_data((unsigned char)(object_pos >> 8));

      return;
      }
   else if (PIN_DATA_BUS == COMMAND_ULTRASONIC)
   	{
      object_pos = get_distance_to_object();

      send_data((unsigned char)object_pos);
      send_data((unsigned char)(object_pos >> 8));

      return;
      }
   }


/* Rising edge interrupt. Triggered when the WR_STAT line goes HIGH, indicating
that we have write status now and can write to the bus.

Keeps sending out data until all the bytes have been sent, at which point it
deasserts the write request line. */
SIGNAL(SIG_INTERRUPT1)
   {

   //keep sending data until it is all sent
   while(data_counter_2 != data_counter)
   	{
 		//wait a few (12) cycles
   	_delay_loop_1(4);

   	//next data_byte
   	data_counter_2++;

   	//output data
   	if (data_counter_2 > (MAX_DATA_BUFFER - 1))
   		{
     		data_counter_2 = 0;
      	}

   	DDR_DATA_BUS = 0xff;
   	PORT_DATA_BUS = data_to_send[data_counter_2];

   	//CLK data onto bus
   	PORT_CONTROL_BUS |= 1<<CONTROL_BUS_CLK_BIT;

   	//wait a few cycles
   	_delay_loop_1(10);

  		//drop CLK
   	PORT_CONTROL_BUS &= ~(1<<CONTROL_BUS_CLK_BIT);
      }

   //drop output data
   DDR_DATA_BUS = 0x00;
   PORT_DATA_BUS = 0x00;

	//set RW to R
   PORT_CONTROL_BUS &= ~(1<<CONTROL_BUS_RW_BIT);

   return;
   }

/* Default interrupt, SHOULD NEVER OCCUR!!!!! */
SIGNAL(__vector_default)
	{
   }
