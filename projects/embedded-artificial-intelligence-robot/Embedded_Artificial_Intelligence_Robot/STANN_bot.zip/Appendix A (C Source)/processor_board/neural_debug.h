#ifndef STANN_NEURAL_DEBUG
#define STANN_NEURAL_DEBUG
/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */


/* This routine will make a neural network, after prompting for a few key pieces
of information */
void 												makenet
	(
   void
   );

/* This routine runs the neural network , prompting for input data */
void 												runnet
	(
   void
   );

/* This is the neural de-bugger, that is responsable for doing most taks on the
neural network */
void 												debugnet
	(
   void
   );

/* This routine loads the neural network from a file on a computer: note currently
this routine is not finished */
void 												loadnet
	(
   void
   );
#endif


