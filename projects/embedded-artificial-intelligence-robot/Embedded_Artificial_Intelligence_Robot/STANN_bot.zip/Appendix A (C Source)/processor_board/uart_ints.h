/* Simple routine to use the hardware UART. USES interrupts.

Created by: Colin O'Flynn
Contact: c_oflynn@yahoo.com or coflynn@newae.com or username c_oflynn on
www.avrfreaks.net

These routines are released free of restrictions, but if anything bad happens
(including but not limited to loss of your time, loss of profit, loss of life,
injury, loss of money, loss of your dog) it is your OWN fault, NO ONE else
can be held responsible*/


//CPU clock speed in Hz
#define CPU_CLK_SPEED		11059200
//Baud rate we want
#define BAUD_RATE1			115200

//Init UART1, set to baud rate as defined in header file
void												init_uart1
	(
   void
   );
//wait forever for a char on UART 1 and return it
char												input_ch_1
	(
   void
   );

//output char data on UART1
void												output_ch_1
	(
	char							data
	);

//error codes returned by functions
#define BYTE_REC				0
#define TIMEOUT				1
