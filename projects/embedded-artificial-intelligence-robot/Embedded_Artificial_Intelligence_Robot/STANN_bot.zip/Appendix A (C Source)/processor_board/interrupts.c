/* IMPORTANT: This file is NOT designed to be compiled seperately, just
included into another source file */

GONE
