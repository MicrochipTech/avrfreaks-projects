/* Simple routine to use the hardware UART. USES Interrupts

Created by: Colin O'Flynn
Contact: c_oflynn@yahoo.com or coflynn@newae.com or username c_oflynn on
www.avrfreaks.net

These routines are released free of restrictions, but if anything bad happens
(including but not limited to loss of your time, loss of profit, loss of life,
injury, loss of money, loss of your dog) it is your OWN fault, NO ONE else
can be held responsible*/

#include <avr/IO.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include "uart.h"

#define SIZE_OF_UART1_BUFFER	10

#define BAUD_RATE1_REG  (unsigned int)(CPU_CLK_SPEED / (16 * BAUD_RATE0) ) - 1
//Actual baud rate, can be used to calculate error
#define ACTUAL_BAUD1    (unsigned int)(CPU_CLK_SPEED / (16 * BAUD_RATE0_REG + 1)

volatile unsigned char		uart1_buffer[SIZE_OF_UART1_BUFFER];
volatile unsigned char		uart1_buffer_counter = 0;
volatile unsigned char		uart1_buffer_counter_read = 0;

void												init_uart1
	(
   void
   )
   {
	//turn on TX and RX, and RX Interrupt
   UCSR1B = (1<<RXEN1) | (1<<TXEN1) | (1<<RXCIE1);
   UCSR1A = 1<<RXC1;

  	UBRR1L = (unsigned char)BAUD_RATE1_REG;
   UBRR1H = (unsigned char)(BAUD_RATE1_REG >> 8);

   UCSR1C = (1<<UCSZ11) | (1<<UCSZ10);

   sei();

   return;
   }
		
char												input_ch_1
	(
   void
   )
   {
   while (uart1_buffer_counter == uart1_buffer_counter_read)
   	{
      continue;
      }

  	uart1_buffer_counter_read++;

   if (uart1_buffer_counter_read == SIZE_OF_UART1_BUFFER )
   	{
      uart1_buffer_counter_read = 0;
      }

	return uart1_buffer[uart1_buffer_counter];

	}
	
void												output_ch_1
	(
	char							data
	)
	{
	while ((UCSR1A & (1<<UDRE1)) != (1<<UDRE1))
		{
		continue;
		}
      
	UDR1 = data;
	
	return;
	}

SIGNAL(SIG_UART1_RECV)
	{

   uart1_buffer_counter++;

   if (uart1_buffer_counter == SIZE_OF_UART1_BUFFER )
   	{
      uart1_buffer_counter = 0;
      }

   uart1_buffer[uart1_buffer_counter] = UDR1;

   }
   





