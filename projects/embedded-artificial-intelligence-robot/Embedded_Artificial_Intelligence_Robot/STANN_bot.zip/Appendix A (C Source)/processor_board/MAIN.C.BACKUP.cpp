#include <avr\io.h>

#include <avr\signal.h>

//need cli() and sei() macros
#include <avr\interrupt.h>


#define DDR_SB_DATABUS		DDRE
#define PORT_SB_DATABUS		PORTE
#define PIN_SB_DATABUS		PINE

#define DDR_SB_ADDRBUS   	DDRB
#define PORT_SB_ADDRBUS   	PORTB
#define PIN_SB_ADDRBUS   	PINB

#define DDR_SB_MISC			DDRD
#define PORT_SB_MISC			PORTD
#define PIN_SB_MISC			PIND

#define SB_CLK_PIN		1
#define SB_WR_REQ_PIN 	5
#define SB_WR_STAT_PIN	0
#define SB_REQ_SBC_PIN	6

void												sb_get_data
	(
   unsigned char *			address,
   unsigned char *			data
   );

void												sb_send_data
	(
   unsigned char				address,
   unsigned char				data
   );


//interrupt setup routines (macros technically)
#define setup_INT0_falling_edge()	(EICRA |= 1<<ISC01)

//delay routine
// 3 cycles/loop
static inline void							delay_1
	(
   unsigned char __counter
   )
	{
	asm volatile
   	(
		"1: dec %0" "\n\t"
		"brne 1b"
		: "=r" (__counter)
		: "0" (__counter)
		);
	}


int												main
	(
   void
   )
   {

   //Databus and addrbus taken care of by interrupt routine, no need to
   //set them, as well as CLK

   //setup INT0 (the WR_STAT line) interrupt to occur on a falling edge
   setup_INT0_falling_edge();
   //enable interrupts
   sei();

   while(1);

   //set WR_REQ and REQ_SBC to outputs and LOW
   DDR_SB_MISC |= 1<<SB_WR_REQ_PIN || 1<<SB_REQ_SBC_PIN;
   PORT_SB_MISC &= ~(1<<SB_WR_REQ_PIN || 1<<SB_REQ_SBC_PIN);

   //send out some data
   sb_send_data(0x02 ,0x0f);


   return 1;
   }


void												sb_send_data
	(
   unsigned char				address,
   unsigned char				data
   )
   {
   //ask for write status
   PORT_SB_MISC |= 1<<SB_WR_REQ_PIN;

   //wait for it to be returned (SB_WR_STAT_PIN to go HIGH)
   while(!(PIN_SB_MISC & 1<<SB_WR_STAT_PIN))
   	{
      continue;
      }

   //make sure clock is low
   PORT_SB_MISC &= ~(1<<SB_CLK_PIN);

   //output databyte
   PORT_SB_DATABUS = data;
   //output address, making sure to only affect lower 5 bits
   PORT_SB_ADDRBUS = address | (PORT_SB_ADDRBUS & 0xE0);

   //pulse clock HIGH
   PORT_SB_MISC |= 1<<SB_CLK_PIN;

   //wait several cycles
   delay_1(4);

   //bring clock LOW
   PORT_SB_MISC &= ~(1<<SB_CLK_PIN);

   //drop write status
   PORT_SB_MISC &= ~(1<<SB_WR_STAT_PIN);

   return;
   }

void												sb_get_data
	(
   unsigned char *			address,
   unsigned char *			data
   )
   {

   //wait until CLK goes high, meaning new data is ready
   while(PORT_SB_MISC & (1<<SB_CLK_PIN))
   	{
      continue;
      }

   *address = PIN_SB_ADDRBUS;
   *data = PIN_SB_DATABUS;
   
   return;
   }
   






/********************Interrupt Stuff ONLY past this point*********************/

/*The WR_STAT line has gone LOW (falling edge), so make sure to tristate
the SB_DATBU lines, SB_ADDRBUS lines and SB_CLK */
SIGNAL(SIG_INTERRUPT0)
	{
   //set Data Direction Register of DATABUS to tristate pins
   DDR_SB_DATABUS = 0x00;
   PORT_SB_DATABUS = 0x00;

   //set Data Direction Register of ADDRBUS to tristate pins
   DDR_SB_ADDRBUS &= ~(0x1F);
   PORT_SB_DATABUS  = ~(0x1F);

   //set CLK to tristate
   DDR_SB_MISC &= ~(1<<SB_CLK_PIN);
   PORT_SB_MISC &= ~(1<<SB_CLK_PIN);
   }

/* Default interrupt, SHOULD NEVER OCCUR */
//SIGNAL(__vector_default)
//	{
//   }


