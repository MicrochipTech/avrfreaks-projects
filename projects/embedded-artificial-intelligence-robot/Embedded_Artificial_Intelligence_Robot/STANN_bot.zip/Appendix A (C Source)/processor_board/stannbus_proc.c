/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*This module is the processor board's communication with the rest of the boards.
See header file for more information on each routine */

#include <avr\io.h>
#include <avr\delay.h>

#include <avr\signal.h>
//need cli() and sei() macros
#include <avr\interrupt.h>

//StannBus Commands
#include "..\commands.h"

#include "stannbus_proc.h"

#define DDR_SB_DATABUS		DDRE
#define PORT_SB_DATABUS		PORTE
#define PIN_SB_DATABUS		PINE

#define DDR_SB_ADDRBUS   	DDRB
#define PORT_SB_ADDRBUS   	PORTB
#define PIN_SB_ADDRBUS   	PINB

#define DDR_SB_MISC			DDRD
#define PORT_SB_MISC			PORTD   
#define PIN_SB_MISC			PIND

#define SB_CLK_PIN		1
#define SB_WR_REQ_PIN 	5
#define SB_WR_STAT_PIN	0
#define SB_REQ_SBC_PIN	6

//interrupt setup routines (macros technically)
#define setup_INT0_falling_edge()	(EICRA |= 1<<ISC01)
#define enable_INT0()					(EIMSK |= 1<<INT0)
#define setup_INT1_rising_edge()		(EICRA |= 1<<ISC11 | 1<<ISC10)
#define enable_INT1()					(EIMSK |= 1<<INT1)


#define MESSAGE_BUFFER_SIZE			10

//hold the data read from the bus
unsigned char 					read_data[MESSAGE_BUFFER_SIZE + 1];
//hold the address that the data came from
unsigned char					read_addr[MESSAGE_BUFFER_SIZE + 1];
//holds the location of the last data written
unsigned char					new_data_counter;
//holds the location of the last data read
unsigned char					data_read_counter;

/*
Initilize all the hardware needed for the STANNBus Interface, including the
interrupts
*/
void												init_stannbus
	(
   void
   )
   {
   //Databus and addrbus taken care of by interrupt routine, no need to
   //set them, as well as CLK

   //setup INT0 (the WR_STAT line) interrupt to occur on a falling edge
   setup_INT0_falling_edge();
   //enable it
   enable_INT0();

   //setup INT1 (the CLK line) interrupt to occur on rising edge
	setup_INT1_rising_edge();
   //enable it
	enable_INT1();

   //enable interrupts
   sei();

   //set WR_REQ and REQ_SBC to outputs and LOW
   DDR_SB_MISC |= 1<<SB_WR_REQ_PIN | 1<<SB_REQ_SBC_PIN;
   PORT_SB_MISC &= ~(1<<SB_WR_REQ_PIN | 1<<SB_REQ_SBC_PIN);

   return;
   }



/*
Initilize CMUCam and track the object held in its main field of view.
*/

void												cmucam_init
	(
   void
   )
   {
   sb_send_data(SENSOR_ADDRESS, COMMAND_START_TRACKING);

   return;
   }

/*
Get the position of the object. Returns between 0 to around 450. However also
possible are -9 which means 'Camera not found' and -6 which means 'object not in
camera view'
*/
int												cmucam_get_position
	(
   void
   )
   {
   unsigned char				address;
   unsigned char				data;
   int							data2;

   sb_get_data_clear_buffers();
  	sb_send_data(SENSOR_ADDRESS, COMMAND_GET_POS);

  	while (sb_get_data(&address, &data) == NO_DATA)
     	{
      continue;
      }

   data2 = data;

  	while (sb_get_data(&address, &data) == NO_DATA)
     	{
      continue;
      }

   data2 |= data << 8;

   return data2;
   }

int												sonar_get_distance
	(
   void
   )
   {
   unsigned char				address;
   unsigned char				data;
   int							data2;

   sb_get_data_clear_buffers();
  	sb_send_data(SENSOR_ADDRESS, COMMAND_ULTRASONIC);

  	while (sb_get_data(&address, &data) == NO_DATA)
     	{
      continue;
      }

   data2 = data;

  	while (sb_get_data(&address, &data) == NO_DATA)
     	{
      continue;
      }

   data2 |= data << 8;

   return data2;
   }


void												vfd1_clear
	(
   void
   )
   {
   sb_send_data(VFD1_ADDRESS, 1);

   return;
   }


void												vfd1_send_message
	(
   char 						  	message[]
   )
   {
   unsigned char i = 0;

   while (message[i] != '\0' && i != 0xFF)
   	{
      _delay_loop_2(300);
      sb_send_data(VFD1_ADDRESS, message[i]);
      i++;
      }

   return;
   }


void												sb_send_data
	(
   unsigned char				address,
   unsigned char				data
   )
   {
   //ask for write status
   PORT_SB_MISC |= 1<<SB_WR_REQ_PIN;

   //wait for it to be returned (SB_WR_STAT_PIN to go HIGH)
   while(!(PIN_SB_MISC & 1<<SB_WR_STAT_PIN))
   	{
      continue;
      }

	//set databus to output
	DDR_SB_DATABUS = 0xFF;

   //set addressbus to output
   DDR_SB_ADDRBUS |= 0x1F;

   //set CLK low
   PORT_SB_MISC &= ~(1<<SB_CLK_PIN);

   //set CLK to output
   DDR_SB_MISC |= 1<<SB_CLK_PIN;

   //output databyte
   PORT_SB_DATABUS = data;
   //output address, making sure to only affect lower 5 bits
   PORT_SB_ADDRBUS = address | (PORT_SB_ADDRBUS & 0xE0);

   //pulse clock HIGH
   PORT_SB_MISC |= 1<<SB_CLK_PIN;

   //wait several cycles
   _delay_loop_1(10);

   //bring clock LOW
   PORT_SB_MISC &= ~(1<<SB_CLK_PIN);

   //drop write status
   PORT_SB_MISC &= ~(1<<SB_WR_REQ_PIN);

   return;
   }



void												sb_get_data_clear_buffers
	(
   void
   )
   {

   //clear interrupts
   cli();

   //wait out
   _delay_loop_1(100);

   data_read_counter = 0;
   new_data_counter = 0;

   //return ints
   sei();

   return;
   }


unsigned char									sb_get_data
	(
   unsigned char *			address,
   unsigned char *			data
   )
   {

   //check for new data
   if (data_read_counter == new_data_counter)
   	{
      //no new data
      return NO_DATA;
      }

   //select next location
   data_read_counter++;
   if (data_read_counter > MESSAGE_BUFFER_SIZE)
   	{
      data_read_counter = 0;
      }

   *address = read_addr[data_read_counter];
   *data = read_data[data_read_counter];

   //new data found
   return NEW_DATA;
   }


/********************Interrupt Stuff ONLY past this point*********************/

/*The WR_STAT line has gone LOW (falling edge), so make sure to tristate
the SB_DATBU lines, SB_ADDRBUS lines and SB_CLK */
SIGNAL(SIG_INTERRUPT0)
	{
   //set Data Direction Register of DATABUS to tristate pins
   DDR_SB_DATABUS = 0x00;
   PORT_SB_DATABUS = 0x00;

   //set Data Direction Register of ADDRBUS to tristate pins
   DDR_SB_ADDRBUS &= ~(0x1F);
   PORT_SB_ADDRBUS  &= ~(0x1F);

   //set CLK to tristate
   DDR_SB_MISC &= ~(1<<SB_CLK_PIN);
   PORT_SB_MISC &= ~(1<<SB_CLK_PIN);
   }

SIGNAL(SIG_INTERRUPT1)
	{
   //check if this board is writing the data, in which case we can ignore it...
   if (PIN_SB_MISC & 1<<SB_WR_REQ_PIN)
   	{
      return;
      }

   new_data_counter++;

   if (new_data_counter > MESSAGE_BUFFER_SIZE)
   	{
      new_data_counter = 0;
      }
      
   read_data[new_data_counter] = PIN_SB_DATABUS;
   read_addr[new_data_counter] = PIN_SB_ADDRBUS;
   }

/* Default interrupt, SHOULD NEVER OCCUR */
SIGNAL(__vector_default)
	{
   }

