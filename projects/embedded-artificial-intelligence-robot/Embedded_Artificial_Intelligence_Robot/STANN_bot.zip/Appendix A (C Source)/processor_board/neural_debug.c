/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*
These routines are placed on the processor board. These routines are responsable
for debugging and working with the neural networks.
*/

#include "neural_debug.h"
#include "uart.h"

#include "neural_net\options.h"
#include "neural_net\data_access_utilities.h"
#include "neural_net\data_access.h"
#include "neural_net\MLP.h"

#include <stdlib.h>

//defines ftoa
#define ftoa(f, s) dtostrf((double)f, 8, 5, s)

//defines atof as the avr-libc version, however future stdlib.h may already have
//this definition built-in
#define atof(s) strtod(s, (char **)0)

#define CHARS_FOR_NDB		3
#define ARGSIZE				10

#define NTYPE_SOURCE 0
#define NTYPE_DEST 1

/* This routine is used by debugnet, and gets the commands and arguments from
the (ndb) prompt */
void												get_netdebug_command
	(
   char 							command[],
   unsigned char *			numargs,
   char 							argument[][ARGSIZE]
   );


   
void 												runnet
	(
   void
   )
	{
   unsigned char				number_of_input_data = 0;
   unsigned char				number_of_output_data = 0;
   struct neuron_list_t		neuron;
   float  						input_data_array[10];
   float  						output_data_array[10];
   char							string[30];
   unsigned char				string_index;
   unsigned char				count;

   neuron.layer = 'A';

   //find number of input neurons
   select_first_neuron(0);
   neuron.neuron = 1;
   while (number_of_input_data < 11 && neuron.layer == 'A')
   	{
      number_of_input_data = neuron.neuron;
      select_next_neuron(0);
      get_current_neuron(&neuron, 0);
      }

   //find number of output neurons
   while (neuron.next_address != 0)
   	{
      select_next_neuron(0);
      get_current_neuron(&neuron, 0);
      }

   number_of_output_data = neuron.neuron;
   if (number_of_output_data > 10)
   	{
      number_of_output_data = 10;
      }

   //get input data

   count = 0;
   string_index = 0;
   //count = 0 when number_of_input_data = 1, thats important to remember
   while (count < number_of_input_data)
  		{
   	send_string_P(PSTR("\nInput data for input neuron "));
   	itoa((count + 1), string, 10);
   	send_string(string);
   	send_string_P(PSTR(" :"));
      do
   		{
      	//get char
	   	string[string_index] = input_ch_1();
      	//echo it
      	output_ch_1(string[string_index]);

      	string_index++;

	   	//wait until a CR, and prevent from going outside the string!!
      	} while (string[string_index - 1] != '\r' && string_index < 30);
      string[string_index - 1] = '\0';
      input_data_array[count] = atof(string);

      count++;
      }
      
	run_through_neural_network(input_data_array, number_of_input_data, output_data_array, number_of_output_data);

   //output output data
 	count = 0;
   string_index = 0;
   //count = 0 when number_of_input_data = 1, thats important to remember
   while (count < number_of_output_data)
  		{
   	send_string_P(PSTR("\nOutput data for output neuron "));
   	itoa((count + 1), string, 10);
   	send_string(string);
   	send_string_P(PSTR(" :"));
		ftoa(output_data_array[count], string);
		send_string(string);
      count++;
      }
   return;

   }

void 												loadnet
	(
   void
   )
   {
   char							ch[20];
   unsigned char				ch_counter;
   char							ch_one;

   unsigned char				number_layers;
   unsigned char				neurons_per_layer[10];
   unsigned char				counter;

   //output message
   send_string_P(PSTR("\nWaiting for neuron file, to abort type ;Q\n"));

   //first, wait for the start of the neuron file
	while (input_ch_1() != ';')
   	{
      continue;
      }

   ch_counter = 0;

   ch[ch_counter] = input_ch_1();

   if (ch[ch_counter] == 'Q')
   	{
      return;
      }

   //get one string of data
   while (ch_counter < 18 && ch[ch_counter] != '#')
   	{
      ch_counter++;
      ch[ch_counter] = input_ch_1();
      }

   //add null char to string in place of #
   ch[ch_counter] = '\0';

   //check if it is ".STARTNEURAL" which it must be, otherwise exit
   if (strncmp(".STARTNEURAL", ch, 11) != 0)
   	{
      send_string_P(PSTR("\nError: .STARTNEURAL not first command"));
      return;
      }

   //get number of layers
   //get one string of data
	while (input_ch_1() != ';')
   	{
      continue;
      }
   ch_counter = 0;
   while (ch_counter < 18 && ch[ch_counter - 1] != '#')
   	{
      ch[ch_counter] = input_ch_1();
      ch_counter++;
      }

	//replace the # with the end of string
   ch[--ch_counter] = '\0';

   //store number of layers
   number_layers = atoi(ch);
   send_string(ch);

   //get neurons per layer
   counter = 0;
   while (counter < number_layers)
   	{
   	//get one string of data
		while (input_ch_1() != ';')
   		{
      	continue;
      	}
   	ch_counter = 0;
   	while (ch_counter < 18 && ch[ch_counter - 1] != '#')
   		{
      	ch[ch_counter] = input_ch_1();
      	ch_counter++;
      	}

		//replace the # with the end of string
      ch[--ch_counter] = '\0';

   send_string(ch);

      neurons_per_layer[counter] = atoi(ch);

      counter++;
      }

   create_neuron_list(number_layers, neurons_per_layer);
   create_weight_list(1);

   return;
   }




void 												makenet
	(
   void
   )
   {

	unsigned char				hidden_layers;
   unsigned char				neurons_per_layer[10];
	char							string[10];
   unsigned char				counter;

	send_string_P(PSTR("\n\n\nCreate Neural Network\n"));
   send_string_P(PSTR("How many hidden layers? "));
   //get response
   hidden_layers = get_uart1_input_number();
   send_string_P(PSTR("\nHow many input neurons? "));
   neurons_per_layer[0] = get_uart1_input_number();


   counter = 0;

   while(counter != hidden_layers)
      {
      counter++;
   	send_string_P(PSTR("\nHow many neurons on hidden layer "));
      output_ch_1(counter + '0');
		send_string_P(PSTR("? "));
   	//get response
   	neurons_per_layer[counter] = get_uart1_input_number();
      }


   send_string_P(PSTR("\nHow many output neurons? "));
   counter++;
   neurons_per_layer[counter] = get_uart1_input_number();

   send_string_P(PSTR("\n\nAbout to create the following neural network:\n"));
	send_string_P(PSTR("\nNeurons on input layer: "));

   itoa(neurons_per_layer[0], string, 10);
   send_string(string);

   counter = 0;

 	while(counter != hidden_layers)
      {
      counter++;
   	send_string_P(PSTR("\nNeurons on hidden layer "));
      output_ch_1(counter + '0');
		send_string_P(PSTR(": "));
      itoa(neurons_per_layer[counter], string, 10);
   	send_string(string);
      }

 	send_string_P(PSTR("\nNeurons on output layer: "));

   itoa(neurons_per_layer[++counter], string, 10);
   send_string(string);

   send_string_P(PSTR("\n\nContinue? (y/n): "));

   if (input_ch_1() != 'y')
   	{
      return;
      }

   create_neuron_list(counter + 1, neurons_per_layer);
   create_weight_list(1);

   send_string_P(PSTR("\nNeural Network Created\n\n"));

   return;
   }

void 												debugnet
	(
   void
   )
	{
   //command data
   char							command[20];
   //argument data
   char							argument[5][ARGSIZE];
   //how many arguments
	unsigned char 				numargs;

   //general purpose
   struct weight_list_t		weight;
   struct neuron_list_t		neuron;
   char							string[10];


   static unsigned char		ntype;

   static unsigned char		wtype;


   //general purpose array index
   unsigned char				i;


   while(1) {

  	get_netdebug_command(command, &numargs, argument);

   if (strcmp_P(command, PSTR("quit")) == 0)
   	{
      return;
      }
//-----START NEURON COMMANDS

   else if (strncmp_P(command, PSTR("ntype"), CHARS_FOR_NDB) == 0)
   	{

      if (numargs != 1)
      	{
         send_string_P(PSTR("\nntype useage: ntype [TYPE] where type is SOURCE or DEST"));
         }
      else
      	{
         if (argument[0][0] == 'S')
         	{
            send_string_P(PSTR("\nntype set to: SOURCE"));
            ntype = NTYPE_SOURCE;
            }
         else if (argument[0][0] == 'D')
         	{
            send_string_P(PSTR("\nntype set to: DEST"));
            ntype = NTYPE_DEST;
            }
         else
         	{
            send_string_P(PSTR("\nUnable to recognize argument: "));
            send_string(argument[0]);
            }
         }
      }

   else if (strncmp_P(command, PSTR("nfirst"), CHARS_FOR_NDB) == 0)
   	{
      if (select_first_neuron(ntype) == NO_ERROR)
      	{
      	send_string_P(PSTR("\nfirst neuron selected for "));
      	if (ntype == NTYPE_SOURCE)
      		{
         	send_string_P(PSTR("SOURCE neuron list"));
         	}
      	else
      		{
         	send_string_P(PSTR("DEST neuron list"));
         	}
         }
      else
      	{
         send_string_P(PSTR("\nError selecting first neuron"));
         }
      }
   else if (strncmp_P(command, PSTR("nnext"), CHARS_FOR_NDB) == 0)
   	{
      if (select_next_neuron(ntype) == NO_ERROR)
      	{
      	send_string_P(PSTR("\nnext neuron selected for "));
      	if (ntype == NTYPE_SOURCE)
      		{
         	send_string_P(PSTR("SOURCE neuron list"));
         	}
      	else
      		{
         	send_string_P(PSTR("DEST neuron list"));
         	}
         }
      else
      	{
         send_string_P(PSTR("\nError selecting next neuron"));
         }
      }
   else if (strncmp_P(command, PSTR("nnum"), CHARS_FOR_NDB) == 0)
   	{
      send_string_P(PSTR("\nnum not yet implemented"));
      }
   else if (strncmp_P(command, PSTR("nspecified"), CHARS_FOR_NDB) == 0)
   	{
      if (numargs != 2)
      	{
         send_string_P(PSTR("\nnspecified useage: nspecified [LAYER] [NEURON]"));
         }
      else
      	{
         if (select_specified_neuron(argument[0][0], atoi(argument[1]), 1, ntype) == NO_ERROR)
         	{
      	  	send_string_P(PSTR("\nneuron "));
            output_ch_1(argument[0][0]);
            send_string(argument[1]);
            send_string_P(PSTR(" selected for "));
      		if (ntype == NTYPE_SOURCE)
      			{
         		send_string_P(PSTR("SOURCE neuron list"));
         		}
      		else
      			{
         		send_string_P(PSTR("DEST neuron list"));
         		}
         	}
         else
         	{
            send_string_P(PSTR("\nError selecting specified neuron"));
            }
         }
      }
   else if (strncmp_P(command, PSTR("nselectweight"), CHARS_FOR_NDB) == 0)
   	{

		if (select_weight_dest_of_current_neuron(ntype, wtype) == NO_ERROR)
   		{
      	send_string_P(PSTR("\nCurrent input weight selected for "));
      	if (ntype == NTYPE_SOURCE)
      		{
         	send_string_P(PSTR("SOURCE"));
         	}
      	else
      		{
         	send_string_P(PSTR("DEST"));
         	}
         send_string_P(PSTR(" neuron list, weight stored on weight list "));
         output_ch_1(wtype + '0');
         }
      else
      	{
         send_string_P(PSTR("\nFailed getting input weight for current neuron"));
         }
      }
   else if (strncmp_P(command, PSTR("nget"), CHARS_FOR_NDB) == 0)
   	{

      if (get_current_neuron(&neuron, ntype) == NO_ERROR)
      	{
         send_string_P(PSTR("\nValue of current neuron on "));
      	if (ntype == NTYPE_SOURCE)
      		{
         	send_string_P(PSTR("SOURCE neuron list:"));
         	}
      	else
      		{
         	send_string_P(PSTR("DEST neuron list:"));
         	}

         send_string_P(PSTR("\nLayer:   "));
         output_ch_1(neuron.layer);
         send_string_P(PSTR("\nNeuron:  "));
         itoa(neuron.neuron, string, 10);
         send_string(string);
         send_string_P(PSTR("\nValue: "));
			dtostrf(neuron.neuron_value, 10, 6, string);
			send_string(string);
         }
      else
      	{
         send_string_P(PSTR("Error getting current neuron"));
			}

      }
   else if (strncmp_P(command, PSTR("nput"), CHARS_FOR_NDB) == 0)
   	{
      if (numargs != 3)
      	{
         send_string_P(PSTR("\nnput useage: nput [layer] [neuron] [neuron value]\
\n [layer] is layer neuron is on (A-E), [neuron] is neuron number (1-255), \
[neuron value] is output value of neuron. Suggested to use nget before nput."));
         }
      else
      	{

         get_current_neuron(&neuron, ntype);

         neuron.layer = argument[0][0];
         neuron.neuron = atoi(argument[1]);
         neuron.neuron_value = atof(argument[2]);

         if (put_current_neuron(&neuron, ntype) == NO_ERROR)
         	{
            send_string_P(PSTR("\nCurrent neuron modified for "));
       		if (ntype == NTYPE_SOURCE)
      			{
         		send_string_P(PSTR("SOURCE neuron list"));
         		}
      		else
      			{
         		send_string_P(PSTR("DEST neuron list"));
         		}
            }
         else
         	{
            send_string_P(PSTR("\nError writing current neuron"));
            }
         }
      }

//-----START WEIGHT COMMANDS

   else if (strncmp_P(command, PSTR("wtype"), CHARS_FOR_NDB) == 0)
   	{

      if (numargs != 1)
      	{
         send_string_P(PSTR("\nwtype useage: wtype [WYPE] where wtype is 0 or 1"));
         }
      else
      	{
         if (argument[0][0] == '0')
         	{
            send_string_P(PSTR("\nwtype set to: 0"));
            wtype = 0;
            }
         else if (argument[0][0] == '1')
         	{
            send_string_P(PSTR("\nwtype set to: 1"));
            wtype = 1;
            }
         else
         	{
            send_string_P(PSTR("\nUnable to recognize argument: "));
            send_string(argument[0]);
            }
         }
      }

   else if (strncmp_P(command, PSTR("wfirst"), CHARS_FOR_NDB) == 0)
   	{
      if (select_first_weight(wtype) == NO_ERROR)
      	{
      	send_string_P(PSTR("\nfirst weight selected for weight list "));
      	output_ch_0(wtype + '0');
         }
      else
      	{
         send_string_P(PSTR("\nError selecting first weight"));
         }
      }
   else if (strncmp_P(command, PSTR("wnext"), CHARS_FOR_NDB) == 0)
   	{
      if (select_next_weight(wtype) == NO_ERROR)
      	{
      	send_string_P(PSTR("\nnext weight selected for weight list "));
      	output_ch_0(wtype + '0');
         }
      else
      	{
         send_string_P(PSTR("\nError selecting next weight"));
         }
      }

   else if (strncmp_P(command, PSTR("wget"), CHARS_FOR_NDB) == 0)
   	{

      if (get_current_weight(&weight, wtype) == NO_ERROR)
      	{
         send_string_P(PSTR("\nValue of current weight on list "));
         output_ch_0('0' + wtype);

         send_string_P(PSTR("\nSource Layer:   "));
         output_ch_1(weight.src_layer);
         send_string_P(PSTR("\nSource Neuron:  "));
         itoa(weight.src_neuron, string, 10);
         send_string(string);
         send_string_P(PSTR("\nDest Layer:     "));
         output_ch_1(weight.dest_layer);
         send_string_P(PSTR("\nDest Neuron:    "));
         itoa(weight.dest_neuron, string, 10);
         send_string(string);

         send_string_P(PSTR("\nValue: "));
			dtostrf(weight.weight_value, 10, 6, string);
			send_string(string);

         send_string_P(PSTR("\nNext Address:   "));
         itoa(weight.next_address, string, 10);
         send_string(string);
         }
      else
      	{
         send_string_P(PSTR("Error getting current weight"));
         }

      }
   else if (strncmp_P(command, PSTR("wput"), CHARS_FOR_NDB) == 0)
   	{
      if (numargs != 5)
      	{
         send_string_P(PSTR("\nwput useage: wput [src layer] [src neuron] [dest layer] [dest neuron] [weight value]\
\n[src layer] is layer source neuron is on (A-E)\n[src neuron] is source neuron\
number (1-255)\n[dest layer] is layer destination neuron is on (A-E)\n\
[dest neuron] is destination neuron number (1-255)\n[weight value] is value of\
weight. Suggested to use wget before wput."));
         }
      else
      	{

         get_current_weight(&weight, wtype);

         weight.src_layer = argument[0][0];
         weight.src_neuron = atoi(argument[1]);
         weight.dest_layer = argument[2][0];
         weight.dest_neuron = atoi(argument[3]);
         weight.weight_value = atof(argument[4]);

         if (put_current_weight(&weight, wtype) == NO_ERROR)
         	{
            send_string_P(PSTR("\nCurrent weight modified for weight list "));
       		output_ch_1(wtype + '0');
            }
         else
         	{
            send_string_P(PSTR("\nError writing current weight"));
            }
         }
      }

   else if (strncmp_P(command, PSTR(""), CHARS_FOR_NDB) == 0)
   	{
      }
   else if (strncmp_P(command, PSTR("help"), CHARS_FOR_NDB) == 0)
   	{
      send_string_P(PSTR("\nBuilt-in help for Neural De-Bugger (nbd)"));
      send_string_P(PSTR("\nTODO: Add help"));
      }
   else
   	{
      send_string_P(PSTR("\nUnknown command: "));
      send_string(command);
      }
   }

   return;
   }



void												get_netdebug_command
	(
   char 							command[],
   unsigned char *			numargs,
   char 							argument[][ARGSIZE]
   )
   {
   unsigned char 				string_index = 0;
   unsigned char				arg_index;
   //character
   char							data;


   //reset numargs
   *numargs = 0;

   //give Neural Network Debugger prompt
   send_string_P(PSTR("\n(ndb) "));

   do
   	{
      //get char
	   command[string_index] = input_ch_1();
      //echo it
      output_ch_1(command[string_index]);

      string_index++;

	   //wait until a space  or CR
      } while (command[string_index - 1] != ' ' && command[string_index - 1] != '\r');

   //check for CR
   if (command[string_index - 1] == '\r')
   	{
   	//put in null character in place of CR
   	command[string_index - 1] = '\0';

    	return;
     	}

   //put in null character in place of space
   command[string_index - 1] = '\0';

   //first char of first string
   string_index = 0;
   arg_index = 0;

   while(1)
   	{
      //get char
      data = input_ch_1();

      //echo it
      output_ch_1(data);

      //see if it is a space
      if (data == ' ')
      	{
         //set end of string to null
         argument[arg_index][string_index] = '\0';
         //next arg
         arg_index++;
         //specify number of arguments
         *numargs = *numargs + 1;
         //back to first char in string
         string_index = 0;
         }
      //see if data is a character return
      else if (data == '\r')
      	{
         //set end of string to null
         argument[arg_index][string_index] = '\0';
         //specify number of arguments
         *numargs = *numargs + 1;
         //return
         return;
         }

      else
      	{
         argument[arg_index][string_index] = data;

         //make sure to not mess around with memory that we shouldn't!!!!!
         if (ARGSIZE != string_index)
         	{
         	//next char in string
         	string_index++;
            }

         }

      }


   return;
   }
