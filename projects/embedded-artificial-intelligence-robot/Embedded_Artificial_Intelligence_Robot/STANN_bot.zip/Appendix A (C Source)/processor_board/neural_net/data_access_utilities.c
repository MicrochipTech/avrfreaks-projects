/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code */

/* This module has the data access utilities in it, which are various routines
for working with the weight_list and neuron_ouput data sets. These are NOT the
routines that perform the access to them, instead they simply perform matinence
on them */

/* contains many options for this module as well as all the modules in general
also contains the type definitions
NOTE: The "options.h" file must be the first file defined */
#include "options.h"

#include "data_access_utilities.h"
#include "low_level_data_access.h"
#include "AVR_rand.h"

#include <avr\pgmspace.h>


/* This routine will set aside the storage space that will store the neuron list.
number_of_layers is between 1 to 6 and is the number of layers. Each element
in the array holds the number of neurons in that layer. so neurons_per_layer[0]
has the number of neurons in the first layer (layer A), neurons_per_layer[1]
has the number of neurons in the second layer (layer B) and so on. The return
value is 0 = no error, 1 = too many layers (6 is max, for no reason other than
these routines aren't designed to work with a huge neuron network) ,
2 = internal error (storage media faliure, other errors along that line) */

unsigned int 									create_neuron_list
	(
   unsigned char				number_of_layers,
   unsigned char*				neurons_per_layer
   )
   {

   //stores the neuron information
   struct neuron_list_t		neuron;

   //stores current neuron's address location
   unsigned int				neuron_address;

   //stores current layer in numerical format (instead of how neuron.layer does)
   unsigned char				current_layer;

   //do an out of bounds check
   if (number_of_layers > MAX_LAYERS)
   	{
      return OUT_OF_BOUNDS_ERROR;
      }

   //initilize neuron list
   neuron.layer 			= 'A';
   current_layer 			= 1;
   neuron.neuron 			= 1;
   neuron.neuron_value 	= 0;
   neuron.next_address 	= 2;
   neuron_address 		= 1;

   //write the table until the last neuron is written, then stop
   while (neuron.next_address != 0)
      {
      //write data to table
      if (low_level_write_neuron_output(neuron_address, &neuron) != 0)
      	{
         return INTERNAL_ERROR;
         }

      //Set up the next neuron in the list, but checking a few things
      //check for last neuron in network
   	if ((current_layer == number_of_layers) &&
   	 	(neuron.neuron == neurons_per_layer[current_layer - 1]))
       	{
       	neuron.next_address = 0;
         //write data to table
      	if (low_level_write_neuron_output(neuron_address, &neuron) != 0)
      		{
         	return INTERNAL_ERROR;
         	}
       	}
   	//check for last neuron on layer
   	else if (neurons_per_layer[current_layer - 1] == neuron.neuron)
   		{
      	current_layer++;
      	neuron.layer++;
      	neuron.neuron = 1;
  	      neuron.next_address++;
   		neuron_address++;
      	}
      //otherwise just move everything up by one
		else
      	{
	     	neuron.neuron++;
	      neuron.next_address++;
   		neuron_address++;
         }
      }

      return NO_ERROR;
   }

/* This routine will create a weight list based on a neuron list. As such,
you need to have already run create_neuron_list. As well it will link the
frst_weight_addr of the neuron list to the weight list.
The return value is 0 = all went okay, 2 = some sort of internal error */

unsigned int									create_weight_list
	(
   unsigned int				starting_neuron_address
   )
   {
   struct neuron_list_t		fakeneuron;
   struct weight_list_t		fakeweight;
   unsigned char				neurons_per_layer[6] = {0};
   unsigned char				dest_layer_counter;
   unsigned char				dest_neuron_counter;
   unsigned char				src_layer_counter;
   unsigned char				src_neuron_counter;
   unsigned char				max_layers;
   unsigned int				address;

   unsigned int				neuron_address;

   char ch[20];


   //address first neuron to get the address of the next one
   if (low_level_read_neuron_output(starting_neuron_address, &fakeneuron) ==
      	 NO_ERROR)
   	{
      //store neuron number in neurons_per_layer array
      neurons_per_layer[fakeneuron.layer - 'A'] = fakeneuron.neuron;
      //until the chain ends, keep getting new neuron numbers
      do
      	{      	
         if (low_level_read_neuron_output(fakeneuron.next_address,
          	&fakeneuron)==	NO_ERROR)
         	{
            neurons_per_layer[fakeneuron.layer - 'A'] = fakeneuron.neuron;
            }
         else
         	{
            return INTERNAL_ERROR;
            }
         } while (fakeneuron.next_address != 0);
         
         max_layers = fakeneuron.layer;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   //now neurons_per_layer array says how many neurons each layer has, max_layers has
   //what last layers is

   fakeneuron.next_address = 1;
   fakeneuron.layer = 'A';
   fakeneuron.neuron = 1;
   
   //get address of neuron B1
   while (fakeneuron.layer != 'B' || fakeneuron.neuron != 1)
   	{
      neuron_address = fakeneuron.next_address;
      low_level_read_neuron_output(neuron_address, &fakeneuron);
      }


   send_string_P(PSTR("\nStarting Neuron: "));
   output_ch_1(fakeneuron.layer);
   output_ch_1(fakeneuron.neuron + '0');

   //Now the harder part, linking all the neurons together with a WEIGHT list

   //start on neuron 1, Layer A as first source
	src_layer_counter = 'A';
   src_neuron_counter = 1;
   //set address of first weight
   address = 1;

   //Start counting destination neurons
   dest_layer_counter = 'B';
   dest_neuron_counter = 1;

   //while there is still layers left
   while (dest_layer_counter <= max_layers)
   	{
      //while there are still neurons left on the current layer
	   while (dest_neuron_counter <= neurons_per_layer[dest_layer_counter - 'A'])
      	{
         if (low_level_read_neuron_output(neuron_address, &fakeneuron) != NO_ERROR)
         	{
            return INTERNAL_ERROR;
            }
         fakeneuron.frst_weight_addr = address;
         if (low_level_write_neuron_output(neuron_address, &fakeneuron) != NO_ERROR)
         	{
            return INTERNAL_ERROR;
            }

         send_string_P(PSTR("\nWrote neuron "));
         output_ch_1(fakeneuron.layer);
   		output_ch_1(fakeneuron.neuron + '0');
         send_string_P(PSTR(" at address "));
         itoa(neuron_address, ch, 10);
         send_string(ch);
         send_string_P(PSTR(" with first weight address "));
         itoa(address, ch, 10);
         send_string(ch);


         //while there are still neurons left on the source layer
         while (src_neuron_counter <= neurons_per_layer[src_layer_counter - 'A'])
         	{
         	//set some random weights
         	get_rnd_float(&fakeweight.weight_value, LOWER_WEIGHT_LIMIT, UPPER_WEIGHT_LIMIT, 1);
            fakeweight.src_neuron = src_neuron_counter;
            fakeweight.src_layer = src_layer_counter;
            fakeweight.dest_neuron = dest_neuron_counter;
            fakeweight.dest_layer = dest_layer_counter;
            fakeweight.next_address = address + 1;
            if (low_level_write_weight_data(address, &fakeweight) != NO_ERROR)
            	{
               return INTERNAL_ERROR;
               }

         send_string_P(PSTR("\nWrote weight from "));
         output_ch_1(fakeweight.src_layer);
   		output_ch_1(fakeweight.src_neuron + '0');
         send_string_P(PSTR(" to "));
         output_ch_1(fakeweight.dest_layer);
   		output_ch_1(fakeweight.dest_neuron + '0');
         send_string_P(PSTR(" at address "));
         itoa(address, ch, 10);
         send_string(ch);

            address++;
            src_neuron_counter++;
            //neuron_address++;
            }
         //got to set next_address to 0 though now...

         fakeweight.next_address = 0;
         if (low_level_write_weight_data(address - 1, &fakeweight) != NO_ERROR)
           	{
            return INTERNAL_ERROR;
            }

         send_string_P(PSTR("\nSet weight's next_address to 0 at address "));
         itoa(address - 1, ch, 10);
         send_string(ch);

         //reset src_neuron_counter
         src_neuron_counter = 1;
         //go to next dest neuron
         dest_neuron_counter++;
         neuron_address++;
         }
      //reset src_neuron and dest_neuron counters
      src_neuron_counter = 1;
      dest_neuron_counter = 1;
      //increase layer counters
      src_layer_counter++;
      dest_layer_counter++;
   	}
  //creates one too many weights
  address--;
  fakeweight.next_address = 0;
  if (low_level_write_weight_data(address, &fakeweight) != NO_ERROR)
  		{
     	return INTERNAL_ERROR;
      }

         send_string_P(PSTR("\nSet weight's next_address to 0 at address "));
         itoa(address, ch, 10);
         send_string(ch);

   return NO_ERROR;
   }




