/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code

www.newae.com*/

/* This module has the actual neural network routines in it. */

#define MAX_INPUT_NEURONS 5
#define MAX_OUTPUT_NEURONS 5

char												run_through_neural_network
	(
	float							input_data_array[],
	unsigned char				number_of_input_data,
	float							output_data_array[],
	unsigned char				number_of_output_data
	);


int												train_neural_network
	(
   float 						input_data_array[][MAX_INPUT_NEURONS],
   float 						target_output_array[][MAX_OUTPUT_NEURONS],
   unsigned char				number_input_neurons,
   unsigned char				number_output_neurons,
   float							learn_rate,
   unsigned char				number_sets,
   float *						error,
   unsigned int				max_cycles
   );


float												activation_function
	(
	float							input_data
	);