/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code

www.newae.com*/

/* This module has the actual neural network routines in it. */


#include "options.h"
#include "low_level_data_access.h"
#include "data_access_utilities.h"
#include "data_access.h"
#include "MLP.h"

//these two includes for debugging only
#include <avr\pgmspace.h>
#include "uart.h"

#include <math.h>

#include <stdlib.h>
#define ftoa(f, s) dtostrf((double)f, 8, 5, s)

static unsigned char			final_layer = 'B';


char												run_through_neural_network
	(
	float							input_data_array[],
	unsigned char				number_of_input_data,
	float							output_data_array[],
	unsigned char				number_of_output_data
	)
	{
	struct weight_list_t		weight_data;
	struct neuron_list_t		neuron_data;
	unsigned char				counter;
	unsigned int				next_address;
	unsigned int				weight_address;
	unsigned int				src_neuron_address;
   unsigned int				next_dest_neuron_address;
   unsigned char 				last_neuron;
   float							sum;

   //for debugging only
   char							ch[20];
   char							ch2[20];
   int							n;

 //  send_string_P(PSTR("\nEntered Neural Network"));

	//check that the number of input data is 1 or greater
	if (number_of_input_data == 0)
		{
		return OUT_OF_BOUNDS_ERROR;
		}

#define SOURCE 			0
#define DESTINATION 		1
#define OUTPUT_NEURONS 	0
#define WEIGHT1			0

   /* Algorith used to get this neural network to work:
   1] Read input data into input neurons
	2] Get location of neuron B1, set that as destination neuron
   3] Get the first weight that links to the current destination neuron
	4] Find location of source neuron for current weight
	5] Clear 'sum'
		6] Read output value of source neuron
		7] Get value of weight
		8] Multiply result of step 6 and 7, add the product to 'sum'
		9] Get next weight
		10] Get next source neuron to current destination neuron
		11] If selecting next source neuron failed because no more inputs to
			 current destination neuron, goto step 12, else goto step 6
	12] Select next destination neuron
	13] If selecting next destination neuron failed because no more neurons,
		 goto step 14, else goto step 3
	14] Read output values of output neurons
   */

   src_neuron_address = 1;

   //1] Read input data into input neurons

   select_first_neuron(SOURCE);

   counter = 0;



	while (counter < number_of_input_data)
		{
      get_current_neuron(&neuron_data, SOURCE);
      neuron_data.neuron_value = input_data_array[counter];
      put_current_neuron(&neuron_data, SOURCE);
      select_next_neuron(SOURCE);
      counter++;
		}



	//2] Get location of neuron B1, set that as destination neuron
	select_specified_neuron('B', 1, 1, DESTINATION);


   do
   	{
   	//3] Get the first weight that links to the current destination neuron
		select_weight_dest_of_current_neuron(DESTINATION, WEIGHT1);
      get_current_weight(&weight_data, WEIGHT1);

      //4] Find location of source neuron for current weight

      //optimized guess of location
		select_specified_neuron(weight_data.src_layer,
									weight_data.src_neuron, 1, SOURCE);


		//5] Clear 'sum'
		sum = 0.0;

 	  	while(1)
  		 	{
			//6] Read output value of source neuron
         get_current_neuron(&neuron_data, SOURCE);

			//7] Get value of weight
         get_current_weight(&weight_data, WEIGHT1);

         /*
      	send_string_P(PSTR("\n\nCurrent Source Neuron: "));
         output_ch_1(neuron_data.layer);
         output_ch_1(neuron_data.neuron + '0');
         send_string_P(PSTR("\nCurrent Weight is from "));
         output_ch_1(weight_data.src_layer);
         output_ch_1(weight_data.src_neuron + '0');
         send_string_P(PSTR(" to "));
         output_ch_1(weight_data.dest_layer);
         output_ch_1(weight_data.dest_neuron + '0');   */

			//8] Multiply result of step 6 and 7, add the product to 'sum'
      	sum = sum + (neuron_data.neuron_value * weight_data.weight_value);

      	//9] Get next weight, if there are no more as there are no more
         //	  inputs to current neuron goto step 12
         if (select_next_weight(WEIGHT1) != NO_ERROR)
         	{
            break;
            }

      	//10] Get next source neuron
         select_next_neuron(SOURCE);
                                   
      	//11] Goto step 6
      	}

      get_current_neuron(&neuron_data, DESTINATION);
      neuron_data.neuron_value = activation_function(sum);
      put_current_neuron(&neuron_data, DESTINATION);
/*
      send_string_P(PSTR("\nWrote value of "));
      ftoa(neuron_data.neuron_value, ch);
      send_string(ch);
      send_string_P(PSTR(" to neuron "));
      output_ch_1(neuron_data.layer);
      output_ch_1(neuron_data.neuron + '0');
*/

   	//	12] Select next destination neuron
     	last_neuron = select_next_neuron(DESTINATION);
      get_current_neuron(&neuron_data, DESTINATION);

/*      send_string_P(PSTR("\nDestination neuron selected as "));
      output_ch_1(neuron_data.layer);
      output_ch_1(neuron_data.neuron + '0');     */

  		// 13] If selecting next destination neuron failed because no more neurons,
		// goto step 14, else goto step 3

      //keep track of final layer
      final_layer = neuron_data.layer;

   	} while (last_neuron == NO_ERROR);

	//	14] Read output values of output neurons
   counter = 0;

   select_specified_neuron(final_layer, 1, 1, OUTPUT_NEURONS);

	while (counter < number_of_output_data)
		{
		if (get_current_neuron(&neuron_data, OUTPUT_NEURONS) != NO_ERROR)
			{
			neuron_data.neuron_value = 0;
			}
		output_data_array[counter] = neuron_data.neuron_value;
		counter++;
      //select next neuron
      select_next_neuron(OUTPUT_NEURONS);
		}

	return 1;
	}


int												train_neural_network
	(
   float 						input_data_array[][MAX_INPUT_NEURONS],
   float 						target_output_array[][MAX_OUTPUT_NEURONS],
   unsigned char				number_input_neurons,
   unsigned char				number_output_neurons,
   float							learn_rate,
   unsigned char				number_sets,
   float *						error,
   unsigned int				max_cycles
   )
   {
   struct neuron_list_t		neuron;
   struct weight_list_t		weight;

   float							sum_error;

   float							output_data_array[MAX_OUTPUT_NEURONS];

   unsigned char				output_neuron;
   unsigned int				next_neuron_address;
   unsigned int				counter = 0;

   unsigned int				guess_neuron_source_address;

   unsigned char				temp;

   //this variable is used to determine if some of the functions returned errors,
   //rather than testing each and every function
   unsigned char				return_values;


   char ch[20];

   unsigned char training_set = 0;


   /*
   Algorithm Used

	1]	Set the destination neuron to the first neuron on the final layer.
	2]	Subtract what the output of the destination neuron should be with what it actually is and store this in error.
   		3] 	Get the first weight that links to the current destination neuron.
   		4] 	Set current source neuron to source neuron of current weight.
				5]		Add to the current weight the product of (output of the source neuron * error * learning rate).
				6] 	Get next input weight.
				7] 	Get next source neuron to current destination neuron.
				8] 	If no more weights that connect to current destination neuron, goto step 9, otherwise goto step 5.
   		9]	Select next output neuron and set to current destination neuron and goto step 3, unless no more output neurons in which case goto step 10.
	10]	Set the first neuron on the current destination layer as the destination neuron.
	11]	Set the current source neuron to the first neuron on the layer before the destination layer.
		12]	Clear sum_error.
			13]	Get the weight that links the current destination neuron to the current source neuron.
			14]	Add to sum_error the product of (current weight value * the error value of the current destination neuron).
			15]	 Select the next destination neuron, and goto step 13. If no more neurons   on destination layer, goto step 16.
		Note: Sum_error now has error value of current source neuron.
		16]	Store sum_error for the current source neuron (this could be stored in the neuron_value of the neuron_list_t, as neuron_value is not required anymore).
		17]	Select the next source neuron, and goto step 12. If no more neurons on current source layer goto step 18.
	18]	Set current destination neuron to first neuron on source layer.
	19]	Set current source neuron to first neuron on destination neuron's layer (from step 18).
   	  20]	Set current weight to the weight that links the current source and destination neuron.
			21]	Add to the current weight the product of (error of current destination neuron * output of current source neuron * learning rate).
			22]	Select next source neuron, and goto step 20. If no more source neurons on current layer goto step 23.
		23]	Set current source neuron to first neuron on current source neuron's layer .
		24]	Select next destination neuron and goto step 20. If no more destination neurons on current layer goto step 25.
	25]	Set the current destination neuron to the first neuron on the current source neuron's layer.
	26]	Set the current source neuron to the first neuron on the layer before the destination layer.
	27]	Goto step 12, unless setting the source neuron failed as the destination layer is the input layer. This means there are no layers before the destination layer, and backpropagation is complete.

   */


   while (counter < max_cycles)
   {

   run_through_neural_network(input_data_array[0], number_input_neurons,
                              output_data_array, number_output_neurons);


	//1]	Set the destination neuron to the first neuron on the final layer.
   output_neuron = 1;
   select_specified_neuron(final_layer, output_neuron, 1, DESTINATION);

   send_string_P(PSTR("\nFirst output neuron: "));
   output_ch_1(final_layer);
   output_ch_1(output_neuron + '0');
   
   do
   	{
   	//2]	Subtract what the output of the destination neuron should be with what it actually is and store this in error.
    	get_current_neuron(&neuron, DESTINATION);
   	(*error) = target_output_array[training_set][output_neuron - 1] - neuron.neuron_value;

	   //store the error value
  	 	neuron.neuron_value = (*error);
   	put_current_neuron(&neuron, DESTINATION);

		//3] 	Get the first weight that links to the current destination neuron.
   	select_weight_dest_of_current_neuron(DESTINATION, WEIGHT1);
   	get_current_weight(&weight, WEIGHT1);

            send_string_P(PSTR("\nWCurrent weight is from "));
         output_ch_1(weight.src_layer);
         output_ch_1(weight.src_neuron + '0');
         send_string_P(PSTR(" to "));
         output_ch_1(weight.dest_layer);
         output_ch_1(weight.dest_neuron + '0');

   	// 4] 	Set current source neuron to source neuron of current weight.
   	select_specified_neuron(weight.src_layer, weight.src_neuron, 1, SOURCE);

      //the 'break' command is inside the loop
      while(1)
      	{
			//5]		Add to the current weight the product of (output of the source neuron * error * learning rate).
   		get_current_neuron(&neuron, SOURCE);
         get_current_weight(&weight, WEIGHT1);
   		weight.weight_value += (neuron.neuron_value * (*error) * learn_rate);
   		put_current_weight(&weight, WEIGHT1);

         //6] 	Get next input weight.
   		if (select_next_weight(WEIGHT1) != NO_ERROR)
         	{
            break;
            }

            send_string_P(PSTR("\nQCurrent weight is from "));
         output_ch_1(weight.src_layer);
         output_ch_1(weight.src_neuron + '0');
         send_string_P(PSTR(" to "));
         output_ch_1(weight.dest_layer);
         output_ch_1(weight.dest_neuron + '0');

         send_string_P(PSTR("\nQCurrent Source Neuron is: "));
         output_ch_1(neuron.layer);
         output_ch_1(neuron.neuron + '0');

   		//7] 	Get next source neuron to current destination neuron.
         select_next_neuron(SOURCE);

         //8] 	If no more weights that connect to current destination neuron, goto step 9, otherwise goto step 5.
         		//this is done in step 6 instead of here
         }

      //9]	Select next output neuron and set to current destination neuron and goto step 2, unless no more output neurons in which case goto step 10.
      } while(select_next_neuron(DESTINATION) == NO_ERROR);

   //10]	Set the first neuron on the current destination layer as the destination neuron.
   select_specified_neuron(weight.dest_layer, 1, 1, DESTINATION);

   while(1)
   {
      do
      {

		//11]	Set the current source neuron to the first neuron on the layer before the destination layer.
		select_specified_neuron(weight.src_layer, 1, 1, SOURCE);

   	//12]	Clear sum_error
      sum_error = 0.0;

         do
         {
      	//13]	Get the weight that links the current destination neuron to the current source neuron.
         select_weight_dest_of_current_neuron(DESTINATION, WEIGHT1);
         get_current_weight(&weight, WEIGHT1);
         get_current_neuron(&neuron, SOURCE);

         //now we have the weight list, just get the correct weight
         while (weight.src_neuron != neuron.neuron)
         	{
            select_next_weight(WEIGHT1);
            get_current_weight(&weight, WEIGHT1);
            } 


         send_string_P(PSTR("\nCurrent weight is from "));
         output_ch_1(weight.src_layer);
         output_ch_1(weight.src_neuron + '0');
         send_string_P(PSTR(" to "));
         output_ch_1(weight.dest_layer);
         output_ch_1(weight.dest_neuron + '0');

         send_string_P(PSTR("\nCurrent Source Neuron is: "));
         output_ch_1(neuron.layer);
         output_ch_1(neuron.neuron + '0');

         //need error values, stored in the destination neurons neuron.neuron_value
         get_current_neuron(&neuron, DESTINATION);

         //14]	Add to sum_error the product of (current weight value * the error value of the current destination neuron).
         sum_error += weight.weight_value * neuron.neuron_value;

         //15]	Select the next destination neuron, and goto step 13. If no more neurons on destination layer, goto step 16.
         if (select_next_neuron(DESTINATION) != NO_ERROR)
         	{
            break;
            }

         get_current_neuron(&neuron, DESTINATION);

         }while (neuron.layer == weight.dest_layer);

  		//16]	Store sum_error for the current source neuron (this could be stored in the neuron_value of the neuron_list_t, as neuron_value is not required anymore).
      get_current_neuron(&neuron, SOURCE);
      neuron.neuron_value = sum_error;
		put_current_neuron(&neuron, SOURCE);

  		//17]	Select the next source neuron, and goto step 11. If no more neurons on current source layer goto step 18.
      //store current source layer
		temp = neuron.layer;
      if (select_next_neuron(SOURCE) != NO_ERROR)
      	{
         break;
         }
      get_current_neuron(&neuron, SOURCE);
      } while (neuron.layer == temp);

   //18]	Set current destination neuron to first neuron on source layer.
   get_current_neuron(&neuron, SOURCE);
   select_specified_neuron(neuron.layer, 1, 1, DESTINATION);

	//19]	Set current source neuron to layer before current destination layer
   select_specified_neuron((neuron.layer - 1), 1, 1, SOURCE);

   	do
      {
      	do
      	{
   		//20]	Set current weight to the weight that links the current source and destination neuron.
   		select_weight_dest_of_current_neuron(DESTINATION, WEIGHT1);
   		get_current_neuron(&neuron, SOURCE);

    		get_current_weight(&weight, WEIGHT1);

   		while (weight.src_neuron != neuron.neuron)
     			{
      		select_next_weight(WEIGHT1);
      		get_current_weight(&weight, WEIGHT1);
				}

      	//21]	Add to the current weight the product of (error of current destination neuron * output of current source neuron * learning rate).
			get_current_neuron(&neuron, DESTINATION);
      	(*error) = neuron.neuron_value;
			get_current_neuron(&neuron, SOURCE);
   		weight.weight_value += (*error) * neuron.neuron_value * learn_rate;

      	//22]	Select next source neuron, and goto step 20. If no more source neurons on current layer goto step 23.
			temp = neuron.layer;
      	if (select_next_neuron(SOURCE) != NO_ERROR)
      		{
         	break;
         	}
      	get_current_neuron(&neuron, SOURCE);
      	} while (neuron.layer == temp);

      //store the weight
      put_current_weight(&weight, WEIGHT1);
      
   	//23]	Set current source neuron to first neuron on current source neuron's layer .
      get_current_neuron(&neuron, SOURCE);
      select_specified_neuron(neuron.layer, 1, 1, SOURCE);

      //24]	Select next destination neuron and goto step 20. If no more destination neurons on current layer goto step 25.
      if (select_next_neuron(DESTINATION) != NO_ERROR)
        	{
         break;
         }
      get_current_neuron(&neuron, DESTINATION);
      }while (neuron.layer == weight.dest_layer);

	//25]	Set the current destination neuron to the first neuron on the current source neuron's layer.
   get_current_neuron(&neuron, SOURCE);
   select_specified_neuron(neuron.layer, 1, 1, DESTINATION);

	//26]	Set the current source neuron to the first neuron on the layer before the destination layer.
   if (neuron.layer == 'A')
   	{
      break;
      }
   else
   	{
      select_specified_neuron(neuron.layer - 1, 1, 1, DESTINATION);
      }

	//27]	Goto step 12, unless setting the source neuron failed as the destination layer is the input layer. This means there are no layers before the destination layer, and backpropagation is complete.
   }

   }

   return NO_ERROR;
   }

/* Simple MLP logistic activation function taking the form
return = 1/(1+exp^-input) */
float												activation_function
	(
	float							input_data
	)
	{
	return (float)inverse(1 + exp((double) (-1 * input_data)));
	}





