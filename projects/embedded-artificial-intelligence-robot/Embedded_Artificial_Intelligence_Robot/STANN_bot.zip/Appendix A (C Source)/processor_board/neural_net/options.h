#ifndef STANN_OPTIONS
#define STANN_OPTIONS


/* This is the header file for the Self Training Artificial Neural Network
(STANN) Project by Colin O'Flynn */

/* This file contains all of the options for the project. Options only used in
one module are also here, but they are identified that they are only used in one
module */

/* The code will be compiled based on what the target platform is. If you add
a platform that the code can be compiled on, please e-mail me the new code at
c_oflynn@yahoo.com */




//---------------------Compile Specific Options (Auto)------------------------

/* Define what you are compiling for, currently this version supports the
following
AVR_GCC
this compiles for the Atmel AVR line of microcontrollers using GCC compiler

PC1
this compiles for a PC (1 is the type of PC, in this version there is only one
type, mine */
//define types of compilers
#define AVR_GCC   	1
#define PC_1			2

#define COMPILER AVR_GCC


/* If we are compiling for AVR_GCC, include these files and make a few defines
AVR_GCC <-- Atmel AVR processor using the AVR-GCC compiler
options.h (this file) defines the compile target */

#if COMPILER == AVR_GCC
	#include <avr\io.h>
#endif

//If we are compiling for PC1, include these needed files and make a few defines
//options.h defines the compile target

#if COMPILER == PC_1
	#include <stdio.h>
	#include <stdlib.h>

   #if MEDIA == HARD_DRIVE
	   #define NEURAL_WEIGHT_FILENAME "weight_list.wgt"
   	#define NEURAL_OUT_FILENAME "neuron_output.lst"
   #endif
#endif

//------------General Options used by ALL modules-----------------------------
//define maximum number of layers
#define MAX_LAYERS 6

//error codes
#define NO_ERROR 						0
#define OUT_OF_BOUNDS_ERROR 		1
#define INTERNAL_ERROR				2


//the weights connecting the neurons, set upper and lower limits when the random
//weights are first assigned
#define LOWER_WEIGHT_LIMIT			-10
#define UPPER_WEIGHT_LIMIT			10

//-------------Options used by low_level_data_access.c------------------------
/* Define where you wish to store the neural network file, acceptable options
are:
FRAM
stores file FRAM chip
HARD_DRIVE
stores file on the hard drive
Note that only certain ones work in certain situations: for example you
could not #define HARD_DRIVE if you previously used #define AVR */
//define types of media
#define FRAM 		 	1
#define HARD_DRIVE 	2

#define MEDIA FRAM

   #if MEDIA == FRAM
   	//how big is the FRAM in BYTES
   	#define FRAM_SIZE								32000
      #warning "Generic warning, always created: Be SURE the FRAM_SIZE define is correct, problems will occur if it is not!"

      //what percentage of the memory should be set for the WEIGHT_DATA
      #define WEIGHT_DATA_PER						0.6

      //figure out where WEIGHT_DATA should start (always RAMEND + 1 normally..)
      #define WEIGHT_DATA_FRAM_START 			(RAMEND + 1)
      //figure out where WEIGHT_DATA should end
      #define WEIGHT_DATA_FRAM_END				(unsigned int)(WEIGHT_DATA_PER * FRAM_SIZE)

      //figure out where NEURON_DATA should start
      #define NEURON_DATA_FRAM_START			(WEIGHT_DATA_FRAM_END + 1)
      //figure out where NEURON_DATA should end
      #define NEURON_DATA_FRAM_END				(FRAM_SIZE)



   #endif

/* In order to manage memory properly, you have to define the maximum size
that the neural network could store in BYTES of the target memory location.
Note that you should specify the minimum size possible, as if you chose
to copy the neural network to RAM, the amount of RAM set aside is
MAX_WEIGHT_FILE_SIZE, and remember that each entry in the weight file
list takes up (sizeof(float) + 6 * sizeof(char)), or 10 bytes in a system
where char is 8 bits  */

#define MAX_WEIGHT_FILE_SIZE 4000

/* If your target has a lot of RAM, then the entire memory contents of the
weight file will be put in RAM. This will greatly speed access to the
neural network data, as writing to and reading from non-volatile memory is slow,
however you MUST have more spare RAM than the MAX_WEIGHT_FILE_SIZE
this will load the maximum possible size of the weight file to RAM.
Note: DO NOT ENABLE, CURRENTLY SOFTWARE WILL NOT TAKE THE FILE FROM RAM AND
STORE IT IN NON-VOLATILE MEMEORY!!!!!
#define LOAD_ALL_WEIGHT_FILE_TO_RAM
this won't
#define LOAD_NO_WEIGHT_FILE_TO_RAM */

#define LOAD_NO_WEIGHT_FILE_TO_RAM


//---------------------Type Declerations--------------------------------------


/* This is the "weight file" structure, used extensivley by the
low_level_data_access.c module, as well as other modules */

struct weight_list_t
	{
   unsigned char 	src_layer;		//Source Layer (should vary from A - F)
   unsigned char 	src_neuron;     //Source Neuron on Layer src_layer (1-255)
   unsigned char 	dest_layer;     //Destination Layer (should vary from A - F)
   unsigned char 	dest_neuron;    //Destination Neuron on Layer dest_neuron (1-255)
   float 		  	weight_value;  	//Weight of the link between thoese neurons
   unsigned int	next_address;	//The address (1 to 1000) of the next INPUT
   										//to the current neuron. So if the current
                                 //neuron address has A1B1, A2B1 is next, then
                                 //A3B1 and so on. It returns 0 when there is
                                 //no more inputs
   };


   #define SIZE_OF_WEIGHT						  sizeof(struct weight_list_t)
	#define SIZE_OF_WEIGHT_SRC_LAYER			  sizeof(unsigned char)
   #define SIZE_OF_WEIGHT_SRC_NEURON		  sizeof(unsigned char)
   #define SIZE_OF_WEIGHT_DEST_LAYER		  sizeof(unsigned char)
	#define SIZE_OF_WEIGHT_DEST_NEURON		  sizeof(unsigned char)
   #define SIZE_OF_WEIGHT_WEIGHT_VALUE		  sizeof(float)
   #define SIZE_OF_WEIGHT_NEXT_ADDRESS		  sizeof(unsigned int)

/* This is the "neuron output" structure, used extensivley by the
low_level_data_access.c module, and a few others */

struct neuron_list_t
	{
   unsigned char 	layer;				//Layer neuron is on
   unsigned char 	neuron;         //Neuron number on .layer
   float 		  	neuron_value;   //The output value of the neuron
   unsigned int	next_address;   //The address (1 to 1000) of the next neuron
   										//in the link. It will traverse layers, so
                                 //it will address A1, then A2, then B1, the B2,
                                 //then B3, and so on. Returns 0 when there
                                 //is no more neurons
   unsigned int	frst_weight_addr;     //address of the first weight that has
   												 //this neuron as the DESTINATION

   };


   #define SIZE_OF_NEURON				 		  sizeof(struct neuron_list_t)
	#define SIZE_OF_NEURON_LAYER				  sizeof(unsigned char)
   #define SIZE_OF_NEURON_NEURON				  sizeof(unsigned char)
   #define SIZE_OF_NEURON_NEURON_VALUE		  sizeof(float)
   #define SIZE_OF_NEURON_NEXT_ADDRESS		  sizeof(unsigned int)
   #define SIZE_OF_NEURON_FRST_WEIGHT_ADDR  sizeof(unsigned int)

#endif

