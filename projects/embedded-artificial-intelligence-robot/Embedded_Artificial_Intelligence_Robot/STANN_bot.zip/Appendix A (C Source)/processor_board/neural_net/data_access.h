#ifndef STANN_DATA_ACCESS
#define STANN_DATA_ACCESS

/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code */

/* This mofule contains the data_access routines, which interface with the
low_level_data_access to provide a high-level interface to them for more power*/

/*Note: all of these routines have net_ref as a parameter. This parameter can
have a value of 0 or 1 (it can actually go from 0 to 255 depending on some
compilation procedures, however in this implementation it is defined to be from
0 to 1). This value is simply a reference to an array that holds the current
address of the neuron or weight being modified. So for example you could use a
command to select the first neuron on list 0, and another command to select the
second neuron on list 1. They both write to and read from the same neuron list
(or weight list), but issuing a select next neuron command on list 1 will not
affect the current pointed-to location of list 0. Writing to a neuron with a
list 1 reference means that list 0 can read the value of (or write the value of)
that neuron, as there is only one physical neuron list.

The use of this is that you may want to hold the location of two different
neurons, such as one list is the source neuron and the other is the destination
neuron.

The return value of all these routines will be either NO_ERROR (which is 0), or
INTERNAL_ERROR which means that some error occurred (including no more neurons
or weights available if using the select_next_x routines).
*/


/*This will select the first weight on the weight list, which is normally the
weight from A1 to B1.*/
unsigned char 									select_first_weight
   (
	unsigned char				net_ref
   );

/*This selects the next weight (as determined by the weight_list_t.next_address)
that is the current input to the current destination neuron. For example if the
current weight is from B1-C1, this will then select A2-C1, then A3-C1, then
there is no more inputs to the destination neuron of the current weight it
cannot advance anymore.  */
unsigned char 									select_next_weight
	(
	unsigned char				net_ref
   );

/*This routine copies the current weight selected to the pointed to weight.*/
unsigned char									get_current_weight
	(
   struct weight_list_t *	weight,
   unsigned char				net_ref
   );

/*This routine copies the data in the pointed to weight into the currently
selected weight.*/
unsigned char 									put_current_weight
   (
   struct weight_list_t *	weight,
	unsigned char				net_ref
   );



/*This will select the first neuron on the neuron list, which is normally A1.*/
unsigned char 									select_first_neuron
   (
	unsigned char				net_ref
   );

/*This will select the next neuron on the neuron list, as determined by the
neuron_list_t.next_address. It will traverse layers until it reaches the end
of the neural network, so for example if the currently selected weight is A1,
it would then select B1, then B2, then B3, and finally C1.  */
unsigned char 									select_next_neuron
	(
	unsigned char				net_ref
   );

/*This routine copies the current neuron selected to the pointed to neuron.*/
unsigned char 									get_current_neuron
   (
   struct neuron_list_t *	neuron,
	unsigned char				net_ref
   );

/*This routine copies the data in the pointed to neuron into the currently
selected neuron.*/
unsigned char 									put_current_neuron
   (
   struct neuron_list_t *	neuron,
	unsigned char				net_ref
   );

/*This routine selects the nth_neuron_number from the start of the neuron list.
So for example in a neural network with neurons A1, B1, B2, B3, and C1 calling
this with nth_neuron_number as 2 should select neuron B1. */
unsigned char 									 select_nth_neuron
   (
   unsigned int				nth_neuron_number,
	unsigned char				net_ref
   );

/* Returns the address of the neuron specified. best_guess_of_neuron_address
is what your best guess is of the address if you have one. Otherwise just set
it to 1 (don't set it to 0). If you have a rough idea where the neuron is,
ALWAYS guess LOW!! The routine starts looking at your guess, so if you are too
high by ONE it will result in the LONGEST search time, as it will go from your
guess to end, then back around again. This routine returns 0 if an error occured */   
unsigned char									select_specified_neuron
	(
	unsigned char				layer,
	unsigned char				neuron,
	unsigned int				best_guess_of_neuron_address,
	unsigned char				net_ref
	);

/*This routine selects the first weight that links to the currently selected
neuron for the net_ref_neuron. The selected weight is selected on the
net_ref_weight reference. Note that there is no one net_ref in this routine, as
a net_ref is needed for both the weight and neuron list.*/
unsigned char									select_weight_dest_of_current_neuron
	(
	unsigned char				net_ref_neuron,
   unsigned char				net_ref_weight
   );
#endif
