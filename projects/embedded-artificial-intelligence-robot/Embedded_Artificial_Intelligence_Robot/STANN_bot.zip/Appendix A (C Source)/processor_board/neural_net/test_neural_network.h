unsigned char	test_neural_network
					  (
                 void
                 );
