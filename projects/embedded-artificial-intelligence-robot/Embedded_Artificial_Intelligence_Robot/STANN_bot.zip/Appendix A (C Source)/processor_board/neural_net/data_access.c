/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code */

/* This module contains the data_access routines, which interface with the
low_level_data_access to provide a high-level interface to them for more power */

//see data_access.h for description of routines

/* contains many options for this module as well as all the modules in general
also contains the type definitions
NOTE: The "options.h" file must be the first file defined */

#include "options.h"


#include "low_level_data_access.h"
#include "data_access.h"


#define NETS_KEPT 2
//this variable holds the next address for the weight chain, this prevents
//the outside routines from accidently messing around with the chain
static unsigned int			next_weight_address[NETS_KEPT];
//this variable holds the current address for the weight chain, this prevents
//the outside routines from accidently messing around with the chain
static unsigned int			current_weight_address[NETS_KEPT];

//this variable holds the next address for the neuron chain, this prevents
//the outside routines from accidently messing around with the chain
static unsigned int			next_neuron_address[NETS_KEPT];
//this variable holds the current address for the neuron chain, this prevents
//the outside routines from accidently messing around with the chain
static unsigned int			current_neuron_address[NETS_KEPT];


unsigned char 									select_first_weight
   (
	unsigned char				net_ref
   )
   {
	struct weight_list_t		weight;
   current_weight_address[net_ref] = 1;

   //read the first weight value, check that it is read properly, and
   //the value is put in the pointer-to location of the weight pointer
   if (low_level_read_weight_data(current_weight_address[net_ref], &weight) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   }

unsigned char 									select_next_weight
	(
	unsigned char				net_ref
   )
   {
	struct weight_list_t		weight;

   get_current_weight(&weight, net_ref);

   next_weight_address[net_ref] = weight.next_address;


   //make sure next weight is a valid one!
   if (next_weight_address[net_ref] != 0)
   	{
      current_weight_address[net_ref] = next_weight_address[net_ref];
      }
   else
   	{
      return INTERNAL_ERROR;
		}

   //read the next weight value, check that it is read properly, and
   //store the next address
   if (low_level_read_weight_data(current_weight_address[net_ref], &weight) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }
   }
   
 
unsigned char 									 select_nth_weight
   (
   unsigned int				nth_weight_number,
	unsigned char				net_ref
   )
   {
	struct weight_list_t		weight;
   unsigned int 				number_of_weights_read;

   //read the nth weight value, where n is a number. It basically just goes
   //through the chain n number of times, starting at number 1

   weight.next_address = 1;
   number_of_weights_read = 0;
   while (number_of_weights_read != nth_weight_number)
   	{
      current_weight_address[net_ref] = next_weight_address[net_ref];
   	if (low_level_read_weight_data(current_weight_address[net_ref], &weight) != NO_ERROR)
   		{
      	return INTERNAL_ERROR;
      	}
      number_of_weights_read++;
      }

   return NO_ERROR;
   }

unsigned char									get_current_weight
	(
   struct weight_list_t *	weight,
   unsigned char				net_ref
   )
   {

   //read the current weight value, check that it is read properly, and
   //the value is put in the pointer-to location of the weight pointer
   if (low_level_read_weight_data(current_weight_address[net_ref], weight) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   }

unsigned char 									select_first_neuron
   (
	unsigned char				net_ref
   )
   {
   struct neuron_list_t		neuron;

   current_neuron_address[net_ref] = 1;

   //read the first neuron value, check that it is read properly, and
   //the value is put in the pointer-to location of the neuron pointer
   if (low_level_read_neuron_output(current_neuron_address[net_ref], &neuron) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   }

unsigned char 									select_next_neuron
	(
	unsigned char				net_ref
   )
   {
   struct neuron_list_t		neuron;

   get_current_neuron(&neuron, net_ref);

   next_neuron_address[net_ref] = neuron.next_address;

   //make sure next neuron is a valid one!
   if (next_neuron_address[net_ref] != 0)
   	{
      current_neuron_address[net_ref] = next_neuron_address[net_ref];
      }
   else
   	{
      return INTERNAL_ERROR;
		}



   //read the next neuron value, check that it is read properly, and
   //the value is put in the pointer-to location of the neuron pointer
   if (low_level_read_neuron_output(current_neuron_address[net_ref], &neuron) == NO_ERROR)
   	{
      //make a local copy of the next address
      next_neuron_address[net_ref] = neuron.next_address;
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }
   }

unsigned char 								get_current_neuron
   (
   struct neuron_list_t *	neuron,
	unsigned char				net_ref
   )
   {

   //read the current neuron value, check that it is read properly, and
   //the value is put in the pointer-to location of the neuron pointer
   if (low_level_read_neuron_output(current_neuron_address[net_ref], neuron) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   }

unsigned char 									 select_nth_neuron
   (
   unsigned int				nth_neuron_number,
	unsigned char				net_ref
   )
   {
   unsigned int 				number_of_neurons_read;
   struct neuron_list_t		neuron;

   //read the nth neuron value, where n is a number. It basically just goes
   //through the chain n number of times, starting at number 1

   neuron.next_address = 1;
   number_of_neurons_read = 0;
   while (number_of_neurons_read != nth_neuron_number)
   	{
      current_neuron_address[net_ref] = neuron.next_address;
   	if (low_level_read_neuron_output(current_neuron_address[net_ref], &neuron) != NO_ERROR)
   		{
      	return INTERNAL_ERROR;
      	}
      number_of_neurons_read++;
      }

   return NO_ERROR;
   }

/* Selects the neuron specified. best_guess_of_neuron_address
is what your best guess is of the address if you have one. Otherwise just set
it to 1 (don't set it to 0). If you have a rough idea where the neuron is,
ALWAYS guess LOW!! The routine starts looking at your guess, so if you are too
high by ONE it will result in the LONGEST search time, as it will go from your
guess to end, then back around again. This routine returns 0 if an error occured */   
unsigned char									select_specified_neuron
	(
	unsigned char				layer,
	unsigned char				neuron,
	unsigned int				best_guess_of_neuron_address,
	unsigned char				net_ref
	)
	{
	struct neuron_list_t		fake_neuron;
	unsigned int				neuron_address;

	//uses the linked list to find a neuron's address
	fake_neuron.next_address = best_guess_of_neuron_address;
	
	//scan the neuron list to the end of the chain	
	while (fake_neuron.next_address != 0)
		{
		neuron_address = fake_neuron.next_address;
		if (low_level_read_neuron_output(neuron_address, &fake_neuron) != NO_ERROR)
			{
			return INTERNAL_ERROR;
			}
		if ((fake_neuron.layer == layer) && (fake_neuron.neuron == neuron))
			{
			current_neuron_address[net_ref] = neuron_address;
         return NO_ERROR;
			}
		}
	//scan from the start now...	
	neuron_address = 1;	
	while (fake_neuron.next_address != best_guess_of_neuron_address)
		{
		neuron_address = fake_neuron.next_address;
		if (low_level_read_neuron_output(neuron_address, &fake_neuron) != NO_ERROR)
			{
			return INTERNAL_ERROR;
			}
		if ((fake_neuron.layer == layer) && (fake_neuron.neuron == neuron))
			{
			current_neuron_address[net_ref] = neuron_address;
			}
		}
		
	//otherwise NO neuron found
	return INTERNAL_ERROR;
	
	}		
	

unsigned char									select_weight_dest_of_current_neuron
	(
	unsigned char				net_ref_neuron,
   unsigned char				net_ref_weight
   )
   {
   struct neuron_list_t		neuron;

   if (low_level_read_neuron_output(current_neuron_address[net_ref_neuron], &neuron) == NO_ERROR)
   	{
      current_weight_address[net_ref_weight] = neuron.frst_weight_addr;
      return NO_ERROR;
      }



	return INTERNAL_ERROR;
  	}



unsigned char 									put_current_weight
   (
   struct weight_list_t *	weight,
	unsigned char				net_ref
   )
   {

   //write the current neuron value, check that it is write properly, and
   //the value is put in the pointer-to location of the neuron pointer
   if (low_level_write_weight_data(current_weight_address[net_ref], weight) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   }

unsigned char 									put_current_neuron
   (
   struct neuron_list_t *	neuron,
	unsigned char				net_ref
   )
   {

   //write the current neuron value, check that it is write properly, and
   //the value is put in the pointer-to location of the neuron pointer
   if (low_level_write_neuron_output(current_neuron_address[net_ref], neuron) == NO_ERROR)
   	{
      return NO_ERROR;
      }
   else
   	{
      return INTERNAL_ERROR;
      }

   }
