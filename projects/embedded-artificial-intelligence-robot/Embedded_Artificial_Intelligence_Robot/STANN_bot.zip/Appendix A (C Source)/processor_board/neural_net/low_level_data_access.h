#ifndef STANN_LOW_LEVEL_DATA_ACCESS
#define STANN_LOW_LEVEL_DATA_ACCESS
/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/* This module has the low level data access routines in it. */

/* If the code needs to be ported to another processor or use a different storage
media, the code in these routines will have to be changed. Specifically, the
following routines access the low-level data:

low_level_read_weight_data();
low_level_write_weight_data();
low_level_read_neuron_output();
low_level_write_neuron_output();

Thoese routines should be examined first, then other modules can be examined
for changed. However be sure to look over the options.h file before anything
else */


/*Initalize storage media. For a file it could create or open the file for
example */
unsigned char init_storage_media
					(
               void
               );


/*This routine is used to write the weight list data onto a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the weight_list_t type that will have the data to be wrote.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */
unsigned char low_level_write_weight_data
					 (
                unsigned int 				address,
                struct weight_list_t*  write_this_weight_pointer
                );

/*This routine is used to read the weight list data from a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the weight_list_t type that will contain the data read.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */
unsigned char low_level_read_weight_data
					 (
                unsigned int				address,
                struct weight_list_t*  read_this_weight_pointer
                );

/*This routine is used to write the neuron output data to a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the neuron_list_t type that will contain the data to write.  It returns 0 if no
error occured, 1 if address_neuron was smaller than 1 or bigger than 1000,
2 if there was a read error */
unsigned char low_level_write_neuron_output
					 (
                unsigned int 				address,
                struct neuron_list_t* 	neuron_output_pointer
                );

/*This routine is used to read the neuron output data from a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the neuron_list_t type that will contain the data read.  It returns 0 if no
error occured, 1 if address_neuron was smaller than 1 or bigger than 1000,
2 if there was a read error */
unsigned char low_level_read_neuron_output
					 (
                unsigned int				address,
                struct neuron_list_t *	neuron_output_pointer
                );

/*Close the storage media, such as a file */
unsigned char close_storage_media
					 (
                void
                );

#endif




