#ifndef STANN_DATA_ACCESS_UTILITIES
#define STANN_DATA_ACCESS_UTILITIES

/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code */

/* This module has the data access utilities in it, which are various routines
for working with the weight_list and neuron_ouput data sets. These are NOT the
routines that perform the access to them, instead they simply perform matinence
on them */


/* This routine will set aside the storage space that will store the neuron list.
number_of_layers is between 1 to 6 and is the number of layers. Each element
in the array holds the number of neurons in that layer. so neurons_per_layer[0]
has the number of neurons in the first layer (layer A), neurons_per_layer[1]
has the number of neurons in the second layer (layer B) and so on. The return
value is 0 = no error, 1 = too many layers (6 is max, for no reason other than
these routines aren't designed to work with a huge neuron network) ,
2 = internal error (storage media faliure, other errors along that line) */

unsigned int create_neuron_list
	(
   unsigned char				number_of_layers,
   unsigned char*				neurons_per_layer
   );


/* This routine will create a weight list based on a neuron list. As such,
you need to have already run create_neuron_list. As well it will link the
frst_weight_addr of the neuron list to the weight list.
The return value is 0 = all went okay, 2 = some sort of internal error */
unsigned int create_weight_list
	(
   unsigned int				starting_neuron_address
	);

#endif

