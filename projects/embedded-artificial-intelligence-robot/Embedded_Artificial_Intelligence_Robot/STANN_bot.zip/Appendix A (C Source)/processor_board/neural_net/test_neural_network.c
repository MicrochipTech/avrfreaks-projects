/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code */

/* This module tests all the various other subroutines, and is called simpily by
test_neural_network() and returns several possible values (check code to confirm
this, someone (or me) might modify these subroutines and forget to modify the
comments. The values are:

*/

/* Note that some subroutines ARE platform dependant... so be careful
Also note that some tests WILL fail on some platforms, a failed test doesn't
mean bad software */

//WARNING! WARNING! WARNING! Calling this routine will ERASE ALL data stored
//on the media used by the low_level routines!!!!

//MUST be first file included, has many options for this and other files
#include "options.h"

//if the compiler is AVR_GCC, we need to include one more file...

#include "low_level_data_access.h"
#include "test_neural_network.h"
#include "data_access_utilities.h"
#include "data_access.h"
#include "uart.h"

//prototype internal routines
char *												int_to_string
	(
   int							int_to_convert
   );

void													init_error_report
	(
   void
   );

void													close_error_report
	(
   void
   );

void													print_message
   (
   char							message[]
   );

void													print_test_message
	(
   char							message[]
   );

void													test_failed
	(
   void
   );

void													test_passed
	(
   void
   );

void													output_char
	(
   char							ch
   );




unsigned char										test_neural_network
	(
   void
   )
   {
   volatile struct weight_list_t 	fakeweight, copy_of_fakeweight;
   volatile struct neuron_list_t		fakeneuron, copy_of_fakeneuron;
   char							response[10];
   int							address;
   unsigned char				neurons_per_layer[6] = {0};
   unsigned char				layer_counter;
   unsigned char				number_of_failures;

	init_error_report();

   print_message("Self Training Artificial Neural Network (STANN) Tester\n");
   print_message("Colin O'Flynn\n\n\n");
   print_message("Now testing low_level_data_access.c\n\n");

   //initilize stoage media used by test
   if (init_storage_media() == NO_ERROR)
   	{
   	print_message("Storage media initilized\n\n");
      }
   else
   	{
      print_message("Storage media FALIURE\n");
      return INTERNAL_ERROR;
      }

	//set some default values
	fakeweight.src_layer 	= 'A';
   fakeweight.src_neuron 	= 1;
   fakeweight.dest_layer	= 'B';
   fakeweight.dest_neuron	= 255;
   fakeweight.weight_value = 10.321233;
   fakeweight.next_address = 2;

   fakeneuron.layer			= 'A';
   fakeneuron.neuron       = 1;
   fakeneuron.neuron_value = 0.232131;
   fakeneuron.next_address	= 2;


   //test that routines return out of bounds
   print_test_message("low_level_write_weight_data out of bounds check");
   if ((low_level_write_weight_data(0, &fakeweight) == OUT_OF_BOUNDS_ERROR) &&
       (low_level_write_weight_data(1001, &fakeweight) == OUT_OF_BOUNDS_ERROR))
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("low_level_write_weight_data out of bounds check");
   if ((low_level_read_weight_data(0, &fakeweight) == OUT_OF_BOUNDS_ERROR) &&
       (low_level_read_weight_data(1001, &fakeweight) == OUT_OF_BOUNDS_ERROR))
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("low_level_write_neuron_output out of bounds check");
   if ((low_level_write_neuron_output(0, &fakeneuron) == OUT_OF_BOUNDS_ERROR) &&
       (low_level_write_neuron_output(1001, &fakeneuron) == OUT_OF_BOUNDS_ERROR))
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("low_level_read_neuron_output out of bounds check");
   if ((low_level_read_neuron_output(0, &fakeneuron) == OUT_OF_BOUNDS_ERROR) &&
       (low_level_read_neuron_output(1001, &fakeneuron) == OUT_OF_BOUNDS_ERROR))
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }


	//Check to see read and write complain when media isn't initilized
   print_message("\nChecking Media error checking\n");
   print_test_message("low_level_write_weight_data works with init'd media");
   if (low_level_write_weight_data(1, &fakeweight) == NO_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("low_level_read_weight_data works with init'd media");
   if (low_level_read_weight_data(1, &fakeweight) == NO_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("low_level_write_neuron_output works with init'd media");
   if (low_level_write_neuron_output(1, &fakeneuron) == NO_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
  	print_test_message("low_level_read_neuron_output works with init'd media.");
   if (low_level_read_neuron_output(1, &fakeneuron) == NO_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }

   //close media to simulate error of some sort
   if (close_storage_media() != NO_ERROR)
   	{
      print_message("\n\nMEDIA CLOSE FALIURE");
      return INTERNAL_ERROR;
      }
   print_message("low_level routines return error with closed media");
   //now try reading and writing, should return error
   print_test_message("write_weight_data");
   if (low_level_write_weight_data(1, &fakeweight) == INTERNAL_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("read_weight_data");
   if (low_level_read_weight_data(1, &fakeweight) == INTERNAL_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("write_neuron_output");
   if (low_level_write_neuron_output(1, &fakeneuron) == INTERNAL_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("read_neuron_output");
   if (low_level_read_weight_data(1, &fakeweight) == INTERNAL_ERROR)
      {
      test_passed();
      }
   else
   	{
      test_failed();
      }
   print_test_message("\nReinitilizing Storage Media");
   if (init_storage_media() == NO_ERROR)
   	{
   	test_passed();
      }
   else
   	{
      test_failed();
      return INTERNAL_ERROR;
      }

   //Test the actual writing and reading
   print_message("\nTesting storage media by writing and reading data to it\n");
   print_message("Testing low_level_write_weight_data\n");

   address 						= 1;
   copy_of_fakeweight = fakeweight;

   //loop that first writes an increaing number to every memory location
   number_of_failures = 0;
   while(address < 1001)
   	{
      print_message("Writing at location ");
      print_test_message(int_to_string(address));

      if (low_level_write_weight_data(address, &fakeweight) == NO_ERROR)
      	{
         test_passed();
         }
      else
      	{
      	if (low_level_write_weight_data(address, &fakeweight) == NO_ERROR)
      		{
         	print_message("REQUIRED 2 TRIES\n");
         	}
         else
         	{
         	if (low_level_write_weight_data(address, &fakeweight) == NO_ERROR)
      			{
         		print_message("REQUIRED 3 TRIES\n");
         		}
         	else
         		{
         		test_failed();
         		number_of_failures++;
         		}
         	}
         }
      address++;
      fakeweight.src_neuron++;
      fakeweight.dest_neuron--;
      fakeweight.weight_value += 0.1321;
      fakeweight.next_address++;
      }
   print_message("\nTotal number of failures: ");
   print_message(int_to_string(number_of_failures));
   print_message("\n");



   print_message("\nTesting low_level_read_weight_data\n");
   print_message("NOTE: the above test MUST have passed or parts of this test will");
   print_message(" fail as it depends on the above test to work\n");


 	address 									= 1;
 	fakeweight.src_layer 	= 'A';
   fakeweight.src_neuron 	= 1;
   fakeweight.dest_layer	= 'B';
   fakeweight.dest_neuron	= 255;
   fakeweight.weight_value = 10.321233;
   fakeweight.next_address = 2;


   //loop that first reads an increaing number to every memory location
   number_of_failures = 0;
   while(address < 1001)
   	{
   	print_message("Reading at location ");
   	print_test_message(int_to_string(address));
      if ((low_level_read_weight_data(address, &fakeweight) == NO_ERROR) &&
      	 (fakeweight.src_neuron == copy_of_fakeweight.src_neuron) &&
          (fakeweight.dest_neuron == copy_of_fakeweight.dest_neuron) &&
          (fakeweight.weight_value == copy_of_fakeweight.weight_value) &&
          (fakeweight.next_address == copy_of_fakeweight.next_address))
      	{
         test_passed();
         }
      else
      	{
      	test_failed();
         number_of_failures++;
         }
      address++;
      copy_of_fakeweight.src_neuron++;
      copy_of_fakeweight.dest_neuron--;
      copy_of_fakeweight.weight_value += 0.1321;
      copy_of_fakeweight.next_address++;
      }
   print_message("\nTotal number of failures: ");
   print_message(int_to_string(number_of_failures));
   print_message("\n");



   print_message("\nTesting low_level_write_neuron_output\n");

   address 						= 1;
   fakeneuron.layer			= 'A';
   fakeneuron.neuron       = 1;
   fakeneuron.neuron_value = 0.232131;
   fakeneuron.next_address	= 1;

   //loop that first writes an increaing number to every memory location
   number_of_failures = 0;
   while(address < 1001)
   	{
      print_message("Writing at location ");
      print_test_message(int_to_string(address));
      if (low_level_write_neuron_output(address, &fakeneuron) == NO_ERROR)
      	{
         test_passed();
         }
      else
      	{
      	test_failed();
         number_of_failures++;
         }
      address++;
   	fakeneuron.neuron++;
   	fakeneuron.neuron_value += 0.432131;
   	fakeneuron.next_address++;
      }
   print_message("\nTotale number of failures: ");
   print_message(int_to_string(number_of_failures));
   print_message("\n");

   print_message("\nTesting low_level_read_neuron_output\n");
   print_message("NOTE: the above test MUST have passed or parts of this test will");
   print_message(" fail as it depends on the above test to work\n");

   address 									= 1;
   copy_of_fakeneuron.layer			= 'A';
   copy_of_fakeneuron.neuron       	= 1;
   copy_of_fakeneuron.neuron_value 	= 0.232131;
   copy_of_fakeneuron.next_address	= 1;

   //loop that first reads an increaing number to every memory location
   number_of_failures = 0;
   while(address < 1001)
   	{
      print_message("Reading at location ");
      print_test_message(int_to_string(address));
      if ((low_level_read_neuron_output(address, &fakeneuron) == NO_ERROR) &&
          (fakeneuron.layer == copy_of_fakeneuron.layer) &&
          (fakeneuron.neuron == copy_of_fakeneuron.neuron) &&
          (fakeneuron.neuron_value == copy_of_fakeneuron.neuron_value) &&
          (fakeneuron.next_address == copy_of_fakeneuron.next_address))
      	{
         test_passed();
         }
      else
      	{
      	test_failed();
         number_of_failures++;
         }
      address++;
   	copy_of_fakeneuron.neuron++;
   	copy_of_fakeneuron.neuron_value += 0.432131;
   	copy_of_fakeneuron.next_address++;
      }
   print_message("\nTotale number of failures: ");
   print_message(int_to_string(number_of_failures));
   print_message("\n");
   print_message("\n\nlow_level_data_access.c tested\n\n\n");

   //test data_access_utilities.c
   print_message("Testing data_access_utilities.c\n");

   neurons_per_layer[0] = 1;
   neurons_per_layer[1] = 5;
   neurons_per_layer[2] = 3;

   print_message("Creating neural network with following number of neurons\n");
   for (layer_counter = 0; layer_counter < MAX_LAYERS; layer_counter++)
   	{
      print_message("Neurons on layer ");
      output_char('A' + layer_counter);
      print_message(": ");
      print_message(int_to_string((int)neurons_per_layer[layer_counter]));
      }

	print_test_message("Creating neuron list");
   if (create_neuron_list(3, neurons_per_layer) == NO_ERROR)
   	{
      test_passed();
      }
   else
   	{
      test_failed();
      }

   //clear variable
   neurons_per_layer[0] = 0;
   neurons_per_layer[1] = 0;
   neurons_per_layer[2] = 0;

	if (low_level_read_neuron_output(1, &fakeneuron) == NO_ERROR)
   	{
      //get number of neurons per layer
      neurons_per_layer[fakeneuron.layer - 'A'] = fakeneuron.neuron;
      while (fakeneuron.next_address != 0)
      	{
         if (low_level_read_neuron_output(fakeneuron.next_address,
          	&fakeneuron)==	NO_ERROR)
         	{
            neurons_per_layer[fakeneuron.layer - 'A'] = fakeneuron.neuron;
            }
         else
         	{
            print_test_message("Reading neural net");
            test_failed();
            }
         }
  		print_message("Neural network read: (MUST be the same as the created\
list)\n");
   	for (layer_counter = 0; layer_counter < MAX_LAYERS; layer_counter++)
   		{
      	print_message("Neurons on layer ");
      	output_char('A' + layer_counter);
      	print_message(": ");
      	print_message(int_to_string((int)neurons_per_layer[layer_counter]));
      	}
      }
   else
   	{
      print_test_message("Reading neural network list");
      test_failed();
      return INTERNAL_ERROR;
      }

   print_message("Finished testing data_access_utilities.c\n");


	//test data_access.c

   print_message("\n\n\nTesting data_access.c\n\n");

   print_message("Test get_first_neuron, assuming first neuron is A1\n");
   if (get_first_neuron(&fakeneuron) != NO_ERROR)
   	{
      print_message("Unexpected Error ");
      return INTERNAL_ERROR;
      }

   print_test_message("Testing get_first_neuron");
   if (fakeneuron.layer == 'A' && fakeneuron.neuron == 1)
   	{
      test_passed();
      }
   else
   	{
      test_failed();
      }

   print_message("Test get_next_neuron, assuming second neuron is B1 and\
previous test ran OK\n");
   if (get_next_neuron(&fakeneuron) != NO_ERROR)
   	{
      print_message("Unexpected Error");
      return INTERNAL_ERROR;
      }

   if (fakeneuron.layer == 'B' && fakeneuron.neuron == 1)
   	{
      if (get_next_neuron(&fakeneuron) != NO_ERROR)
   		{
      	print_message("Unexpected Error");
      	return INTERNAL_ERROR;
      	}
      print_test_message("Testing get_next_neuron");
      if (fakeneuron.layer == 'B' && fakeneuron.neuron == 2)
      	{
         test_passed();
         }
      else
      	{
         test_failed();
         }
      }
   else
   	{
      print_test_message("Testing get_next_neuron");
      test_failed();
      }

   print_message("Testing get_nth_neuron, assuming 5th neuron is B4...\n");
   if (get_nth_neuron(5, &fakeneuron) != NO_ERROR)
   	{
      print_message("Internal Error");
      return INTERNAL_ERROR;
      }

   print_test_message("Testing get_nth_neuron");
   if (fakeneuron.layer == 'B' && fakeneuron.neuron == 4)
   	{
      test_passed();
      }
   else
   	{
      test_failed();
      }

   print_test_message("Closing storage media");
   //close storage media
   if (close_storage_media() == NO_ERROR)
   	{
      test_passed();
      }
   else
   	{
      test_failed();
      return INTERNAL_ERROR;
      }
   print_message("\n\nCheck complete. Check screen for more information");

   return NO_ERROR;
   }



//Compiler non-specific routines
char *											int_to_string
	(
   int							int_to_convert
   )
   {
   static char					strint[6];

   strint[0] = int_to_convert / 10000;
   strint[1] = (int_to_convert / 1000) - (strint[0] * 10);
   strint[2] = (int_to_convert / 100) - (strint[0] * 100) - (strint[1] * 10);
   strint[3] = (int_to_convert / 10) - (strint[0] * 1000) - (strint[1] * 100) -
   				(strint[2] * 10);
   strint[4] = int_to_convert - (strint[0] * 10000) - (strint[1] * 1000) -
   				(strint[2] * 100) - (strint[3] * 10);
   strint[5] = '\0';

   strint[0] = strint[0] + '0';
   strint[1] = strint[1] + '0';
   strint[2] = strint[2] + '0';
   strint[3] = strint[3] + '0';
   strint[4] = strint[4] + '0';

	return strint;
   }


#if COMPILER == AVR_GCC
//routines that use the UART0 of the AVR selected, designed to use polling
//and not modify anything

//place to save the UCR register contents
static unsigned char			old_UCR_register;

//initilizes error reporting mechanism (if applicable)
void													init_error_report
	(
   void
   )
   {
   /*
   //make a back-up of the current UCR contents
   old_UCR_register = UCR;

   //set defaults
   UCR = 0x00;
   //turn on RX
   //UCR |= 1<<RXEN;
   //turn on TX
   UCR |= 1<<TXEN;

	//set up baud rate
	UBRR = 1;

	UDR = '\r';
   */
   return;
   }

//closes error reporting mechanism (if applicable)
void													close_error_report
	(
   void
   )
   { /*
   //return the UCR register to the status it was at before
   UCR = old_UCR_register;
 */  return;
   }

//prints Message (MAX size of 50 chars)
void													print_message
   (
   char						message[]
   )
   {
   unsigned char message_counter = 0;

   while ((message[message_counter] != '\0') && (message_counter != 50))
   	{
      output_char(message[message_counter]);
      message_counter++;
      };

   return;
   }

//prints Message and puts enough spaces so that the cursor is now
//50 spaces over from the left margin
void													print_test_message
	(
   char						message[]
   )
   {
   unsigned char			message_counter = 0;

   while ((message[message_counter] != '\0') && (message_counter != 50))
   	{
		output_char(message[message_counter]);
      message_counter++;
      }

   while (message_counter != 50)
   	{
      output_char(' ');
      message_counter++;
      }

   return;
   }

//prints [FAILED] followed by a carriage return
void													test_failed
	(
   void
   )
   {
   output_char('[');
   output_char('F');
   output_char('A');
   output_char('I');
   output_char('L');
   output_char('E');
   output_char('D');
   output_char(']');
   output_char('\r');
   return;
   }

//prints [OK] followed by a carriage return
void													test_passed
	(
   void
   )
   {
   output_char('[');
   output_char('O');
   output_char('K');
   output_char(']');
   output_char('\r');

   return;
   }

//subroutine that outputs the character that is selected, changing newlines
//to  carriage return for the UART program
void													output_char
	(
   char							ch
   )
   {  /*

    if (ch == '\n')
   	{
   	ch = '\r';
   	}

   while ((USR & (1 << UDRE)) != (1 << UDRE))
   	{
   	continue;
   	}
   UDR = ch;
 */
   return;

   }
#endif
