/* This module is part of the STANN (Self Training Artificial Neural Network)
project. Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code */

/* contains many options for this module as well as all the modules in general
also contains the type definitions
NOTE: The "options.h" file must be the first file defined */

#include "options.h"

#include "rcon.h"
#include "low_level_data_access.h"
#include "data_access.h"

unsigned char									allow_remote_control
	(
	void
	)
	{
	//Variables used in the environment that can be accessed by the UART
	//connection
	unsigned char				unsigned_char_var[10];
	short							short_var[5];
	int							int_var[5];
	float							float_var[5];
	weight_list_t				weight_list_t_var;
	neuron_list_t				neuron_list_t_var;
	
	//variables used to pass data back and forth between routines
	unsigned char				command_code;
	unsigned char				data[5];
	
	//set up the time-out timer
	set_up_time_out_timer();
	
	//wait until security code is inputted, effectively "Unlocking" the system
	wait_for_security_code();
	
	}
	


	
