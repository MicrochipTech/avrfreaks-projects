/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/* This module has the low level data access routines in it. */

/* If the code needs to be ported to another processor or use a different storage
media, the code in these routines will have to be changed. Specifically, the
following routines access the low-level data:

low_level_read_weight_data();
low_level_write_weight_data();
low_level_read_neuron_output();
low_level_write_neuron_output();

Thoese routines should be examined first, then other modules can be examined
for changed. However be sure to look over the options.h file before anything
else */

/* The weight_list_t type is declared in options.h, and is used throughout
this module and others, however its really important in this module. */


/* contains many options for this module as well as all the modules in general
also contains the type definitions
NOTE: The "options.h" file must be the first file defined */

#include "options.h"
#include "low_level_data_access.h"


//-----------------------------------------------------------------------------
//The routines that use the AVR
#if COMPILER == AVR_GCC

#include <avr\delay.h>

//with FRAM (Parallel)
#if MEDIA == FRAM

static unsigned int			VCC_min;


/* This routine will intilize the FRAM, by mapping it into the internal SRAM of the
AVR Process. As well reads the value of VCC, and sets VCC_min to 90% of current
ADC reading. Returns 1 if an error occured, 0 if all went well... although there
is no error check so it always returns NO_ERROR. */
unsigned char		init_storage_media
	(
   void
	)
	{
   char ch[10];

   //Enable the XRAM interface by
	MCUCR = MCUCR | (1 << SRE);

   //may need waitstates...
   MCUCR = MCUCR | (1 << SRW);

   //enable ADC in free-running mode with adc sample rate of (XTAL / 128)
   ADCSRA = (1<<ADEN) | (1<<ADSC) | (1<<ADFR) | (1<<ADPS0) | (1<<ADPS1) | (1<<ADPS2);

   /*enable ADC internal ref, select Channel 0 (where a 10k 1% and 4k 1%
   resistor form a voltage divider to sample VCC*/
   ADMUX = (1<<REFS0) | (1<<REFS1);

   //wait for ADC to stabalize
   _delay_loop_2(20000);
   _delay_loop_2(20000);
   _delay_loop_2(20000);
   _delay_loop_2(20000);
   _delay_loop_2(20000);
   _delay_loop_2(20000);

   //set the minimum 'safe' reading of the ADC value at 91% of the current
   //VCC value (for 5 volts that is 4.55 V)
   VCC_min = ADC;
   VCC_min = (unsigned int)((((long)VCC_min * 100) * 91) / 10000);

	return NO_ERROR;
	}


//Doesn't do anything, but it is needed to be compatible with the header file
unsigned char				close_storage_media
   (
   void
   )
   {
   return NO_ERROR;
   }

/*This routine is used to write the weight list data onto a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the weight_list_t type that will have the data to be wrote.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char	        	                low_level_write_weight_data
   (
   unsigned int	         address_weight,
   struct weight_list_t*   write_this_weight_pointer
   )
   {
   volatile unsigned char * FRAM_address;
   float							weight_value_temp;
   volatile unsigned char * byte_ptr;
   unsigned char				size_of_var_count;
   unsigned int				uint_temp;

	//Check that the XRAM is initlized, as if it is not then the program will crash
	//and burn when attempting to write to an address that does not exsist
	if ((MCUCR & (1 << SRE)) != (1 << SRE))
		{
		init_storage_media();
		}

   //Check that we keep the address within bounds
   if (address_weight > 1000 || address_weight < 1)
		{
		return OUT_OF_BOUNDS_ERROR;
		}

   //locate the spot in the FRAM to write data to (FRAM is mapped after external
   //SRAM)
   FRAM_address = (volatile unsigned char *)
   					(address_weight * SIZE_OF_WEIGHT + WEIGHT_DATA_FRAM_START);
	//check for overflow
   if (FRAM_address > WEIGHT_DATA_FRAM_END)
   	{
      return OUT_OF_BOUNDS_ERROR;
      }

   //check for falling VCC
   if (VCC_min > ADC)
   	{
      return INTERNAL_ERROR;
      }

   //write the data
   *FRAM_address = write_this_weight_pointer -> src_layer;
   //test that the data has been written
   if (*FRAM_address != write_this_weight_pointer -> src_layer)
   	{
      return INTERNAL_ERROR;
      }

   //select next address
   FRAM_address++;
   //write the data
   *FRAM_address = write_this_weight_pointer -> src_neuron;
   //test that the data has been written
   if (*FRAM_address != write_this_weight_pointer -> src_neuron)
   	{
      return INTERNAL_ERROR;
      }

   //select next address
   FRAM_address++;
   //write the data
   *FRAM_address = write_this_weight_pointer -> dest_neuron;
   //test that the data has been written
   if (*FRAM_address != write_this_weight_pointer -> dest_neuron)
   	{
      return INTERNAL_ERROR;
      }

   //select next address
   FRAM_address++;
   //write the data
   *FRAM_address = write_this_weight_pointer -> dest_layer;
   //test that the data has been written
   if (*FRAM_address != write_this_weight_pointer -> dest_layer)
   	{
      return INTERNAL_ERROR;
      }

//start code that writes the weight_value, a float type number

	//make a local copy of the floating point data to copy
	weight_value_temp = write_this_weight_pointer -> weight_value;
   //make a pointer to that location, but really make the pointer a byte so
   //we can extract the information at each of the 4 memory locations
   byte_ptr = &weight_value_temp;

   //select next address
   FRAM_address++;
   //store data
   *FRAM_address = *byte_ptr;
   //check data
   if (*FRAM_address != *byte_ptr)
   	{
      return INTERNAL_ERROR;
      }

   //write this as many times as there are bytes in the float variable
   //(but one of the bytes has already been written above)
   size_of_var_count = SIZE_OF_WEIGHT_WEIGHT_VALUE;
   while (size_of_var_count != 1)
   	{
   	//select next address
   	FRAM_address++;
   	//select next byte of the float
   	byte_ptr++;
   	//store data
   	*FRAM_address = *byte_ptr;
   	//check data
   	if (*FRAM_address != *byte_ptr)
   		{
     		return INTERNAL_ERROR;
      	}

      //decrease the count
      size_of_var_count--;
      }

//finish code that writes the weight_value

	size_of_var_count = 0;
	uint_temp = write_this_weight_pointer -> next_address;
	byte_ptr = &uint_temp;

	while (size_of_var_count != SIZE_OF_WEIGHT_NEXT_ADDRESS)
		{
		//increase number of bytes written
		size_of_var_count++;
   	//select next address
   	FRAM_address++;
   	//write the data
   	*FRAM_address = *byte_ptr;
   	//check the data
   	if (*FRAM_address != *byte_ptr)
   		{
      	return INTERNAL_ERROR;
      	}
		//select next byte
		byte_ptr++;
		}
   //if we got this far then no error has occured, and all is well
   return NO_ERROR;
   }


/*This routine is used to read the weight list data from a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the weight_list_t type that will contain the data read.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char	        	                low_level_read_weight_data
   (
   unsigned int	         address_weight,
   struct weight_list_t*   read_this_weight_pointer
   )
   {
   volatile unsigned char * FRAM_address;
   float							weight_value_temp;
   volatile unsigned char * byte_ptr;
   unsigned char				size_of_var_count;
   unsigned int				uint_temp;

	//Check that the XRAM is initlized, as if it is not then the program will crash
	//and burn when attempting to write to an address that does not exsist
	if ((MCUCR & (1 << SRE)) != (1 << SRE))
		{
		init_storage_media();
		}


   //Check that we keep the address within bounds
   if (address_weight > 1000 || address_weight < 1)
		{
		return OUT_OF_BOUNDS_ERROR;
		}

   //locate the spot in the FRAM to write data to (FRAM is mapped after external
   //SRAM)
   FRAM_address = (volatile unsigned char *)
   					(address_weight * SIZE_OF_WEIGHT + WEIGHT_DATA_FRAM_START);

	//check for overflow
   if (FRAM_address > WEIGHT_DATA_FRAM_END)
   	{
      return OUT_OF_BOUNDS_ERROR;
      }

   //check for falling VCC
   if (VCC_min > ADC)
   	{
      return INTERNAL_ERROR;
      }

   //read the data
   read_this_weight_pointer -> src_layer = *FRAM_address;

   //select next address
   FRAM_address++;
   //read the data
  	read_this_weight_pointer -> src_neuron = *FRAM_address;


   //select next address
   FRAM_address++;
   //read the data
   read_this_weight_pointer -> dest_neuron = *FRAM_address;

   //select next address
   FRAM_address++;
   //read the data
   read_this_weight_pointer -> dest_layer =  *FRAM_address;


//start code that reads the weight_value, a float type number

   //make a pointer to a float, but really make the pointer a byte so
   //we can write the information to each of the 4 memory locations
   byte_ptr = &weight_value_temp;

   //select next address
   FRAM_address++;
   //read data
   *byte_ptr = *FRAM_address;

   //write this as many times as there are bytes in the float variable
   //(but one of the bytes has already been written above)
   size_of_var_count = SIZE_OF_WEIGHT_WEIGHT_VALUE;
   while (size_of_var_count != 1)
   	{
   	//select next address
   	FRAM_address++;
   	//select next byte of the float
   	byte_ptr++;
   	//read data
   	*byte_ptr = *FRAM_address;
      //decrease the count
      size_of_var_count--;
      }

   //copy local copy of data to real location
	read_this_weight_pointer -> weight_value = weight_value_temp;

//finish code that writes the weight_value


	size_of_var_count = 0;
	byte_ptr = &uint_temp;

	while (size_of_var_count != SIZE_OF_WEIGHT_NEXT_ADDRESS)
		{
		//increase number of bytes written
		size_of_var_count++;
   	//select next address
   	FRAM_address++;
   	//readthe data
      *byte_ptr = *FRAM_address;
		//select next byte
		byte_ptr++;
		}

	//copy variable
	read_this_weight_pointer -> next_address = uint_temp;

  //There is no error checking... just assume all went well!
   return NO_ERROR;
   }

/*This routine is used to write the neuron output data to a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the neuron_list_t type that will contain the data to write.  It returns 0 if no
error occured, 1 if address_neuron was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char     	        				  low_level_write_neuron_output
   (
   unsigned int 	 		  address_neuron,
   struct neuron_list_t*  neuron_output_pointer
   )
   {
   volatile unsigned char * FRAM_address;
   float							neuron_value_temp;
   volatile unsigned char * byte_ptr;
   unsigned char				size_of_var_count;
   unsigned int				uint_temp;

	//Check that the XRAM is initlized, as if it is not then the program will crash
	//and burn when attempting to write to an address that does not exsist
	if ((MCUCR & (1 << SRE)) != (1 << SRE))
		{
		init_storage_media();
		}

   //Check that we keep the address within bounds
   if (address_neuron > 1000 || address_neuron < 1)
		{
		return OUT_OF_BOUNDS_ERROR;
		}

   //locate the spot in the FRAM to write data to (FRAM is mapped after external
   //SRAM)
   FRAM_address = (volatile unsigned char *)
   					(address_neuron * SIZE_OF_NEURON + NEURON_DATA_FRAM_START);

	//check for overflow
   if (FRAM_address > NEURON_DATA_FRAM_END)
   	{
      return OUT_OF_BOUNDS_ERROR;
      }

   //check for falling VCC
   if (VCC_min > ADC)
   	{
      return INTERNAL_ERROR;
      }

   //write the data
   *FRAM_address = neuron_output_pointer -> layer;
   //test that the data has been written
   if (*FRAM_address != neuron_output_pointer -> layer)
   	{
      return INTERNAL_ERROR;
      }

   //select next address
   FRAM_address++;
   //write the data
   *FRAM_address = neuron_output_pointer -> neuron;
   //test that the data has been written
   if (*FRAM_address != neuron_output_pointer -> neuron)
   	{
      return INTERNAL_ERROR;
      }

//start code that writes the neuron_value, a float type number

	//make a local copy of the floating point data to copy
	neuron_value_temp = neuron_output_pointer -> neuron_value;
   //make a pointer to that location, but really make the pointer a byte so
   //we can extract the information at each of the 4 memory locations
   byte_ptr = &neuron_value_temp;

   //select next address
   FRAM_address++;
   //store data
   *FRAM_address = *byte_ptr;
   //check data
   if (*FRAM_address != *byte_ptr)
   	{
      return INTERNAL_ERROR;
      }

   //write this as many times as there are bytes in the float variable
   //(but one of the bytes has already been written above)
   size_of_var_count = SIZE_OF_NEURON_NEURON_VALUE;
   while (size_of_var_count != 1)
   	{
   	//select next address
   	FRAM_address++;
   	//select next byte of the float
   	byte_ptr++;
   	//store data
   	*FRAM_address = *byte_ptr;
   	//check data
   	if (*FRAM_address != *byte_ptr)
   		{
     		return INTERNAL_ERROR;
      	}

      //decrease the count
      size_of_var_count--;
      }

//finish code that writes the neuron_value


	size_of_var_count = 0;
	uint_temp = neuron_output_pointer -> next_address;
	byte_ptr = &uint_temp;

	while (size_of_var_count != SIZE_OF_NEURON_NEXT_ADDRESS)
		{
		//increase number of bytes written
		size_of_var_count++;
   	//select next address
   	FRAM_address++;
   	//write the data
   	*FRAM_address = *byte_ptr;
   	//check the data
   	if (*FRAM_address != *byte_ptr)
   		{
      	return INTERNAL_ERROR;
      	}
		//select next byte
		byte_ptr++;
		}


	size_of_var_count = 0;
	uint_temp = neuron_output_pointer -> frst_weight_addr;
	byte_ptr = &uint_temp;

	while (size_of_var_count != SIZE_OF_NEURON_FRST_WEIGHT_ADDR)
		{
		//increase number of bytes written
		size_of_var_count++;
   	//select next address
   	FRAM_address++;
   	//write the data
   	*FRAM_address = *byte_ptr;
   	//check the data
   	if (*FRAM_address != *byte_ptr)
   		{
      	return INTERNAL_ERROR;
      	}
		//select next byte
		byte_ptr++;
		}

   
   //if we got this far then no error has occured, and all is well
   return NO_ERROR;
   }


/*This routine is used to read the neuron output data from a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the neuron_list_t type that will contain the data read.  It returns 0 if no
error occured, 1 if address_neuron was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char								     low_level_read_neuron_output
   (
   unsigned int 	 	      address_neuron,
   struct neuron_list_t*  neuron_output_pointer
   )
   {
   volatile unsigned char * FRAM_address;
   float							neuron_value_temp;
   volatile unsigned char * byte_ptr;
   unsigned char				size_of_var_count;
   unsigned int				uint_temp;

   //Check that the XRAM is initlized, as if it is not then the program will crash
	//and burn when attempting to write to an address that does not exsist
	if ((MCUCR & (1 << SRE)) != (1 << SRE))
		{
		init_storage_media();
		}


   //Check that we keep the address within bounds
   if (address_neuron > 1000 || address_neuron < 1)
		{
		return OUT_OF_BOUNDS_ERROR;
		}

   //locate the spot in the FRAM to write data to (FRAM is mapped after external
   //SRAM)
   FRAM_address = (volatile unsigned char *)
   					(address_neuron * SIZE_OF_NEURON + NEURON_DATA_FRAM_START);
                  
	//check for overflow
   if (FRAM_address > NEURON_DATA_FRAM_END)
   	{
      return OUT_OF_BOUNDS_ERROR;
      }

   //check for falling VCC
   if (VCC_min > ADC)
   	{
      return INTERNAL_ERROR;
      }

   //read the data
   neuron_output_pointer -> layer = *FRAM_address;

   //select next address
   FRAM_address++;
   //read the data
  	neuron_output_pointer -> neuron = *FRAM_address;

//start code that reads the neuron_value, a float type number

   //make a pointer to a float, but really make the pointer a byte so
   //we can write the information to each of the 4 memory locations
   byte_ptr = &neuron_value_temp;

   //select next address
   FRAM_address++;
   //read data
   *byte_ptr = *FRAM_address;

   //write this as many times as there are bytes in the float variable
   //(but one of the bytes has already been written above)
   size_of_var_count = SIZE_OF_NEURON_NEURON_VALUE;
   while (size_of_var_count != 1)
   	{
   	//select next address
   	FRAM_address++;
   	//select next byte of the float
   	byte_ptr++;
   	//read data
   	*byte_ptr = *FRAM_address;
      //decrease the count
      size_of_var_count--;
      }

   //copy local copy of data to real location
	neuron_output_pointer -> neuron_value = neuron_value_temp;

//finish code that writes the weight_value

	size_of_var_count = 0;
	byte_ptr = &uint_temp;

	while (size_of_var_count != SIZE_OF_NEURON_NEXT_ADDRESS)
		{
		//increase number of bytes written
		size_of_var_count++;
   	//select next address
   	FRAM_address++;
   	//readthe data
      *byte_ptr = *FRAM_address;
		//select next byte
		byte_ptr++;
		}

	//copy variable
	neuron_output_pointer -> next_address = uint_temp;



	size_of_var_count = 0;
	byte_ptr = &uint_temp;

	while (size_of_var_count != SIZE_OF_NEURON_FRST_WEIGHT_ADDR)
		{
		//increase number of bytes written
		size_of_var_count++;
   	//select next address
   	FRAM_address++;
   	//readthe data
      *byte_ptr = *FRAM_address;
		//select next byte
		byte_ptr++;
		}

	//copy variable
	neuron_output_pointer -> frst_weight_addr = uint_temp;


   //There is no error checking... just assume all went well!
   return NO_ERROR;
   }



#endif
#endif
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
//The routines that use the PC1 (may NOT BE SUPPORTED, this code hasn't been
//tested in a while!!!
#if COMPILER == PC_1

//with hard drive
#if MEDIA == HARD_DRIVE

//the pointer to the file, visible to routines within this module
static FILE*	  				weight_list_file_pointer;
static FILE*     				neuron_out_file_pointer;

/* This routine will intilize the hard drive. Returns 1 if an error occured,
0 if all went well. */

unsigned char				init_storage_media
   (
   )
   {

   if ((weight_list_file_pointer = fopen(NEURAL_WEIGHT_FILENAME, "r+b")) == NULL)
      {
      if ((weight_list_file_pointer = fopen(NEURAL_WEIGHT_FILENAME, "w+b")) == NULL)
      	{
         return OUT_OF_BOUNDS_ERROR;
         }
      }

   if ((neuron_out_file_pointer = fopen(NEURAL_OUT_FILENAME, "r+b")) == NULL)
      {
      if ((neuron_out_file_pointer = fopen(NEURAL_OUT_FILENAME, "w+b")) == NULL)
      	{
         return OUT_OF_BOUNDS_ERROR;
         }
      }

   return NO_ERROR;
   }

/* This routine will close the hard drive file. Returns 1 if error occured,
0 if all went well */
unsigned char				close_storage_media
   (
   )
   {
   if (fclose(weight_list_file_pointer) != 0)
      {
      return OUT_OF_BOUNDS_ERROR;
      }
   if (fclose(neuron_out_file_pointer) != 0)
      {
      return OUT_OF_BOUNDS_ERROR;
      }

   return NO_ERROR;
   }

/*This routine is used to write the weight list data onto a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the weight_list_t type that will have the data to be wrote.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char	        	                low_level_write_weight_data
   (
   unsigned int	         address_weight,
   struct weight_list_t*   write_this_weight_pointer
   )
   {
   long 							file_address;
   unsigned char 				num_items_wrote;

   //Check that we keep the address within bounds
   if (address_weight > 1000 || address_weight < 1)
		{
		return OUT_OF_BOUNDS_ERROR;
		}

   //locate the spot in the file to load data from
   file_address = address_weight * SIZE_OF_WEIGHT;

   //set the file pointer to the proper spot
   if (fseek(weight_list_file_pointer, file_address, SEEK_SET) != 0)
   	{
		return INTERNAL_ERROR;
	   }

   //do the actual writing of the file
   num_items_wrote =  fwrite(&(write_this_weight_pointer -> src_layer),
    						 SIZE_OF_WEIGHT_SRC_LAYER, 1, weight_list_file_pointer);

   num_items_wrote += fwrite(&(write_this_weight_pointer -> src_neuron),
   						 SIZE_OF_WEIGHT_SRC_NEURON, 1, weight_list_file_pointer);

   num_items_wrote += fwrite(&(write_this_weight_pointer -> dest_layer),
    						 SIZE_OF_WEIGHT_DEST_LAYER, 1, weight_list_file_pointer);

   num_items_wrote += fwrite(&(write_this_weight_pointer -> dest_neuron),
     						 SIZE_OF_WEIGHT_DEST_NEURON, 1, weight_list_file_pointer);

   num_items_wrote += fwrite(&(write_this_weight_pointer -> weight_value),
     						 SIZE_OF_WEIGHT_WEIGHT_VALUE, 1, weight_list_file_pointer);

   num_items_wrote += fwrite(&(write_this_weight_pointer -> next_address),
     						 SIZE_OF_WEIGHT_NEXT_ADDRESS, 1, weight_list_file_pointer);

   //check that the write went OK
   if (num_items_wrote != 6)
     	{
      return INTERNAL_ERROR;
      }

   return NO_ERROR;
   }

/*This routine is used to read the weight list data onto a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the weight_list_t type that will store the result.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char	        	                low_level_read_weight_data
   (
   unsigned int	         address_weight,
   struct weight_list_t*   read_this_weight_pointer
   )
   {
   long 							file_address;
   unsigned char 				num_items_read;

   //Check that we keep the address within bounds
   if (address_weight > 1000 || address_weight < 1)
		{
	   return OUT_OF_BOUNDS_ERROR;
	 	}

   //locate the spot in the file to load data from
   file_address = address_weight * SIZE_OF_WEIGHT;

   //set the file pointer to the proper spot
   if (fseek(weight_list_file_pointer, file_address, SEEK_SET) != 0)
      {
	  	return INTERNAL_ERROR;
	 	}

   //do the actual reading of the file
   num_items_read =  fread(&(read_this_weight_pointer -> src_layer),
     						SIZE_OF_WEIGHT_SRC_LAYER, 1, weight_list_file_pointer);

   num_items_read += fread(&(read_this_weight_pointer -> src_neuron),
     						SIZE_OF_WEIGHT_SRC_NEURON, 1, weight_list_file_pointer);

   num_items_read += fread(&(read_this_weight_pointer -> dest_layer),
     						SIZE_OF_WEIGHT_DEST_LAYER, 1, weight_list_file_pointer);

   num_items_read += fread(&(read_this_weight_pointer -> dest_neuron),
     					   SIZE_OF_WEIGHT_DEST_NEURON, 1, weight_list_file_pointer);

   num_items_read += fread(&(read_this_weight_pointer -> weight_value),
     					   SIZE_OF_WEIGHT_WEIGHT_VALUE, 1, weight_list_file_pointer);

   num_items_read += fread(&(read_this_weight_pointer -> next_address),
     					   SIZE_OF_WEIGHT_NEXT_ADDRESS, 1, weight_list_file_pointer);

   if (num_items_read != 6)
     	{
      return INTERNAL_ERROR;
      }

   return NO_ERROR;
   }


/*This routine is used to read the neuron output data onto a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the neuron_list_t type that will store the result.  It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char								     low_level_read_neuron_output
    (
    unsigned int 	 	      address_neuron,
    struct neuron_list_t*  neuron_output_pointer
    )
    {
    long 						file_address;
    unsigned char 			num_items_read;

    //Check that we keep the address within bounds
    if (address_neuron > 1000 || address_neuron < 1)
	 	{
	   return OUT_OF_BOUNDS_ERROR;
	 	}

    //locate the spot in the file to load data from
    file_address = address_neuron * SIZE_OF_NEURON;

    //set the file pointer to the proper spot
    if (fseek(neuron_out_file_pointer, file_address, SEEK_SET) != 0)
      {
	  	return INTERNAL_ERROR;
	  	}

    //do the actual reading of the file
    num_items_read =  fread(&(neuron_output_pointer -> layer),
     						 SIZE_OF_NEURON_LAYER, 1, neuron_out_file_pointer);

    num_items_read += fread(&(neuron_output_pointer -> neuron),
      					 SIZE_OF_NEURON_NEURON, 1, neuron_out_file_pointer);

    num_items_read += fread(&(neuron_output_pointer -> neuron_value),
      					 SIZE_OF_NEURON_NEURON_VALUE, 1, neuron_out_file_pointer);

    num_items_read += fread(&(neuron_output_pointer -> next_address),
      					 SIZE_OF_NEURON_NEXT_ADDRESS, 1, neuron_out_file_pointer);

    num_items_read += fread(&(neuron_output_pointer -> frst_weight_addr),
    					    SIZE_OF_NEURON_FRST_WEIGHT_ADDR, 1,
                      neuron_out_file_pointer);

    if (num_items_read != 5)
     	{
      return INTERNAL_ERROR;
      }

   return NO_ERROR;
   }


   /*This routine is used to write the neuron output data onto a storage media.
This low level access routine will take an address that can vary between
1 to 1000 (it should never actually go that high, all that
will probably be used is between 1 to 100 or so). It expects a pointer to
the neuron_list_t type that has the data to be written. It returns 0 if no
error occured, 1 if address_weight was smaller than 1 or bigger than 1000,
2 if there was a read error */

unsigned char     	        				  low_level_write_neuron_output
   (
   unsigned int 	 		  address_neuron,
   struct neuron_list_t*  neuron_output_pointer
   )
   {
   long 							file_address;
   unsigned char 				num_items_wrote;

   //Check that we keep the address within bounds
   if (address_neuron > 1000 || address_neuron < 1)
		{
	  	return OUT_OF_BOUNDS_ERROR;
	  	}

   //locate the spot in the file to load data from
   file_address = address_neuron * SIZE_OF_NEURON;

   //set the file pointer to the proper spot
   if (fseek(neuron_out_file_pointer, file_address, SEEK_SET) != 0)
      {
	  	return INTERNAL_ERROR;
	  	}

   //do the actual writing of the file
   num_items_wrote =  fwrite(&(neuron_output_pointer -> layer),
      					 SIZE_OF_NEURON_LAYER, 1, neuron_out_file_pointer);

   num_items_wrote += fwrite(&(neuron_output_pointer -> neuron),
      					 SIZE_OF_NEURON_NEURON, 1, neuron_out_file_pointer);

   num_items_wrote += fwrite(&(neuron_output_pointer -> neuron_value),
      					 SIZE_OF_NEURON_NEURON_VALUE, 1, neuron_out_file_pointer);

   num_items_wrote += fwrite(&(neuron_output_pointer -> next_address),
      					 SIZE_OF_NEURON_NEXT_ADDRESS, 1, neuron_out_file_pointer);

   num_items_wrote += fwrite(&(neuron_output_pointer -> frst_weight_addr),
      					 SIZE_OF_NEURON_FRST_WEIGHT_ADDR, 1,
                      neuron_out_file_pointer);

   if (num_items_wrote != 4)
     	{
      return INTERNAL_ERROR;
      }

   return NO_ERROR;
   }



#endif
#endif
//-----------------------------------------------------------------------------



