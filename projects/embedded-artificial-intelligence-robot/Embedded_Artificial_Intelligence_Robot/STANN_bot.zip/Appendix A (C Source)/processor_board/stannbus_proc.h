/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

#define NO_DATA 	0
#define NEW_DATA 	1

//This routine will initialize the StannBus interface, and should be called early on.
void												init_stannbus
	(
   void
   );

//This routine will send a byte of data to address.
void												sb_send_data
	(
   unsigned char				address,
   unsigned char				data
   );

/*This routine will get the latest piece of data that has not yet been read from
 the StannBus, storing the data from the bus in the (*data) variable and the
 address the data that was sent to in (*address).*/
unsigned char									sb_get_data
	(
   unsigned char *			address,
   unsigned char *			data
   );

/*This routine is used to clear the data buffers for reading from the StannBus.
This can be called before new data is due to arrive (for example if you are
about to ask for new data from some source) to ensure that when calling the
sb_get_data() routine you are getting the latest data, and not reading data from
the buffers that was accidentally received a while ago (but has not yet been
read, as the data was not needed). */
void												sb_get_data_clear_buffers
	(
   void
   );

/*This is a specific routine to send data to the output board, specifically the
Vacuum Fluorescent Display (VFD). This function will clear the display.*/
void												vfd1_clear
	(
   void
   );

/*This is a specific routine to send data to the output board, specifically the
Vacuum Fluorescent Display (VFD). This routine prints the string pointer passed
as message to the VFD. A newline (\n) results in the selection of the lower
line, regardless if the lowest line is the currently selected line.*/
void												vfd1_send_message
	(
   char 						  	message[]
   );

/*This is a specific routine to send data to the sensor board, specifically the
CMUCam section of it. This routine initializes the CMUCam and starts tracking
the colour held in front of it.*/
void												cmucam_init
	(
   void
   );

/*This is a specific routine to send data to the sensor board, specifically the
CMUCam section of it. This routine can be run after the cmucam_init() routine.
The return value is the location of the colour being tracked by the CMUCam, in
its own grid-system. A value of -6 means the CMUCam does not see any object of
the right colour, and a return of -9 means the CMUCam failed and is not
responding.*/
int												cmucam_get_position
	(
   void
   );

/*This is a specific routine to send data to the sensor board, specifically the
SONAR section of it. The return is the distance to an obstacle in units, a value
of 0 means no echo was seen (SONAR probably failed). */
int												sonar_get_distance
	(
   void
   );
