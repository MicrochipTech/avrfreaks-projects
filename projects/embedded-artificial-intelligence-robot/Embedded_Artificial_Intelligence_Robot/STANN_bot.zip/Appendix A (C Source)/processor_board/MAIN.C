/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*
Processorboard Routines
*/

#include <avr\io.h>
#include <avr\delay.h>
#include <avr\wdt.h>
#include <avr\pgmspace.h>
//need cli() and sei() macros
#include <avr\interrupt.h>
#include <stdlib.h>

//defines ftoa
#define ftoa(f, s) dtostrf((double)f, 8, 5, s)

//defines atof as the avr-libc version, however future stdlib.h may already have
//this definition built-in
#define atof(s) strtod(s, (char **)0)

#include <ctype.h>

#include "..\commands.h"

#include "neural_net\options.h"
#include "neural_net\data_access_utilities.h"
#include "neural_net\data_access.h"
#include "neural_net\MLP.h"

#include "uart.h"
#include "stannbus_proc.h"
#include "neural_debug.h"


#define display_delay()	  	counter = 0;				\
									while(counter != 100)	\
   									{                    \
   									_delay_loop_2(30000);\
     									counter++;           \
      								}

int 												draw_menu
	(
   void
   );

void												process_menu
	(
   void
   );

void												init_hardware
	(
   void
   );


int												main
	(
   void
   )
   {
   int							cmu_pos, sonar;
   char							message[40];
   unsigned char				counter;

   struct neuron_list_t	neuron_list;


   //test hardware, POST basically
   init_hardware();

   //send boot-up string
   send_string_P(PSTR("Atmel AVR RISC Processor\n"));

   while(1){
   process_menu();
            }

   display_delay();
   
   display_delay();


   return 1;
	}

//menu stuff
int												draw_menu
	(
   void
   )
   {
   send_string_P(PSTR("\nWelcome to Al-Bot\n\nColin O'Flynn\nwww.newae.com\n\n"));
   send_string_P(PSTR("Please make your selection\n"));
   send_string_P(PSTR("1. Reset System\n"));
   send_string_P(PSTR("2. Initilize CMUCam, track object in field of view\n"));
   send_string_P(PSTR("3. Track object with robot\n"));
   send_string_P(PSTR("4. Create neural network\n"));
   send_string_P(PSTR("5. Run Neural De-Bugger (ndb)\n"));
   send_string_P(PSTR("6. Load Weight File\n"));
   send_string_P(PSTR("7. Setup training sets\n"));
   send_string_P(PSTR("8. Run neural network\n"));
   send_string_P(PSTR("9. Train neural network\n"));
   send_string_P(PSTR("10. Redraw this menu\n"));
   send_string_P(PSTR("\nPlease select a number: "));

   return get_uart1_input_number();
   }

void												process_menu
	(
   void
   )
   {
   int							cmu_pos, sonar;
   char							message[40];
   unsigned char				counter;


   float error;
   float 						input_data_array[1][MAX_INPUT_NEURONS];
   float 						target_output_array[1][MAX_OUTPUT_NEURONS];

   switch(draw_menu())
   	{
      case 1 ://Reset system

      		//enable WDT which will reset system in 15 ms
            wdt_enable(WDTO_15MS);
            //wait for death
            while(1);
      		break;

      case 2 :	//Initilize CMUCam, track object in field of view
            cmucam_init();
      		break;

      case 3 : //Track ball with robot


	//simple loop used here (ANN not used)

   sb_send_data(MOTORL_ADDRESS, (char)128);
   _delay_loop_2(20);
   sb_send_data(MOTORR_ADDRESS, (char)128);

   while(1){


  	 //sb_send_data(MOTORL_ADDRESS, (char)100);
   //_delay_loop_2(40);
   //sb_send_data(MOTORR_ADDRESS, (char)100);

   cmu_pos = cmucam_get_position();

   sonar = sonar_get_distance();

   //error conditions
   if (cmu_pos == -9 || cmu_pos == -6)
   	{
   	sb_send_data(MOTORL_ADDRESS, (char)-50);
   	_delay_loop_2(40);
   	sb_send_data(MOTORR_ADDRESS, (char)50);
      }

   else if (cmu_pos > 230)
   	{
   	sb_send_data(MOTORL_ADDRESS, (char)0);
   	_delay_loop_2(40);
   	sb_send_data(MOTORR_ADDRESS, (char)-100);
      }

   else if (cmu_pos < 205)
   	{
  		 sb_send_data(MOTORL_ADDRESS, (char)-100);
   	_delay_loop_2(40);
   	sb_send_data(MOTORR_ADDRESS, (char)0);
      }

   else
   	{
  		sb_send_data(MOTORL_ADDRESS, (char)128);
   	_delay_loop_2(40);
   	sb_send_data(MOTORR_ADDRESS, (char)128);
      }


	vfd1_clear();
   vfd1_send_message("CMUCam : ");
   itoa(cmu_pos, message, 10);
   vfd1_send_message(message);
   vfd1_send_message("\nSONAR: ");
   itoa(sonar, message, 10);
   vfd1_send_message(message);

   };



      		break;


      case 4 :	//Make a neural network
            makenet();
      		break;

      case 5 : //Debug the neural network
            debugnet();
      		break;

      case 6 : //Load the neural network
            loadnet();
      		break;

      case 7 : //not implimented yet

      		break;

      case 8 : //run neural network
            runnet();
      		break;

      case 9 : //train neural network

      input_data_array[0][0] = 0.5;
      target_output_array[0][0] = 0.5;
      train_neural_network(input_data_array, target_output_array, 1, 1, 0.15,1,&error,100);



      		break;

      case 10 : //redraw the menu
            draw_menu();
      		break;

      default :
            send_string_P(PSTR("Invalid selection\n\n"));
            draw_menu();
      		break;
      }

   return 1;

   }




//Power On Self Test
void												init_hardware
	(
   void
   )
   {

   unsigned char				errors = 0;
   unsigned char				counter;

   //setup UART1
   init_uart1();

   //setup StannBus
   init_stannbus();

   //clear the display
   vfd1_clear();
   //if we got this far the processor is OK, echo that
   vfd1_send_message("Atmel AVR RISC\n");
   vfd1_send_message("[OK]");

   //wait a few secs
   display_delay();

   //initilize CMUcam and start tracking object
   cmucam_init();
   vfd1_clear();
   vfd1_send_message("CMUCam  ");
	//try to get tracking information, see if the Camera is connected!
   if (cmucam_get_position() == -9)
   	{
      //camera failed, echo that
      vfd1_send_message("[FAILED]");
      errors++;
      }
   else
      {
      //camera is connected, echo that
      vfd1_send_message("[OK]");
      }

   vfd1_send_message("\n");

   vfd1_send_message("SONAR   ");

   //check the SONAR, see if it is connected
   if (sonar_get_distance() == 0)
   	{
      //sonar failed, echo that
      vfd1_send_message("[FAILED]");
      errors++;
      }
   else
   	{
      //sonar is around, echo that
      vfd1_send_message("[OK]");
      }

   //wait a few secs
   display_delay();
   vfd1_clear();

   //make sure there is no backlog in the VFD board
   _delay_loop_2(10000);

   //all boards have been tested, print boot-up message
   vfd1_send_message("Al-Bot Online\n");
   if (errors != 0)
   	{
   	vfd1_send_message("System Failures");
      }
   else
   	{
      vfd1_send_message("All Systems OK");
      }

   return;
   }


  

