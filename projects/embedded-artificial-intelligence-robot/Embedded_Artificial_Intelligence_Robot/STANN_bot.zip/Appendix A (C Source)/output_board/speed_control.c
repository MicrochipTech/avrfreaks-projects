/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*
Physical connection:
OC1A(PB.1 on AtMega8): goes to MOTOR1's /shutdown connection (motor is ON when OC1A is high)
this shutdown pin is used to PWM the motor
PORTB.2: goes to MOTOR1's direction connection (1= motor goes forwards, 0 = reverse)

OC2(PB.3 on AtMega8): goes to MOTOR2's /shutdown conneciton (motor is ON when OC2 is high)
this shutdown pin is used to PWM the motor
PORTB.4 goes to MOTOR2's direction connection (1= motor goes forwards, 0 = reverse)
*/
#include <avr\io.h>
#include "speed_control.h"


void												init_motor
	(
   void
   )
   {
   //set internal oscillator for 8 MHz.. although it would be more normal to use
   //STK500 to get proper value and load into a memory location, this way it is
   //impossible to forget to do this...
   OSCCAL = 0x95;

	//set OC1A and OC2 to OUTPUTs, as well as PORTB.2 and PORTB.4 (direction control)
   DDRB |= 1<<1 | 1<<2 | 1<<3 | 1<<4;

   //default PWM to motors off
   motor1_speed = 0x00;
	motor2_speed = 0x00;
 
   //set 8 bit PWM mode using FAST
   TCCR1A = 1<<WGM10;
   TCCR1B = 1<<WGM12;

   //CLEAR the OC1A pin when the Timer1 (TCNT1) register reaches the compare
   //(OCR1AL), SET that pin when the Timer1 reaches TOP (0xFF)
   TCCR1A |= 1<<COM1A1;

   //Prescale of 1, so use clock frequency directly
   TCCR1B |= 1<<CS10;

   /* NOTE: You could also use the OC1B pin to generate a PWM signal now as well
   by doing
   TCCR1A |= 1<<COM1B1;
   then just write to the OCR1B with a PWM value */

	//set FAST mode for Timer2's PWM
   TCCR2 = 1<<WGM20 | 1<<WGM21;

   //CLEAR the OC2 pin when the Timer2 (TCNT2) register reaches the compare
   //(OCR2), SET that pin when the Timer2 reaches TOP (0xFF)
	TCCR2 |= 1<<COM21;

   //Prescale of 1, so use clock frequency directly
   TCCR2 |= 1<<CS20;

   return;
   }

