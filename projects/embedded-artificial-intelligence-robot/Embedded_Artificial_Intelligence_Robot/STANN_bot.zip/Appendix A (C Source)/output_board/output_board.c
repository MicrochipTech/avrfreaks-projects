/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*
This code is used on the 'output board', which controls the two motors and a
VFD display
*/

#include <avr\io.h>
#include <avr\interrupt.h>
#include <avr\signal.h>

#include <avr\delay.h>

//VFD Control
#include "VFD_162S.h"

//Motor control
#include "speed_control.h"

//the 2-bit address bus, on pins 3 and 4 of the respective PORT
#define PIN_ADDR_BUS		PIND
#define DDR_ADDR_BUS    DDRD

#define INT_DDR			DDRD
#define INT0_NEWDATA_BIT 2

//2-bit addresses of stuff
#define ADDRESS_VFD1		0x00  		//VFD (Vacuum Fluorescent Display) 1
#define ADDRESS_MTRL		0x01        //Left motor
#define ADDRESS_MTRR		0x02        //Right motor

//buffers for VFD
#define MAX_VFD_162S_BUFFER  32
//hold pointer to last read from VFD1 buffer location
volatile unsigned char		VFD_162S_data_counter_read;
//hold pointer to last written to VFD1 buffer location
volatile unsigned char		VFD_162S_data_counter_write;
//VFD1 buffer
volatile unsigned char		VFD_162S_data[MAX_VFD_162S_BUFFER + 1];


int												main
	(
   void
   )
   {

   //setup the data_bus to be input
   DDRC = 0x00;
   DDRB &= ~(1<<6 | 1<<7);

   //address bus to be input
   DDR_ADDR_BUS &= ~(1<<3 | 1<<4);

   //INT0 is input
   INT_DDR &= ~(1<<INT0_NEWDATA_BIT);

   //enable INT0 on RISING edge
   MCUCR |= (1<<ISC01 | 1<<ISC00);
   GICR |= 1<<INT0;

   //enable interrupts
   sei();

   //enable VFD
   VFD_162S_init();

   //enable motors
   init_motor();

   //start looping
   while(1)
   	{

      /*If data is to be outputted to the VFD, then output each byte adding
      a delay inbetween sending to give the VFD time to update */
      if(VFD_162S_data_counter_read != VFD_162S_data_counter_write)
      	{

         VFD_162S_data_counter_read++;

         if (VFD_162S_data_counter_read > MAX_VFD_162S_BUFFER)
         	{
            VFD_162S_data_counter_read = 0;
            }

         _delay_loop_2(10000);

         //send data if it is needed to be sent
  	      VFD_162S_putchar(VFD_162S_data[VFD_162S_data_counter_read]);
         }
      }



   return 1;
   }


/*int0 rising edge interrupt. This will go HIGH when new data can be used on
the databus and decoded for a command...*/
SIGNAL(SIG_INTERRUPT0)
   {
   unsigned char				addr;
   unsigned char				data;
   signed char					datachar;

   //shift address and cut it
   addr = (PIN_ADDR_BUS >> 3) & 0x03;

   //get data
   data = PINC | (PINB & 0xC0);
   datachar = PINC | (PINB & 0xC0);

   //data is for the VFD
   if (addr == ADDRESS_VFD1)
   	{

      //select next buffer location
      VFD_162S_data_counter_write++;

      //check for overflow
      if (VFD_162S_data_counter_write > MAX_VFD_162S_BUFFER)
      	{
         VFD_162S_data_counter_write = 0;
         }

      //write the data
      VFD_162S_data[VFD_162S_data_counter_write] = data;
      }

   //data is for the Right Motor
   else if (addr == ADDRESS_MTRR)
   	{
      if (datachar < 0)
      	{
         motor1_direction_reverse();
         //get motor speed and set it
         motor1_speed = (datachar - 120) * -1;
         }

      else if (datachar > 0)
      	{
         motor1_direction_forward();
         //get motor speed and set it
         motor1_speed = (datachar + 120);
         }

      else
      	{
         motor1_speed = 0;
         }
      }

	//data is for the Left Motor
   else if (addr == ADDRESS_MTRL)
   	{
      if (datachar < 0)
      	{
         motor2_direction_reverse();
         //get motor speed and set it
         motor2_speed = (datachar - 120) * -1;
         }

      else if (datachar > 0)
      	{
         motor2_direction_forward();
         //get motor speed and set it
         motor2_speed = (datachar + 120);
         }

      else
      	{
         motor2_speed = 0;
         }

      }
   }

/* Default interrupt, SHOULD NEVER OCCUR!!!!! */
SIGNAL(__vector_default)
	{
   }
