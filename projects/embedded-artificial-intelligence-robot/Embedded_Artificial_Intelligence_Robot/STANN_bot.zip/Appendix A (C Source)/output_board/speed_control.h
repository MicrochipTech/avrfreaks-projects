/* This module is part of the STANN (Self Training Artificial Neural Network)
project. The code is also part of the Al-Bot (Al as in Allan) Artificial
Intelligence Development Platform.

Project made by Colin O'Flynn, and can be used in any project,
commercial or non-commercial, however this source code must be provided for free,
which means you can't sell this code. There is NO warranties of any type that
comes with this code, comments in code, or project.

Check http://www.newae.com for more information, and/or e-mail c_oflynn@yahoo.com
OR coflynn@newae.com */

/*
Physical connection:
OC1A(PB.1 on AtMega8): goes to MOTOR1's /shutdown connection (motor is ON when OC1A is high)
this shutdown pin is used to PWM the motor
PORTB.2: goes to MOTOR1's direction connection (1= motor goes forwards, 0 = reverse)

OC2(PB.3 on AtMega8): goes to MOTOR2's /shutdown conneciton (motor is ON when OC2 is high)
this shutdown pin is used to PWM the motor
PORTB.4 goes to MOTOR2's direction connection (1= motor goes forwards, 0 = reverse)
*/

//setup PWM
void												init_motor
	(
   void
   );

//macros used
#define motor1_direction_forward()	(PORTB |= 1<<2)
#define motor1_direction_reverse()	(PORTB &= ~(1<<2))

#define motor2_direction_forward()	(PORTB |= 1<<4)
#define motor2_direction_reverse()	(PORTB &= ~(1<<4))

#define motor1_speed						OCR1A		//NOTE: This is actually a 16 bit reg
#define motor2_speed						OCR2

