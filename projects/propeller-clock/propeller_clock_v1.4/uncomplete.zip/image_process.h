/*
 * image_process.h
 *
 * Created: 01-06-2011 23:44:02
 *  Author: limapapy
 */ 


#ifndef IMAGE_PROCESS_H_
#define IMAGE_PROCESS_H_


typedef struct{
	unsigned int x:6;
	unsigned int y:6;
}coord_t;



coord_t polar_to_rectangular(int theta,int radius);

#endif /* IMAGE_PROCESS_H_ */