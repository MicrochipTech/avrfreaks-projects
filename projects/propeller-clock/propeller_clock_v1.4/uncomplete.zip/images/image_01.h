#ifndef IMAGE_01_H 
#define IMAGE_01_H


#ifndef rgb_t
typedef struct{
	unsigned int r:2;
	unsigned int g:2;
	unsigned int b:2;
}rgb_t;
#endif
	extern const rgb_t image_01[64][64];

#endif //IMAGE_01_H