﻿/*
 * propeller.c
 *
 * Created: 27-05-2011 19:51:24
 *  Author: limapapy
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "rs232.h"
#include "i2c_com.h"
#include "ext_int.h"
//#include "image_process.h"

typedef struct b{
	unsigned char v:2;
} char_2_t;

char_2_t val;

int main(void)
{

	serial_init(BAUD_PRESCALE);
	init_INT();
	reset_values();
	DDRF=0xFF;
	//PORTF=(3<<1);
	//serial_send_message("Patricio");
    while(1)
    {
    }
}

ISR(USART0_RX_vect){
	unsigned char rec;
	command cmd;
	rec = UDR0; // Fetch the received byte value into the variable "ByteReceived"
	UDR0 = rec; // Echo back the received byte back to the computer 
	
	USART_WORD[USART_WORD_INDEX]=rec;
	USART_WORD_INDEX=(USART_WORD_INDEX+1)%MAX_SIZE_WORD;
	cmd = decode_CMD(USART_WORD);
	LAST_CHAR=rec;
	switch(rec){
		case ENTER:
			switch (cmd){
			case SET_CLOCK:
				set_clock();
				set_clockRTC(seconds,minuts,hours);
				LAST_CHAR=cmd;
				break;
			case GET_CLOCK:
				serial_send_message(get_clock());
				PORTF=val.v;
				LAST_CHAR=cmd;
				break;
			case INVALID_CMD:
				serial_send_message("Invalid command\r\n");
			
			default:
			reset_values();
			break;
			}
			reset_values();
			break;	
		case BACK_SPACE:
			if (USART_WORD_INDEX>0)
			{
				USART_WORD_INDEX--;
				USART_WORD[USART_WORD_INDEX]='\0';
				USART_WORD_INDEX--;
				USART_WORD[USART_WORD_INDEX]='\0';
			}
			break;
		default:
		
		break;
		
		
	}
		
}
ISR(INT2_vect){
	INT2_task();
	
}
