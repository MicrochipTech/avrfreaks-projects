/*
 * ext_int.h
 *
 * Created: 06-06-2011 23:14:13
 *  Author: limapapy
 */ 


#ifndef EXT_INT_H_
#define EXT_INT_H_



void init_INT(void);

void INT2_task(void);


#endif /* EXT_INT_H_ */