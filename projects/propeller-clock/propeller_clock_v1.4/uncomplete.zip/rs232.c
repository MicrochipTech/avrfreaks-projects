/*
 * rs232.c
 *
 * Created: 27-05-2011 20:12:06
 *  Author: limapapy
 * TXCn check the transmitter has complete.
 * RXCn check if data on receiver.
 */ 
#include <stdio.h>
#include <avr/io.h>
#include <string.h>
#include <avr/interrupt.h>
#include <string.h>
#include "rs232.h"

unsigned int hours;
unsigned int minuts;
unsigned int seconds;
unsigned char USART_WORD[MAX_SIZE_WORD];
unsigned int USART_WORD_INDEX;
unsigned int LAST_CHAR;

//initialize serial interface
void serial_init(unsigned int ubrr){
	//set the baud rate
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)(ubrr);
	//enable transmitter and receiver
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	//set frame format 8 bit for data 1 stop bit
	UCSR0C = (3<<UCSZ00);	
	UCSR0B |=(1<<RXCIE0); //enable usart receiver interrupt
	
	sei();	//enabling global interrupt
	
}

//send a character through serial port
void serial_send(unsigned char data){
	
	/*wait until the buffer is empty*/
	while (!(UCSR0A & (1<<UDRE0)));
	
	//when is ready put the data in the register to be sent
	UDR0 = data;
	
}

//receive a character from serial port
unsigned char serial_receive(void){
	//wait for data 
	while (!(UCSR0A & (1<<RXC0)));
	return UDR0;
}

void serial_send_message(unsigned char *msg){
	int i;
	int len=strlen((char *)msg);
	for (i=0;i<len;i++)
	{
		serial_send(msg[i]);
	}
	
}

void set_clock(void){
	unsigned char data[6];
	unsigned int i;
	bool number=true;
	for (i=0;i<6;i++)
	{
		data[i]=USART_WORD[i+CMD_SIZE];
		LAST_CHAR=i;
		if (data[i]<0x30 || data[i]>0x39 )
		{
			number=false;
			break;
		}
	}
	if (number==false){
		serial_send(0x0D);
		serial_send_message((unsigned char*)"Invalid Clock Format");
		return;
	}
	hours=((data[0] & 0x0F)<<4)|(data[1] & 0x0F );
	minuts=((data[2] & 0x0F)<<4)|(data[3] & 0x0F );
	seconds=((data[4] & 0x0F)<<4)|(data[5] & 0x0F );
	return;
}

command decode_CMD(unsigned char *cmd){
	if (strncasecmp((char*)cmd,"SCLK",4)==true)
	{
		return SET_CLOCK;
	} 
	else if(strncasecmp((char*)cmd,"GCLK",4)==true)
	{
		return GET_CLOCK;
	}
	else if (strncasecmp((char*)cmd,"SPIC",4)==true)
	{
		return SEND_PIC;
	}else if (strncasecmp((char*)cmd,"DPIC",4)==true)
	{
		return DISP_PIC;
	}else
	{
		return INVALID_CMD;
	}
		
	
}

void reset_values(void){
	
	memset(USART_WORD,0,MAX_SIZE_WORD);
	USART_WORD_INDEX=0;
	hours=0;
	minuts=0;
	seconds=0;
	
	
}