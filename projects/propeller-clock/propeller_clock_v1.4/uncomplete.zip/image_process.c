/*
 * image_process.c
 *
 * Created: 01-06-2011 23:44:26
 *  Author: limapapy
 */ 
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "image_process.h"
#include "images/image_01.h"
#include "spi_com.h"

#define X_PIXEL				64
#define Y_PIXEL				64
#define RADIUS				32
#define CURRENT_IMAGE		image_01
//rgb_t IMAGE[X_PIXEL][Y_PIXEL];
unsigned int CURRENT_ANGLE;

//convert the rectangular to polar
coord_t polar_to_rectangular(int theta,int radius){
	coord_t pos;
	pos.x=(int)((float)radius*(float)cos(theta)+32);
	pos.y=(int)(-(float)radius*(float)sin(theta)+32);
	return pos;
}

//get the next state of the leds from the matrix 
rgb_t *get_train(int theta){
	int i=0;
	coord_t pos;
	rgb_t *train=(rgb_t*)malloc(RADIUS*sizeof(rgb_t));
	for (i=0;i<RADIUS;i++){
		pos = polar_to_rectangular(theta,i);
		train[i]=CURRENT_IMAGE[pos.y][pos.x];
	}
	return train;
}

//send the data to the leds drivers
void  next_train(rgb_t *leds){
	unsigned char i;
	int to_send=0;
	for (i=0;i<32;i+=2){
		//send first 3 byte
		to_send=(leds[i].r<<10);
		to_send=(to_send<<12)|(leds[i].g<<10);
		SPI_send(to_send);
		to_send=to_send>>8;
		SPI_send(to_send);
		to_send=to_send>>8;
		SPI_send(to_send);
		
		//send second 3 byte
		to_send=(leds[i].b<<10);
		to_send=(to_send<<12)|(leds[i+1].r<<10);
		SPI_send(to_send);
		to_send=to_send>>8;
		SPI_send(to_send);
		to_send=to_send>>8;
		SPI_send(to_send);
		
		//send third 3 byte
		to_send=(leds[i+1].g<<10);
		to_send=(to_send<<12)|(leds[i+1].b<<10);
		SPI_send(to_send);
		to_send=to_send>>8;
		SPI_send(to_send);
		to_send=to_send>>8;
		SPI_send(to_send);
		
	}
}



