/*
 * ext_int.c
 *
 * Created: 06-06-2011 22:57:08
 *  Author: limapapy
 */ 
#include <avr/interrupt.h>

void init_INT(void){
	EICRA = (1<<ISC20)|(1<<ISC21);	//choose rising edge
	EIMSK = (1<<INT2);				//set the mask for INT2
	EIFR = (1<<INTF2);
	//DDRD |=(1<<2);
	DDRD &=~(1<<2);	//set as input
	PORTD |=(1<<2); //activate internal pull up.
	sei();
}	

void INT2_task(void){
	PORTF^=0x01;
	
}