#include <avr/io.h>
#include "spi_com.h"


void SPI_MasterConfig(void)
{
/* Set MOSI and SCK output, all others input */
DDRB = (1<<DDB2)|(1<<DDB1)|(1<<DDB0);
/* Enable SPI, Master, set clock rate fck/4 */
SPCR = (1<<SPE)|(1<<MSTR);
}

void SPI_send(unsigned char cData)
{
/* Start transmission */
SPDR = cData;
/* Wait for transmission complete */
while(!(SPSR & (1<<SPIF))){;}
}


void set_xlat(void)
	{
	PORTB |= _BV(PB0);
	}

void clear_xlat(void)
	{
	PORTB &= ~(_BV(PB0));
	}
