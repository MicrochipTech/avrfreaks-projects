#!/bin/sh

. config.sh

echod "Building AVR-libc ${AVRLIBC_VERSION}"

cd build/avr-libc-${AVRLIBC_VERSION} || \
	die "Could not CD to build/gmp-${AVRLIBC_VERSION}"

test -f config.status || {
	./configure --prefix=$PREFIX --host=avr || \
		die "Could not configure AVRLIBC ${AVRLIBC_VERSION}"
}

$MAKE $MAKEFLAGS || \
	die "Could not build AVRLIBC ${AVRLIBC_VERSION}"

$MAKE check || \
	die "AVRLIBC ${AVRLIBC_VERSION} tests failed"

$MAKE install || \
	die "Could not install ${AVRLIBC_VERSION}"

cp LICENSE $PREFIX/licenses/LICENSE.avrlibc
