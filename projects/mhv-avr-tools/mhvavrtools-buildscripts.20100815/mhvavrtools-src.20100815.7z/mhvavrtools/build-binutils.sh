#!/bin/sh

. config.sh

echod "Building binutils ${BINUTILS_VERSION}"

cd build/binutils-${BINUTILS_VERSION} || \
	die "Could not CD to build/gmp-${BINUTILS_VERSION}"

mkdir obj-avr
cd obj-avr

test -f config.status || {
	../configure --target=avr --disable-nls --prefix=$PREFIX --with-mpc=$PREFIX --with-mpfr=$PREFIX --with-gmp=$PREFIX || \
		die "Could not configure BINUTILS ${BINUTILS_VERSION}"
}

make configure-host || \
	die "Could not make configure-host"

cd bfd
$MAKE headers || \
	die "Could not build bfd headers"
cd ..


$MAKE || \
	die "Could not build BINUTILS ${BINUTILS_VERSION}"

#$MAKE  check || \
#	die "BINUTILS ${BINUTILS_VERSION} tests failed"

$MAKE install || \
	die "Could not install ${BINUTILS_VERSION}"

cd ..
for file in COPYING*; do
	cp $file $PREFIX/licenses/$file.binutils
done
