#AUTOCONF_VERSION=2.67
#AUTOCONF_VERSION=2.61
AVRLIBC_VERSION=1.7.0
BINUTILS_VERSION=2.20.1
LIBTOOL_VERSION=2.2.10
GCC_VERSION=4.5.1
MAKE_VERSION=3.82
GMP_VERSION=5.0.1
MPFR_VERSION=3.0.0
MPC_VERSION=0.8.2
SWIG_VERSION=2.0.0
# Currently using the GIT version until the release supports GMP 5
#PPL_VERSION=0.10.2
#CLOOG_PPL_VERSION=0.15.9
AVRLIBC_VERSION=1.7.0
AVRDUDE_VERSION=5.10
LIBUSB_VERSION=1.2.1.0

TOP=`pwd`
#PREFIX="$TOP/root"
PREFIX="c:/mhvavrtools"
export PREFIX

#ABI=32
#export ABI

#M4=m4
#export M4

CPPFLAGS="-I$PREFIX/include"
export CPPFLAGS

LDFLAGS="-L$PREFIX/lib"
export LDFLAGS

MAKEFLAGS=""


PATH="/c/mhvavrtools/bin:/usr/local/bin:/mingw/bin:/bin:/c/Python2.7:/c/Windows/system32:/c/Windows:/c/Windows/System32/Wbem:/c/Windows/system32/wbem"
export PATH



MAKE="/bin/make"
export MAKE

echod() {
	echo `date`: $*
}

die() {
	echod $*
	exit 1
}

