Copyright (c) 2010, Make, Hack, Void Inc
All rights reserved.

A WinAVR replacement, since WinAVR is no longer being updated.

Currently consists of the following binaries:

GCC 4.5.1          http://gcc.gnu.org
GNU Binutils 2.20  http://www.gnu.org/software/binutils/
AVR LibC 1.7.0     http://www.nongnu.org/avr-libc/
AVRDUDE 5.10       http://www.nongnu.org/avrdude/

And the following supporting libraries:

GNU MP            http://gmplib.org/
MPC               http://www.multiprecision.org/
GNU MPFR          http://www.mpfr.org/

The tools were built using:
MinGW/MSYS        http://www.mingw.org

For an efficiency-oriented runtime library, we recommend:
MHVLib            http://www.makehackvoid.com/mhvlib