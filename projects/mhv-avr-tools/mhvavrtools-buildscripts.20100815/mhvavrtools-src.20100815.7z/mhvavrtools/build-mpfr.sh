#!/bin/sh

. config.sh

echod "Building MPFR ${MPFR_VERSION}"

cd build/mpfr-${MPFR_VERSION} || \
	die "Could not CD to build/gmp-${MPFR_VERSION}"

test -f config.log || {
	./configure --prefix=$PREFIX --with-gmp-build=../gmp-${GMP_VERSION} --enable-shared || \
		die "Could not configure MPFR ${MPFR_VERSION}"
}

$MAKE $MAKEFLAGS || \
	die "Could not build MPFR ${MPFR_VERSION}"

#$MAKE check || \
#	die "MPFR ${MPFR_VERSION} tests failed"

$MAKE install || \
	die "Could not install ${MPFR_VERSION}"

for file in COPYING*; do
	cp $file $PREFIX/licenses/$file.mpfr
done
