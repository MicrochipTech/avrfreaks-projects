#!/bin/sh

. config.sh

mkdir build
cd build

for file in ../download/*.bz2; do
	echod "Extracting $file"
	tar jxf $file
done

for file in ../download/*.gz; do
	echod "Extracting $file"
	tar zxf $file
done

for file in ../download/*.zip; do
	echod "Extracting $file"
	unzip $file
done

for file in ../download/*.xz; do
	echod "Extracting $file"
	xz -d -c $file | tar xf -
done

cd binutils-${BINUTILS_VERSION}
for file in ../../patches/binutils-*.patch; do
	echod Patching with $file
	patch -p0 < $file || \
		die "Patch failed"
done
cd ..

cd avr-libc-${AVRLIBC_VERSION}
for file in ../../patches/avr-libc-*.patch; do
	echod Patching with $file
	patch -p0 < $file || \
		die "Patch failed"
done
cd ..

cd gcc-${GCC_VERSION}
for file in ../../patches/gcc-*.patch; do
	echod Patching with $file
	patch -p1 < $file || \
		die "Patch failed"
done
cd ..

cd gmp-${GMP_VERSION}
for file in ../../patches/gmp-*.patch; do
	echod Patching with $file
	patch -p0 < $file || \
		die "Patch failed"
done
cd ..

cd make-${MAKE_VERSION}
for file in ../../patches/make-*.patch; do
	echod Patching with $file
	patch -p1 < $file || \
		die "Patch failed"
done
cd ..
