#!/bin/sh

. config.sh

echod "Building AVRDUDE ${AVRDUDE_VERSION}"

cd build/avrdude-${AVRDUDE_VERSION} || \
	die "Could not CD to build/avrdude-${AVRDUDE_VERSION}"

export CFLAGS="$CFLAGS -I$TOP/build/libusb-win32-bin-${LIBUSB_VERSION}/include"
export LDFLAGS="$LDFLAGS -L$TOP/build/libusb-win32-bin-${LIBUSB_VERSION}/lib/gcc -lusb"

test -f config.log ||  {
	./configure --build=mingw32 --prefix=$PREFIX --sysconfdir="c:\\mhvavrtools\bin" || \
		die "Could not configure AVRDUDE ${AVRDUDE_VERSION}"
}

$MAKE || \
	die "Could not build AVRDUDE ${AVRDUDE_VERSION}"

$MAKE install || \
	die "Could not install ${AVRDUDE_VERSION}"

cp COPYING $PREFIX/licenses/COPYING.avrdude
