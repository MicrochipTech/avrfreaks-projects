	Simple VGA adapter demo1
This example demonstrate how to make simplest users handler
Here work 2 tasks:
1. Checked PortC.1 and show this state onto display
2. Count some time value, encode it at ��� and show this value onto display
