	Simple VGA adapter demo2
This example demonstrate advanced users handler
Used task switcher and here work 3 tasks:
1. Primitive logic analizer. Checked PortC.1 and show this state onto display
2. Primitive stop watch. Timer running on logical "0" at pin PortC.1.
   Count time value, encode it at decimal sec and show this value onto display
3. Primitive DC Voltmeter. Get the ADC value from ADC0, convert it to decimal Volts
   and show this value onto display
