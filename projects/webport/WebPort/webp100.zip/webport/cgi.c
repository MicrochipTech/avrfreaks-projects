/*
 * Copyright (C) 2002 by egnite Software GmbH. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by egnite Software GmbH
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY EGNITE SOFTWARE GMBH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL EGNITE
 * SOFTWARE GMBH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.ethernut.de/
 *
 */

#include <string.h>
#include <io.h>

#include <dev/spidigio.h>
#include <sys/print.h>
#include <pro/httpd.h>

#include "webport.h"

/*!
 * \addtogroup xgCGI
 */
/*@{*/

static u_char spi_ni = 255;     /*!< \brief Number of detected opto inputs. */
static u_char spi_no = 255;     /*!< \brief Number of detected relays. */
static u_long relay_status;     /*!< \brief Relays status. */
static u_char relay_known;      /*!< \brief Equals zero as long as the relay status is unknown. */

/*!
 * \brief Print HTML code for a row of LEDs.
 *
 * The resulting HTML code will present a row of LEDs. The color and
 * the lit state of each LED is determined by three bit values. The
 * required images are expected in the URL root of the urom flash
 * filesystem:
 *
 * - r0.gif Red LED not lit. Will be displayed if the corresponding
 *          bit in the direction mask is set and the input and output
 *          bits are both not set.
 * - r1.gif Red LED lit. Will be displayed if the corresponding
 *          bit in the direction mask is set and the input and output
 *          bits are both set.
 * - g0.gif Green LED not lit. Will be displayed if the corresponding
 *          bit in the direction mask and the input value are both not set.
 * - g1.gif Green LED lit. Will be displayed if the corresponding
 *          bit in the direction mask is not set and the input bit is set.
 * - y0.gif Yellow LED not lit. Will be displayed if the corresponding
 *          bit in the direction mask is set, the output bit is set
 *          but the input bit is not set.
 * - y1.gif Yellow LED lit. Will be displayed if the corresponding
 *          bit in the direction mask is set, the output bit is not set
 *          but the input bit is set.
 *
 * All LED images must be of the same size, 28 x 28 pixels.
 *
 * \param stream HTML code is printed to this stream device.
 * \param num    The number of LEDs to print.
 * \param desc   If not equal zero, bits are processed in descending order.
 * \param ival   Input bit values.
 * \param oval   Output bit values.
 * \param dir    Data direction mask. Any bit set to one represents an output.
 */
static void HtmlLedRow(NUTDEVICE *stream, u_char num, u_char desc, u_long ival, u_long oval, u_long dir)
{
    u_char i;
    u_long mask;

    for(i = 0; i < num; i++) {
        if(desc)
            mask = 1UL << (num - i - 1);
        else
            mask = 1UL << i;
        NutPrintString_P(stream, PSTR("<td><img src=\"/"));
        if(dir & mask) {
            if(oval & mask) {
                if(ival & mask) 
                    NutPrintString_P(stream, PSTR("r1"));
                else 
                    NutPrintString_P(stream, PSTR("y0"));
            }
            else {
                if(ival & mask)
                    NutPrintString_P(stream, PSTR("y1"));
                else
                    NutPrintString_P(stream, PSTR("r0"));
            }
        }
        else {
            if(ival & mask) {
                NutPrintString_P(stream, PSTR("g1"));
            }
            else {
                NutPrintString_P(stream, PSTR("g0"));
            }
        }
        NutPrintString_P(stream, PSTR(".gif\" width=\"28\" heigth=\"28\"></td>\r\n"));
    }
}

/*!
 * \brief Print HTML code for a row of checkboxes.
 *
 * The resulting HTML code will present a row of checkboxes. 
 *
 * \param stream HTML code is printed to this stream device.
 * \param num    The number of checkboxes to print.
 * \param desc   If not equal zero, bits are processed in descending order.
 * \param name   Identifier of the checkboxes.
 * \param check  The checkbox will be checked if the corresponding bit is set.
 * \param enable The checkbox will be created only, ff the corresponding bit 
 *               in this bitmask is set.
 */
static void HtmlCheckboxRow(NUTDEVICE *stream, u_char num, u_char desc, u_char *name, u_long check, u_long enable)
{
    u_char i;
    u_long mask;

    for(i = 0; i < num; i++) {
        if(desc)
            mask = 1UL << (num - i - 1);
        else
            mask = 1UL << i;
        if(enable & mask) {
            NutPrintString_P(stream, PSTR("<td><input type=\"checkbox\" name=\""));
            NutPrintFormat(stream, "%s\" value=\"%u\" ", name, i);
            if(check & mask) 
                NutPrintString_P(stream, PSTR(" checked=\"checked\""));
            NutPrintString_P(stream, PSTR("></td>\r\n"));
        }
        else
            NutPrintString_P(stream, PSTR("<td></td>\r\n"));
    }
}


/*!
 * \brief Print HTML code for a separator row.
 *
 * The resulting HTML code will present a black row. 
 *
 * \param stream HTML code is printed to this stream device.
 * \param width  Separator width in columns.
 * \param height Separator width in pixels.
 */
static void HtmlSeparatorRow(NUTDEVICE *stream, u_char width, u_char height)
{
    NutPrintFormat(stream, "<tr bgcolor=\"#000000\"><td colspan=\"%u\" "
                           "height=\"%u\"></td></tr>", width, height);
}

/*!
 * \brief Print HTML code to display a single I/O port.
 *
 * The resulting HTML code will present a row of LEDs and two rows of
 * checkboxes. While the LEDs show the current port status, the checkboxes
 * may be used to modify the port output and the data direction register.
 *
 * See HtmlLedRow() for further details about how LEDs are displayed.
 * The checkboxes are created by calling HtmlCheckboxRow().
 *
 * \param stream HTML code is printed to this stream device.
 * \param name   Port identifier, typically 'A' for Port A, 'B' for port B etc.
 * \param pin    Contents of the PIN register.
 * \param port   Contents of the PORT register.
 * \param ddr    Contents of the data direction register.
 * \param enable If a bit is not set in this bit mask, then the corresponding
 *               checkboxes are not created and the port bits and data direction
 *               can't be modified.
 */
static void HtmlInOutPortRow(NUTDEVICE *stream, char name, u_char pin, u_char port, u_char ddr, u_char enable)
{
    char ditem[3] = { 'D', 'X', 0 };
    char pitem[3] = { 'P', 'X', 0 };

    ditem[1] = name;
    pitem[1] = name;
    NutPrintString_P(stream, PSTR("<tr><th rowspan=\"4\">"));
    NutPrintFormat(stream, "%c", name);
    NutPrintString_P(stream, PSTR("</th><td>Status</td>"));
    HtmlLedRow(stream, 8, 1, pin, port, ddr);
    NutPrintString_P(stream, PSTR("</tr>\r\n<tr><td>Output</td>"));
    HtmlCheckboxRow(stream, 8, 1, ditem, ddr, enable);
    NutPrintString_P(stream, PSTR("</tr>\r\n<tr><td>Pull up</td>"));
    HtmlCheckboxRow(stream, 8, 1, pitem, port, enable);
    NutPrintString_P(stream, PSTR("</tr>\r\n"));
}

/*!
 * \brief Process request parameters for CPU port control.
 *
 * Parse the CGI query and perform the corresponding action:
 *
 * - Dx=y will set bit y in the data direction register of port x.
 * - Px=y will set bit y in the port output register of port x.
 *
 * All other bits are switched off.
 *
 * \param query CGI query string.
 */
static void ProcessCgiPortRequest(char *query)
{
    u_char *item = query;
    u_char *val;
    u_char ddrb = 0;
    u_char portb = 0;
    u_char ddrd = 0;
    u_char portd = 0;
    u_char ddre = 0;
    u_char porte = 0;
    
    for(;;) {
        if((val = strchr(item, '=')) == 0)
            break;
        *val++ = 0;
        if(strcmp(item, "DB") == 0)
            ddrb |= BV(*val - '0'); 
        else if(strcmp(item, "PB") == 0)
            portb |= BV(*val - '0'); 
        else if(strcmp(item, "DD") == 0)
            ddrd |= BV(*val - '0'); 
        else if(strcmp(item, "PD") == 0)
            portd |= BV(*val - '0'); 
        else if(strcmp(item, "DE") == 0)
            ddre |= BV(*val - '0'); 
        else if(strcmp(item, "PE") == 0)
            porte |= BV(*val - '0');
        if((item = strchr(val, '&')) == 0)
            break;
        item++;
    }
    outp(ddrb, DDRB);
    outp(portb, PORTB);
    outp(ddrd, DDRD);
    outp(portd, PORTD);
    outp(ddre, DDRE);
    outp(porte, PORTE);
}

/*!
 * \brief Process request parameters for relay output control.
 *
 * Parse the CGI query and switch the corresponding relays.
 * 'S=y' will switch on relay y. All other relays are switched off.
 *
 * Note, that before calling this function is called for the first time,
 * the status of the relays is unknown.
 *
 * \param query CGI query string.
 */
static void ProcessCgiRelayRequest(char *query)
{
    u_char *item = query;
    u_char *val;
    
    relay_status = 0;
    for(;;) {
        if((val = strchr(item, '=')) == 0)
            break;
        *val++ = 0;
        if(item[0] == 'S')
            relay_status |= 1UL << (*val - '0');
        if((item = strchr(val, '&')) == 0)
            break;
        item++;
    }
    SpiDigitalSet(spi_no, relay_status);
    relay_known = 1;
}

/*!
 * \brief CGI callback function to control the CPU ports.
 *
 * Creates HTML code to show the status of CPU ports B, D, E and F
 * plus a HTML form to modify the port and data direction registers 
 * of ports B, D and E by checkboxes. 
 *
 * The resulting HTML code is send back to the browser. If the submit
 * button is clicked on this page, this function will be called again
 * to process the checkboxes.
 *
 * \image html cport.gif
 *
 * This function is called by the HTTP module when a browser requests
 * a CGI function, for which this routine has been registered via
 * NutRegisterCgi().
 *
 * \param sostream Stream device of the HTTP connection.
 * \param req      Pointer to the CGI ::REQUEST structure.
 *
 * \return 0 on success or -1 in case of any failure.
 */
int CpuPortControl(NUTDEVICE *sostream, REQUEST *req)
{
    NutHttpSendHeaderTop(sostream, req, 200, "Ok");
    NutHttpSendHeaderBot(sostream, "text/html", -1);

    NutPrintString_P(sostream, PSTR("<html>"
                                 "<head>"
                                 "<meta http-equiv=\"expires\" content=\"0\">"
                                 "<title>Ethernut CPU Port Control</title>"
                                 "</head>"
                                 "<body bgcolor=\"#C7D0D9\"><a href=\"/\">"
                                 "<img src=\"/enmini.gif\" border=\"0\" width=\"70\" height=\"17\">"
                                 "</a><div align=\"center\">"));
    if(req->req_query)
        ProcessCgiPortRequest(req->req_query);

    NutPrintString_P(sostream, PSTR("<form action=\"" PORT_CONTROL_CGI
                                    "\" enctype=\"text/plain\">"
                                    "<table border=\"1\" cellspacing=\"0\">\r\n"
                                    "<thead><tr><th rowspan=\"2\"> PORT </th>"
                                    "<th rowspan=\"2\"> Type </th>"
                                    "<th colspan=\"8\">Bit</th></tr>"
                                    "<tr><th>7</th><th>6</th><th>5</th><th>4</th><th>3</th>"
                                    "<th>2</th><th>1</th><th>0</th></tr>"
                                    "</thead><tfoot>\r\n"));
 
    HtmlInOutPortRow(sostream, 'B', inp(PINB), inp(PORTB), inp(DDRB), 0xFF);
    HtmlSeparatorRow(sostream, 10, 5);
    HtmlInOutPortRow(sostream, 'D', inp(PIND), inp(PORTD), inp(DDRD), 0xFF);
    HtmlSeparatorRow(sostream, 10, 5);
    HtmlInOutPortRow(sostream, 'E', inp(PINE), inp(PORTE), inp(DDRE), 0xDC);
    HtmlSeparatorRow(sostream, 10, 5);

    NutPrintString_P(sostream, PSTR("<tr><th>F</th><td>Status</td>"));
    HtmlLedRow(sostream, 8, 1, inp(PINF), inp(PINF), 0);
    NutPrintString_P(sostream, PSTR("</tr>\r\n"));

    NutPrintString_P(sostream, PSTR("</tfoot></table><br>"
                                    " <input type=\"submit\" value=\" Set \"> "
                                    " <input type=\"reset\" value=\" Cancel \"> "
                                    "</form>\r\n</div></body>\r\n</html>"));
    NutPrintFlush(sostream);
    return 0;
}


/*!
 * \brief CGI callback function to display the status of the CPU ports.
 *
 * Creates HTML code to show the status of CPU ports B, D, E and F.
 * The page will be automatically refreshed once a second.
 *
 * \image html sport.gif
 *
 * This function is called by the HTTP module when a browser requests
 * a CGI function, for which this routine has been registered via
 * NutRegisterCgi().
 *
 * \param sostream Stream device of the HTTP connection.
 * \param req      Pointer to the CGI ::REQUEST structure.
 *
 * \return 0 on success or -1 in case of any failure.
 */
int CpuPortStatus(NUTDEVICE *sostream, REQUEST *req)
{
    NutHttpSendHeaderTop(sostream, req, 200, "Ok");
    NutHttpSendHeaderBot(sostream, "text/html", -1);

    NutPrintString_P(sostream, PSTR("<html>"
                                 "<head>"
                                 "<meta http-equiv=\"refresh\" content=\"1; URL=" PORT_STATUS_CGI "\">"
                                 "<title>Ethernut CPU Port Status</title>"
                                 "</head>"
                                 "<body bgcolor=\"#C7D0D9\"><a href=\"/\">"
                                 "<img src=\"/enmini.gif\" border=\"0\" width=\"70\" height=\"17\">"
                                 "</a><div align=\"center\">"));

    NutPrintString_P(sostream, PSTR("<table border=\"1\" cellspacing=\"0\">\r\n"
                                    "<thead><tr><th rowspan=\"2\"> PORT </th>"
                                    "<th colspan=\"8\">Bit</th></tr>"
                                    "<tr><th>7</th><th>6</th><th>5</th><th>4</th><th>3</th>"
                                    "<th>2</th><th>1</th><th>0</th></tr>"
                                    "</thead><tfoot>\r\n"));
 
    NutPrintString_P(sostream, PSTR("<tr><th>B</th>"));
    HtmlLedRow(sostream, 8, 1, inp(PINB), inp(PORTB), inp(DDRB));
    NutPrintString_P(sostream, PSTR("</tr>\r\n"));

    NutPrintString_P(sostream, PSTR("<tr><th>D</th>"));
    HtmlLedRow(sostream, 8, 1, inp(PIND), inp(PORTD), inp(DDRD));
    NutPrintString_P(sostream, PSTR("</tr>\r\n"));

    NutPrintString_P(sostream, PSTR("<tr><th>E</th>"));
    HtmlLedRow(sostream, 8, 1, inp(PINE), inp(PORTE), inp(DDRE));
    NutPrintString_P(sostream, PSTR("</tr>\r\n"));

    NutPrintString_P(sostream, PSTR("<tr><th>F</th>"));
    HtmlLedRow(sostream, 8, 1, inp(PINF), inp(PINF), 0);
    NutPrintString_P(sostream, PSTR("</tr>\r\n"));

    NutPrintString_P(sostream, PSTR("</tfoot></table><br>"
                                    "</div></body>\r\n</html>"));
    NutPrintFlush(sostream);
    return 0;
}


/*!
 * \brief CGI callback function to control a SPI relay output board.
 *
 * Creates HTML code to show the status of any attached SPI relay 
 * output board plus a HTML form to modify the current relay status
 * via checkboxes.
 *
 * The resulting HTML code is send back to the browser. If the submit
 * button is clicked on this page, this function will be called again
 * to process the checkboxes and display the updated status.
 *
 * \image html relay.gif
 *
 * This function is called by the HTTP module when a browser requests
 * a CGI function, for which this routine has been registered via
 * NutRegisterCgi().
 *
 * \param sostream Stream device of the HTTP connection.
 * \param req      Pointer to the CGI ::REQUEST structure.
 *
 * \return 0 on success or -1 in case of any failure.
 */
int SpiRelayControl(NUTDEVICE *sostream, REQUEST *req)
{
    u_char i;

    if(spi_no == 255)
        SpiDigitalInit(&spi_ni, &spi_no);

    NutHttpSendHeaderTop(sostream, req, 200, "Ok");
    NutHttpSendHeaderBot(sostream, "text/html", -1);

    NutPrintString_P(sostream, PSTR("<html>"
                                 "<head>"
                                 "<meta http-equiv=\"expires\" content=\"0\">"
                                 "<title>Ethernut SPI Relay Output</title>"
                                 "</head>"
                                 "<body bgcolor=\"#C7D0D9\"><a href=\"/\">"
                                 "<img src=\"/enmini.gif\" border=\"0\" width=\"70\" height=\"17\">"
                                 "</a><div align=\"center\">"));

    if(spi_no) {
        if(req->req_query) 
            ProcessCgiRelayRequest(req->req_query);

        NutPrintString_P(sostream, PSTR("<form action=\"" RELAY_CONTROL_CGI "\" enctype=\"text/plain\">"
                                        "<table border=\"1\" cellspacing=\"0\">\r\n"
                                        "<thead><tr><th> </th><th colspan=\""));
        NutPrintFormat(sostream, "%u", spi_no);
        NutPrintString_P(sostream, PSTR("\">Relay</th></tr><tr><td> </td>"));
        for(i = 1; i <= spi_no; i++)
            NutPrintFormat(sostream, "<th>%u</th>", i);
        NutPrintString_P(sostream, PSTR("</tr></thead><tfoot>\r\n"));

        NutPrintString_P(sostream, PSTR("<tr><td> </td>"));
        if(relay_known)
            HtmlLedRow(sostream, spi_no, 0, relay_status, relay_status, 0xFFFFFFFF);
        else
            HtmlLedRow(sostream, spi_no, 0, relay_status, ~relay_status, 0xFFFFFFFF);
        NutPrintString_P(sostream, PSTR("</tr>\r\n"));

        NutPrintString_P(sostream, PSTR("<tr><td>On</td>"));
        HtmlCheckboxRow(sostream, spi_no, 0, "S", relay_status, 0xFFFFFFFF);
        NutPrintString_P(sostream, PSTR("</tr>\r\n"));

        NutPrintString_P(sostream, PSTR("</tfoot></table><br>"
                                        " <input type=\"submit\" value=\" Set \"> "
                                        " <input type=\"reset\" value=\" Cancel \"> "
                                        "</form>\r\n"));
    }
    else
        NutPrintString_P(sostream, PSTR("No SPI Output"));
    NutPrintString_P(sostream, PSTR("</div></body>\r\n</html>"));
    NutPrintFlush(sostream);
    return 0;
}

/*!
 * \brief CGI callback function to control a SPI input board.
 *
 * Creates HTML code to show the status of the optically isolated inputs
 * of an attached SPI input board. The page will be automatically refreshed 
 * once a second.
 *
 * \image html opto.gif
 *
 * This function is called by the HTTP module when a browser requests
 * a CGI function, for which this routine has been registered via
 * NutRegisterCgi().
 *
 * \param sostream Stream device of the HTTP connection.
 * \param req      Pointer to the CGI ::REQUEST structure.
 *
 * \return 0 on success or -1 in case of any failure.
 */
int SpiOptoStatus(NUTDEVICE *sostream, REQUEST *req)
{
    u_long status;
    u_char i;

    if(spi_ni == 255)
        SpiDigitalInit(&spi_ni, &spi_no);

    NutHttpSendHeaderTop(sostream, req, 200, "Ok");
    NutHttpSendHeaderBot(sostream, "text/html", -1);

    NutPrintString_P(sostream, PSTR("<html><head>"));
    if(spi_ni)
        NutPrintString_P(sostream, PSTR("<meta http-equiv=\"refresh\" content=\"1; URL=" OPTO_STATUS_CGI "\">"));
    NutPrintString_P(sostream, PSTR("<title>Ethernut SPI Isolated Input</title>"
                                    "</head><body bgcolor=\"#C7D0D9\"><a href=\"/\">"
                                    "<img src=\"/enmini.gif\" border=\"0\" width=\"70\" height=\"17\">"
                                    "</a><div align=\"center\">"));
    if(spi_ni) {
        NutPrintString_P(sostream, PSTR("<table border=\"1\" cellspacing=\"0\">\r\n"
                                        "<thead><tr><th colspan=\""));
        NutPrintFormat(sostream, "%u", spi_ni);
        NutPrintString_P(sostream, PSTR("\">Input</th></tr><tr>"));
        for(i = 1; i <= spi_ni; i++)
            NutPrintFormat(sostream, "<th>%u</th>", i);
        NutPrintString_P(sostream, PSTR("</tr></thead><tfoot><tr>\r\n"));
        status = SpiDigitalGet(spi_ni);
        HtmlLedRow(sostream, spi_ni, 0, status, status, 0);
        NutPrintString_P(sostream, PSTR("</tfoot></table><br>"));
    }
    else
        NutPrintString_P(sostream, PSTR("No SPI Input"));
    NutPrintString_P(sostream, PSTR("</div></body>\r\n</html>"));
    NutPrintFlush(sostream);
    return 0;
}



/*@}*/
