/*
 * Copyright (C) 2002 by egnite Software GmbH. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by egnite Software GmbH
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY EGNITE SOFTWARE GMBH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL EGNITE
 * SOFTWARE GMBH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.ethernut.de/
 */

/*
 * $Log$
 */

#include <string.h>

#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <sys/print.h>

#include <dev/nicrtl.h>
#include <netinet/sostream.h>
#include <arpa/inet.h>

#include <pro/httpd.h>

#include "webport.h"

/*!
 * \addtogroup xgWebPort
 */
/*@{*/

/*!
 * \brief CPU reset macro.
 *
 * Start all over on fatal initialization errors.
 */
#define JUMP_RESET asm volatile("cli\n\tcall 0\n\t" ::)

/*!
 * \brief Process a single HTTP request.
 *
 * This routine performs the whole cycle of a HTTP request.
 *
 * - Creating a socket.
 * - Listening on the defined port.
 * - Processing the request.
 * - Closing the socket.
 */
void Service(void)
{
    TCPSOCKET *sock;        /* TCP socket pointer. */
    NUTDEVICE *sostream;    /* Virtual stream device. */

    /*
     * Let the Nut/OS library create a TCP socket for us.
     */
    if((sock = NutTcpCreateSocket()) != 0) {

        /*
         * Listen on the port defined in webport.h.
         */
        if(NutTcpAccept(sock, HTTP_PORT) == 0) {

            /*
             * The Nut/OS memory manager dynamically allocates
             * and releases SRAM space. In this application
             * most memory is used by incoming telegrams and
             * the socket interface. If the available space
             * becomes low, we sleep for 200 milliseconds and
             * try again. This way we will always leave some
             * RAM for more important parts of the system.
             * The watermark is defined in webport.h.
             */
            while(NutHeapAvailable() < LOW_MEM_MARK)
                NutSleep(200);

            /*
             * Create a stream device from the socket.
             */
            if((sostream = NutSoStreamCreate(sock)) != 0) {
            
                /*
                 * Process http request and destroy stream
                 * device when done.
                 */
                NutHttpProcessRequest(sostream);
                NutSoStreamDestroy(sostream);
            }
        }

        /*
         * Close the socket.
         */
        NutTcpCloseSocket(sock);
    }
}

/*! \fn ServiceThread(void *arg)
 * \brief Background thread to process HTTP requests.
 *
 * This thread calls Service() in an endless loop.
 */
THREAD(ServiceThread, arg)
{
    /*
     * Loop endless for connections.
     */
    for(;;) 
        Service();
}

/*! \fn NutMain(void *arg)
 * \brief Main entry of our application.
 *
 * Nut/OS automatically calls this entry after initialization.
 * 
 * This routine will do all required initialization, start some
 * background threads and then process incoming HTTP requests together 
 * with the concurrently running background threads.
 */
THREAD(NutMain, arg)
{
    u_char i;

    /*
     * Register Realtek controller at address 8300 hex and interrupt 5.
     * Then configure the LAN interface.
     */
    if(NutRegisterDevice(&devEth0, 0x8300, 5))
        JUMP_RESET;
    if(NutNetAutoConfig("eth0"))
        JUMP_RESET;

    /*
     * Register our CGI routines.
     */
    if(NutRegisterCgi(PORT_CONTROL_CGI, CpuPortControl))
        JUMP_RESET;
    if(NutRegisterCgi(PORT_STATUS_CGI, CpuPortStatus))
        JUMP_RESET;
    if(NutRegisterCgi(RELAY_CONTROL_CGI, SpiRelayControl))
        JUMP_RESET;
    if(NutRegisterCgi(OPTO_STATUS_CGI, SpiOptoStatus))
        JUMP_RESET;

    /*
     * Start a defined number of concurrent background
     * threads. The more threads we have running, the
     * more connections we can handle concurrently.
     * However, each thread occupies some additional
     * RAM.
     */
    for(i = 0; i < NUM_HTTP_THREADS - 1; i++) {
        char *thname = "httpd0";
        thname[5] = '0' + i;
        NutThreadCreate(thname, ServiceThread, 0, HTTP_THREAD_STACK);
    }

    /*
     * Loop endless for connections.
     */
    for(;;) 
        Service();
}

/*@}*/
