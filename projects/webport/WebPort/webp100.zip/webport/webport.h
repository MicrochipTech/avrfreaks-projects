#ifndef _APP_WEBPORT_H_
#define _APP_WEBPORT_H_

/*
 * Copyright (C) 2002 by egnite Software GmbH. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by egnite Software GmbH
 *    and its contributors.
 *
 * THIS SOFTWARE IS PROVIDED BY EGNITE SOFTWARE GMBH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL EGNITE
 * SOFTWARE GMBH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.ethernut.de/
 *
 */

/*
 * $Log$
 */

/*!
 * \addtogroup xgWPDefs
 */
/*@{*/

#define HTTP_PORT           80      /*!< \brief TCP port number to listen to. */
#define LOW_MEM_MARK        4096    /*!< \brief Delay responses if available memory falls below. */
#define NUM_HTTP_THREADS    6       /*!< \brief Total number of concurrent HTTP server threads. */
#define HTTP_THREAD_STACK   640     /*!< \brief Stack size given to each HTTP server thread. */

#define PORT_CONTROL_CGI    "ccports.cgi"   /*!< \brief Name of the CGI to control CPU ports. */
#define PORT_STATUS_CGI     "csports.cgi"   /*!< \brief Name of the CGI to display CPU ports. */
#define RELAY_CONTROL_CGI   "relay.cgi"     /*!< \brief Name of the CGI to control SPI relay boards. */
#define OPTO_STATUS_CGI     "opto.cgi"      /*!< \brief Name of the CGI to control SPI input boards. */

/*@}*/

/*
 * CGI prototypes.
 */
extern int CpuPortControl(NUTDEVICE *sostream, REQUEST *req);
extern int CpuPortStatus(NUTDEVICE *sostream, REQUEST *req);

extern int SpiRelayControl(NUTDEVICE *sostream, REQUEST *req);
extern int SpiOptoStatus(NUTDEVICE *sostream, REQUEST *req);


#endif
