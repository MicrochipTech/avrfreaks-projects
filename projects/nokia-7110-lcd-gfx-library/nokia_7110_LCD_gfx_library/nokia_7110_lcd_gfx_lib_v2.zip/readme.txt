
-********************************************-
-*- Nokia 7110 LCD graphics library V2     -*-
-*- programming and research by            -*-
-*- Rolf R Bakke                           -*-
-********************************************-



OVERVIEW:
This project enables you to connect a Nokia 7110 LCD to your AVR and use it to show text
and graphics. The library contains routines for drawing text, numbers, pixels and lines.
The LCD is 96x64 pixels. 



OBTAINING A LCD:
Get yourself a defect 7110. Don't pay much for it, even working ones is pretty worthless.
As long as the LCD is physically intact, there is a 99% chance for it to be OK.
These LCD's seldom fail, as opposed to LCD's of certain other Nokia phones....
*atjho8210ish!*
You also may try buying a used LCD at a cellphone repair shop.



LCD PINOUT:
take a look at '7110 lcd pinout.jpg'

pin 2 : Chip Select (CS)

pin 4 : Control/Display data flag (CD) 
        tsetup minimum 150 ns
        thold  minimum 150 ns 
        low for Control data
        high for Display data

pin 5 : Serial Clock (SCL). 
        tcycle minimum 250 ns
        thigh  minimum 100 ns
        tlow   minimum 100 ns

pin 11: GND

pin 12: VDD
        2.7 til 3.3 volts
        200 uA max.

pin 13: Serial Data (SDA).

pin 14: Reset
        


CONNECTING THE LCD TO THE AVR:
This is tested vith a ATMEGA163L 4PI running at 4MHz. Vcc=3V
Note: You have to use the 4MHz version, the 8MHz version does not work at 3v.


connections:

LCD pin 2  ->  AVR pin 23
LCD pin 4  ->  AVR pin 26
LCD pin 5  ->  AVR pin 24
LCD pin 11 ->  GND
LCD pin 12 ->  VCC
LCD pin 13 ->  AVR pin 25
LCD pin 14 ->  AVR pin 27

Complete the circuit with your favorite 4MHz crystal, ISP header, assorted components and 
3V supply.

Note that the controller on the LCD is light sensitive, protect it from bright light.
(Bright light does not damage it, just makes the controller freak out) 



ASSEMBLING:
Assemble the file 'demo.asm'. This is a demo on how to use the library file 'gd50_gfx_lib.asm'
The demo shows some moving lines and text on the LCD. 
(Contest: make a better demo! :)


ROUTINE DESCRIPTIONS:
Here is a description of the routines in the 'gd50_gfx_lib.asm' file:

ROUTINE NAME: Init the GD50 (Nokia 7110) display

ROUTINE LABEL: g_lcd_init

INPUT: None 

OUTPUT: None

DESTROYS: z,r16,r2,r17

DESCRIPTION: Turns on the display and sets contrast. If you need to change the contrast level,
change the 0x2e byte in the table located at label g_intab. Valid values is
0x00 (lightest) to 0x3f (darkest).





ROUTINE NAME: transfer virtual screen to the GD50 (Nokia 7110) display

ROUTINE LABEL: g_lcd_swap

INPUT: 96x64 bitmap located in SRAM at label g_vscreen 

OUTPUT: None

DESTROYS: None 

DESCRIPTION: transfer virtual screen to the LCD. 

Put this line into the beginning of your program:

.equ	g_vscreen=0x0130

to specify the address of the virtual screen. Change the address to suit your program. The 
virtual screen size is 0x300 bytes.

NOTE: Nothing useful is shown on the LCD before you transfer the virtual screen to the LCD!





ROUTINE NAME: clear virtual screen

ROUTINE LABEL: g_lcd_clr

INPUT: None 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: None 

DESCRIPTION: clears the virtual screen.





ROUTINE NAME: Draw a line (bresenham)

ROUTINE LABEL: g_drawline

INPUT: x1,y1,x2,y2,pmode 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: xpos, ypos

DESCRIPTION: Draws a line between (x1,y1) and (x2,y2). X and Y range is 0x00 to 0xff, 
but only linesegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
For a black line set pmode=0
For a white line set pmode=1
For a reversed line set pmode=-1





ROUTINE NAME: Plot pixel 

ROUTINE LABEL: g_plotxy 

INPUT: xpos, ypos, pmode 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: None

DESCRIPTION: Plots a pixel at (xpos,ypos). X and Y range is 0x00 to 0xff, 
but only pixels inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
For a black pixel set pmode=0
For a white pixel set pmode=1
For a reversed pixel set pmode=-1





ROUTINE NAME: Read pixel 

ROUTINE LABEL: g_readxy

INPUT: xpos, ypos, 96x64 bitmap located in SRAM at label g_vscreen

OUTPUT: carry flag

DESTROYS: None 

DESCRIPTION: Reads a pixel at (xpos,ypos). Carry flag returns status of pixel: 
c=0 if pixel is white (cleared)
c=1 if pixel is black (set)
X and Y range is 0x00 to 0xff, status for pixels outside the X and Y range of
0x00-0x5f and 0x00-0x3f is returned as c=1 (black)





ROUTINE NAME: Print one 6x8 char 

ROUTINE LABEL: g_draw6x8

INPUT: x1, y1, r0, pmode 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: xpos, ypos, x1, x2, y2

DESCRIPTION: Draws a 6x8 char at (x1,y1). X and Y range is 0x00 to 0xff, 
but only charsegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
For a black char set pmode=0
For a white char set pmode=1
For a reversed char set pmode=-1
Char to be drawn is read from r0
x1 is incremented with 6, wraps at 0xff.





ROUTINE NAME: Print a string with 6x8 chars 

ROUTINE LABEL: g_print6x8 

INPUT: z, x1, y1, pmode

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: xpos, ypos, x1, x2, y2

DESCRIPTION: Uses the routine above to draw a string with 6x8 chars.
z must be set to point to a zero-terminated string stored in FLASH. 





ROUTINE NAME: Print one 4x6 char 

ROUTINE LABEL: g_draw4x6

INPUT: x1, y1, r0, pmode 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: xpos, ypos, x1, x2, y2

DESCRIPTION: Draws a 4x6 char at (x1,y1). X and Y range is 0x00 to 0xff, 
but only charsegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
For a black char set pmode=0
For a white char set pmode=1
For a reversed char set pmode=-1
Char to be drawn is read from r0
x1 is incremented with 4, wraps at 0xff.





ROUTINE NAME: Print a string with 4x6 chars 

ROUTINE LABEL: g_print4x6 

INPUT: z, x1, y1, pmode

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: xpos, ypos, x1, x2, y2

DESCRIPTION: Uses the routine above to draw a string with 4x6 chars.
z must be set to point to a zero-terminated string stored in FLASH. 
(use byte address, not word)





ROUTINE NAME: Draw 3D button

ROUTINE LABEL: g_drawbutton

INPUT: xl, xh, yl, yh 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: x1, x2, y1, y2, pmode

DESCRIPTION: Draws a 3D button. X and Y range is 0x00 to 0xff, 
but only buttonsegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
Upper left corner: (xl,yl)  
lower right corner: (xh,yh)
Buttonface and sides is drawn in white, outline in black.





ROUTINE NAME: Draw rectangle

ROUTINE LABEL: g_drawframe

INPUT: xl, xh, yl, yh, pmode

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: x1, x2, y1, y2

DESCRIPTION: Draws a rectangle. X and Y range is 0x00 to 0xff, 
but only rectanglesegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
Upper left corner: (xl,yl)  
lower right corner: (xh,yh)
For a black rectangle set pmode=0
For a white rectangle set pmode=1
For a reversed rectangle set pmode=-1





ROUTINE NAME: print a 16bit hex number 

ROUTINE LABEL: g_printhex 

INPUT: x, x1, y1, pmode 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: xpos, ypos, x1, x2, y2

DESCRIPTION: Prints a 16bit hex number at (x1,y1). X and Y range is 0x00 to 0xff, 
but only numbersegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
For a black number set pmode=0
For a white number set pmode=1
For a reversed number set pmode=-1
x1 is incremented with 24, wraps at 0xff.




ROUTINE NAME: print a 16bit decimal number 

ROUTINE LABEL: g_printbcd 

INPUT: x, x1, y1, pmode 

OUTPUT: 96x64 bitmap located in SRAM at label g_vscreen

DESTROYS: x, xpos, ypos, x1, x2, y2

DESCRIPTION: Prints a 16bit decimal number at (x1,y1). X and Y range is 0x00 to 0xff, 
but only numbersegments inside the X and Y range of 0x00-0x5f and 0x00-0x3f is drawn. 
For a black number set pmode=0
For a white number set pmode=1
For a reversed number set pmode=-1
x1 is incremented with 30, wraps at 0xff.





ROUTINE NAME: Delay

ROUTINE LABEL: g_wms

INPUT: zl 

OUTPUT: None

DESTROYS: r16

DESCRIPTION: delays for zl milliseconds 

