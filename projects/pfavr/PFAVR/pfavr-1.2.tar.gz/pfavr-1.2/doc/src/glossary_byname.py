#!/usr/bin/env python
"""This script builds a glossary of words sorted by name"""

import schwartz

import wordparse
import glossary

def printHeader(fid):
  fid.write( """<html>
<head>
<title>PFAVR -- Glossary By Word Name</title>
</head>

<body bgcolor="#ffffff" link="#0000c0" vlink="#8f008f">
<p><font size="+2">PFAVR -- Glossary By Word Name</font></p>
<blockquote>
  <p><a href="http://claymore.engineer.gvsu.edu/%7Esteriana"><font
 size="-1">Andrew Sterian</font></a><font size="-1"><br>
Padnos School of Engineering<br>
Grand Valley State University</font></p>
</blockquote>
<p></p>
<hr align="left">
<table width="100%" border="0" cellspacing="2" cellpadding="0">
  <tbody>
    <tr>
      <td><a href="index.html">Top-Level</a> | <a href="glossary.html">Glossary</a> | <a
 href="design.html">Compiler Design</a> | <a href="rationale.html">Rationale</a>
| <a href="notes.html">Notes</a><br>
      </td>
      <td align="right"><font size="-1">Version \(version)<br>
      </font></td>
    </tr>
    <tr>
      <td><!-- --><br>
      </td>
      <td align="right"><font size="-1">\(release_date)</font><br>
      </td>
    </tr>
    <tr>
      <td> <font size="-1"><a href="glossary_bylang.html">Glossary by Language Category</a> | Glossary by Word
Name | <a href="glossary_bysource.html">Glossary by Source Location</a>
| <a href="glossary_bywordset.html">Glossary by ANS Word Set</a></font></td>
      <td><!-- --><br>
      </td>
    </tr>
  </tbody>
</table>
<hr align="left">
<P>The flags column may contain the letters <TT>I</TT> or <TT>D</TT> to indicate
immediate or deferred words.
<P>The source definition column is either of the form ID_XXXX to indicate an internal
word with the given ID, or is the filename (minus the <TT>.ft</TT> extension) where
the word is defined.
<P>The ANS section column is either <TT>pforth</TT> to indicate the word is not
an ANS standard word, or is the name of an ANS standard word set which describes
the word.
<P>The language category column describes the part of the Forth language that the
word applies to (e.g., io, loops, math, etc.)
<P>The description column provides a brief reference on the word.
<P>
<TABLE WIDTH="100%" CELLSPACING=1 CELLPADDING=1 BORDER=1>
<TR>
  <TH ALIGN="CENTER"><B>Word Name</B></TH>
  <TH ALIGN="CENTER"><B>Flags</B></TH>
  <TH ALIGN="CENTER"><B>Source Definition</B></TH>
  <TH ALIGN="CENTER"><B>ANS Section</B></TH>
  <TH ALIGN="CENTER"><B>Language Category</B></TH>
  <TH ALIGN="CENTER"><B>Description</B></TH>
</TR>
""")

def printFooter(fid):
  fid.write("""
<hr align="left">
<p></p>
<center><font size="-1">&copy; \(copyright_years), Copyright by <a
 href="http://claymore.engineer.gvsu.edu/%7Esteriana">Andrew Sterian</a>;
All Rights Reserved. mailto: <a
 href="mailto:steriana@claymore.engineer.gvsu.edu?subject=PFAVR">steriana@claymore.engineer.gvsu.edu</a></font></center>
  </body>
</html>
""")

def sortMetric(word):
  return word.name

if __name__=="__main__":
  try:
    fid = file('glossary_byname.htm','wt')
  except IOError, detail:
    print 'Unable to create "glossary_byname.htm":\n  %s' % str(detail)
    raise

  L = wordparse.BuildWordList('WordList')
  L = schwartz.schwartz(L, sortMetric)

  printHeader(fid)
  for word in L:
    fid.write("""<TR>
  <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
  <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
  <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
  <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
  <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
  <TD ALIGN="LEFT"><FONT SIZE="-1">%s</TD>
</TR>
""" %     (glossary.toHTML(word.name), glossary.unblank(word.flags), word.source, glossary.makeHTMLLink(word.lang, word.name), word.cat, glossary.toHTML(word.desc)) \
   )

  fid.write("</TABLE>\n")
  printFooter(fid)
