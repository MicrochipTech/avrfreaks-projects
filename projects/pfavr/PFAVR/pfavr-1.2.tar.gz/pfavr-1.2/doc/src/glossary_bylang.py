#!/usr/bin/env python
"""This script builds a glossary of words sorted by language category"""

import operator

import schwartz

import wordparse
import glossary

Desc = (
   ('stack', 'Stack Manipulation', 'These words perform primary stack manipulations.'),
   ('math', 'Single-Word Mathematical Operations', 'These words perform single-word (i.e., 1 cell) mathematical operations.'),
   ('logical', 'Logical and Comparison Operations', 'These words compute logical and comparison functions.'),
   ('lang', 'Core Language', 'These words are core language components.'),
   ('flow', 'Flow Control', 'These words implement loops and selection statements.'),
   ('io', 'Input and Output', 'These words implement formatted and unformatted number display as well as character I/O.'),
   ('string', 'String Operations', 'These words implement string operations.'),
   ('double', 'Double-Word Operations', 'These words perform double-word (i.e., 2 cells) mathematical operations.'),
   ('memory', 'Memory Operations', 'These words are concerned with manipulating memory locations.'),
   ('preprocess', 'Preprocessor Words', 'Preprocessor words can be used for conditional compilation.'),
   ('utility', 'Utility Words', 'These words are not easily categorized, hence are grouped here.'),
   ('dictionary', 'Dictionary Manipulation', 'These words directly manipulate the Forth dictionary and code space areas.'),
   ('compiler', 'Internal Use', 'These words support the Forth implementation and are not likely to be directly used in Forth programs.'),
   ('deprecated', 'Obsolete Words', 'These words are deprecated by the ANS Forth standard.')
   )

def printHeader(fid):
  fid.write( """<html>
<head>
<title>PFAVR -- Glossary By Language Category</title>
</head>

<body bgcolor="#ffffff" link="#0000c0" vlink="#8f008f">
<p><font size="+2">PFAVR -- Glossary By Language Category</font></p>
<blockquote>
  <p><a href="http://claymore.engineer.gvsu.edu/%7Esteriana"><font
 size="-1">Andrew Sterian</font></a><font size="-1"><br>
Padnos School of Engineering<br>
Grand Valley State University</font></p>
</blockquote>
<p></p>
<hr align="left">
<table width="100%" border="0" cellspacing="2" cellpadding="0">
  <tbody>
    <tr>
      <td><a href="index.html">Top-Level</a> | <a href="glossary.html">Glossary</a> | <a
 href="design.html">Compiler Design</a> | <a href="rationale.html">Rationale</a>
| <a href="notes.html">Notes</a><br>
      </td>
      <td align="right"><font size="-1">Version \(version)<br>
      </font></td>
    </tr>
    <tr>
      <td><!-- --><br>
      </td>
      <td align="right"><font size="-1">\(release_date)</font><br>
      </td>
    </tr>
    <tr>
      <td> <font size="-1">Glossary by Language Category | <a href="glossary_byname.html">Glossary by Word
Name</a> | <a href="glossary_bysource.html">Glossary by Source Location</a>
| <a href="glossary_bywordset.html">Glossary by ANS Word Set</a></font></td>
      <td><!-- --><br>
      </td>
    </tr>
  </tbody>
</table>
<hr align="left">
<P>The flags column may contain the letters <TT>I</TT> or <TT>D</TT> to indicate
immediate or deferred words.
<P>The source definition column is either of the form ID_XXXX to indicate an internal
word with the given ID, or is the filename (minus the <TT>.ft</TT> extension) where
the word is defined.
<P>The ANS section column is either <TT>pforth</TT> to indicate the word is not
an ANS standard word, or is the name of an ANS standard word set which describes
the word.
<P>The language category column describes the part of the Forth language that the
word applies to (e.g., io, loops, math, etc.)
<P>The description column provides a brief reference on the word.
<P>
""")

def printTableHeader(fid):
  fid.write(r"""
<TABLE WIDTH="100%" CELLSPACING=1 CELLPADDING=1 BORDER=1>
<TR>
  <TH ALIGN="CENTER"><B>Word Name</B></TH>
  <TH ALIGN="CENTER"><B>Flags</B></TH>
  <TH ALIGN="CENTER"><B>Source Definition</B></TH>
  <TH ALIGN="CENTER"><B>ANS Section</B></TH>
  <TH ALIGN="CENTER"><B>Language Category</B></TH>
  <TH ALIGN="CENTER"><B>Description</B></TH>
</TR>
""")

def printFooter(fid):
  fid.write("""
<hr align="left">
<p></p>
<center><font size="-1">&copy; \(copyright_years), Copyright by <a
 href="http://claymore.engineer.gvsu.edu/%7Esteriana">Andrew Sterian</a>;
All Rights Reserved. mailto: <a
 href="mailto:steriana@claymore.engineer.gvsu.edu?subject=PFAVR">steriana@claymore.engineer.gvsu.edu</a></font></center>
  </body>
</html>
""")

def sortMetric(word):
  return word.name

if __name__=="__main__":
  try:
    fid = file('glossary_bylang.htm','wt')
  except IOError, detail:
    print 'Unable to create "glossary_bylang.htm":\n  %s' % str(detail)
    raise

  printHeader(fid)

  L = wordparse.BuildWordList('WordList')
  ValidCategories = map(operator.__getitem__, Desc, [0]*len(Desc))

  Lang = {}
  for word in L:
    if word.cat:
      if word.cat not in ValidCategories:
        print 'Word "%s" has unknown category "%s"' % (word.name, word.cat)
    else:
      print 'Word "%s" is not categorized' % word.name

  for cat,desc,extdesc in Desc:
    fid.write('<P><HR><A NAME="%s"><H2>%s</H2>\n<P>%s\n<P>' % (cat,desc,extdesc))

    subset = filter(lambda l: l.cat==cat, L)

    if not subset:
      fid.write('<P>No words in this language category\n')
      continue

    subset = schwartz.schwartz(subset, sortMetric)

    printTableHeader(fid)
    for word in subset:
      fid.write("""<TR>
    <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
    <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
    <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
    <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
    <TD ALIGN="CENTER"><FONT SIZE="-1">%s</TD>
    <TD ALIGN="LEFT"><FONT SIZE="-1">%s</TD>
  </TR>
  """ %     (glossary.toHTML(word.name), glossary.unblank(word.flags), word.source, glossary.makeHTMLLink(word.lang,word.name), word.cat, glossary.toHTML(word.desc)) \
     )

    fid.write("</TABLE>\n")
  printFooter(fid)
