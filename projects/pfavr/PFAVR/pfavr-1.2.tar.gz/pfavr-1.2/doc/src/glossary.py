#!/usr/bin/env python
"""This file contains support routines for writing out glossaries"""

import string

import anslink

def toHTML(s):
  s=string.replace(s, '&', '&amp;')
  s=string.replace(s, '"', '&quot;')
  s=string.replace(s, '<', '&lt;')
  s=string.replace(s, '>', '&gt;')
  s=string.replace(s, '\\', '\\\\')

  return s

def makeHTMLLink(lang, name):
  try:
    url = anslink.ANSLink['%s_%s' % (lang, name)]
  except KeyError:
    return lang

  return '<A HREF="ANS/%s">%s</A>' % (url, lang)

def unblank(s):
  "Take empty strings and return &nbsp;"
  if not s:
    return '&nbsp;'
  else:
    return s
