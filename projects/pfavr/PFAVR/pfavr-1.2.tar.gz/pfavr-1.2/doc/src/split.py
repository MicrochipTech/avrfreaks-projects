import sys
import re

pat = re.compile(r'^([^|]+)\|([^|]+)\|([^|]+)\|([^|]+)\|(.+)$')
fid = file('WordList','rt')
out = file('WordListNew','wt')
for line in fid:
  match = pat.match(line)
  if not match:
    print 'Error matching:\n', line
    sys.exit(1)

  out.write('%-15s | %-24s | %-10s | %-10s | %-s\n' % \
            (match.group(1).strip(), match.group(2).strip(),
             match.group(3).strip(), match.group(4).strip(),
             match.group(5).strip()))
             
