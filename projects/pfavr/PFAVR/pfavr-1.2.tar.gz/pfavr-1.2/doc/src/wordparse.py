#!/usr/bin/env python
"""This file parses the WordList file and builds up a list of
Word objects.
"""

import string
import re

# Columns are:
#   1: Name
#   2: Flag characters; 'I' for immediate, 'D' for deferred
#   3: Source (optional, if not implemented)
#   4: ANS Language section
#   5: Language category (optional)
#   6: Description
pat = re.compile(r'^\s*(\S+)\s+\|\s+(\S*)\s+\|\s+(\S*)\s+\|\s+(\S+)\s+\|\s+(\S*)\s+\|(.+)$')

class Word:
  def __init__(self, s):
    match = pat.match(s)
    if not match:
      raise RuntimeError, "Line is not a valid word description:\n %s" % s

    self.name, self.flags, self.source, self.lang, self.cat, self.desc = match.groups()
    self.desc = self.desc.strip()
    #print self.name, ' | ', self.source, ' | ', self.lang, ' | ', self.cat, ' | ', self.desc

def BuildWordList(fname):
  L = []
  try:
    fid = file(fname, 'rt')
  except IOError, detail:
    print 'Cannot open "%s" for reading:\n  %s' % (fname, str(detail))
    raise

  for line in fid:
    L.append(Word(line))
  fid.close()

  return L

