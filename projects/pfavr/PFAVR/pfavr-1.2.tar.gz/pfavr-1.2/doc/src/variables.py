version = "1.2"
release_date = "February 28, 2004"
copyright_years = "2003-2004"
