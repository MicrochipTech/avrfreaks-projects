import os
import glob
import string

files = glob.glob('*')
for file in files:
  newname = file.lower()
  if newname != file:
    os.rename(file, newname)
