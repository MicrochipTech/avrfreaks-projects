#!/usr/bin/env python
"""Simple script to generate the forthwords.h include file
from a list of Forth files."""

import sys

fid = file('forthwords.h','wt')
for name in sys.argv[1:]:
  fid.write('#include "../system/%s"\n' % name)
fid.close()
