#!/usr/bin/env python
"""This script analyzes a map file from the GNU LD program
to determine how each memory section has been utilized."""

import sys
import os
import string
import re
import getopt
import operator

def hexCvt(s):
  try:
    val = int(s,16)
  except Exception, detail:
    print 'hexCvt: Illegal hexadecimal: "%s":\n  %s' % (s, str(detail))
    sys.exit(2)

  return val

def getMemConfig(ifid):
  mem_sect_pat = re.compile(r'^Memory Configuration')
  mem_sect_pat2 = re.compile(r'^Name\s+Origin\s+Length\s+Attributes')
  mem_sect_pat3 = re.compile(r'^(\S+)\s+(0x.{8})\s+(0x.{8})')

  for line in ifid:
    if mem_sect_pat.match(line):  # Look for "Memory Configuration"
      for line in ifid:
        if mem_sect_pat2.match(line):   # Look for "Name Origin Length Attributes"
          L = {}
          for line in ifid:
            match = mem_sect_pat3.match(line)
            if not match:
              return L

            if match.group(1) != "*default*" and match.group(3) != "0xffffffff":
              origin = hexCvt(match.group(2))
              length = hexCvt(match.group(3))
            
              L[match.group(1)] = (origin, origin+length-1)
          else:
            print 'getMemConfig: Premature end-of-file'
            sys.exit(3)
      else:
        print 'getMemConfig: Did not find memory configuration header'
        sys.exit(3)
  else:
    print 'getMemConfig: Did not find Memory Configuration line'
    sys.exit(3)

def findSections(ifid):
  pat = re.compile(r'^\.(\S+)\s+(0x.{8})\s+(0x\S+)')

  L = []
  i = iter(fid)
  for line in ifid:
    match = pat.match(line)
    if match:
      sect = match.group(1)
      origin = hexCvt(match.group(2))
      length = hexCvt(match.group(3))
      if length == 0:
        continue

      if sect=='comment':
        continue

      if sect[:5]=='debug':
        continue

      if sect[:4]=='stab':
        continue

      L.append((sect, origin, length))
      
  return L

def inRegion(RegionList, start, length):
  """Checks to see if memory area starting at start of length length
  lives at all within any one of the regions in RegionList. The
  latter is a list of (start,end) tuples where start and end are
  inclusive. The return value is 1 if the (start,length) region
  is wholly contained, 2 if only partially contained, and 0 if
  not at all. Return value is actually a tuple with the code
  above followed by the region in RegionList which matches first."""

  extent = start+length-1

  for region in RegionList:
    # Is start in the region?
    if start >= region[0] and start <= region[1]:
      # Start value is in the region. Wholly contained?
      if extent <= region[1]:
        return 1, region  # Wholly contained
      else:
        return 2, region # Not wholly contained

    # Is end in the region
    elif extent >= region[0] and extent <= region[1]:
      # End point is in the region, but start is not.
      # Definitely not wholly contained.
      return 2, region

  return 0, None

def printAnalysis(Sections, Usage):
  totalErrors = 0

  for sect,sRange in Sections.items():
    print
    print sect, "   (0x%04X - 0x%04X)" % (sRange[0], sRange[1])
    print '='*len(sect)
    sectSize = sRange[1]-sRange[0]+1

    errors = 0
    totUsed = 0
    usedRegions = []  # List of (start,end,name) tuples
    for used in Usage:  # Usage is list of (sectname,origin,length) tuples
      extent = used[1]+used[2]-1
      retcode, region = inRegion([sRange], used[1], used[2])

      if retcode==2:
        errors += 1
        print '    (0x%04X - 0x%04X) %s: ERROR -- Region is not wholly contained in the memory section' % \
            (used[1], extent, used[0])
        usedRegions.append((used[1], extent, used[0]))

      elif retcode==1:
        # Now see if it overlaps with other regions
        retcode, region = inRegion(usedRegions, used[1], used[2])
        if retcode: # Either wholly contained or not, it overlaps!
          print '    (0x%04X - 0x%04X) %s: ERROR -- Region overlaps another region in this section' % \
            (used[1], extent, used[0])
          errors += 1

        usedRegions.append((used[1], extent, used[0]))

    totalErrors += errors

    # Sort sections by start address
    usedRegions.sort()

    lastAddr = sRange[0] # Start address for this section
    freeSpace = 0 # Bytes

    for region in usedRegions:   # Each region is (start,end,name)

      if region[0] > lastAddr:
        freeSpace += region[0]-lastAddr
        print '    (0x%04X - 0x%04X) %5.1f%% FREE SPACE' % (lastAddr, region[0]-1, 100.0*(region[0]-lastAddr)/sectSize)

      print '    (0x%04X - 0x%04X) %5.1f%% %s' % (region[0], region[1], 100.0*(region[1]-region[0]+1)/sectSize, region[2])

      lastAddr = region[1]+1

    if lastAddr < sRange[1]:
      freeSpace += sRange[1]-lastAddr+1
      print '    (0x%04X - 0x%04X) %5.1f%% FREE SPACE' % (lastAddr, sRange[1], 100.0*(sRange[1]-lastAddr+1)/sectSize)

    print '    --------------------------------'
    print '                %5d %5.1f%% BYTES USED' % (sectSize-freeSpace, 100.0*(sectSize-freeSpace)/sectSize)
    print '                %5d %5.1f%% BYTES FREE' % (freeSpace, 100.0*freeSpace/sectSize)

  if totalErrors:
    print
    print '*'*60
    print totalErrors, "ERRORS ENCOUNTERED!"
    print '*'*60

def usage():
  print """
Usage: analyzemem [Options] mapfilename

Options:
      -h, --help         -- This help summary
"""
  sys.exit(1)

if __name__=="__main__":
  try:
    optlist, args = getopt.getopt(sys.argv[1:], 'h', ['help'])
  except getopt.GetoptError:
    usage()

  for opt,arg in optlist:
    if opt in ("-h", "--help"):
      usage()

  if len(args) != 1: 
    usage()

  try:
    fid = file(args[0], 'rt')
  except Exception, detail:
    print 'Unable to open file "%s":\n  %s' % (args[0], str(detail))
    sys.exit(4)

  ifid = iter(fid)
  MemConfig = getMemConfig(ifid)
  SectUsage = findSections(ifid)

  printAnalysis(MemConfig, SectUsage)
