#!/usr/bin/env python
"""Process an output file from m6811-elf-gdb to create
   pre-built dictionary and exec area, as well as some auxilliary variables.
"""

import sys
import os
import re
import string

byteDump = re.compile(r'(0x80....)\s[^:]*:(.+)')
byteDump2 = re.compile(r'(0x..)')
wordDump = re.compile(r'(0x....)')
printable = string.digits+string.letters+string.punctuation  # string.printable has control characters

if __name__=="__main__":
  if len(sys.argv) != 2:
    print "Usage: doprebuild.py inputfile"
    sys.exit(1)

  try:
    f = file(sys.argv[1], 'rt')
  except Exception, detail:
    print 'Unable to open input file:\n  %s\n' % str(detail)
    sys.exit(2)

  lines = f.readlines()
  f.close()

  # Look for "td_DictSize:" line telling us dictionary size in bytes
  for ix in range(len(lines)):
    if lines[ix][:12] == 'td_DictSize:': 
      dictSize = int(lines[ix][13:])
      print 'Initial dictionary is %d bytes' % dictSize
      break
  else:
    raise RuntimeError, "Could not find 'td_DictSize' definition"

  # Look for "td_ExecSize:" line telling us exec area size in cells
  for ix in range(len(lines)):
    if lines[ix][:12] == 'td_ExecSize:': 
      execSize = int(lines[ix][13:])
      print 'Initial code area is %d bytes' % (execSize*2)
      break
  else:
    raise RuntimeError, "Could not find 'td_ExecSize' definition"

  # Look for "td_Dict:" line telling us we have the dictionary
  for ix in range(len(lines)):
    if lines[ix][:8] == 'td_Dict:': break

  # Process the dictionary. We write it out as one big string.
  f = file('predict.h', 'wt')
  byteCount = 0
  for ix in range(ix+1, len(lines)):
    match = byteDump.match(lines[ix])
    if match:
      f.write('"')
      #print match.groups()
      bytes = byteDump2.findall(match.group(2))
      #print bytes
      for byte in bytes:
        byte = chr(eval(byte))
        if byte not in printable or byte in ('"', '\\', '?'): # Why '?'...to avoid trigraphs
          f.write(r'\%03o' % ord(byte))
        else:
          f.write(byte)

        byteCount += 1
        if byteCount >= dictSize:
          break

      f.write('"\n')
      if byteCount >= dictSize:
        break
    else:
      break

  # If we've written an even number of bytes, write another
  # byte so we have an odd number of data bytes. With the
  # terminating null character for the string, this makes
  # the entire string of even length. GCC requires even
  # alignment in the text section, otherwise mysterious
  # compiler errors arise.
  if (not (byteCount & 1)):
    f.write('"0"\n')
    byteCount += 1
    print 'Padding predict.h to even bytes'

  f.close()
  print 'Wrote %d bytes to "predict.h"' % byteCount

  # Next line up should be "td_Exec:"
  for ix in range(ix, len(lines)):
    if lines[ix][:8] == 'td_Exec:': break

  # Process the exec area. We write it out as 16-bit unsigneds
  f = file('preexec.h', 'wt')
  cellCount = 0
  for ix in range(ix+1, len(lines)):
    match = byteDump.match(lines[ix])
    if match:
      f.write('    ')
      words = wordDump.findall(match.group(2))
      for word in words:
        word = eval(word)
        f.write('0x%04X, ' % word)

        cellCount += 1
        if cellCount >= execSize:
          break

      f.write('\n')
      if cellCount >= execSize:
        break
    else:
      break

  f.close()
  print 'Wrote %d cells to "preexec.h"' % cellCount

  # Look for "prevars:" marker indicating start of variable output
  for ix in range(ix, len(lines)):
    if lines[ix][:8] == 'prevars:': break
  else:
    raise RuntimeError, "Could not find 'prevars:' marker"

  # Everything else goes in "prevars.h"
  f = file('prevars.h', 'wt')
  for ix in range(ix+1, len(lines)):
    f.write('%s\n' % lines[ix])
  f.close()

  print 'Wrote "prevars.h"'
