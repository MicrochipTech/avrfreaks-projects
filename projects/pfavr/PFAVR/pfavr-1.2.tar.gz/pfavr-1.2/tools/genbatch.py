#!/usr/bin/env python
"""This little script creates a batch.gdb file for avr-gdb.
The purpose of this batch file is to extract the dictionary and
code space of an already-initialized PFAVR run for creating the
prebuilt version. Most of the batch.gdb file is static, but the
sizes of the dictionary and code space are configured as constants
in ../config.h. We extract these manifests from the file.
"""

import sys
import os
import re

dict_pat = re.compile(r'\s*#define\s+DICTIONARY_SIZE\s+(\S+)')
exec_pat = re.compile(r'\s*#define\s+EXEC_AREA_SIZE\s+(\S+)')

try:
  fid = file('../config.h', 'rt')
except Exception, detail:
  print 'Cannot find file "../config.h":\n  %s' % str(detail)
  sys.exit(1)

DictSize = None
ExecSize = None

for line in fid:
  match = dict_pat.match(line)
  if match:
    DictSize = int(match.group(1))
    continue

  match = exec_pat.match(line)
  if match:
    ExecSize = int(match.group(1))
    continue

if DictSize is None:
  print 'Error: Could not find DICTIONARY_SIZE definition in config.h'
  sys.exit(1)

if ExecSize is None:
  print 'Error: Could not find EXEC_AREA_SIZE definition in config.h'
  sys.exit(1)

fid.close()
try:
  fid = file('batch.gdb', 'wt')
except Exception, detail:
  print 'Cannot create file "batch.gdb":\n  %s' % str(detail)
  sys.exit(1)

fid.write( \
r"""target remote :1212
load pfavr.elf
b gdb_stop_here
continue
# Dict area size in bytes
printf "td_DictSize: %%d\n", (unsigned short)td_DictPtr-(unsigned short)&td_Dict
# Exec area size in cells
printf "td_ExecSize: %%d\n", (unsigned short)td_ExecPtr-(unsigned short)&td_Exec
#
printf "td_Dict:\n"
x/%dxb &td_Dict
#
printf "td_Exec:\n"
x/%dxh &td_Exec
#
printf "prevars:\n"
printf "td_DictPtr = (unsigned char *)0x%%X;\n", (unsigned short)td_DictPtr
printf "td_ExecPtr = (cell *)0x%%X;\n", (unsigned short)td_ExecPtr
printf "td_Dict_check = (unsigned char *)0x%%X;\n", &td_Dict-0x800000
printf "td_Exec_check = (cell *)0x%%X;\n", &td_Exec-0x800000
printf "gVarContext = (char *)0x%%X;\n", gVarContext
printf "gVarBase = %%d;\n", gVarBase
""" % (DictSize, ExecSize))
fid.close()

sys.exit(0)
