#ifndef _config_h_
#define _config_h_

/* Define PF_NO_CLIB if you want PFAVR versions of strlen, strchr, etc.
 * which are smaller than the libc versions but are not thread safe.
 * If you don't define PF_NO_CLIB, you'll have to link with a C library
 * like newlib (libc.a).
 */
#define PF_NO_CLIB

/* Define PF_SUPPORT_TRACE for tracing. This traces pf_inner (pfExecuteToken)
 * when the TRACE_INNER bit (bit 1) of gVarTraceFlags is set, obtainable by
 * using the TRACE-FLAGS word. Enabling trace increases memory footprint.
 */
#define PF_SUPPORT_TRACE

// Size of the main stack, in units of cells
#define DATA_STACK_SIZE 128

// Size of the return stack, in units of cells
#define RETURN_STACK_SIZE 128

// Size of the name dictionary, in units of bytes
#define DICTIONARY_SIZE 10000

// Size of the execution code area, in units of cells
#define EXEC_AREA_SIZE 8000

// Define how much free space we expect in the exec area
// prior to defining a new word, measured in cells.
#define EXEC_SAFETY_MARGIN 20

// Size of the data input area (maximum line length, in characters)
#define TIB_SIZE 256

// Define this to the value to write to the UBRR (UART Baud Rate
// Register), effectively defining your serial baud rate. You must
// take the AVR clock frequency into account. The USART asynchronous
// normal mode is used so the required UBRR value is given by (cf.
// page 172 of ATmega128 data sheet):
//
//          UBRR = (Fosc/(16*BaudRate)) - 1
// 
// For example:
//       16 MHz clock:
//          2400  ==> 416
//          9600  ==> 103
//          14.4k ==> 68
//          19.2k ==> 51
//          28.8k ==> 34
//          38.4k ==> 25
//    
//       8 MHz clock:
//          2400  ==> 207
//          9600  ==> 51
//          14.4k ==> 34
//          19.2k ==> 25
//          28.8k ==> 16
//          38.4k ==> 12
//
//       3.68 MHz clock (STK500 Development Board):
//          2400  ==> 95
//          9600  ==> 23
//          14.4k ==> 15
//          19.2k ==> 11
//          28.8k ==> 7
//          38.4k ==> 5
//    
#define UBRR_VALUE 23

// Set WHICH_USART to either 0 to 1 to use USART0 or USART1 for
// serial communication.
#define WHICH_USART 1

// Define this to process Ctrl-C (ASCII code 0x03) as an interrupt
// key, equivalent to (QUIT), which causes an abort.
#define SIO_CTRL_C_ABORTS

// Define this to use interrupt-driven serial I/O. Comment out
// to use polling and keep USART interrupt free for other things
// (and to save some memory). Note, however, that without
// interrupt-driven serial I/O, XON/XOFF flow control is not
// supported and blasting Forth source to PFAVR will easily
// overrun the program. Non-interrupt SIO should only be used
// for purely interactive use (unless you write your own alternative
// driver to handle lots of received data at a time).
#define PFAVR_INTERRUPT_SIO

// If PFAVR_INTERRUPT_SIO is defined, these define the size of
// the receive and transmit buffers in bytes.
#define SIO_RX_BUFSIZE 256
#define SIO_TX_BUFSIZE 128

// If PFAVR_INTERRUPT_SIO is defined, these define the high
// and low receive buffer levels at which to send XON and XOFF.
// XOFF is sent if SIO_RX_XOFFLEVEL bytes are in the receive buffer,
// and XON is sent if the buffer goes down below SIO_RX_XONLEVEL 
// characters.
#define SIO_RX_XOFFLEVEL (3*SIO_RX_BUFSIZE/4)
#define SIO_RX_XONLEVEL  (SIO_RX_BUFSIZE/4)

// This defines a function FeedCOP() for resetting the computer-
// operating-properly watchdog. This is necessary if the watchdog timer fuse is
// set to enable the watchdog timer.  Note that this feature has not been
// tested. FeedCOP() is *probably* called often enough, but I'm not sure.
// Safest is to disable the watchdog timer fuse.
#define USE_COP

/////////////////////////////////////////////////////////////////
// This defines how you'd like to exit PFAVR when you type 'bye'.
// The default, if you define an empty pfavrexit, is to just
// do whatever the avr-libc libraries do upon exit().

// Null pfavrexit...standard exit() shutdown.
//#define pfavrexit    

// Jump to address location 0, the reset vector, to restart PFAVR.
#define pfavrexit asm("  jmp 0x00")
//
/////////////////////////////////////////////////////////////////

/*
 * Now that you've finished configurations in this file, here are
 * some other things you might want to configure:
 *
 *    - src/crt0.s has start-up code before main() is called. Here
 *      we configure external RAM, number of wait states, bus
 *      keepers, etc.
 *
 */

#endif // _config_H_ 
