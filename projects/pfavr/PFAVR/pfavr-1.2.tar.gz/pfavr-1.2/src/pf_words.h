/* @(#) pf_words.h 96/12/18 1.7 */
#ifndef _pforth_words_h
#define _pforth_words_h

/***************************************************************
** Include file for PForth Words
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
***************************************************************/

extern void ffDot( int n );
extern void ffDotHex( int n );
extern void ffDotS( void );
extern cell ffSkip( char *AddrIn, cell Cnt, char c, char **AddrOut );
extern cell ffScan( char *AddrIn, cell Cnt, char c, char **AddrOut );

#endif /* _pforth_words_h */
/* vim: expandtab */
