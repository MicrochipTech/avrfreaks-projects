/* @(#) pf_inner.c 98/03/16 1.7 */
/***************************************************************
** Inner Interpreter for Forth based on 'C'
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
****************************************************************
**
** 940502 PLB Creation.
** 940505 PLB More macros.
** 940509 PLB Moved all stack stuff into pfExecuteToken.
** 941014 PLB Converted to flat secondary strusture.
** 941027 rdg added casts to ID_SP_FETCH, ID_RP_FETCH, 
**             and ID_HERE for armcc
** 941130 PLB Made w@ unsigned
** 030420 ADS Stripped down
**
***************************************************************/

#include "pf_all.h"

#include "sio.h"

// Define this to cache top-of-stack in a variable
#define CACHE_TOS

// Define this for inline stack operations
//#define INLINE_PUSH_POP

/***************************************************************
** Macros for data stack access.
** TOS is cached in a register in pfExecuteToken.
***************************************************************/

#ifdef INLINE_PUSH_POP
#define M_POP    (*(td_StackPtr++))
#define M_PUSH(n) {*(--(td_StackPtr)) = (cell) (n);}
#else
static cell __M_POP(void) { return *td_StackPtr++; }
static void __M_PUSH(cell n) { *--td_StackPtr = n; }
#define M_POP __M_POP()
#define M_PUSH(n) __M_PUSH(n)
#endif

// Effort to not have CACHE_TOS defined is not yet complete.
// Stopped at ID_2_TO_R. For the moment, you must leave CACHE_TOS
// defined for stuff to work
#ifdef CACHE_TOS
#define TOS      (TopOfStack)
#define UNCACHE  M_PUSH(TOS)     /* Uncache */
#define M_STACK(n) (td_StackPtr[n])   /* Access element n not counting TOS */
#define M_DUP    PUSH_TOS;
#define M_DROP   { TOS = M_POP; }
#define PUSH(x)  { M_PUSH(TOS); TOS = x; }
#define SET_TOS(x) TOS=(x)
#define PUSH_TOS M_PUSH(TOS)  /* Should rename all these to UNCACHE */
#else
#define TOS      (td_StackPtr[0])
#define UNCACHE                   /* No need to uncache */
#define M_STACK(n) (td_StackPtr[n+1])  /* Remember that n does not count TOS */
#define M_DUP   { td_StackPtr--; *td_StackPtr = td_StackPtr[1]; }
#define M_DROP  (td_StackPtr++)
#define PUSH(x) M_PUSH(x)
#define SET_TOS(x) M_PUSH(x)
#define PUSH_TOS
#endif

/***************************************************************
** Macros for return stack access.
***************************************************************/

#ifdef INLINE_PUSH_POP
#define M_R_DROP {td_ReturnPtr++;}
#define M_R_POP (*(td_ReturnPtr++))
#define M_R_PUSH(n) {*(--(td_ReturnPtr)) = (cell) (n);}
#else
static void __M_R_DROP(void) { td_ReturnPtr++; }
static cell __M_R_POP(void) { return *td_ReturnPtr++; }
static void __M_R_PUSH(cell n) { *--td_ReturnPtr = n; }
#define M_R_DROP __M_R_DROP()
#define M_R_POP  __M_R_POP()
#define M_R_PUSH(n) __M_R_PUSH(n)
#endif
#define M_R_PICK(n) (td_ReturnPtr[n])

/***************************************************************
** Misc Forth macros
***************************************************************/
            
// Branches are always stored as the number of bytes (not cells) from current location
#ifdef INLINE_PUSH_POP
#define M_BRANCH   { InsPtr = (cell *) (((uint8 *) InsPtr) + *InsPtr); }
#else
static cell *__M_BRANCH(cell *insptr) { return (cell *)((uint8 *)insptr + *insptr); }
#define M_BRANCH { InsPtr = __M_BRANCH(InsPtr); }
#endif

/* Cache top of data stack like in JForth. */
#ifdef CACHE_TOS
#define LOAD_REGISTERS \
    { \
         TOS = M_POP; \
     }
     
#define SAVE_REGISTERS \
    { \
        M_PUSH( TOS ); \
     }
#else
#define LOAD_REGISTERS
#define SAVE_REGISTERS
#endif

// This is needed (.S) to push the cached TOS back on the stack prior to printing
// it out.
#define M_DOTS \
    SAVE_REGISTERS; \
    ffDotS( ); \
    LOAD_REGISTERS;
    
#define DO_VAR(varname) PUSH((cell) &varname);

#define M_QUIT \
    { \
        ResetForthTask( ); \
        LOAD_REGISTERS; \
    }

/***************************************************************
** Other macros
***************************************************************/

void EMIT_CR(void)
{
  EMIT('\n');
}

// ADS: Made these functions to save space
void MSG_NUM_D(const char *str, int num)
{
  MSG(str);
  ffDot(num);
  EMIT_CR();
}

void MSG_NUM_H(const char *str, int num)
{
  MSG(str);
  ffDotHex(num);
  EMIT_CR();
}

#ifdef CACHE_TOS
#define BINARY_OP( op ) { TOS = M_POP op TOS; }
#else
#define BINARY_OP(op) { td_StackPtr[1] = td_StackPtr[1] op td_StackPtr[0]; td_StackPtr++; }
#endif

#define endcase break
        
#if !defined(PF_SUPPORT_TRACE)
    #define TRACENAMES /* no names */
#else
/* Display name of executing routine. */
static void TraceNames( ExecToken Token, int Level )
{
    const char *DebugName;
    int i;
    
    if( ffTokenToName( Token, &DebugName ) )
    {
        cell NumSpaces;
        if( td_OUT > 0 ) EMIT_CR();
        EMIT( '>' );
        for( i=0; i<Level; i++ )
        {
            MSG( "  " );
        }
        TypeName( DebugName );
/* Space out to column N then .S */
        NumSpaces = 30 - td_OUT;
        for( i=0; i < NumSpaces; i++ )
        {
            EMIT( ' ' );
        }
        ffDotS();
/* No longer needed?        gCurrentTask->td_OUT = 0; */ /* !!! Hack for ffDotS() */
        
    }
    else
    {
        MSG_NUM_H("Couldn't find Name for ", Token);
    }
}

#define TRACENAMES \
    if( (gVarTraceLevel > Level) ) \
    { SAVE_REGISTERS; TraceNames( Token, Level ); LOAD_REGISTERS; }
#endif

static cell __D_OP(cell tos, int ID)
{
  int32 s1 = MAKE_INT_32(tos, M_POP);
  int32 s2 = MAKE_INT_32(M_POP,0);
  s2 |= (ucell)M_POP;

  switch (ID) {
    case ID_D_PLUS:
      s2 += s1;
      break;

    case ID_D_MINUS:
      s2 -= s1;
      break;

    case ID_D_LESSTHAN:
      return (s2<s1) ? FTRUE : FFALSE;
  }
  M_PUSH(INT32_L(s2));
  return INT32_H(s2);
}

/**************************************************************/
void pfExecuteToken( ExecToken XT )
{
#ifdef CACHE_TOS
  cell TopOfStack;
#endif
    cell *InsPtr = 0; // Address
#if 0
    cell Token;
#endif
    cell Scratch;
#ifdef PF_SUPPORT_TRACE
    int Level = 0;
#endif
    cell Temp;
    cell *InitialReturnStack;
    cell FakeSecondary[2] = { 0, ID_EXIT };
    char *CharPtr;
    
/* Move data from task structure to registers for speed (if CACHE_TOS is defined). */
    LOAD_REGISTERS;
    InitialReturnStack = td_ReturnPtr;
#if 0
    Token = XT; // Is this really necessary? Token just shadows XT.
#else
#define Token XT
#endif  

    do
    {
DBUG(("pfExecuteToken: Token = 0x%x\n", Token ));


/* --------------------------------------------------------------- */
/* If secondary, thread down code tree until we hit a primitive. */
        while( !IsTokenPrimitive( Token ) )
        {
#ifdef PF_SUPPORT_TRACE
            if((gVarTraceFlags & TRACE_INNER) )
            {
                MSG("pfExecuteToken: Secondary Token = 0x");
                ffDotHex(Token);
                MSG_NUM_H(", InsPtr = 0x", (cell)InsPtr);
            }
            TRACENAMES;
#endif

/* Save IP on return stack like a JSR. */
            M_R_PUSH( (cell)InsPtr );
            
            InsPtr = (cell *)Token;    // Token is an absolute address
            Token = *InsPtr++;
            
#ifdef PF_SUPPORT_TRACE
/* Bump level for trace display */
            Level++;
#endif
        }

        FeedCOP();  // Reset the computer-operating-properly watchdog

#ifdef PF_SUPPORT_TRACE
        TRACENAMES;
#endif
            
/* Execute primitive Token. */
        switch( Token )
        {
            
    /* Pop up a level. Put first in switch because ID_EXIT==0 */
        case ID_EXIT:
            InsPtr = ( cell *) M_R_POP;

#ifdef PF_SUPPORT_TRACE
            Level--;
#endif
            endcase;
                        
#ifdef MAX_INTERN      
        case ID_1MINUS:  TOS--; endcase;
            
        case ID_1PLUS:   TOS++; endcase;
#endif
            
        case ID_2_R_FETCH:
            UNCACHE;
            M_PUSH( (*(td_ReturnPtr+1)) );
            SET_TOS(*(td_ReturnPtr));
            endcase;

        case ID_2_R_FROM:
            UNCACHE;
            Scratch = M_R_POP;
            M_PUSH( M_R_POP );
            SET_TOS(Scratch);
            endcase;

        case ID_2_TO_R:
            M_R_PUSH( M_POP );
            M_R_PUSH( TOS );
            M_DROP;
            endcase;
        
#ifdef MAX_INTERN
        case ID_2DUP:   /* ( a b -- a b a b ) */
            PUSH_TOS;
            Scratch = M_STACK(1);
            M_PUSH(Scratch);
            endcase;
#endif // MAX_INTERN
            
        case ID_2LITERAL:
            ff2Literal( TOS, M_POP );
            M_DROP;
            endcase;

        case ID_2LITERAL_P:
/* hi part stored first, put on top of stack */
            PUSH_TOS;
            TOS = (cell) *InsPtr++;
            M_PUSH((cell) *InsPtr++);
            endcase;
            
#if 0
        case ID_2MINUS:  TOS -= 2; endcase;
            
        case ID_2PLUS:   TOS += 2; endcase;
#endif
        
#ifdef MAX_INTERN
        case ID_2OVER:  /* ( a b c d -- a b c d a b ) */
            PUSH_TOS;
            Scratch = M_STACK(3);
            M_PUSH(Scratch);
            TOS = M_STACK(3);
            endcase;
            
        case ID_2SWAP:  /* ( a b c d -- c d a b ) */
            Scratch = M_STACK(0);    /* c */
            M_STACK(0) = M_STACK(2); /* a */
            M_STACK(2) = Scratch;    /* c */
            Scratch = TOS;           /* d */
            TOS = M_STACK(1);        /* b */
            M_STACK(1) = Scratch;    /* d */
            endcase;
#endif    
        case ID_ACCEPT: /* ( c-addr +n1 -- +n2 ) */
            CharPtr = (char *) M_POP;
            TOS = ioAccept( CharPtr, TOS);
            endcase;
            
#if 0 // ADS: These are not necessary since addresses are absolute
#ifndef PF_NO_SHELL
        case ID_ALITERAL:
            ffALiteral( ABS_TO_CODEREL(TOS) );
            M_DROP;
            endcase;
#endif  /* !PF_NO_SHELL */

        case ID_ALITERAL_P:
            PUSH_TOS;
            TOS = (cell) LOCAL_CODEREL_TO_ABS( *InsPtr++ );
            endcase;
#endif
            
        case ID_ARSHIFT:     BINARY_OP( >> ); endcase;  /* Arithmetic right shift */
        
        case ID_AND:     BINARY_OP( & ); endcase;
        
#if 0
        case ID_BAIL:
            MSG("Emergency exit.\n");
            EXIT(1);
            endcase;
#endif
        
   // This is used by CREATE.
#if 0   
        case ID_BODY_OFFSET:
            PUSH_TOS;
            TOS = CREATE_BODY_OFFSET;
            endcase;
#endif
            
/* Clear GO flag to tell QUIT to return. */
        case ID_BYE:
            td_Flags &= ~CFTD_FLAG_GO;
            endcase;

/* Branch is followed by an offset relative to address of offset. */
        case ID_BRANCH:
DBUGX(("Before Branch: IP = 0x%x\n", InsPtr ));
            M_BRANCH;
DBUGX(("After Branch: IP = 0x%x\n", InsPtr ));
            endcase;

        case ID_CFETCH:   TOS = *((uint8 *) TOS); endcase;

        case ID_CMOVE: /* ( src dst n -- ) */
            {
                register char *DstPtr = (char *) M_POP; /* dst */
                CharPtr = (char *) M_POP;    /* src */
                for( Scratch=0; (unsigned) Scratch < (unsigned) TOS ; Scratch++ )
                {
                    *DstPtr++ = *CharPtr++;
                }
                M_DROP;
            }
            endcase;
            
        case ID_CMOVE_UP: /* ( src dst n -- ) */
            {
                register char *DstPtr = ((char *) M_POP) + TOS; /* dst */
                CharPtr = ((char *) M_POP) + TOS;;    /* src */
                for( Scratch=0; (unsigned) Scratch < (unsigned) TOS ; Scratch++ )
                {
                    *(--DstPtr) = *(--CharPtr);
                }
                M_DROP;
            }
            endcase;
        
        case ID_COLON:
            ffColon( );
            endcase;

#if 0 // ADS: These have something to do with include files...don't need it
        case ID_COLON_P:  /* ( $name xt -- ) */
            CreateDicEntry( TOS, (char *) M_POP, 0 );
            M_DROP;
            endcase;
#endif

        case ID_COMPARE:
            {
                const char *s1, *s2;
                int len1;
                s2 = (const char *) M_POP;
                len1 = M_POP;
                s1 = (const char *) M_POP;
                TOS = ffCompare( s1, len1, s2, TOS );
            }
            endcase;
            
/* ( a b -- flag , Comparisons ) */
        case ID_COMP_EQUAL:
            TOS = ( TOS == M_POP ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_NOT_EQUAL:
            TOS = ( TOS != M_POP ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_GREATERTHAN:
            TOS = ( M_POP > TOS ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_U_GREATERTHAN:
            TOS = ( ((single_unsigned)M_POP) > ((single_unsigned)TOS) ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_LESSTHAN:
            TOS = (  M_POP < TOS ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_U_LESSTHAN:
            TOS = ( ((single_unsigned)M_POP) < ((single_unsigned)TOS) ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_ZERO_EQUAL:
            TOS = ( TOS == 0 ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_ZERO_NOT_EQUAL:
            TOS = ( TOS != 0 ) ? FTRUE : FALSE ;
            endcase;
        case ID_COMP_ZERO_GREATERTHAN:
            TOS = ( TOS > 0 ) ? FTRUE : FFALSE ;
            endcase;
        case ID_COMP_ZERO_LESSTHAN:
            TOS = ( TOS < 0 ) ? FTRUE : FFALSE ;
            endcase;
            
        case ID_CR:
            EMIT_CR();
            endcase;
        
      /* Effects of CREATE are to create a new dictionary name and then add the
       * following to the exec area:
       *
       *    ( ID_CREATE_P EXIT EXIT )
       *
       * The idea is that the first EXIT is replaced by DOES> to be the
       * XT address of the actual body.
       *
       * ID_CREATE_P will then, at runtime, push the address just past the
       * second EXIT onto the stack. Thus, the body of the variable just
       * CREATE'd begins with this address as its sole parameter.
       */
        case ID_CREATE:
            ffCreate();
            endcase;

        case ID_CREATE_P:
            PUSH_TOS;
/* Put address of body on stack.  Insptr points after code start. */
            TOS = (cell) ((char *)InsPtr - sizeof(cell) + CREATE_BODY_OFFSET );
            endcase;
    
        case ID_CSTORE: /* ( c caddr -- ) */
            *((uint8 *) TOS) = (uint8) M_POP;
            M_DROP;
            endcase;

        case ID_DEFER:
            ffDefer( );
            endcase;

        case ID_DEFER_P:
            endcase;

        case ID_DEPTH:
            PUSH_TOS;
            TOS = td_StackBase - td_StackPtr;
            endcase;
            
        case ID_DIVIDE:     BINARY_OP( / ); endcase;
            
        case ID_DOT:
            ffDot( TOS );
            M_DROP;
            endcase;
            
        case ID_DOTS:
            M_DOTS;
            endcase;
            
        case ID_DO_P: /* ( limit start -- ) ( R: -- start limit ) */
            M_R_PUSH( TOS );
            M_R_PUSH( M_POP );
            M_DROP;
            endcase;
            
        case ID_DROP:  M_DROP; endcase;
            
        case ID_DUMP:
            Scratch = M_POP;
            DumpMemory( (char *) Scratch, TOS );
            M_DROP;
            endcase;

        case ID_DUP:   M_DUP; endcase;
        
/* Double precision add. */
        case ID_D_PLUS:  /* D+ ( al ah bl bh -- sl sh ) */ 
      TOS = __D_OP(TOS, ID_D_PLUS);
            endcase;
    
/* Double precision subtract. */
        case ID_D_MINUS:  /* D- ( al ah bl bh -- sl sh ) */ 
      TOS = __D_OP(TOS, ID_D_MINUS);
            endcase;
            
      // 32/16 unsigned divide for 16-bit result
        case ID_D_UMSMOD:  /* UM/MOD ( al ah bdiv -- rem q ) */ 
            {
        uint32 dividend = MAKE_UINT_32(M_POP,0);
        dividend |= (ucell)M_POP;
        M_PUSH((ucell)(dividend % (ucell)TOS));
        TOS = dividend / (ucell)TOS;
            }
            endcase;

/* Perform signed 16*16 bit multiply for 32 bit result */
        case ID_D_MTIMES:  /* M* ( a b -- pl ph ) */ 
            {
        int32 s1 = (int32)TOS * (int32)M_POP;
        M_PUSH(UINT32_L(s1));
        TOS = UINT32_H(s1);
            }
            endcase;

/* Perform 16*16 bit unsigned multiply for 32 bit result */
        case ID_D_UMTIMES:  /* UM* ( a b -- pl ph ) */ 
      {
        uint32 s1 = (uint32)(ucell)TOS * (ucell)M_POP;
        M_PUSH(UINT32_L(s1));
        TOS = UINT32_H(s1);
            }
            endcase;
            
      // Perform 32/16 bit unsigned divide with 32-bit result and 16-bit remainder
        case ID_D_MUSMOD:  /* MU/MOD ( al am bdiv -- rem ql qh ) */ 
            {
        uint32 dividend = MAKE_UINT_32(M_POP,0);
        ucell rem;

        dividend |= (ucell)M_POP;
        rem = dividend % (ucell)TOS;
        dividend /= (ucell)TOS;
        M_PUSH(rem);
        M_PUSH(UINT32_L(dividend));
        TOS = UINT32_H(dividend);
            }
            endcase;

    case ID_D_ULESSTHAN: /* DU< ( du1 du2 -- du1<du2? ) */
      {
        uint32 du2 = MAKE_UINT_32(TOS, M_POP);
        uint32 du1 = MAKE_UINT_32(M_POP, 0);
        du1 |= (ucell)M_POP;
        TOS = (du1<du2) ? FTRUE : FFALSE;
      }
      endcase;

        case ID_EMIT_P:
            EMIT( (char) TOS );
            M_DROP;
            endcase;
            
        case ID_EOL:    /* ( -- end_of_line_char ) */
            PUSH_TOS;
            TOS = (cell) '\n';
            endcase;
            
        case ID_ERRORQ_P:  /* ( flag num -- , quit if flag true ) */
            Scratch = TOS;
            M_DROP;
            if(TOS)
            {
                MSG_NUM_D("Error: ", (int) Scratch);
                M_QUIT;
            }
            else
            {
                M_DROP;
            }
            endcase;
            
        case ID_EXECUTE:
/* Save IP on return stack like a JSR. */
            M_R_PUSH( (cell)InsPtr );
#ifdef PF_SUPPORT_TRACE
/* Bump level for trace. */
            Level++;
#endif
            if( IsTokenPrimitive( TOS ) )
            {
                FakeSecondary[0] = TOS;   /* Build a fake secondary and execute it. */
                InsPtr = &FakeSecondary[0];
            }
            else
            {
                InsPtr = (cell *) TOS;
            }
            M_DROP;
            endcase;
            
        case ID_FETCH:   TOS = *((cell *) TOS); endcase;
        
        case ID_FILL: /* ( caddr num charval -- ) */
            {
                register char *DstPtr;
                Temp = M_POP;    /* num */
                DstPtr = (char *) M_POP; /* dst */
                for( Scratch=0; (unsigned) Scratch < (unsigned) Temp ; Scratch++ )
                {
                    *DstPtr++ = (char) TOS;
                }
                M_DROP;
            }
            endcase;
            
        case ID_FIND:  /* ( $addr -- $addr 0 | xt +-1 ) */
            TOS = ffFind( (char *) TOS, (ExecToken *) &Temp );
            M_PUSH( Temp );
            endcase;
            
        case ID_FINDNFA:
            TOS = ffFindNFA( (const ForthString *) TOS, (const ForthString **) &Temp );
            M_PUSH( (cell) Temp );
            endcase;

#if 0
        case ID_FLUSHEMIT:
      fflush(stdout);
            endcase;
#endif
            
        case ID_HERE:
            PUSH_TOS;
            TOS = (cell)CODE_HERE;
            endcase;
        
        case ID_HEXNUMBERQ_P:   /* ( addr -- 0 | n 1 ) */
/* Convert using HEX number converter in 'C'.
** Only supports single precision for bootstrap.
*/
            TOS = (cell) ffNumberQ( (char *) TOS, &Temp );
            if( TOS == NUM_TYPE_SINGLE)
            {
                M_PUSH( Temp );   /* Push single number */
            }
            endcase;
            
        case ID_I:  /* ( -- i , DO LOOP index ) */
            PUSH_TOS;
            TOS = M_R_PICK(1);
            endcase;

#if 0
#ifndef PF_NO_SHELL
        case ID_INCLUDE_FILE:
            FileID = (FileStream *) TOS;
            M_DROP;    /* Drop now so that INCLUDE has a clean stack. */
            SAVE_REGISTERS;
            ffIncludeFile( FileID );
            LOAD_REGISTERS;
            endcase;
#endif  /* !PF_NO_SHELL */
#endif
            
        case ID_J:  /* ( -- j , second DO LOOP index ) */
            PUSH_TOS;
            TOS = M_R_PICK(3);
            endcase;

        case ID_KEY:
            PUSH_TOS;
            TOS = ioKey();
            endcase;
            
        case ID_LEAVE_P: /* ( R: index limit --  ) */
            M_R_DROP;
            M_R_DROP;
            M_BRANCH;
            endcase;

        case ID_LITERAL:
            ffLiteral( TOS );
            M_DROP;
            endcase;

        case ID_LITERAL_P:
            DBUG(("ID_LITERAL_P: InsPtr = 0x%x, *InsPtr = 0x%x\n", InsPtr, *InsPtr ));
            PUSH_TOS;
            TOS = *InsPtr++;
            endcase;
    
        case ID_LOOP_P: /* ( R: index limit -- | index limit ) */
            Temp = M_R_POP; /* limit */
            Scratch = M_R_POP + 1; /* index */
            if( Scratch == Temp )
            {
                InsPtr++;   /* skip branch offset, exit loop */
            }
            else
            {
/* Push index and limit back to R */
                M_R_PUSH( Scratch );
                M_R_PUSH( Temp );
/* Branch back to just after (DO) */
                M_BRANCH;
            }
            endcase;
                
        case ID_LSHIFT:     BINARY_OP( << ); endcase;
        
        case ID_MAX:
            Scratch = M_POP;
            TOS = ( TOS > Scratch ) ? TOS : Scratch ;
            endcase;
            
        case ID_MIN:
            Scratch = M_POP;
            TOS = ( TOS < Scratch ) ? TOS : Scratch ;
            endcase;
            
        case ID_MINUS:     BINARY_OP( - ); endcase;
            
        case ID_NAME_TO_TOKEN:
            TOS = (cell) NAME_TO_TOKEN((ForthString *)TOS);
            endcase;
            
        case ID_NAME_TO_PREVIOUS:
            TOS = (cell) NAME_TO_PREVIOUS((ForthString *)TOS);
            endcase;
            
#if 0
        case ID_NOOP:
            endcase;
#endif
            
        case ID_OR:     BINARY_OP( | ); endcase;
        
        case ID_OVER:
            PUSH_TOS;
            TOS = M_STACK(1);
            endcase;
            
        case ID_PICK: /* ( ... n -- sp(n) ) */
            TOS = M_STACK(TOS);
            endcase;

        case ID_PLUS:     BINARY_OP( + ); endcase;
        
        case ID_PLUSLOOP_P: /* ( delta -- ) ( R: index limit -- | index limit ) */
            {
                ucell OldIndex, NewIndex, Limit;

                Limit = M_R_POP;
                OldIndex = M_R_POP;
                NewIndex = OldIndex + TOS; /* add TOS to index, not 1 */
/* Do indices cross boundary between LIMIT-1 and LIMIT ? */
                if( ( (OldIndex - Limit) & ((Limit-1) - NewIndex) & MOST_NEGATIVE_CELL ) ||
                    ( (NewIndex - Limit) & ((Limit-1) - OldIndex) & MOST_NEGATIVE_CELL ) )
                {
                    InsPtr++;   /* skip branch offset, exit loop */
                }
                else
                {
/* Push index and limit back to R */
                    M_R_PUSH( NewIndex );
                    M_R_PUSH( Limit );
/* Branch back to just after (DO) */
                    M_BRANCH;
                }
                M_DROP;
            }
            endcase;

        case ID_PLUS_STORE:   /* ( n addr -- , add n to *addr ) */
            *((cell *) TOS) += M_POP;
            M_DROP;
            endcase;

        case ID_QUIT_P: /* Stop inner interpreter, go back to user. */
#ifdef PF_SUPPORT_TRACE
            Level = 0;
#endif
            ffAbort();
            endcase;
            
        case ID_QDO_P: /* (?DO) ( limit start -- ) ( R: -- start limit ) */
            Scratch = M_POP;  /* limit */
            if( Scratch == TOS )
            {
/* Branch to just after (LOOP) */
                M_BRANCH;
            }
            else
            {
                M_R_PUSH( TOS );
                M_R_PUSH( Scratch );
                InsPtr++;   /* skip branch offset, enter loop */
            }
            M_DROP;
            endcase;

        case ID_QDUP:     if( TOS ) M_DUP; endcase;

        case ID_QTERMINAL:  /* WARNING: Typically not implemented! */
            PUSH_TOS;
      TOS = isinput() ? FTRUE : FFALSE;
            endcase;
        
        case ID_REFILL:
            PUSH_TOS;
            TOS = ffRefill();
            endcase;
            
        case ID_ROLL: /* ( xu xu-1 xu-1 ... x0 u -- xu-1 xu-1 ... x0 xu ) */
            {
                ucell ri;
                cell *srcPtr, *dstPtr;
                Scratch = M_STACK(TOS);
                srcPtr = &M_STACK(TOS-1);
                dstPtr = &M_STACK(TOS);
                for( ri=0; ri<TOS; ri++ )
                {
                    *dstPtr-- = *srcPtr--;
                }
                TOS = Scratch;
                td_StackPtr++;
            }
            endcase;

        case ID_ROT:  /* ( a b c -- b c a ) */
            Scratch = M_POP;    /* b */
            Temp = M_POP;       /* a */
            M_PUSH( Scratch );  /* b */
            PUSH_TOS;           /* c */
            TOS = Temp;         /* a */
            endcase;

/*
** RP@ and RP! are called secondaries so we must
** account for the return address pushed before calling.
*/
        case ID_RP_FETCH:    /* ( -- rp , address of top of return stack ) */
            PUSH_TOS;
            TOS = (cell)td_ReturnPtr;  /* value before calling RP@ */ // I think this comment is wrong
            endcase;
            
        case ID_RP_STORE:    /* ( rp -- , address of top of return stack ) */
            td_ReturnPtr = (cell *) TOS;
            M_DROP;
            endcase;
            
/* Logical right shift */
        case ID_RSHIFT:     { TOS = ((ucell)M_POP) >> TOS; } endcase;   
        
        case ID_R_DROP:
            M_R_DROP;
            endcase;

        case ID_R_FETCH:
            PUSH_TOS;
            TOS = (*(td_ReturnPtr));
            endcase;
        
        case ID_R_FROM:
            PUSH_TOS;
            TOS = M_R_POP;
            endcase;
            
        case ID_SEMICOLON:
            ffSemiColon( );
            endcase;
            
        case ID_SCAN: /* ( addr cnt char -- addr' cnt' ) */
            Scratch = M_POP; /* cnt */
            Temp = M_POP;    /* addr */
            TOS = ffScan( (char *) Temp, Scratch, (char) TOS, &CharPtr );
            M_PUSH((cell) CharPtr);
            endcase;
            
        case ID_SKIP: /* ( addr cnt char -- addr' cnt' ) */
            Scratch = M_POP; /* cnt */
            Temp = M_POP;    /* addr */
            TOS = ffSkip( (char *) Temp, Scratch, (char) TOS, &CharPtr );
            M_PUSH((cell) CharPtr);
            endcase;

        case ID_SOURCE:  /* ( -- c-addr num ) */
            PUSH_TOS;
            M_PUSH( (cell) td_SourcePtr );
            TOS = (cell) td_SourceNum;
            endcase;
            
        case ID_SOURCE_SET: /* ( c-addr num -- ) */
            td_SourcePtr = (char *) M_POP;
            td_SourceNum = TOS;
            M_DROP;
            endcase;
            
        case ID_SP_FETCH:    /* ( -- sp , address of top of stack, sorta ) */
            PUSH_TOS;
            TOS = (cell)td_StackPtr;
            endcase;
            
        case ID_SP_STORE:    /* ( sp -- , address of top of stack, sorta ) */
            td_StackPtr = (cell *) TOS;
            M_DROP;
            endcase;
            
        case ID_STORE: /* ( n addr -- , write n to addr ) */
            *((cell *) TOS) = M_POP;
            M_DROP;
            endcase;

        case ID_SWAP:
            Scratch = TOS;
            TOS = *td_StackPtr;
            *td_StackPtr = Scratch;
            endcase;
            
        case ID_TICK:
            PUSH_TOS;
            CharPtr = (char *) ffWord( (char) ' ' );
            TOS = ffFind( CharPtr, (ExecToken *) &Temp );
            if( TOS == 0 )
            {
                ERR("' could not find ");
                ioType( (char *) CharPtr+1, *CharPtr );
                M_QUIT;
            }
            else
            {
                TOS = Temp;
            }
            endcase;
            
        case ID_TIMES: BINARY_OP( * ); endcase;
            
        case ID_TO_R:
            M_R_PUSH( TOS );
            M_DROP;
            endcase;

        case ID_TYPE:
            Scratch = M_POP; /* addr */
            ioType( (char *) Scratch, TOS );
            M_DROP;
            endcase;

        case ID_VAR_BASE: DO_VAR(gVarBase); endcase;
        case ID_VAR_CODE_BASE: 
        PUSH_TOS;
        TOS = (cell)td_Exec;
        endcase;
        case ID_VAR_CODE_LIMIT:  // ( -- address_just_beyond_exec_area )
        PUSH_TOS;
        TOS = (cell)(td_Exec + EXEC_AREA_SIZE);
        endcase;
        case ID_VAR_CONTEXT: DO_VAR(gVarContext); endcase;
        case ID_VAR_DP: DO_VAR(CODE_HERE); endcase;
        case ID_VAR_ECHO: DO_VAR(gVarEcho); endcase;
        case ID_VAR_HEADERS_BASE: 
        PUSH_TOS;
        TOS = (cell)td_Dict;
        endcase;
        case ID_VAR_HEADERS_PTR: DO_VAR(td_DictPtr); endcase;
        case ID_VAR_HEADERS_LIMIT: // ( -- address_just_beyond_dict )
        PUSH_TOS;
        TOS = (cell)(td_Dict + DICTIONARY_SIZE);
        endcase;
        case ID_VAR_NUM_TIB: DO_VAR(td_SourceNum); endcase;
        case ID_VAR_OUT: DO_VAR(td_OUT); endcase;
        case ID_VAR_RETURN_CODE: DO_VAR(gVarReturnCode); endcase;
        case ID_VAR_STATE: DO_VAR(gVarState); endcase;
        case ID_VAR_TO_IN: DO_VAR(td_IN); endcase;
        case ID_VAR_TRACE_FLAGS: DO_VAR(gVarTraceFlags); endcase;
        case ID_VAR_TRACE_LEVEL: DO_VAR(gVarTraceLevel); endcase;
        case ID_VAR_TRACE_STACK: DO_VAR(gVarTraceStack); endcase;

        case ID_WORD:
            TOS = (cell) ffWord( (char) TOS );
            endcase;

#if 0 // ADS: Unnecessary because FETCH and STORE are already 16 bits
        case ID_WORD_FETCH: /* ( waddr -- w ) */
/* Experiment with direct word access to avoid ENDIAN problem. */
#if 1
            {
                uint16 *uwp = (uint16 *) TOS;
                TOS = *uwp;
            }
#else
            {
                unsigned char *ucp;
                ucp = (unsigned char *) TOS;
                TOS = (*ucp++)<<8;
                TOS |= *ucp;
            }
#endif
            endcase;

        case ID_WORD_STORE: /* ( w waddr -- ) */
#if 1
            {
                uint16 *uwp = (uint16 *) TOS;
                *uwp = (uint16) M_POP;
                M_DROP;
            }
#else
            CharPtr = (char *) TOS;
            Scratch = M_POP;
            *CharPtr++ = (char) (Scratch >> 8);
            *CharPtr = (char) Scratch;
            M_DROP;
#endif
            endcase;
#endif

        case ID_XOR: BINARY_OP( ^ ); endcase;
                
/* Branch is followed by an offset relative to address of offset. */
        case ID_ZERO_BRANCH:
DBUGX(("Before 0Branch: IP = 0x%x\n", InsPtr ));
            if( TOS == 0 )
            {
                M_BRANCH;
            }
            else
            {
                InsPtr++;      /* skip over offset */
            }
            M_DROP;
DBUGX(("After 0Branch: IP = 0x%x\n", InsPtr ));
            endcase;
            
    case ID_FM_S_MOD:      // FM/MOD (d1 n1 -- d1%n1 d1/n1 ) Both quotient and remainder are signed 16 bits, floored division
      // We do symmetric division and decrease quotient if there is a remainder and dividend/divisor are opposite in sign
      {
        cell remainder, quotient;
        int oppsign = (cell)(M_STACK(0) ^ TOS) < 0; // M_STACK(0) is MSB of d1, TOS is n1
        int32 dividend = MAKE_INT_32(M_POP,0);
        dividend |= (ucell)M_POP;

        remainder = dividend % TOS;
        if (oppsign && remainder) {
          quotient = (dividend / TOS) - 1;
          M_PUSH(dividend - TOS*quotient);
          TOS = quotient;
        } else {
          // Same as symmetric division
          M_PUSH(remainder);
          TOS = dividend / TOS;
        }
      }
      endcase;

    case ID_SM_S_REM:      // ( d1 n1 -- d1%n1 d1/n1 ) Both quotient and remainder are signed 16 bits, symmetric division
      // Since GCC implements symmetric division (at least for the 68CH11), this one's easy
      {
        int32 dividend = MAKE_INT_32(M_POP,0);
        dividend |= (ucell)M_POP;
        M_PUSH(dividend % TOS);
        TOS = dividend / TOS;
      }
      endcase;

    case ID_D_LESSTHAN:     // ( d1l d1h d2l d2h -- flag ) Sets flag if d1<d2
      TOS = __D_OP(TOS, ID_D_LESSTHAN);
      endcase;

    case ID_NO_SEMI_CHECK:
      td_Flags |= CFTD_NO_SEMICOLON_CHECK;
      endcase;

    case ID_GDB_BREAK:
      gdb_stop_here();
      endcase;

        default:
            ERR("pfExecuteToken: Unrecognised token = 0x");
            ffDotHex(Token);
            ERR(" at 0x");
            ffDotHex((int) InsPtr);
            EMIT_CR();
            InsPtr = 0;
            endcase;
        }
        
        if(InsPtr) Token = *InsPtr++;   /* Traverse to next token in secondary. */
        
#ifdef PF_DEBUG
        M_DOTS;
#endif

    } while( (( InitialReturnStack - td_ReturnPtr) > 0  ) && (!CHECK_ABORT) );

    SAVE_REGISTERS;
}
// vim: expandtab ts=4
