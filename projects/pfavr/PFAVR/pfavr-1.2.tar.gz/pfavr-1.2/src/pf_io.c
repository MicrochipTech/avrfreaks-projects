/* @(#) pf_io.c 96/12/23 1.12 */
/***************************************************************
** I/O subsystem for PForth based on 'C'
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
****************************************************************
** 941004 PLB Extracted IO calls from pforth_main.c
** 030420 ADS Modified for 68hc11
** 100303 ADS Modified for AVR
***************************************************************/

#include "pf_all.h"

#include "sio.h"

/***************************************************************
** Send single character to output stream.
*/
void ioEmit( char c )
{
  if ((c=='\n') && (gVarEcho & ECHO_CHAR_PREPENDCR)) {
    output('\r');
  }

  output(c);

	if ((c == '\n') || (c == '\r'))
	{
		td_OUT = 0;
	}
	else
	{
		td_OUT++;
	}
}

void ioType( const char *s, int n )
{
	int i;

	for( i=0; i<n; i++)
	{
		ioEmit ( *s++ );
	}
}

/***************************************************************
** Return single character from input device, always keyboard.
*/
cell ioKey( void )
{
	  return inchar();
}

/**************************************************************
** Receive line from input stream.
** Return length, or -1 for EOF.
*/
#define BACKSPACE  (8)
cell ioAccept( char *Target, cell MaxLen)
{
	int c;
	int Len;
	char *p;

DBUGX(("ioAccept(0x%x, 0x%x)\n", Target, Len ));
	p = Target;
	Len = MaxLen;
	while(Len > 0)
	{
    c = ioKey();

    if (CHECK_ABORT) {
      // User pressed Ctrl-C while we're waiting for a character
      return 0;
    }

    if (gVarEcho & ECHO_CHAR) {
			ioEmit( c );
			if( (c == '\r') && (gVarEcho & ECHO_CHAR_APPENDLF)) ioEmit('\n'); /* Send LF after CR */
    }

		switch(c)
		{
			case -1 /*EOF*/:
				DBUG(("EOF\n"));
				return -1;
				break;
				
			case '\r':
			case '\n':
				*p++ = (char) c;
				DBUGX(("EOL\n"));
				goto gotline;
				break;
				
			case BACKSPACE:
				if( Len < MaxLen )  /* Don't go beyond beginning of line. */
				{
					EMIT(' ');
					EMIT(BACKSPACE);
					p--;
					Len++;
				}
				break;
				
			default:
				*p++ = (char) c;
				Len--;
				break;
		}
		
	}
gotline:
	*p = '\0';
		
	return pfCStringLength( Target );
}
// vim: expandtab ts=4
