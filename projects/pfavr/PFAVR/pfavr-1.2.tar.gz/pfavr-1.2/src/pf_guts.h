/* @(#) pf_guts.h 98/01/28 1.4 */
#ifndef _pf_guts_h
#define _pf_guts_h

/***************************************************************
** Include file for PForth, a Forth based on 'C'
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
***************************************************************/


/*
** PFORTH_FILE_VERSION changes when incompatible changes are made
** in the ".dic" file format.
**
** FV3 - 950225 - Use ABS_TO_CODEREL for CodePtr. See file "pf_save.c".
** FV4 - 950309 - Added NameSize and CodeSize to pfSaveForth().
** FV5 - 950316 - Added Floats and reserved words.
** FV6 - 961213 - Added ID_LOCAL_PLUSSTORE, ID_COLON_P, etc.
** FV7 - 971203 - Added ID_FILL, (1LOCAL@),  etc., ran out of reserved, resorted.
** ADS - 030420 - Updated for PFAVR
*/
#define PF_FILE_VERSION (7)   /* Bump this whenever primitives added. */
#define PF_EARLIEST_FILE_VERSION (7)  /* earliest one still compatible */

/***************************************************************
** Sizes and other constants
***************************************************************/

#ifndef FALSE
	#define FALSE (0)
#endif
#ifndef TRUE
	#define TRUE (1)
#endif

#define FFALSE (0)
#define FTRUE (-1)
#define BLANK (' ')

/* Debug TRACE flags */
#define TRACE_INNER     (0x0002)
#define TRACE_COMPILE   (0x0004)
#define TRACE_SPECIAL   (0x0008)

/* Numeric types returned by NUMBER? */
#define NUM_TYPE_BAD    (0)
#define NUM_TYPE_SINGLE (1)
#define NUM_TYPE_DOUBLE (2)
#define NUM_TYPE_FLOAT  (3)

// What is this used for? Apparently, for CREATE_P. But why 3?
#define CREATE_BODY_OFFSET  (3*sizeof(cell))

/***************************************************************
** Primitive Token IDS
** Do NOT change the order of these IDs or dictionary files will break!
***************************************************************/
enum cforth_primitive_ids
{
	ID_EXIT = 0,  /* ID_EXIT must always be zero. */
/* Do NOT change the order of these IDs or dictionary files will break! */
	ID_1MINUS,
	ID_1PLUS,
	ID_2_R_FETCH,
	ID_2_R_FROM,
	ID_2_TO_R,
	ID_2DUP,
	ID_2LITERAL,
	ID_2LITERAL_P,
#if 0
	ID_2MINUS,
	ID_2PLUS,
#endif
	ID_2OVER,
	ID_2SWAP,
	ID_ACCEPT,
#if 0
	ID_ALITERAL,
	ID_ALITERAL_P,
#endif
	ID_ARSHIFT,
	ID_AND,
#if 0
	ID_BAIL,
	ID_BODY_OFFSET,
#endif
	ID_BYE,
	ID_BRANCH,
	ID_CFETCH,
	ID_CMOVE,
	ID_CMOVE_UP,
	ID_COLON,
#if 0
	ID_COLON_P,
#endif
	ID_COMPARE,
	ID_COMP_EQUAL,
	ID_COMP_NOT_EQUAL,
	ID_COMP_GREATERTHAN,
	ID_COMP_U_GREATERTHAN,
	ID_COMP_LESSTHAN,
	ID_COMP_U_LESSTHAN,
	ID_COMP_ZERO_EQUAL,
	ID_COMP_ZERO_NOT_EQUAL,
	ID_COMP_ZERO_GREATERTHAN,
	ID_COMP_ZERO_LESSTHAN,
	ID_CR,
	ID_CREATE,
	ID_CREATE_P,
	ID_CSTORE,
	ID_DEFER,
	ID_DEFER_P,
	ID_DEPTH,
	ID_DIVIDE,
	ID_DOT,
	ID_DOTS,
	ID_DO_P,
	ID_DROP,
	ID_DUMP,
	ID_DUP,
	ID_D_PLUS,
	ID_D_MINUS,
	ID_D_UMSMOD,
	ID_D_MTIMES,
	ID_D_UMTIMES,
	ID_D_MUSMOD,
  ID_D_ULESSTHAN,
#if 0
	ID_EMIT,
#endif
	ID_EMIT_P,
	ID_EOL,
	ID_ERRORQ_P,
	ID_EXECUTE,
	ID_FETCH,
#if 0
	ID_FILE_CLOSE,
	ID_FILE_CREATE,
	ID_FILE_OPEN,
	ID_FILE_POSITION,
	ID_FILE_READ,
	ID_FILE_REPOSITION,
	ID_FILE_RO,
	ID_FILE_RW,
	ID_FILE_SIZE,
	ID_FILE_WRITE,
#endif
	ID_FILL,
	ID_FIND,
	ID_FINDNFA,
#if 0
	ID_FLUSHEMIT,
#endif
	ID_HERE,
	ID_HEXNUMBERQ_P,
	ID_I,
#if 0
	ID_INCLUDE_FILE,
#endif
	ID_J,
	ID_KEY,
	ID_LEAVE_P,
	ID_LITERAL,
	ID_LITERAL_P,
#if 0
	ID_LOADSYS,
#endif
#if 0
	ID_LOCAL_COMPILER,
	ID_LOCAL_ENTRY,
	ID_LOCAL_EXIT,
	ID_LOCAL_FETCH,
	ID_LOCAL_FETCH_1,
	ID_LOCAL_FETCH_2,
	ID_LOCAL_FETCH_3,
	ID_LOCAL_FETCH_4,
	ID_LOCAL_FETCH_5,
	ID_LOCAL_FETCH_6,
	ID_LOCAL_FETCH_7,
	ID_LOCAL_FETCH_8,
	ID_LOCAL_PLUSSTORE,
	ID_LOCAL_STORE,
	ID_LOCAL_STORE_1,
	ID_LOCAL_STORE_2,
	ID_LOCAL_STORE_3,
	ID_LOCAL_STORE_4,
	ID_LOCAL_STORE_5,
	ID_LOCAL_STORE_6,
	ID_LOCAL_STORE_7,
	ID_LOCAL_STORE_8,
#endif
	ID_LOOP_P,
	ID_LSHIFT,
	ID_MAX,
	ID_MIN,
	ID_MINUS,
	ID_NAME_TO_TOKEN,
	ID_NAME_TO_PREVIOUS,
#if 0 // Nobody uses this!
	ID_NOOP,
	ID_NUMBERQ,
#endif
	ID_OR,
	ID_OVER,
	ID_PICK,
	ID_PLUS,
	ID_PLUSLOOP_P,
	ID_PLUS_STORE,
	ID_QUIT_P,
	ID_QDO_P,
	ID_QDUP,
	ID_QTERMINAL,
	ID_REFILL,
#if 0
	ID_RESTORE_INPUT,
#endif
	ID_ROLL,
	ID_ROT,
	ID_RP_FETCH,
	ID_RP_STORE,
	ID_RSHIFT,
	ID_R_DROP,
	ID_R_FETCH,
	ID_R_FROM,
	ID_SEMICOLON,
#if 0
	ID_SAVE_FORTH_P,
	ID_SAVE_INPUT,
#endif
	ID_SCAN,
	ID_SKIP,
	ID_SOURCE,
#if 0
	ID_SOURCE_ID,
	ID_SOURCE_ID_POP,
	ID_SOURCE_ID_PUSH,
#endif
	ID_SOURCE_SET,
	ID_SP_FETCH,
	ID_SP_STORE,
	ID_STORE,
	ID_SWAP,
#if 0
	ID_TEST1,
	ID_TEST2,
	ID_TEST3,
#endif
	ID_TICK,
	ID_TIMES,
	ID_TO_R,
	ID_TYPE,
#if 0
	ID_TYPE_P,
#endif
	ID_VAR_BASE,
	ID_VAR_CODE_BASE,
	ID_VAR_CODE_LIMIT,
	ID_VAR_CONTEXT,
	ID_VAR_DP,
	ID_VAR_ECHO,
	ID_VAR_HEADERS_BASE,
	ID_VAR_HEADERS_PTR,
	ID_VAR_HEADERS_LIMIT,
	ID_VAR_NUM_TIB,
	ID_VAR_OUT,
	ID_VAR_RETURN_CODE,
#if 0
	ID_VAR_SOURCE_ID,
#endif
	ID_VAR_STATE,
	ID_VAR_TO_IN,
	ID_VAR_TRACE_FLAGS,
	ID_VAR_TRACE_LEVEL,
	ID_VAR_TRACE_STACK,
#if 0
	ID_VLIST,
#endif
	ID_WORD,
#if 0
	ID_WORD_FETCH,
	ID_WORD_STORE,
#endif
	ID_XOR,
	ID_ZERO_BRANCH,
  ID_FM_S_MOD,
  ID_SM_S_REM,
  ID_D_LESSTHAN,

  ID_NO_SEMI_CHECK,

  ID_GDB_BREAK,

/* Add new IDs by replacing reserved IDs or extending FP routines. */
/* Do NOT change the order of these IDs or dictionary files will break! */
	NUM_PRIMITIVES     /* This must always be LAST */
};


/***************************************************************
** Structures
***************************************************************/
extern cell td_Flags; // Used for abort checking...
#define CFTD_FLAG_GO	(0x0001)
/* This flag is true when ABORTing to cause the 'C' code to unravel. */
#define CFTD_FLAG_ABORT	(0x0002)

/* This flag is true when we want to skip the next check for matching
 * stack level when a semicolon is encountered. See design notes for the
 * necessity of doing so.
 */
#define CFTD_NO_SEMICOLON_CHECK (0x0004)

// Stacks grow down. Pointers point to last-used location (not next-free).
extern cell *td_StackPtr;  // Primary data stack
extern cell td_Stack[];
#define td_StackBase (td_Stack+DATA_STACK_SIZE)

extern cell *td_ReturnPtr; // Return stack
extern cell td_Return[];
#define td_ReturnBase (td_Return+RETURN_STACK_SIZE)

extern cell *td_InsPtr;    // Current instruction pointer

extern char td_TIB[]; // Buffer for terminal input
extern cell td_IN;    // Index into td_TIB
extern cell td_OUT;   // Current output column
extern cell td_SourceNum; // Number of characters in current input buffer
extern char *td_SourcePtr; // Address of current input buffer
extern int td_LineNumber;

#define FLAG_PRECEDENCE (0x80)  // Apparently, this has no purpose whatsoever
#define FLAG_IMMEDIATE  (0x40)  // Set in a name's length field to mark an immediate word
#define FLAG_SMUDGE     (0x20)  // Set in a name's length field while it is in the process of being defined
#define MASK_NAME_SIZE  (0x1F)  // Maximum length of a name in the dictionary

// The dictionary maps names to execution tokens. The structure is dictEntry.
typedef struct dictEntry {
  char             *prevEntry;  // Pointer to 'len' field of previous entry, or 0 if first name
  ExecToken        XT;          // Either a primitive or an absolute address
  unsigned char    len;         // Length of name (maximum 31), OR'ed with FLAG_XXX bits
  char             name[];      // Variable-length name.
} dictEntry;

// Go from len field address to XT field
static inline ExecToken NAME_TO_TOKEN(const char *x)
{
  return ((ExecToken *)(x))[-1];
}

// Go from len field address to address of previous name (len field)
static inline char *NAME_TO_PREVIOUS(const char *x) {
  return *(char **)(x-4);
}

// Go from one entry pointer to the next
static inline dictEntry *NEXT_DICT_ENTRY(dictEntry *x) {
  return ((dictEntry *)((char *)(x) + sizeof(dictEntry) + ((x)->len & MASK_NAME_SIZE)));
}

// There's no point in making these pointers to dictEntry as this structure
// has variable size. We will always be working with these pointers in terms
// of bytes.
extern unsigned char *td_DictPtr; // Pointer into dictionary area, where to store next dictionary entry
extern unsigned char td_Dict[];

// Each entry in the execution area is a cell-sized execution token. The
// token is either a "small" number (less than NUM_PRIMITIVES) to indicate a built-in primitive
// or a 16-bit address pointing to another execution token in this execution area.
extern cell *td_ExecPtr; // Pointer into execution token area, where definitions are stored
extern cell td_Exec[];

/***************************************************************
** Prototypes
***************************************************************/

#define DEPTH_AT_COLON_INVALID (-100)
extern int         gDepthAtColon; // What does this do?

/* Global variables. */
extern char *gVarContext;   /* Points to the 'len' field of the last dictEntry added */
extern cell  gVarState;     /* 1 if compiling. */
extern cell  gVarBase;      /* Numeric Base. */
extern cell  gVarEcho;      /* Echo flags */
extern cell  gVarTraceLevel;
extern cell  gVarTraceStack;
extern cell  gVarTraceFlags;
extern cell  gVarReturnCode;  /* Returned to caller of Forth, eg. UNIX shell. */
extern char gScratch[];

/* Flags for gVarEcho */
#define ECHO_CHAR           0x01  /* Echo each character as it is received in ioAccept() */
#define ECHO_LINE           0x02  /* Echo each line after reception in ffRefill() */
#define ECHO_CHAR_APPENDLF  0x04  /* If ECHO_CHAR is on, append \n after every \r received */
#define ECHO_NO_OK          0x08  /* Do not print OK as a prompt */
#define ECHO_CHAR_PREPENDCR 0x10  /* On output, send \r before every \n */

/***************************************************************
** Macros
***************************************************************/

#define CODE_HERE td_ExecPtr
#define CODE_COMMA( N ) { *(CODE_HERE++) = (cell) N; }
#define NAME_BASE td_Dict
#define CODE_BASE td_Exec
#define NAME_SIZE DICTIONARY_SIZE
#define CODE_SIZE EXEC_AREA_SIZE

// Tokens are cells. If they are less than NUM_PRIMITIVES they are primitives,
// otherwise they are the address of another token in the execution
// area. The cast to unsigned is necessary so addresses above 0x8000 aren't
// interpreted as negative numbers.
#define IsTokenPrimitive(xt) ((unsigned)xt < (unsigned)NUM_PRIMITIVES)

#define SET_ABORT { td_Flags |= CFTD_FLAG_ABORT; }
#define CLEAR_ABORT { td_Flags &= ~CFTD_FLAG_ABORT; }
#define CHECK_ABORT (td_Flags & CFTD_FLAG_ABORT)

#define DATA_STACK_DEPTH (td_StackBase - td_StackPtr)
#define DROP_DATA_STACK (td_StackPtr++)
#define POP_DATA_STACK (*td_StackPtr++)
#define PUSH_DATA_STACK(x) {*(--(td_StackPtr)) = (cell) x; }

#define MIN(a,b)  ( ((a)<(b)) ? (a) : (b) )
#define MAX(a,b)  ( ((a)>(b)) ? (a) : (b) )

#ifndef TOUCH
	#define TOUCH(argument) ((void)argument)
#endif

/***************************************************************
** I/O related macros
***************************************************************/

#define EMIT(c)  ioEmit(c)

#if 0
#define DBUG(x) printf x
#define DBUGX(x) printf x
#else
#define DBUG(x)
#define DBUGX(x)
#endif

#define MSG(cs)   pfMessage(cs)
#define ERR(x)    MSG(x)

// Work with 32-bit uint's on a 16-bit machine
#define MAKE_UINT_32(a,b) ((((uint32)(ucell)(a)) << 16) | (ucell)b)
#define UINT32_L(a) ((unsigned short)(a & 0xFFFF))
#define UINT32_H(a) ((unsigned short)((a >> 16) & 0xFFFF))

// Work with 32-bit int's on a 16-bit machine
#define MAKE_INT_32(a,b) ((((int32)(cell)(a)) << 16) | (ucell)b)
#define INT32_L(a) ((short)(a & 0xFFFF))
#define INT32_H(a) ((short)((a >> 16) & 0xFFFF))

extern void pfExecuteToken( ExecToken XT );

extern void MSG_NUM_D(const char *str, int num);
extern void MSG_NUM_H(const char *str, int num);
extern void EMIT_CR(void);

extern ExecToken     gLocalCompiler_XT;      /* CFA of (LOCAL) compiler. */

extern void gdb_stop_here(void);

#endif  /* _pf_guts_h */

// vim: expandtab ts=4
