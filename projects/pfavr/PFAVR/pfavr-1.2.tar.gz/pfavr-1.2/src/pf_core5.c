#include "pf_all.h"

unsigned char *td_DictPtr PAGE0; // Pointer into dictionary area, where to store next dictionary entry

  /*
   * td_Dict must always be in .bss else things don't work out right
   */
  unsigned char td_Dict[DICTIONARY_SIZE + 16 /* headroom */];
