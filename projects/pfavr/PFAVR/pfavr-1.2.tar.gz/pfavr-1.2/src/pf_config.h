#ifndef __PF_CONFIG_H__
#define __PF_CONFIG_H__

#include <inttypes.h>
#include "../config.h"

/*
** PFAVR was based on pForth version 19
*/
#define PFAVR_VERSION "1.0"

/*
 * Configuration values for PFAVR
 */

// Signeds, unsigneds, doubles
typedef int16_t single_signed;
typedef uint16_t single_unsigned;
typedef int32_t double_signed;
typedef uint32_t double_unsigned;

// The type of a cell. It is assumed to be a signed type.
typedef single_signed   cell;
typedef single_unsigned ucell;
typedef ucell ExecToken;     // Execution token

// The most negative number that can be stored in a cell
#define MOST_NEGATIVE_CELL 0x8000

// /////////////////////////////////////////////////////////////////
//
// Derived configuration values
//
// /////////////////////////////////////////////////////////////////

/* Stub for now...perhaps used later to place certain globals in
 * internal RAM for faster access.
 */
#define PAGE0

/*
 * Method of placing something in the text section. We do this
 * for the prebuilt dictionary so it does not reside in the data
 * section, where it would occupy space in both program and data
 * memory (wasteful).
 */
#define TEXTSECT __attribute(( section(".text") ))

/*
 * If we're not using the COP, then define a stub function.
 */
#ifndef USE_COP
static inline void FeedCOP(void) { }
#else
static inline void FeedCOP(void) { asm("   wdr"); }
#endif

#endif // __PF_CONFIG_H__
// vim: expandtab ts=4
