/* @(#) pf_types.h 96/12/18 1.3 */
#ifndef _pf_types_h
#define _pf_types_h

#include <inttypes.h>

/***************************************************************
** Type declarations for PForth, a Forth based on 'C'
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
***************************************************************/

/***************************************************************
** Type Declarations
***************************************************************/

#ifndef int32
	typedef int32_t int32;
#endif
#ifndef uint32
	typedef uint32_t uint32;
#endif
#ifndef int16
	typedef int16_t int16;
#endif
#ifndef uint16
	typedef uint16_t uint16;
#endif
#ifndef int8
	typedef int8_t int8;
#endif
#ifndef uint8
	typedef uint8_t uint8;
#endif

#ifndef Err
	typedef int Err;
#endif

typedef char ForthString;
typedef char *ForthStringPtr;

#endif /* _pf_types_h */
/* vim: expandtab */
