#include "pf_all.h"

// Stacks grow down. Pointers point to last-used location (not next-free).
cell *td_StackPtr PAGE0;  // Primary data stack
cell td_Stack[DATA_STACK_SIZE+16 /* headroom */];

