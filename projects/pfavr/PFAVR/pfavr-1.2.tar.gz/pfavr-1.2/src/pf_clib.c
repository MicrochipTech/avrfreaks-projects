/* @(#) pf_clib.c 96/12/18 1.12 */
/***************************************************************
** Duplicate functions from stdlib for PForth based on 'C'
**
** This code duplicates some of the code in the 'C' lib
** because it reduces the dependency on foreign libraries
** for monitor mode where no OS is available.
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
****************************************************************
** 961124 PLB Advance pointers in pfCopyMemory() and pfSetMemory()
** 030420 ADS Modified for 68hc11
***************************************************************/

#include "pf_all.h"

#ifdef PF_NO_CLIB
/* Count chars until NUL.  Replace strlen() */
#define  NUL  ((char) 0)
cell pfCStringLength( const char *s )
{
	cell len = 0;
	while( *s++ != NUL ) len++;
	return len;
}
 
/*    void *memset (void *s, int32 c, size_t n); */
void *pfSetMemory( void *s, cell c, cell n )
{
	uint8 *p = s, byt = (uint8) c;
	while( (n--) > 0) *p++ = byt;
	return s;
}

/*  void *memccpy (void *s1, const void *s2, int32 c, size_t n); */
void *pfCopyMemory( void *s1, const void *s2, cell n)
{
	uint8 *p1 = s1;
	const uint8 *p2 = s2;
	while( (n--) > 0) *p1++ = *p2++;
	return s1;
}

char pfCharToUpper( char c )
{
	return( ((c>='a') && (c<='z')) ? (c - ('a' - 'A')) : c );
}

char pfCharToLower( char c )
{
	return( ((c>='A') && (c<='Z')) ? (c + ('a' - 'A')) : c );
}

char *pfStrchr(const char *s, char c)
{
  while (*s && (*s != c)) s++;

  return *s ? (char *)s : 0;
}
#endif  /* PF_NO_CLIB */
/* vim: expandtab ts=4 */
