/*
 * Here is all the code that is used to build the dictionary and
 * exec areas. It is only invoked in non-prebuilt targets.
 */

#include "pf_all.h"

#if defined(PFAVR_PREBUILT)
#include <avr/io.h>
#include <avr/pgmspace.h>

  /*
   * We store the initialized dictionaries and code areas here
   * then copy them to td_Dict and td_Exec in pfBuildDictionary.
   */
/*static*/ const unsigned char td_DictPrebuilt[] TEXTSECT = {
#include "predict.h"
};

/*static*/ const cell td_ExecPrebuilt[] TEXTSECT = {
#include "preexec.h"
};

#else // PFAVR_PREBUILT

static char ForthWordsText[] = 
#include "forthwords.h"
    ;

static void printForthWordsString(const char *s)
{
  while (*s != '\r') {
    ioEmit(*s++);
  }
  EMIT_CR();
}

static void LoadForthWordsText(void)
{
  char *oldSourcePtr;

  // For each line, pass it to ffInterpret(), setting the
  // source pointer and length each time.
  td_SourcePtr = ForthWordsText;

  while (*td_SourcePtr) {
    td_SourceNum = pfStrchr(td_SourcePtr, '\r') - td_SourcePtr + 1;
    td_IN = 0;

    //MSG("Interpreting:");EMIT_CR();
    //printForthWordsString(td_SourcePtr);
    //EMIT('.');

    oldSourcePtr = td_SourcePtr; // 'cuz ffInterpret() resets it in case of abort
    if (ffInterpret()) {
      MSG("Aborting LoadForthWordsText at line:"); EMIT_CR();
      printForthWordsString(oldSourcePtr);
      break;
    }

    td_SourcePtr += td_SourceNum;
  }

  pfCreateTask(); // Reset td_SourcePtr and clear stacks
  td_IN = 0;
}

/* Convert name then create deferred dictionary entry. */
static void  CreateDeferredC( ExecToken DefaultXT, const char *CName )
{
    char FName[40];
    CStringToForth( FName, CName );
    ffStringDefer( FName, DefaultXT );
}

/***************************************************************
** Convert name then create dictionary entry.
*/
static void  CreateDicEntryC( ExecToken XT, const char *CName, unsigned Flags )
{
    ForthString FName[40];
    CStringToForth( FName, CName );
    CreateDicEntry( XT, FName, Flags );

  //outstr("Dict space free: "); ffDot(DICTIONARY_SIZE - (td_DictPtr-td_Dict)); EMIT_CR();
  //outstr("Code space free: "); ffDot(EXEC_AREA_SIZE - (td_ExecPtr-td_Exec)); EMIT_CR();
  //dumpDictionary();
  DBUG(("Dict space free: %d\n", DICTIONARY_SIZE - (td_DictPtr-td_Dict)));
  DBUG(("Code space free: %d\n", EXEC_AREA_SIZE  - (td_ExecPtr-td_Exec)));
}

#endif // PFAVR_PREBUILT

// This is just a known symbol that we can stop at to have the simulator
// dump out the dictionary and exec area.
void gdb_stop_here(void)
{
}

/***************************************************************
** Build a dictionary from scratch.
*/
void  pfBuildDictionary( void )
{

#ifndef PFAVR_PREBUILT
    pfCreateDictionary( );

    CreateDicEntryC( ID_EXIT, "EXIT", 0 );
#ifdef MAX_INTERN
    CreateDicEntryC( ID_1MINUS, "1-", 0 );
    CreateDicEntryC( ID_1PLUS, "1+", 0 );
#endif
    CreateDicEntryC( ID_2_R_FETCH, "2R@", 0 );
    CreateDicEntryC( ID_2_R_FROM, "2R>", 0 );
    CreateDicEntryC( ID_2_TO_R, "2>R", 0 );
#ifdef MAX_INTERN
    CreateDicEntryC( ID_2DUP, "2DUP", 0 );
#endif
    CreateDicEntryC( ID_2LITERAL, "2LITERAL", FLAG_IMMEDIATE );
    CreateDicEntryC( ID_2LITERAL_P, "(2LITERAL)", 0 );
#if 0
    CreateDicEntryC( ID_2MINUS, "2-", 0 );
    CreateDicEntryC( ID_2PLUS, "2+", 0 );
#endif
#ifdef MAX_INTERN
    CreateDicEntryC( ID_2OVER, "2OVER", 0 );
    CreateDicEntryC( ID_2SWAP, "2SWAP", 0 );
#endif
    CreateDicEntryC( ID_ACCEPT, "ACCEPT", 0 );
#if 0 // ADS: Don't know what these do
    CreateDicEntryC( ID_ALITERAL, "ALITERAL", FLAG_IMMEDIATE );
    CreateDicEntryC( ID_ALITERAL_P, "(ALITERAL)", 0 );
#endif
    CreateDicEntryC( ID_ARSHIFT, "ARSHIFT", 0 );
    CreateDicEntryC( ID_AND, "AND", 0 );
#if 0
    CreateDicEntryC( ID_BAIL, "BAIL", 0 );
    CreateDicEntryC( ID_BODY_OFFSET, "BODY_OFFSET", 0 );
#endif
    CreateDicEntryC( ID_BYE, "BYE", 0 );
    CreateDicEntryC( ID_BRANCH, "BRANCH", 0 );
    CreateDicEntryC( ID_CFETCH, "C@", 0 );
    CreateDicEntryC( ID_CMOVE, "CMOVE", 0 );
    CreateDicEntryC( ID_CMOVE_UP, "CMOVE>", 0 );
    CreateDicEntryC( ID_COLON, ":", 0 );
#if 0 // ADS
    CreateDicEntryC( ID_COLON_P, "(:)", 0 );
#endif
    CreateDicEntryC( ID_COMPARE, "COMPARE", 0 );
    CreateDicEntryC( ID_COMP_EQUAL, "=", 0 );
    CreateDicEntryC( ID_COMP_NOT_EQUAL, "<>", 0 );
    CreateDicEntryC( ID_COMP_GREATERTHAN, ">", 0 );
    CreateDicEntryC( ID_COMP_U_GREATERTHAN, "U>", 0 );
    CreateDicEntryC( ID_COMP_LESSTHAN, "<", 0 );
    CreateDicEntryC( ID_COMP_U_LESSTHAN, "U<", 0 );
    CreateDicEntryC( ID_COMP_ZERO_EQUAL, "0=", 0 );
    CreateDicEntryC( ID_COMP_ZERO_NOT_EQUAL, "0<>", 0 );
    CreateDicEntryC( ID_COMP_ZERO_GREATERTHAN, "0>", 0 );
    CreateDicEntryC( ID_COMP_ZERO_LESSTHAN, "0<", 0 );
    CreateDicEntryC( ID_CR, "CR", 0 );
    CreateDicEntryC( ID_CREATE, "CREATE", 0 );
    CreateDicEntryC( ID_CREATE_P, "(CREATE)", 0 );
    CreateDicEntryC( ID_CSTORE, "C!", 0 );
    CreateDicEntryC( ID_DEFER, "DEFER", 0 );
  // ID_DEFER_P comes here
    CreateDicEntryC( ID_DEPTH, "DEPTH",  0 );
    CreateDicEntryC( ID_DIVIDE, "/", 0 );
    CreateDicEntryC( ID_DOT, ".",  0 );
    CreateDicEntryC( ID_DOTS, ".S",  0 );
    CreateDicEntryC( ID_DO_P, "(DO)", 0 );
    CreateDicEntryC( ID_DROP, "DROP", 0 );
    CreateDicEntryC( ID_DUMP, "DUMP", 0 );
    CreateDicEntryC( ID_DUP, "DUP",  0 );
    CreateDicEntryC( ID_D_PLUS, "D+", 0 );
    CreateDicEntryC( ID_D_MINUS, "D-", 0 );
    CreateDicEntryC( ID_D_UMSMOD, "UM/MOD", 0 );
    CreateDicEntryC( ID_D_MTIMES, "M*", 0 );
    CreateDicEntryC( ID_D_UMTIMES, "UM*", 0 );
    CreateDicEntryC( ID_D_MUSMOD, "MU/MOD", 0 );
    CreateDicEntryC( ID_D_ULESSTHAN, "DU<", 0 );
    CreateDicEntryC( ID_EMIT_P, "(EMIT)",  0 );
    CreateDeferredC( ID_EMIT_P, "EMIT");
    CreateDicEntryC( ID_EOL, "EOL",  0 );
#if 0
    CreateDicEntryC( ID_ERRORQ_P, "(?ERROR)",  0 );
#endif
    CreateDicEntryC( ID_ERRORQ_P, "?ERROR",  0 );
    CreateDicEntryC( ID_EXECUTE, "EXECUTE",  0 );
    CreateDicEntryC( ID_FETCH, "@",  0 );
#if 0
    CreateDicEntryC( ID_FILE_CREATE, "CREATE-FILE",  0 );
    CreateDicEntryC( ID_FILE_OPEN, "OPEN-FILE",  0 );
    CreateDicEntryC( ID_FILE_CLOSE, "CLOSE-FILE",  0 );
    CreateDicEntryC( ID_FILE_READ, "READ-FILE",  0 );
    CreateDicEntryC( ID_FILE_SIZE, "FILE-SIZE",  0 );
    CreateDicEntryC( ID_FILE_WRITE, "WRITE-FILE",  0 );
    CreateDicEntryC( ID_FILE_POSITION, "FILE-POSITION",  0 );
    CreateDicEntryC( ID_FILE_REPOSITION, "REPOSITION-FILE",  0 );
    CreateDicEntryC( ID_FILE_RO, "R/O",  0 );
    CreateDicEntryC( ID_FILE_RW, "R/W",  0 );
#endif
    CreateDicEntryC( ID_FILL, "FILL", 0 );
    CreateDicEntryC( ID_FIND, "FIND",  0 );
    CreateDicEntryC( ID_FINDNFA, "FINDNFA",  0 );
#if 0
    CreateDicEntryC( ID_FLUSHEMIT, "FLUSHEMIT",  0 );
#endif
    CreateDicEntryC( ID_HERE, "HERE",  0 );
    CreateDicEntryC( ID_HEXNUMBERQ_P, "(HEXNUMBER?)",  0 );
    CreateDicEntryC( ID_I, "I",  0 );
    CreateDicEntryC( ID_J, "J",  0 );
#if 0
    CreateDicEntryC( ID_INCLUDE_FILE, "INCLUDE-FILE",  0 );
#endif
    CreateDicEntryC( ID_KEY, "KEY",  0 );
    CreateDicEntryC( ID_LEAVE_P, "(LEAVE)", 0 );
    CreateDicEntryC( ID_LITERAL, "LITERAL", FLAG_IMMEDIATE );
    CreateDicEntryC( ID_LITERAL_P, "(LITERAL)", 0 );
#if 0
    CreateDicEntryC( ID_LOADSYS, "LOADSYS", 0 );
#endif
#if 0
    CreateDicEntryC( ID_LOCAL_COMPILER, "LOCAL-COMPILER", 0 );
    CreateDicEntryC( ID_LOCAL_ENTRY, "(LOCAL.ENTRY)", 0 );
    CreateDicEntryC( ID_LOCAL_EXIT, "(LOCAL.EXIT)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH, "(LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_1, "(1_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_2, "(2_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_3, "(3_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_4, "(4_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_5, "(5_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_6, "(6_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_7, "(7_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_FETCH_8, "(8_LOCAL@)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE, "(LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_1, "(1_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_2, "(2_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_3, "(3_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_4, "(4_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_5, "(5_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_6, "(6_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_7, "(7_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_STORE_8, "(8_LOCAL!)", 0 );
    CreateDicEntryC( ID_LOCAL_PLUSSTORE, "(LOCAL+!)", 0 );
#endif
    CreateDicEntryC( ID_LOOP_P, "(LOOP)", 0 );
    CreateDicEntryC( ID_LSHIFT, "LSHIFT", 0 );
    CreateDicEntryC( ID_MAX, "MAX", 0 );
    CreateDicEntryC( ID_MIN, "MIN", 0 );
    CreateDicEntryC( ID_MINUS, "-", 0 );
    CreateDicEntryC( ID_NAME_TO_TOKEN, "NAME>", 0 );
    CreateDicEntryC( ID_NAME_TO_PREVIOUS, "PREVNAME", 0 );
#if 0
    CreateDicEntryC( ID_NOOP, "NOOP", 0 );
#endif
    CreateDeferredC( ID_HEXNUMBERQ_P, "NUMBER?" );
    CreateDicEntryC( ID_OR, "OR", 0 );
    CreateDicEntryC( ID_OVER, "OVER", 0 );
    CreateDicEntryC( ID_PICK, "PICK",  0 );
    CreateDicEntryC( ID_PLUS, "+",  0 );
    CreateDicEntryC( ID_PLUSLOOP_P, "(+LOOP)", 0 );
    CreateDicEntryC( ID_PLUS_STORE, "+!",  0 );
    CreateDicEntryC( ID_QUIT_P, "(QUIT)",  0 );
    CreateDeferredC( ID_QUIT_P, "QUIT" );
    CreateDicEntryC( ID_QDO_P, "(?DO)", 0 );
    CreateDicEntryC( ID_QDUP, "?DUP",  0 );
#if 0
    CreateDicEntryC( ID_QTERMINAL, "?TERMINAL",  0 );
#endif
    CreateDicEntryC( ID_QTERMINAL, "KEY?",  0 );
    CreateDicEntryC( ID_REFILL, "REFILL",  0 );
    CreateDicEntryC( ID_ROLL, "ROLL",  0 );
    CreateDicEntryC( ID_ROT, "ROT",  0 );
    CreateDicEntryC( ID_RP_FETCH, "RP@",  0 );
    CreateDicEntryC( ID_RP_STORE, "RP!",  0 );
    CreateDicEntryC( ID_RSHIFT, "RSHIFT",  0 );
    CreateDicEntryC( ID_R_DROP, "RDROP",  0 );
    CreateDicEntryC( ID_R_FETCH, "R@",  0 );
    CreateDicEntryC( ID_R_FROM, "R>",  0 );
    CreateDicEntryC( ID_SEMICOLON, ";",  FLAG_IMMEDIATE );
#if 0
    CreateDicEntryC( ID_SAVE_FORTH_P, "(SAVE-FORTH)",  0 );
#endif
    CreateDicEntryC( ID_SCAN, "SCAN",  0 );
    CreateDicEntryC( ID_SKIP, "SKIP",  0 );
    CreateDicEntryC( ID_SOURCE, "SOURCE",  0 );
    CreateDicEntryC( ID_SOURCE_SET, "SET-SOURCE",  0 );
    CreateDicEntryC( ID_SP_FETCH, "SP@",  0 );
    CreateDicEntryC( ID_SP_STORE, "SP!",  0 );
    CreateDicEntryC( ID_STORE, "!",  0 );
    CreateDicEntryC( ID_SWAP, "SWAP",  0 );
    CreateDicEntryC( ID_TICK, "'", 0 );
    CreateDicEntryC( ID_TIMES, "*", 0 );
    CreateDicEntryC( ID_TO_R, ">R", 0 );
    CreateDicEntryC( ID_TYPE, "TYPE", 0 );
    CreateDicEntryC( ID_VAR_BASE, "BASE", 0 );
    CreateDicEntryC( ID_VAR_CODE_BASE, "CODE-BASE", 0 );
    CreateDicEntryC( ID_VAR_CODE_LIMIT, "CODE-LIMIT", 0 );
    CreateDicEntryC( ID_VAR_CONTEXT, "CONTEXT", 0 );
    CreateDicEntryC( ID_VAR_DP, "DP", 0 );
    CreateDicEntryC( ID_VAR_ECHO, "ECHO", 0 );
    CreateDicEntryC( ID_VAR_HEADERS_BASE, "HEADERS-BASE", 0 );
    CreateDicEntryC( ID_VAR_HEADERS_PTR, "HEADERS-PTR", 0 );
    CreateDicEntryC( ID_VAR_HEADERS_LIMIT, "HEADERS-LIMIT", 0 );
    CreateDicEntryC( ID_VAR_NUM_TIB, "#TIB", 0 );
    CreateDicEntryC( ID_VAR_OUT, "OUT", 0 );
    CreateDicEntryC( ID_VAR_RETURN_CODE, "RETURN-CODE", 0 );
    CreateDicEntryC( ID_VAR_TRACE_FLAGS, "TRACE-FLAGS", 0 );
    CreateDicEntryC( ID_VAR_TRACE_LEVEL, "TRACE-LEVEL", 0 );
    CreateDicEntryC( ID_VAR_TRACE_STACK, "TRACE-STACK", 0 );
    CreateDicEntryC( ID_VAR_STATE, "STATE", 0 );
    CreateDicEntryC( ID_VAR_TO_IN, ">IN", 0 );
#if 0
    CreateDicEntryC( ID_VLIST, "VLIST", 0 );
#endif
    CreateDicEntryC( ID_WORD, "WORD", 0 );
#if 0
    CreateDicEntryC( ID_WORD_FETCH, "W@", 0 );
    CreateDicEntryC( ID_WORD_STORE, "W!", 0 );
#endif
    CreateDicEntryC( ID_XOR, "XOR", 0 );
    CreateDicEntryC( ID_ZERO_BRANCH, "0BRANCH", 0 );
  CreateDicEntryC( ID_FM_S_MOD, "FM/MOD", 0 );
  CreateDicEntryC( ID_SM_S_REM, "SM/REM", 0 );
  CreateDicEntryC( ID_D_LESSTHAN, "D<", 0 );

  CreateDicEntryC( ID_NO_SEMI_CHECK, "NO;CHECK", 0 );
  CreateDicEntryC( ID_GDB_BREAK, "GDB-BREAK", FLAG_IMMEDIATE );

  // Must do these so we can use NUMBER?
    if( FindSpecialXTs() < 0 ) {
    MSG("Can't find special XT's");
  }

  // Now load some Forth words defined as simulated files.
  LoadForthWordsText();

  // This is just here so we can have a convenient spot to stop the
  // simulator and dump various things.
  gdb_stop_here();
#else // PFAVR_PREBUILT
  /*
   * Set td_DictPtr, td_ExecPtr to precomputed values of next free
   * location
   */
  {
    unsigned char *td_Dict_check;
    cell *td_Exec_check;
#include "prevars.h"

    if ( (td_Dict_check != td_Dict) || (td_Exec_check != td_Exec) ) {
      MSG("Prebuilt location mismatch.");
    }
    /* We must take the role of GCC loader, copying td_DictPrebuilt to
     * td_Dict, and same for td_ExecPrebuilt/td_Exec. Since the sources reside
     * in program memory, we must use the avr-libc memcpy_P() functions.
     */
    memcpy_P(td_Dict, td_DictPrebuilt, td_DictPtr-td_Dict);
    memcpy_P(td_Exec, td_ExecPrebuilt, sizeof(td_Exec[0])*(td_ExecPtr-td_Exec));
  }

  gdb_stop_here();

  if( FindSpecialXTs() < 0 ) {
    MSG("Can't find special XT's");
  }

#endif // not PFAVR_PREBUILT

  //DumpMemory(td_DictPtr-32, 32);

}
// vim: expandtab ts=4
