/* @(#) pf_core.c 98/01/28 1.5 */
/***************************************************************
** Forth based on 'C'
**
** This file has the main entry points to the pForth library.
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
****************************************************************
** 940502 PLB Creation.
** 940505 PLB More macros.
** 940509 PLB Moved all stack handling into inner interpreter.
**        Added Create, Colon, Semicolon, HNumberQ, etc.
** 940510 PLB Got inner interpreter working with secondaries.
**        Added (LITERAL).   Compiles colon definitions.
** 940511 PLB Added conditionals, LITERAL, CREATE DOES>
** 940512 PLB Added DO LOOP DEFER, fixed R>
** 940520 PLB Added INCLUDE
** 940521 PLB Added NUMBER?
** 940930 PLB Outer Interpreter now uses deferred NUMBER?
** 941005 PLB Added ANSI locals, LEAVE, modularised
** 950320 RDG Added underflow checking for FP stack
** 970702 PLB Added STACK_SAFETY to FP stack size.
** 030420 ADS Modified for 68hc11
***************************************************************/

#include "pf_all.h"
 
/***************************************************************
** Global Data
***************************************************************/

char          gScratch[TIB_SIZE];

/* Depth of data stack when colon called. */
int         gDepthAtColon;

/* Global Forth variables. */
char *gVarContext;      /* Points to last name field. */
cell  gVarState;        /* 1 if compiling. */
cell  gVarBase;         /* Numeric Base. */
cell  gVarEcho;	        /* Echo input. */
cell  gVarTraceLevel;   /* Trace Level for Inner Interpreter. */
cell  gVarTraceStack;   /* Dump Stack each time if true. */
cell  gVarTraceFlags;   /* Enable various internal debug messages. */
cell  gVarReturnCode;   /* Returned to caller of Forth, eg. UNIX shell. */

cell *td_InsPtr PAGE0;    // Current instruction pointer

cell td_Flags; // Used for abort checking...
char td_TIB[TIB_SIZE]; // Buffer for terminal input
cell td_IN;    // Index into td_TIB
cell td_OUT;   // Current output column
cell td_SourceNum;
char *td_SourcePtr;   // Pointer to where parseable area is (normally, td_TIB)
int td_LineNumber;

/* Initialize non-zero globals in a function to simplify loading on
 * embedded systems which may only support uninitialized data segments.
 */
void pfInitGlobals( void )
{
	gVarBase = 10;       
	gVarTraceStack = 0;  
	gDepthAtColon = DEPTH_AT_COLON_INVALID;
}

/***************************************************************
** Task Management
***************************************************************/

void pfCreateTask( void )
{
  // Initialize data stack
  td_StackPtr = td_StackBase;

  // Initialize return stack
  td_ReturnPtr = td_ReturnBase;

  td_SourcePtr = td_TIB;
}

/***************************************************************
** Dictionary Management
***************************************************************/

void pfExecByName( const char *CString )
{
  ExecToken  autoInitXT;
  if( ffFindC( CString, &autoInitXT ) )
  {
    pfExecuteToken( autoInitXT );
  }
}

/***************************************************************
** Create a complete dictionary.
*/
void pfCreateDictionary( void ) 
{
  pfSetMemory(td_Dict, 0, DICTIONARY_SIZE);
  td_DictPtr = td_Dict;
  //gVarContext = td_DictPtr;
  gVarContext = 0;

  td_ExecPtr = td_Exec;
}

/***************************************************************
** Used by Quit and other routines to restore system.
***************************************************************/

void ResetForthTask( void )
{
  pfCreateTask();

	td_IN = td_SourceNum;
	gVarState = 0;
}

/***************************************************************
** RunForth
***************************************************************/

int pfRunForth( void )
{
	ffQuit();
	return gVarReturnCode;
}

/***************************************************************
** Output 'C' string message.
** This is provided to help avoid the use of printf() and other I/O
** which may not be present on a small embedded system.
***************************************************************/

void pfMessage( const char *CString )
{
	ioType( CString, pfCStringLength(CString) );
}

/**************************************************************************
** Main entry point fo pForth
*/
int pfDoForth( void )
{
  int Result;

	pfInitGlobals();
	
	pfCreateTask( );

  MSG( "PFAVR " PFAVR_VERSION "\r\n" );

  pfBuildDictionary( );

  pfExecByName("AUTO.INIT");

  Result = pfRunForth();

  pfExecByName("AUTO.TERM");

  return Result;
}
// vim: expandtab ts=4
