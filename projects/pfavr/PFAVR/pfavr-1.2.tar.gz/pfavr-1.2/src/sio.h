#ifndef _SIO_H_
#define _SIO_H_

extern void outstr(const char *);  // Write a string
extern void output(unsigned char); // Write a single character
extern int isinput(void);          // Return true if character available
extern int input(void);            // Poll for a character, return -1 if none
extern unsigned char inchar(void); // Poll for a character
extern void sio_init(void);        // Initialize and enable serial ports
extern void sio_cleanup(void);     // Prepare to exit PFAVR

extern void FeedCOP(void);         // Reset the computer-operating-properly watchdog

#endif /* _SIO_H_ */
/* vim: expandtab */
