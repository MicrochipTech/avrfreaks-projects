#include "pf_all.h"

cell *td_ExecPtr PAGE0; // Pointer into execution token area, where definitions are stored

  /*
   * For a ROM target, td_Exec must always be in .bss else things
   * don't work out right.
   */
  cell td_Exec[EXEC_AREA_SIZE + 16 /* headroom */];
