/* @(#) pfcompil.h 96/12/18 1.11 */

#ifndef _pforth_compile_h
#define _pforth_compile_h

/***************************************************************
** Include file for PForth Compiler
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
***************************************************************/

extern ExecToken NameToToken( const ForthString *NFA );
extern cell  ffFind( const ForthString *WordName, ExecToken *pXT );
extern cell  ffFindC( const char *WordName, ExecToken *pXT );
extern cell  ffFindNFA( const ForthString *WordName, const ForthString **NFAPtr );
extern cell  ffNumberQ( const char *FWord, cell *Num );
extern cell  ffRefill( void );
extern cell  ffTokenToName( ExecToken XT, const ForthString **NFAPtr );
extern cell *NameToCode( ForthString *NFA );
extern void  pfBuildDictionary( void );
extern char *ffWord( char c );
extern const ForthString *NameToPrevious( const ForthString *NFA );
extern int FindSpecialCFAs( void );
extern int FindSpecialXTs( void );
extern int NotCompiled( const char *FunctionName );
extern int ffInterpret( void );
extern void  CreateDicEntry( ExecToken XT, const ForthStringPtr FName, unsigned Flags );
extern void  ff2Literal( cell dHi, cell dLo );
extern void  ffALiteral( cell Num );
extern void  ffAbort( void );
extern void  ffColon( void );
extern void  ffCreate( void );
extern void  ffCreateSecondaryHeader( const ForthStringPtr FName);
extern void  ffDefer( void );
extern void  ffFinishSecondary( void );
extern void  ffLiteral( cell Num );
extern void  ffOK( void );
extern void  ffQuit( void );
extern void  ffSemiColon( void );
extern void  ffStringCreate( ForthStringPtr FName);
extern void  ffStringDefer( const ForthStringPtr FName, ExecToken DefaultXT );

#endif /* _pforth_compile_h */
/* vim: expandtab */
