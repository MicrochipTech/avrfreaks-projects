/*
 * AVR serial I/O support
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include "pf_all.h"
#include "sio.h"

/*
 * Define which USART we should use by selecting the
 * following defines
 */
#if WHICH_USART==0  // USART0
#define UCSRA UCSR0A
#define UCSRB UCSR0B
#define UCSRC UCSR0C
#define UBRRH UBRR0H
#define UBRRL UBRR0L
#define UDR   UDR0
#define SIG_UART_RECV SIG_UART0_RECV
#define SIG_UART_DATA SIG_UART0_DATA
#elif WHICH_USART==1  // USART1
#define UCSRA UCSR1A
#define UCSRB UCSR1B
#define UCSRC UCSR1C
#define UBRRH UBRR1H
#define UBRRL UBRR1L
#define UDR   UDR1
#define SIG_UART_RECV SIG_UART1_RECV
#define SIG_UART_DATA SIG_UART1_DATA
#else
#error "Unknown value of WHICH_USART...check config.h"
#endif

#ifdef PFAVR_INTERRUPT_SIO

#define XON_CHAR  0x11
#define XOFF_CHAR 0x13

#define interruptsOFF cli
#define interruptsON  sei

static unsigned char *_rx_tail PAGE0;
static unsigned char * volatile _rx_head PAGE0;
static unsigned char _rx_buf_start[SIO_RX_BUFSIZE];
static unsigned char volatile _rx_flags PAGE0;
static unsigned volatile _rx_chars PAGE0;
#define _rx_buf_limit (_rx_buf_start+sizeof(_rx_buf_start))

static unsigned char * volatile _tx_tail PAGE0;
static unsigned char *_tx_head PAGE0;
static unsigned char _tx_buf_start[SIO_TX_BUFSIZE];
static unsigned char volatile _tx_flags PAGE0;
#define _tx_buf_limit (_tx_buf_start+sizeof(_tx_buf_start))

// Flags for _tx_flags
#define TX_FLAG_SEND_XOFF  0x01 // transmitter should send XOFF instead of next character
#define TX_FLAG_SEND_XON   0x02 // transmitter should send XON instead of next character
#define TX_FLAG_SUSPENDED  0x04 // Host has requested XOFF

// Flags for _rx_flags
#define RX_FLAG_SUSPENDED  0x01  // XOFF has been sent to host
#define RX_FLAG_OVERRUN    0x02  // Software overrun (rather than USART overrun)
#define RX_FLAG_FE         0x10  // framing error, same as _BV(FE) bit in AVR
#define RX_FLAG_OR         0x08  // overrun, same as _BV(DOR) bit in AVR

/* SIGNAL(xxx) runs with interrupts disabled */
/* Interrupt handler for data reception. */
SIGNAL(SIG_UART_RECV)
{
  unsigned char scsr = UCSRA & (_BV(DOR)|_BV(FE));

  _rx_flags |= scsr;
  *_rx_head = UDR;

  // If no errors have been flagged for this character, check for XON/XOFF reception
  // then check for need to send XOFF if high watermark reached.

  if (scsr) {
    // Ignore data if we have overrun or framing error.
    return;
  }

  if (*_rx_head == XOFF_CHAR) {
    _tx_flags |= TX_FLAG_SUSPENDED;
    return;

  } else if (*_rx_head == XON_CHAR) {
    _tx_flags &= ~TX_FLAG_SUSPENDED;

    /* Enable transmit data register empty interrupt */
    UCSRB |= _BV(UDRIE);
    return;
  }

#ifdef SIO_CTRL_C_ABORTS
  if (*_rx_head == 0x03) {
    SET_ABORT;
    return;
  }
#endif

  // It's not a special character, so it's a data character.
  if ((++_rx_chars >= SIO_RX_XOFFLEVEL) && ((_rx_flags & RX_FLAG_SUSPENDED) == 0)) {
    // We've gone above XOFF level, send XOFF and enable transmitter
    _tx_flags |= TX_FLAG_SEND_XOFF;
    _rx_flags |= RX_FLAG_SUSPENDED;

    /* Enable transmit data register empty interrupt */
    UCSRB |= _BV(UDRIE);
  }
      
  // Finally, update head pointer to indicate received character
  if (++_rx_head >= _rx_buf_limit) {
    _rx_head = _rx_buf_start;
  }
  if (_rx_head == _rx_tail) {
    _rx_flags |= RX_FLAG_OVERRUN;
  }
}
      
/* SIGNAL(xxx) runs with interrupts disabled */
/* Interrupt handler for data transmission. */
SIGNAL(SIG_UART_DATA)
{
  // If request to send XON/XOFF is pending, do it instead of next buffer character
  if (_tx_flags & TX_FLAG_SEND_XON) {
      UDR = XON_CHAR; UCSRA = _BV(TXC); // Clear TXC bit...just in case? (probably not necessary)
      _tx_flags &= ~TX_FLAG_SEND_XON;

  } else if (_tx_flags & TX_FLAG_SEND_XOFF) {
      UDR = XOFF_CHAR; UCSRA = _BV(TXC); // Clear TXC bit...just in case? (probably not necessary)
      _tx_flags &= ~TX_FLAG_SEND_XOFF;

  } else if ((_tx_tail != _tx_head) && ((_tx_flags & TX_FLAG_SUSPENDED) == 0)) {
      UDR = *_tx_tail++; UCSRA = _BV(TXC); // Clear TXC bit...just in case? (probably not necessary)
      if (_tx_tail >= _tx_buf_limit) {
          _tx_tail = _tx_buf_start;
      }
  } else {
    /* No more characters to transmit or we've been requested to XOFF. Disable interrupt. */
      UCSRB &= ~_BV(UDRIE);
  }
}

int isinput(void)
{
  return ! (_rx_tail == _rx_head);
}

int input(void)
{
  unsigned char c;

  /* Detect and clear overrun condition */
  if (_rx_flags & (_BV(DOR)|_BV(FE)|RX_FLAG_OVERRUN)) { 
    //outstr("\n\nsio_rx error: <"); disp8(_rx_flags); outstr(">");
    outstr("\n\nsio_rx error:");
    if (_rx_flags & _BV(DOR)) {
      outstr(" OR");
    }
    if (_rx_flags & _BV(FE)) {
      outstr(" FE");
    }
    if (_rx_flags & RX_FLAG_OVERRUN) {
      outstr(" OV");
    }
    EMIT_CR();
    interruptsOFF();
    _rx_flags &= ~(_BV(DOR)|_BV(FE)|RX_FLAG_OVERRUN);
    _rx_tail = _rx_head;
    _rx_chars = 0;
    interruptsON();
  }

  FeedCOP(); // Reset computer-operating-properly watchdog

  if (_rx_tail == _rx_head) return -1;

  c = *_rx_tail++;

  interruptsOFF();
  _rx_chars--;
  if ((_rx_flags & RX_FLAG_SUSPENDED) && (_rx_chars <= SIO_RX_XONLEVEL)) {
    _tx_flags |= TX_FLAG_SEND_XON;
    _rx_flags &= ~RX_FLAG_SUSPENDED;

    /* Enable transmit interrupt */
    UCSRB |= _BV(UDRIE);
  }
  interruptsON();

  if (_rx_tail >= _rx_buf_limit) {
    _rx_tail = _rx_buf_start;
  }

  return (unsigned int)c;
}

#else // PFAVR_INTERRUPT_SIO

int isinput(void)
{
    return bit_is_set(UCSRA, RXC);
}

/*
 * This function checks for available serial input. If none is available, it
 * returns -1, otherwise it returns the character found in the lower byte
 * with the upper byte set to 0.
 */
int input(void)
{
  FeedCOP(); // Reset computer-operating-properly watchdog

  if (bit_is_set(UCSRA, RXC)) {
    unsigned int scdr = (unsigned int)UDR;
#ifdef SIO_CTRL_C_ABORTS
    if (scdr == 0x03) {
      SET_ABORT;
      return -1;
    } else {
      return scdr;
    }
#else
    return scdr;
#endif
  } else {
    return -1;
  }
}

#endif // PFAVR_INTERRUPT_SIO

/*
 * This function waits until a character is received, then returns that
 * character.
 */
unsigned char inchar(void)
{
  int c;

  while (((c=input()) == -1) && ! CHECK_ABORT) /* NULL */ ;

  return (unsigned char)c;
}

/*
 * This function writes a single character to the serial port.
 */
#ifdef PFAVR_INTERRUPT_SIO
void output(unsigned char c)
{
  unsigned char *newHead = _tx_head+1;

  if (newHead >= _tx_buf_limit) {
    newHead = _tx_buf_start;
  }

  // Block if buffer is now full
  *_tx_head = c;
  do {
    FeedCOP(); // Reset the computer-operating-properly watchdog
  } while (newHead == _tx_tail);

  _tx_head = newHead;

  UCSRB |= _BV(UDRIE); /* Enable tx interrupt */
}
#else

void output(unsigned char c)
{
  while (bit_is_clear(UCSRA, UDRE)) {
    FeedCOP(); // Reset the computer-operating-properly watchdog
  }

  UDR = c;
}
#endif

/*
 * This function writes a string to the serial port.
 */
void outstr(const char *s)
{
  while (*s) {
    output(*s++);
  }
}

/*
 * This function initializes the serial port.
 */

void sio_init(void)
{
	UBRRH = (unsigned)UBRR_VALUE / 256U;
	UBRRL = (unsigned)UBRR_VALUE % 256U;
    
    // Set single-speed operation, no multi-processor communication mode
    UCSRA = 0;

	// Set frame format: 8 data bits, 1 stop bit, no parity,
    // asynchronous.
	UCSRC = 6;

    /* Clear any reception by turning USART off/on */
    UCSRB = 0;
    
	// Enable receiver and transmitter
	UCSRB = _BV(RXEN)|_BV(TXEN);
    
#ifdef PFAVR_INTERRUPT_SIO
  _rx_head = _rx_tail = _rx_buf_start;
  _rx_flags = 0;

  _tx_head = _tx_tail = _tx_buf_start;
  _tx_flags = 0;

  _rx_chars = 0; // Number of characters in receive buffer

  UCSRB |= _BV(RXCIE); /* Don't enable TIE until characters are written */

  interruptsON();
#endif
}

/*
 * This function waits for the transmitter to be empty before quitting.
 */

void sio_cleanup(void)
{
    while (bit_is_clear(UCSRA, TXC)) /* NULL */ ; // Wait for transmit complete
}
// vim: expandtab ts=4
