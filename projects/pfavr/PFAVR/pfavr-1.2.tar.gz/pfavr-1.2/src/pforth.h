/* @(#) pforth.h 98/01/26 1.2 */
#ifndef _pforth_h
#define _pforth_h

/***************************************************************
** Include file for pForth, a portable Forth based on 'C'
**
** This file is included in any application that uses pForth as a tool.
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
**
***************************************************************/

/* Main entry point to pForth. */
extern void pfDoForth( void IfInit );

/* Turn off messages. */
extern void  pfSetQuiet( int IfQuiet );

/* Query message status. */
extern int  pfQueryQuiet( void );

/* Send a message using low level I/O of pForth */
extern void  pfMessage( const char *CString );

/* Create a task used to maintain context of execution. */
extern void pfCreateTask( void );

/* Establish this task as the current task. */
extern void  pfSetCurrentTask( void );

/* Delete task created by pfCreateTask */
extern void  pfDeleteTask( void );

/* Build a dictionary with all the basic kernel words. */
extern void pfBuildDictionary( void );

/* Create an empty dictionary. */
extern void pfCreateDictionary( void );

/* Delete dictionary data. */
extern void  pfDeleteDictionary( void );

/* Execute the pForth interpreter. */
extern void   pfRunForth( void );

/* Execute a single execution token in the current task. */
extern void pfExecuteToken( ExecToken XT );
 
/* Execute a Forth word by name. */
extern void   pfExecByName( const char *CString );

#endif  /* _pforth_h */
/* vim: expandtab */
