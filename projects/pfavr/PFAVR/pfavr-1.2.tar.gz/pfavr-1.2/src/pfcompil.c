/* @(#) pfcompil.c 98/01/26 1.5 */
/***************************************************************
** Compiler for PForth based on 'C'
**
** These routines could be left out of an execute only version.
**
** Author: Phil Burk
** Copyright 1994 3DO, Phil Burk, Larry Polansky, Devid Rosenboom
**
** The pForth software code is dedicated to the public domain,
** and any third party may reproduce, distribute and modify
** the pForth software code or any derivative works thereof
** without any compensation or license.  The pForth software
** code is provided on an "as is" basis without any warranty
** of any kind, including, without limitation, the implied
** warranties of merchantability and fitness for a particular
** purpose and their equivalents under the laws of any jurisdiction.
**
****************************************************************
** 941004 PLB Extracted IO calls from pforth_main.c
** 950320 RDG Added underflow checking for FP stack
** 030420 ADS Modified for 68HC11
***************************************************************/

#include "pf_all.h"
#include "pfcompil.h"

#define ABORT_RETURN_CODE   (10)

/***************************************************************/
/************** GLOBAL DATA ************************************/
/***************************************************************/

static ExecToken gNumberQ_XT;         /* XT of NUMBER? */
static ExecToken gQuitP_XT;           /* XT of (QUIT) */

/***************************************************************/
/************** Static Prototypes ******************************/
/***************************************************************/

static void ffStringColon( const ForthStringPtr FName );
//static int CheckRedefinition( const ForthStringPtr FName );
static void ffUnSmudge( void );
static void FindAndCompile( const char *theWord );
static int ffCheckDictRoom( const ForthStringPtr FName );
static int ffCheckExecRoom( void );

#if 0
int NotCompiled( const char *FunctionName )
{
	MSG("Function ");
	MSG(FunctionName);
	MSG(" not compiled in this version of PForth.\n");
	return -1;
}
#endif

/***************************************************************
** Create an entry in the Dictionary for the given ExecutionToken.
** FName is name in Forth format.
*/
void CreateDicEntry( ExecToken XT, const ForthStringPtr FName, unsigned Flags )
{
  dictEntry *curr = (dictEntry *)td_DictPtr;

  if ((! ffCheckDictRoom(FName)) || (! ffCheckExecRoom())) {
    ffAbort();
    return;
  }

  td_DictPtr += (*FName) + sizeof(dictEntry);

  curr->prevEntry = gVarContext;
  curr->XT = XT;

  pfCopyMemory(&(curr->len), FName, (*FName)+1);

  gVarContext = &(curr->len);
  *gVarContext |= (unsigned char) Flags;
}

/***************************************************************
** Find XTs needed by compiler.
*/
int FindSpecialXTs( void )
{
	
	if( ffFindC( "(QUIT)", &gQuitP_XT ) == 0) goto nofind;
	if( ffFindC( "NUMBER?", &gNumberQ_XT ) == 0) goto nofind;

DBUG(("gNumberQ_XT = 0x%x\n", gNumberQ_XT ));
	return 0;
	
nofind:
	ERR("FindSpecialXTs failed!\n");
	return -1;
}

/*
** ( xt -- nfa 1 , x 0 , find NFA in dictionary from XT )
** 1 for IMMEDIATE values
*/
#ifdef PF_SUPPORT_TRACE
cell ffTokenToName( ExecToken XT, const ForthString **NFAPtr )
{
  dictEntry *curr = (dictEntry *)td_Dict;

  while (curr < (dictEntry *)td_DictPtr) {
    if (curr->XT == XT) {
      *NFAPtr = (const ForthString *)&(curr->len);
      return 1;
    }

    curr = NEXT_DICT_ENTRY(curr);
  }

  return 0;
}
#endif

/*
** ( $name -- $addr 0 | nfa -1 | nfa 1 , find NFA in dictionary )
** 1 for IMMEDIATE values
*
*/
cell ffFindNFA( const ForthString *WordName, const ForthString **NFAPtr )
{
	const ForthString *WordChar;
	uint8 WordLen;
	const char *NameField, *NameChar;
	int8 NameLen;
	int Searching = TRUE;
	cell Result = 0;
	
  //outstr("ffFindNFA: WordName: "); TypeName(WordName); EMIT_CR();
	WordLen = (uint8) ((unsigned char)*WordName & MASK_NAME_SIZE);
	WordChar = WordName+1;
	
	NameField = gVarContext;
	do
	{
    //outstr("Checking: "); TypeName(NameField); EMIT_CR();

		NameLen = (uint8) ((unsigned char)(*NameField) & MASK_NAME_SIZE);
		NameChar = NameField+1;
    
		if(	((*NameField & FLAG_SMUDGE) == 0) && (NameLen == WordLen) &&
			ffCompareTextCaseN( NameChar, WordChar, WordLen ) ) /* FIXME - slow */ {
			*NFAPtr = NameField ;
			Result = ((*NameField) & FLAG_IMMEDIATE) ? 1 : -1;
			Searching = FALSE;
		} else {
      NameField = NAME_TO_PREVIOUS(NameField);
      if (NameField == 0) {
				*NFAPtr = WordName;
				Searching = FALSE;
			}
		}
	} while ( Searching);
	return Result;
}

/***************************************************************
** ( $name -- $name 0 | xt -1 | xt 1 )
** 1 for IMMEDIATE values
*/

cell ffFind( const ForthString *WordName, ExecToken *pXT )
{
	const ForthString *NFA;
	int Result;
	
	Result = ffFindNFA( WordName, &NFA );
	if( Result )
	{
		*pXT = NAME_TO_TOKEN( NFA );
	}
	else
	{
		*pXT = (ExecToken) WordName;
	}

	return Result;
}

/****************************************************************
** Find name when passed 'C' string.
*/
cell ffFindC( const char *WordName, ExecToken *pXT )
{
DBUG(("ffFindC: %s\n", WordName ));
	CStringToForth( gScratch, WordName );
	return ffFind( gScratch, pXT );
}

/***********************************************************/
/********* Compiling New Words *****************************/
/***********************************************************/

/*************************************************************
**  Check for dictionary overflow. 
*/
static int ffCheckDictRoom( const ForthStringPtr FName )
{
  int usedBytes = td_DictPtr - td_Dict + (*FName & MASK_NAME_SIZE) + sizeof(dictEntry);
  if (usedBytes > DICTIONARY_SIZE) {
		pfReportError(PF_ERR_HEADER_ROOM);
		return 0;
	}

  return 1;
}

static int ffCheckExecRoom(void)
{
  int usedCells = td_ExecPtr - td_Exec + EXEC_SAFETY_MARGIN;
  if (usedCells > EXEC_AREA_SIZE) {
		pfReportError(PF_ERR_CODE_ROOM);
		return 0;
	}

	return 1;
}

/*************************************************************
**  Create a dictionary entry given a string name. 
*/
void ffCreateSecondaryHeader( const ForthStringPtr FName)
{
	//ADS: Who cares?
  //CheckRedefinition( FName );

/* Align CODE_HERE */
	//ADS: Unnecessary: CODE_HERE = (cell *)( (((uint32)CODE_HERE) + 3) & ~3);
	CreateDicEntry( (ExecToken) CODE_HERE, FName, FLAG_SMUDGE );
}

/*************************************************************
** Begin compiling a secondary word.
*/
static void ffStringColon( const ForthStringPtr FName)
{
	ffCreateSecondaryHeader( FName );
	gVarState = 1;
}

/*************************************************************
** Read the next ExecToken from the Source and create a word.
*/
void ffColon( void )
{
	char *FName;
	
	gDepthAtColon = DATA_STACK_DEPTH;
	
	FName = ffWord( BLANK );
	if( *FName > 0 )
	{
		ffStringColon( FName );
	}
}

void ffStringCreate( char *FName)
{
	ffCreateSecondaryHeader( FName );
	
	CODE_COMMA( ID_CREATE_P );
	CODE_COMMA( ID_EXIT );    /* Why is this ID_EXIT here given that ffFinishSecondary puts one in too? */
                            /* Well, this ID_EXIT is necessary for words like CONSTANT. But couldn't the
                             * implementation of VARIABLE and CONSTANT be separated to remove the unnecessary
                             * word from VARIABLE? This would require a different ID_CREATE_P for the two
                             * words. */
	ffFinishSecondary();
}

/* Read the next ExecToken from the Source and create a word. */
void ffCreate( void )
{
	char *FName;
	
	FName = ffWord( BLANK );
	if( *FName > 0 )
	{
		ffStringCreate( FName );
	}
}

void ffStringDefer( const ForthStringPtr FName, ExecToken DefaultXT )
{
	
	ffCreateSecondaryHeader( FName );
	
	CODE_COMMA( ID_DEFER_P );
	CODE_COMMA( DefaultXT );
	
	ffFinishSecondary();
}

/* Read the next token from the Source and create a word. */
void ffDefer( void )
{
	char *FName;
	
	FName = ffWord( BLANK );
	if( *FName > 0 )
	{
		ffStringDefer( FName, ID_QUIT_P );
	}
}

/* Unsmudge the word to make it visible. */
void ffUnSmudge( void )
{
	*gVarContext &= ~FLAG_SMUDGE;
}

/* Implement ; */
void ffSemiColon( void )
{
	gVarState = 0;
	
	if( (gDepthAtColon != DATA_STACK_DEPTH) &&
	    (gDepthAtColon != DEPTH_AT_COLON_INVALID) ) /* Ignore if no ':' */ {
    if (td_Flags & CFTD_NO_SEMICOLON_CHECK) {
      // Freebie
      td_Flags &= ~CFTD_NO_SEMICOLON_CHECK;
      ffFinishSecondary();
    } else {
      pfReportError(PF_ERR_COLON_STACK);
      ffAbort();
    }
	} else {
		ffFinishSecondary();
	}
	gDepthAtColon = DEPTH_AT_COLON_INVALID;
}

/* Finish the definition of a Forth word. */
void ffFinishSecondary( void )
{
	CODE_COMMA( ID_EXIT );
	ffUnSmudge();
}

/**************************************************************/
/* Used to pull a number from the dictionary to the stack */
void ff2Literal( cell dHi, cell dLo )
{
	CODE_COMMA( ID_2LITERAL_P );
	CODE_COMMA( dHi );
	CODE_COMMA( dLo );
}
#if 0
void ffALiteral( cell Num )
{
	CODE_COMMA( ID_ALITERAL_P );
	CODE_COMMA( Num );
}
#endif
void ffLiteral( cell Num )
{
	CODE_COMMA( ID_LITERAL_P );
	CODE_COMMA( Num );
}

/**************************************************************/
void FindAndCompile( const char *theWord )
{
	int Flag;
	ExecToken XT;
	cell Num;
	
	Flag = ffFind( theWord, &XT);
DBUG(("FindAndCompile: theWord = %8s, XT = 0x%x, Flag = %d\n", theWord, XT, Flag ));

/* Is it a normal word ? */
	if( Flag == -1 )
	{
		if( gVarState )  /* compiling? */
		{
			CODE_COMMA( XT );
		}
		else
		{
			pfExecuteToken( XT );
		}
	}
	else if ( Flag == 1 ) /* or is it IMMEDIATE ? */
	{
DBUG(("FindAndCompile: IMMEDIATE, theWord = 0x%x\n", theWord ));
		pfExecuteToken( XT );
	}
	else /* try to interpret it as a number. */
	{
/* Call deferred NUMBER? */
		int NumResult;
		
DBUG(("FindAndCompile: not found, try number?\n" ));
		PUSH_DATA_STACK( theWord );   /* Push text of number */
DBUG(("gNumberQ_XT = 0x%x\n", gNumberQ_XT));    
		pfExecuteToken( gNumberQ_XT );
DBUG(("FindAndCompile: after number?\n" ));
		NumResult = POP_DATA_STACK;  /* Success? */
		switch( NumResult )
		{
		case NUM_TYPE_SINGLE:
			if( gVarState )  /* compiling? */
			{
				Num = POP_DATA_STACK;
				ffLiteral( Num );
			}
			break;
			
#if 0 // Never generated
		case NUM_TYPE_DOUBLE:
			if( gVarState )  /* compiling? */
			{
				Num = POP_DATA_STACK;  /* get hi portion */
				ff2Literal( Num, POP_DATA_STACK );
			}
			break;
#endif

		case NUM_TYPE_BAD:
		default:
			ioType( theWord+1, *theWord );
			MSG( ": unknown word\n" );
			ffAbort( );
			break;
		
		}
	}
}

/**************************************************************
** Forth outer interpreter.  Parses words from Source.
** Executes them or compiles them based on STATE.
*/
int ffInterpret( void )
{
	char *theWord;
	
/* Is there any text left in Source ? */
	while( (td_IN < (td_SourceNum-1) ) && !CHECK_ABORT) {
DBUGX(("ffInterpret: IN=%d, SourceNum=%d\n", td_IN, td_SourceNum ) );

		theWord = ffWord( BLANK );

DBUGX(("ffInterpret: theWord = 0x%x, Len = %d\n", theWord, *theWord ));
		if( *theWord > 0 )
		{
#if 0
      int Flag;

			Flag = 0;
			if( gLocalCompiler_XT )
			{
				PUSH_DATA_STACK( theWord );   /* Push word. */
				pfExecuteToken( gLocalCompiler_XT );
				Flag = POP_DATA_STACK;  /* Compiled local? */
			}
			if( Flag == 0 )
#endif
			{
        //dumpDictionary();
				FindAndCompile( theWord );
			}
		}
	}
	DBUG(("ffInterpret: CHECK_ABORT = %d\n", CHECK_ABORT));
	return( CHECK_ABORT ? -1 : 0 );
}
		
/**************************************************************/
void ffOK( void )
{
/* Check for stack underflow.   %Q what about overflows? */
	if( (td_StackBase - td_StackPtr) < 0 )
	{
		MSG("Stack underflow\n");
		ResetForthTask( );
	}

	else 
	{
		if( !gVarState )  /* executing? */
		{
			if( ! (gVarEcho & ECHO_NO_OK) )
			{
				MSG( "OK\n" );
				if(gVarTraceStack) ffDotS();
			}
			else
			{
				/*EMIT_CR()*/;
			}
		}
	}
}

/***************************************************************
** Interpret input in a loop.
***************************************************************/
static int checkAbort(void)
{
		if (CHECK_ABORT) {
			CLEAR_ABORT;
      ResetForthTask();
      MSG("ABORT\n");
      return 1;
		} else {
      return 0;
    }
}

void ffQuit( void )
{
	td_Flags |= CFTD_FLAG_GO;

	while( td_Flags & CFTD_FLAG_GO )
	{
		if(!ffRefill())
		{
/*			gCurrentTask->td_Flags &= ~CFTD_FLAG_GO; */
			return;
		}
    // Abort if user pressed Ctrl-C while typing a line
    if (checkAbort()) continue;

		ffInterpret();
		DBUG(("gCurrentTask->td_Flags = 0x%x\n",  td_Flags));	
		if(! checkAbort()) {
			ffOK( );
		}
	}
}

void ffAbort( void )
{
	ResetForthTask();
	SET_ABORT;
	if( gVarReturnCode == 0 ) gVarReturnCode = ABORT_RETURN_CODE;
}

/**************************************************************/
/* ( -- , fill Source from current stream ) */
/* Return FFALSE if no characters. */
cell ffRefill( void )
{
	cell Num, Result = FTRUE;
	
/* get line from current stream */
	Num = ioAccept( td_SourcePtr, TIB_SIZE);
	if( Num < 0 )
	{
		Result = FFALSE;
		Num = 0;
	}
	
/* reset >IN for parser */
	td_IN = 0;
	td_SourceNum = Num;
	td_LineNumber++;  /* Bump for include. */
	
/* echo input if requested */
	if( (gVarEcho & ECHO_LINE) && ( Num > 0))
	{
		MSG( td_SourcePtr );
	}
	
	return Result;
}
// vim: expandtab ts=4
