#!/usr/bin/env python
"""This script strips a Forth file of all comments, blank lines,
and unnecessary whitespace. It can also write the resulting output
as a set of C strings for inclusion in a program.

This script assumes that the following constructs have their usual
meanings:

   \ single-line comments
   ( comments that end with a right-paren )
   ." strings that end with a quote"
   ABORT" string that ends with a quote"
   S" string that ends with a quote"
   C" string that ends with a quote"
   .( string that ends with a right-paren )
"""

import sys
import os
import string
import getopt

OutFileName = None
WriteCStrings = 0
InFileName = None

class ForthStripper:
  def __init__(self, outFid):
    self.outFid = outFid
    self.writeCStrings = 0

    # Character to match in a (..) or ." ... " sequence, etc.
    self.matchingChar = None

    # Set to 1 to discard stuff while waiting for a match. This allows
    # the distinction between ( comment ) and .( printing stuff )
    self.discardToMatch = 0

    # Hack to prevent entering matching mode when defining these special
    # words.
    self.prevword = None

    # List of words built up
    self.S=[]

  def feedline(self, line):
    # Parse the way Forth would, character by character
    cix = 0
    lineStarted = 0

    # Chop trailing newline
    if line and line[-1] in ('\r', '\n'):
      line = line[:-1]

    while cix < len(line):
      if self.matchingChar:
        if not self.discardToMatch:
          self.startLine(lineStarted)
          lineStarted=1
          self.write(line[cix])
          
        if line[cix]==self.matchingChar:
          self.matchingChar = None

        cix += 1
        continue

      # Skip blanks
      if line[cix] in (' ', '\t'): 
        cix += 1
        continue

      startix = cix
      while cix < len(line) and line[cix] not in (' ', '\t', '\r', '\n'):
        cix += 1

      word = line[startix:cix]
      if not word:
        # This line's done
        break

      # Check out special words
      if word=='\\' and not self.isPostpone(self.prevword):
        # Done with this line
        break

      elif word=='(' and not self.isPostpone(self.prevword):
        # Comment ending with ')'
        self.matchingChar = ')'
        self.discardToMatch = 1
        word = None

      elif word=='."' and not self.isPostpone(self.prevword):
        # String ending with "
        self.matchingChar = '"'
        self.discardToMatch = 0

      elif word.upper()=='ABORT"' and not self.isPostpone(self.prevword):
        # String ending with "
        self.matchingChar = '"'
        self.discardToMatch = 0
        
      elif word.upper()=='S"' and not self.isPostpone(self.prevword):
        # String ending with "
        self.matchingChar = '"'
        self.discardToMatch = 0
        
      elif word=='.(' and not self.isPostpone(self.prevword):
        # String ending with ')'
        self.matchingChar = ')'
        self.discardToMatch = 0

      elif word=='C"' and not self.isPostpone(self.prevword):
        # String ending with "
        self.matchingChar = '"'
        self.discardToMatch = 0
        
      self.prevword = word

      # If we just entered matching character mode, flush
      # the current list of words and print out the one
      # we just got
      if self.matchingChar:
        if self.S:
          self.startLine(lineStarted)
          lineStarted=1

          self.write(string.join(self.S))
          self.S = []

        if word:
          if lineStarted:
            self.write(' '+word+' ')
          else:
            self.startLine(lineStarted)
            lineStarted=1
            self.write(word+' ')

          word = None
        elif lineStarted:
          self.outFid.write(' ')

      elif word:
        self.S.append(word)
        
      cix += 1
    # end of while cix < len(line)

    if self.S:
      self.startLine(lineStarted)
      lineStarted=1
      self.write(string.join(self.S))
      self.S = []

    if lineStarted:
      if self.writeCStrings:
        self.outFid.write('\\r"\n')
      else:
        self.outFid.write('\n')

  def write(self, s):
    for c in s:
      if self.writeCStrings:
        if c=='"':
          self.outFid.write(r'\"')
        elif c=='\\':
          self.outFid.write('\\\\')
        else:
          self.outFid.write(c)
      else:
        self.outFid.write(c)

  def startLine(self, lineStarted):
    if not lineStarted and self.writeCStrings:
      self.outFid.write('"')

  def isPostpone(self, word):
    return word and (word.lower() in (':', 'compile', '[compile]', 'postpone'))

def forthStrip(inFid, outFid):
  FS = ForthStripper(outFid)
  FS.writeCStrings = WriteCStrings
  for line in inFid:
    FS.feedline(line)

def usage():
  print """  
Usage: fthstrip.py [Options] [file.fth]

Options:

     -h, --help             -- This help summary
     -o file, --output=file -- Set output file name (default: stdout)
     -c, --C                -- Write C strings (for generating static dictionaries)
"""
  sys.exit(1)

if __name__=="__main__":
  try:
    optlist, args = getopt.getopt(sys.argv[1:], 'ho:c', ['help', 'output=', 'C'])
  except getopt.GetoptError:
    usage()

  for opt,arg in optlist:
    if opt in ("-h", "--help"):
      usage()
    elif opt in ("-o", "--output"):
      OutFileName = arg
    elif opt in ("-c", "--C"):
      WriteCStrings = 1

  if len(args) > 1: 
    usage()
  elif len(args)==1:
    InFileName = args[0]

  fid = sys.stdin
  if InFileName:
    try:
      fid = file(InFileName, 'rt')
    except Exception, detail:
      print 'Unable to open input file "%s":\n  %s\n' % (InFileName, str(detail))
      sys.exit(1)

  outfid = sys.stdout
  if OutFileName:
    try:
      outfid = file(OutFileName, 'wt')
    except Exception, detail:
      print 'Unable to open output file "%s":\n  %s\n' % (OutFileName, str(detail))
      sys.exit(1)

  forthStrip(fid, outfid)

  fid.close()
  outfid.close()
