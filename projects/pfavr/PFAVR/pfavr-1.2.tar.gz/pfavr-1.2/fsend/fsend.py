#!/usr/bin/env python
"""This script sends a Forth file to a device (or fifo). The XON/XOFF
protocol is used.
"""

import os
import sys
import getopt
import time
import tty
import termios
import StringIO

import fthstrip

#Device = '/dev/modem'
#DeviceRx = '../sio2host'         # Can also use FIFO's, but then must disable XON/XOFF stuff
#DeviceTx = '../sio2fth'
DeviceRx = '/dev/ttyS1'
DeviceTx = '/dev/ttyS1'

XON_CHAR = '\x11'
XOFF_CHAR = '\x13'

EchoCharacters = 0
LinePacing = 0
StripForth = 1
SoftXONXOFF = 1

def usage():
  print """
Usage: fsend [Options] forth_file [forth_file ...]

Options:
 -h,     --help            -- This help summary
 -r DEV, --rx-device=DEV   -- Device (filename) to read from (default: %s)
 -t DEV, --tx-device=DEV   -- Device (filename) to write to (default: %s)
 -l sec, --line-pacing=sec -- Line pacing (seconds) (default: 0.0)
 -e,     --echo-chars      -- Echo all characters sent
 -S,     --no-strip        -- Do not strip files before transmission
 -x,     --no-soft-xonxoff -- Do not implement XON/XOFF flow control in software
""" % (DeviceRx, DeviceTx)

  sys.exit(1)

def openDevice():
  global SoftXONXOFF

  try:
    fidrx = os.open(DeviceRx, os.O_RDONLY|os.O_NDELAY)
  except Exception,detail:
    print "Unable to open device '%s':\n  %s" % (DeviceRx,str(detail))
    sys.exit(2)
  try:
    fidtx = os.open(DeviceTx, os.O_WRONLY)
  except Exception,detail:
    print "Unable to open device '%s':\n  %s" % (DeviceTx,str(detail))
    sys.exit(2)

  # How can we tell if the following fileno's are tty devices?
  try:
    tty.setraw(fidtx)
    tty.setraw(fidrx)
    attr = termios.tcgetattr(fidrx)
    attr[0] |= termios.IXON|termios.IXOFF  # iflag
    termios.tcsetattr(fidrx, termios.TCSANOW, attr)
    attr = termios.tcgetattr(fidtx)
    attr[0] |= termios.IXON|termios.IXOFF  # iflag
    termios.tcsetattr(fidtx, termios.TCSANOW, attr)

    # If this worked, we don't need soft XON/XOFF
    SoftXONXOFF = 0
  except:
    print 'Hardware XON/XOFF FAILED!'
    if SoftXONXOFF:
      print 'Using soft XON/XOFF...'

  return (fidrx,fidtx)

def closeDevice(dev):
  #os.write(dev[1], '\x04')
  os.close(dev[1])
  os.close(dev[0])

def printc(s):          
  if ord(s[0]) >= 0x20 or s[0] in ('\x0A', '\x0D'):  # Is it printable?
    sys.stdout.write(s[0])
  else:
    sys.stdout.write('>>%02X<<' % ord(s[0]))         # If not, dump as hex character
  sys.stdout.flush()

if __name__=="__main__":
  try:
    optlist, args = getopt.getopt(sys.argv[1:], 'hr:t:l:eSx', ['help', 'rx-device=', 'tx-device=', 'line-pacing=', 'echo-chars',
                                                              'no-strip', 'no-soft-xonxoff'])
  except getopt.GetoptError:
    usage()

  for opt,arg in optlist:
    if opt in ("-h", "--help"):
      usage()
    elif opt in ("-r", "--rx-device"):
      DeviceRx = arg
    elif opt in ("-t", "--tx-device"):
      DeviceTx = arg
    elif opt in ("-l", "--line-pacing"):
      LinePacing = float(arg)
    elif opt in ("-e", "--echo-chars"):
      EchoCharacters = 1
    elif opt in ("-S", "--no-strip"):
      StripForth = 0
    elif opt in ("-x", "--no-soft-xonxoff"):
      SoftXONXOFF = 0

  if len(args) < 1:
    usage()

  print "Opening connection ..."
  dev = openDevice()

  print "Press ENTER to begin ..."
  s = raw_input()

  for fname in args:
    print "Opening", fname, "..."
    try:
      fid = file(fname, 'rt')
    except Exception, detail:
      print "Unable to open file '%s':\n  %s" % (fname,str(detail))
      sys.exit(3)

    ccount = 0
    xoffcount = 0

    if StripForth:
      print 'Stripping...'

      sbuf = StringIO.StringIO()
      FS = fthstrip.ForthStripper(sbuf)
      for line in fid:
        FS.feedline(line)

      fid.close()
      fid = sbuf
      fid.seek(0)

    print 'Sending...'
    for line in fid:
      for c in line:
        # Display all characters ready to be displayed
        while 1:
          try:
            s = os.read(dev[0],1)
          except Exception, detail:
            # File not ready yet
            #print "Can't read: %s" % str(detail)
            #time.sleep(1)
            #continue
            break

          if s and SoftXONXOFF and s[0]==XOFF_CHAR:
            xoffcount += 1
            while 1:
              try:
                s = os.read(dev[0], 1)
              except:
                s = ''
                time.sleep(0.01)  # Should use poll()
              if s:
                if s[0]==XON_CHAR:
                  break
                else:
                  printc(s)
            # end while not XON received
          elif s:
            printc(s)
          else:
            break
        # end while characters to be received

        if EchoCharacters:
          sys.stdout.write(c)

        os.write(dev[1], c)
        ccount += 1
      # end for each character in line
      if LinePacing:
        time.sleep(LinePacing)

    fid.close()
    if SoftXONXOFF:
      print 'Received', xoffcount, 'XOFF requests'

  print 'Done...polling'
  while 1:
    try:
      s = os.read(dev[0], 1)
      printc(s)
    except:
      time.sleep(0.01) # Should use poll()
      pass

  closeDevice(dev)
