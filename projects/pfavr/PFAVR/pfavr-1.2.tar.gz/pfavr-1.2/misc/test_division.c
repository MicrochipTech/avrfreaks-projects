/*
 * This file is intended to probe whether the C compiler implements
 * symmetric or floored division.
 *
 * Before running the program, set a breakpoint at either fail() or
 * pass(). Which breakpoint is hit determines whether or not symmetric
 * division is implemented (pass==symmetric division).
 */

void fail(void) { while(1); }
void pass(void) { while(1); }

#define assert(X) { if (! (X)) fail(); }

void main(void)
{
  /*
   * This demonstrates that GCC for the AVR implements SYMMETRIC DIVISION
   * (see Table 3.4 in ANS Forth spec (dpans3.htm))
   */

  /* 10/7 --> Quotient=1, Remainder=3 */
  assert((10/7)==1);
  assert((10%7)==3);

  /* -10/7 --> Quotient=-1, Remainder=-3 */
  assert((-10/7)==-1);
  assert((-10%7)==-3);

  /* 10/-7 --> Quotient=-1, Remainder=3 */
  assert((10/-7)==-1);
  assert((10%-7)==3);

  /* -10/-7 --> Quotient=1, Remainder=-3 */
  assert((-10/-7)==1);
  assert((-10%-7)==-3);

  pass();
}
