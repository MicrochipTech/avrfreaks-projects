/**
 * @file
 * 
 * Target monitor test program for AVR.
 *
 * Copyright 2003 J�rgen Birkler mailto:birkler@yahoo.com) 
 *
 * @author J�rgen Birkler (birkler@yahoo.com)
 *
 */


#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include "monitor.h"


#define RED_LED_BIT  PD3

#define LEDS_INIT()          {sbi(DDRD,RED_LED_BIT);}
#define RED_LED_ON()         cbi(PORTD,RED_LED_BIT)
#define RED_LED_OFF()        sbi(PORTD,RED_LED_BIT)
#define RED_LED_CHANGE()     PORTD^=_BV(RED_LED_BIT)


///@todo Use printf and stdio and assign Monitor_SendByte to a file (stdout)
#define DEBUG_PRINT_INFO_(x) (void)(0)

///@todo Make interrupt example with hardware breakpoint in Timer1

static void Function2(int i)
{
  volatile uint16_t b = i;
  {  //critical section begin

    uint8_t saved_sreg = SREG;
    cli();
    b++;
    SREG=saved_sreg;
  }//critical section end
  
}


static void Function1(int i)
{
  volatile int a = i;
  a++;
}

static char to_hex(uint8_t i)
{
  i &= 0xF;
  if (i < 10)
    return i+'0';
  else 
    return i-10+'A';
}


/**
 * Da main program
 *
 */
int main(void)
{
  uint16_t my_variable = 10;

  //Initialize
  //////////////////////
  LEDS_INIT();

  RED_LED_ON();

  //Startup
  ///////////////////////////////////////////

  //We're alive!
  DEBUG_PRINT_INFO_("\r\nAVR up and running...");
  DEBUG_PRINT_INFO_("\r\nRemote control receiver (C) 2003 J�rgen Birkler birkler@yahoo.com\r\n");
  Monitor_SendByte('x');
 
  //Enable interrupts
  ///////////////////////////  
  sei();

  //Call trap to switch to monitor
  TRAP();

  //HW_BREAKPOINT(1);
  HW_BREAKPOINT(0);

  //Main program loop begin
  /////////////////////////////
  for(;;) 
  {
    volatile uint16_t a = 0x12;

    if (my_variable-- == 0) 
    {
      //uint8_t another_variable = a;
      my_variable =20000;
      //Monitor_SendByte(to_hex(avr_monitor_data.hw_bp_flags>>4));
      //Monitor_SendByte(to_hex(avr_monitor_data.hw_bp_flags));
      HW_BREAKPOINT(1);
      RED_LED_CHANGE();
    }
    
    Function1(a);
    
    Function2(2);
  }
}


void dbg_sendchar(char data, void* not_used)
{
  not_used = not_used;
  //Monitor_SendByte(data);
  //UART_WRITE_BYTE(data);
}








