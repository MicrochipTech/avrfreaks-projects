/**  
 * @file
 *
 * AVR Monitor for in System Debugging using MISO, MOSI and SCK
 * with host program that can connect to GDB using GDB serial protocol.
 *
 * Copyright (C) 1999 by Denis Chertykov (denisc@overta.ru)
 * Copyright (C) 2002 by J�rgen Birkler (birkler@yahoo.com)
 *
 * You can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, or (at your option) any later version.
 *
 * This program works with the connection scheme used in Atmels "STK200
 * Starter Kit". The connection allows to program the AVR with Uros
 * Platise `uisp' in `-dstk200' mode.
 *
 * 
 * @author Denis Chertykov (denisc@overta.ru)
 * @author J�rgen Birkler (birkler@yahoo.com)
 *
 * @par History
 * 1999 Denis Chertykov
 * - First version. Denis magic fingers write the trap interrupt loop
 * .
 * 2002 June J�rgen Birkler
 * - Updated code to work with GCC 3.2.
 * - Renamed some of the communications functions to better reflect their origin
 *   'Monitor_'.
 * - Added AT90S8535 as target.
 * .
 * 2003 April J�rgen Birkler
 * - Using GCC 3.3
 * - Updates to protocol. More comments to trap loop
 * - Trap loop now easier to configure to different hardware
 * .
 *
 */

#ifndef _AVR_MONITOR_H__
#define _AVR_MONITOR_H__



//extern void gdb_break(void);


///Send a byte to the host
extern void Monitor_SendByte(unsigned char);


/**
 * Trap and start the monitor
 * @hideinitializer
 */
#define TRAP() asm volatile ("rcall gdb_break")


/**
 * Creates a hardware breakpoint
 * @param num Must be unique number from 0..7
 * @hideinitializer
 */
#define HW_BREAKPOINT(num) {\
  asm volatile (".global avr_monitor_hwbp_"#num"\n"); \
  asm volatile("avr_monitor_hwbp_"#num":"); \
  if (avr_monitor_data.hw_bp_flags & (0x1<<(num))) TRAP(); \
}




#if !defined(AVR_MONITOR_HOST)
#include <inttypes.h>
#ifndef __AVR__
#error "Doesn't seem to be compiling for AVR."
#endif
#endif //defined(AVR_MONITOR_TARGET)

typedef uint16_t avr_ptr_t;
typedef uint16_t avr_sp_t;
typedef uint16_t avr_breakpoint_t;
typedef uint8_t avr_hw_bp_flag_t;


/** 
 * @defgroup avr_monitor_protocol Host-Target Protocol  
 *
 * The protocol uses the MISO, MOSI and SCK lines of the AVR. The PC is master of
 * clock SCK and listens for rx bits from target. Each character received is
 * #TARGET2HOST_BITS. 
 * Higher level protocol is sync by either #TARGET_TX_SYNC or #TARGET_RX_SYNC.
 * #TARGET_TX_SYNC means that next #TARGET2HOST_BITS clocks is a byte from the target, 
 * character received is masked to 0x00FF.
 * #TARGET_TX_SYNC means that target will read the next #TARGET2HOST_BITS clocks
 * as a byte to the target.
 *
 * When the target is in running the monitor it sends a byte, 
 * #TARGET2HOST_SIGTRAP. When this is read from the target by the host
 * switches to monitor mode and is ready to receive commands from the
 * debugger. Commands are received in a #avr_monitor_packet_t structure.
 *
 * Command packet host<->target
 *
 * - \b 'r' Read SRAM or IO area memory
 *     - cmd = 'r' addr = [address to read] length = [bytes to read]
 *     - cmd = 'r' addr = [address read] length = [bytes read] buffer = [data]
 *     .
 * - \b 'w' Write SRAM or IO area  
 *     - cmd = 'w' addr = [address to write] data = [byte to write]
 *     - cmd = 'w' addr = [address written] length = 1 buffer = [byte written]
 *     .
 * - \b 'p' Read program memory
 *     - cmd = 'p' addr = [address to read] length = [bytes to read]
 *     - cmd = 'p' addr = [address read] length = [bytes read] buffer = [data]
 *     .
 * - \b 'q' Quit monitor
 *     - cmd = 'q' data = [#avr_monitor_run_mode_t]
 *     .  
 * .
 */
/**
 * @addtogroup avr_monitor_protocol 
 * \@{
 */

//Bits when target reads from host
#define HOST2TARGET_BITS 8

//Bits when target sends to host
#define TARGET2HOST_BITS 13


///Monitor run mode
typedef enum {
	avr_monitor_continue = 0,             ///<Go. Do not break on software breakpoints
	avr_monitor_step_asm_instruction = 1, ///<Step next asm instruction
	avr_monitor_step_to_next_bp = 2       ///<Step asm instructions until breakpoint
} avr_monitor_run_mode_t;

///Host and target packet
typedef struct avr_monitor_packet_s
{
  /** command letter r p w q*/
  uint8_t cmd;		
  /** operation address */
  union
  {
    uint16_t addr;	
    struct {uint8_t lo;uint8_t hi;} raw;
  } addr;

  union {
    uint8_t continue_cmd; /**< #avr_monitor_run_mode_t */
    uint8_t data;		  /**< data for write */    
    uint8_t length;		/**< length to read */
    uint8_t raw;
  } rw;

  #ifdef AVR_MONITOR_HOST
  uint8_t buffer[256];
  #endif //#ifdef AVR_MONITOR_HOST
} __attribute__ ((packed)) avr_monitor_packet_t;
 

/* We use different sync characters for Tx and Rx to be able to catch
   any situation where both host and target tries to do the same
   operation at the same time. */

///Sent by target to indicate that a character is about to be transmittet
#define TARGET_TX_SYNC 0x0FFB  /* 01111 11111011 */

///Sent by target to indicate that it will read character
#define TARGET_RX_SYNC 0x0FF9  /* 01111 11111001 */

///Character sent by target to indicate that it is switching to monitor mode
#define TARGET2HOST_SIGTRAP 0xfc


/**\@}*/


/** 
 * @defgroup avr_monitor_data Monitor Data
 * Data structures used by the monitor to handle registers and
 * do communication.
 *
 * \@{
 */


/**
 * avr-gcc mask for FALSH, SRAM/IO and EEPROM area
 * @hideinitializer
 */
//@{
#define AVR_GCC_IS_FLASH(addr)  ((addr) < 0x00800000) 
#define AVR_GCC_MASK_FLASH 0xFFFFF
#define AVR_GCC_IS_SRAMIO(addr) (0x00800000 <= (addr) && (addr) < 0x00810000)
#define AVR_GCC_MASK_SRAM 0xFFFF
#define AVR_GCC_IS_EEPROM(addr) (0x00810000 <= (addr) && (addr) < 0x00820000)
#define AVR_GCC_MASK_EEPROM 0xFFFF
//@}


 


/**
 * Registers in the avr. 
 *
 * It is used by:
 * Target to store the registers when executing the monitor.
 * GDB internally, it much match in AVR-GDB (avr-tdep.c) avr_register_raw_size(int regnum)
 * avr_register_name (int regnum)
 *
 * @note Packed struct was not working for i386 gcc so host does a manual translation
 */
typedef struct avr_registers_s {
  uint8_t reg[32];  ///<0x00: Registers r0-r31
  uint8_t sreg;     ///<0x20: Status register
  avr_sp_t sp;      ///<0x21: Stack Pointer
#if defined(AVR_MONITOR_TARGET)
  uint16_t pc;      ///<0x23:Program counter. (Word addresses), bytes address is PC*2
#elif defined(AVR_MONITOR_HOST)
  uint32_t pc;      ///<gdb uses byte addresses for PC, 32 bits
#endif
  ///0x25                    
} avr_registers_t;



///Number of software breakpoints
///@hideinitializer
#define AVR_MONITOR_NUM_BREAKPOINTS 4
//Size of the register structure
#define AVR_MONITOR_REGS_SIZE (0x25)
//Offset into the monitor data structure for breakpoints
#define AVR_MONITOR_BP_FLAGS_OFFSET (AVR_MONITOR_REGS_SIZE)
//Offset into the monitor data structure for breakpoints
#define AVR_MONITOR_BREAKPOINTS_OFFSET (AVR_MONITOR_REGS_SIZE+sizeof(avr_hw_bp_flag_t)+sizeof(uint16_t))
//Size of the breakpoint structure
#define AVR_MONITOR_BREAKPOINTS_SIZE (sizeof(avr_breakpoint_t)*AVR_MONITOR_NUM_BREAKPOINTS)
//Not used yet. Offste in the monitor structure for the monitor dedicated stack
#define AVR_MONITOR_STACK_OFFSET (sizeof(avr_breakpoint_t)*AVR_MONITOR_NUM_BREAKPOINTS + AVR_MONITOR_BREAKPOINTS_OFFSET)

/**
 * Data used by the target monitor to save registers
 * and to communication
 */
typedef struct avr_monitor_data_s {
  ///0x00: Saved registers
  avr_registers_t regs;
  
  ///0x25: Enabled hardware breakpoints, each bit correspond to a hw break point
  avr_hw_bp_flag_t hw_bp_flags;           
  
  ///0x26: Previous PC when stepping, allows to step over cli / sei sections.
  uint16_t lastpc;                              
  
  ///0x28: Software bp addresses. 0 if entry not used
  avr_breakpoint_t breakpoint[AVR_MONITOR_NUM_BREAKPOINTS]; 
} avr_monitor_data_t;


extern volatile avr_monitor_data_t avr_monitor_data;

/**\@}*/


#endif //_AVR_MONITOR_H__


/**
 * @mainpage AVR Monitor
 *
 * \image html insight_screen_shot.png "AVR Insight debugging in an at90s4433"
 * 
 * \section avr_monitor_overview Overview
 * - \ref avr_monitor_intro Introduction to monitor and protocols
 * - \ref avr_monitor_building Building target, host and avr-gdb
 * - \ref avr_monitor_running Inspecting memory, setting breakpoints, running
 *
 * \section avr_monitor_intro Introduction
 * Most AVR devices td not have JTAG interface for in systems debugging.
 * With a small monitor in the target you can do in-system debugging.
 * The GNU debugger - GDB http://www.gnu.org/software/gnu and Insight 
 * http://www.redhat.com/sources/insight- have support for the AVR
 * thanks to the effort of Denis Chertykov and Theodore Roth.
 * 
 * \subsection avr_monitor_intro2 Connection
 * GDB connects to the AVR target through a proxy using the GDB serial protocol.
 * The AVR Monitor host translates the 
 * \ref avr_monitor_gdb_serial_commands "serial protocol commands" to the
 * AVR target protocol. The host and the target is connected through the MISO/MOSI/SCK
 * lines, so the monitor can be used if the ISP connector is available.
 * 
 * <b><tt>[GDB] <- tcp/ip -> [AVR Host] <- MISO/MOSI/SCK -> [AVR Target]</tt></b>
 *
 * \subsection avr_monitor_intro3 Target Monitor
 * The monitor uses an interrupt to do the assembler stepping and
 * to set breakpoints. Interrupt to use is configurable.
 * When software breakpoints are set the monitor steps assembler
 * instructions one by one until a break point is reached.
 *
 * Assembler instructions are stepped by enabling and triggering an interrupt
 * in the monitor and then doing a RETI. When the AVR core returns from the interrupt
 * it will always execute one assembler instruction before the interrupt vector is loaded again.
 * The monitor cannot step assembler instructions when interrupts are disabled and thus cannot break
 * on software breakpoints if interrupts are disabled. 
 * 
 * The monitor cannot step assembler instructions in interrupts that have higher priority
 * than the monitor; it is recommended to use INT0 as the monitor interrupt. 
 *
 * \subsection avr_monitor_intro4 Breakpoints
 * The monitor can handle two different types of breakpoints. 
 *
 * - Software breakpoints can be inserted and removed during runtime, GDB uses the software breakpoints when
 *   stepping C expressions and stepping into functions. The number of software breakpoints
 *   are limited. If one or more software breakpoints are
 *   enabled the monitor steps assembler instruction by instruction until a breakpoint is reached.
 *   This can be very slow in certain applications.
 * - Hardware breakpoints are inserted during compilation with the #HW_BREAKPOINT macro,
 *   when only hardware breakpoints are enabled the target can be run with full speed with only a very small
 *   overhead at the compiled breakpoints.
 * .
 * The breakpoints are treated like software breakpoints from GDB, the host does a translation
 * to a hardware breakpoint if the address matches one of the compiled breakpoints. The monitor
 * supports eight compiled breakpoints.
 *
 * \section avr_monitor_building Configuring and Building
 * Download the host and target source code <a href="./avr-monitor.tar.gz">avr-monitor.tar.gz</a>
 *
 * \subsection avr_monitor_building_target Target
 * In the target you add monitor.c to your project. In source code you include monitor.h.
 *
 * You need to select which interrupt to use for the monitor, currently INT0, INT1 or
 * TIMER0 is supported. It is fairly easy to add more. Look in monitor.c for available interrupt selections.
 * \code
 * CFLAGS += -DAVR_MONITOR_INT0
 * \endcode
 *
 * Edit make; select correct MCU
 * \code
 * $ cd test
 * $ make flash
 * \endcode
 *
 * \subsection avr_monitor_building_host Host
 * \code
 * $ cd host
 * $ make
 * $make install
 * \endcode
 * 
 * \subsection avr_monitor_building_gdb AVR Insight
 * Download snapshot or release later than 2003-05-05
 * \code
 * $ cd /usr/src
 * $ bunzip2 --keep --stdout insight-xxx.bz2 | tar --extract
 * $ mkdir avr-gdb
 * $ cd avr-gdb
 * $ /usr/src/insightxxx/configure --target=avr --program-prefix=avr- 
 * $ make
 * $ make install
 * \endcode
 * 
 * \section avr_monitor_running Running
 * Flash your target with the test program if not already done
 * \code
 * $ cd test
 * $ make flash
 * ...
 * \endcode
 * Open a new prompt and start the host, the host should report that it is waiting for GDB
 * \code
 * $ cd host
 * $ avr-monitor -d --gdb=localhost
 * \endcode
 * Start insight (gdb) and bring up the command prompt or use the menus.
 * Note: Make sure you don't have any spaces in the path for the .elf file,
 * Insight for CYGWIN cannot handle this, UNIX stuff I guess.
 * \code
 * $ cd test
 * $ avr-insight monitor_test.elf
 * (gdb) target remote localhost:11111
 * Remote debugging using localhost:11111
 * main () at monitor_test.c:85
 * (gdb) step
 * \endcode
 * You should be able to see the debug information about the GDB commands set to the host.
 * Read flash, read SRAM, etc.
 * \code
 * Read Registers:PC=0x00e8 SP=0xdd SREG=[ C=0 Z=1 N=0 V=0 S=0 H=0 T=0 I=0]
 * Read Flash   [0x00be-0x00c6]:cdedd0e0debfcdbf
 * Remove breakpoint @ 0x010a
 * Read SRAM/IO [0x00de-0x00e0]:1200
 * Read Flash   [0x00be-0x00c6]:cdedd0e0debfcdbf
 * Read SRAM/IO [0x00de-0x00e0]:1200
 * Read Flash   [0x00be-0x00c6]:cdedd0e0debfcdbf
 * Read SRAM/IO [0x00de-0x00e0]:1200
 * Read Flash   [0x00be-0x00c6]:cdedd0e0debfcdbf
 * Read SRAM/IO [0x00de-0x00e0]:1200
 * Read Flash   [0x00be-0x00c6]:cdedd0e0debfcdbf 
 * \endcode
 *
 * \section avr_monitor_internals More information
 * - \ref avr_monitor_data
 * - \ref avr_monitor_protocol
 * - \ref todo
 * .
 * - http://www.gnu.org/software/gdb
 * - http://sources.redhat.com/insight/
 * - http://www.birkler.net
 * - http://www.nongnu.org/avr-libc/
 * - http://winavr.sourceforge.net
 * .
 */



