/*  
  Copyright (C) 1999 by Denis Chertykov (denisc@overta.ru)
  STK200 communication added by Tor Ringstad (torhr@pvv.ntnaddr.no).

  You can redistribute it and/or modify it under the terms of the GNU
  General Public License as published by the Free Software Foundation;
  either version 2, or (at your option) any later version.

  This program works with the connection scheme used in Atmels "STK200
  Starter Kit". The connection allows to program the AVR with Uros
  Platise `uisp' in `-dstk200' mode.

  Bugs: For me this work only if Parellel port in EPP mode.
        May be ECP mode also work? 



  Copyright 2003 J�rgen Birkler mailto:birkler@yahoo.com
  
  Some major updates. Now support the standard serial line protocol in GDB, no need to patch GDB.
  Monitor a little more tolerant to different hardware and easier to configure.
  
*/

#include <stdarg.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#if defined(__CYGWIN__)
#include "cygwin_io.c"
#else 
#include <sys/io.h>
#endif 
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <fcntl.h>

#define __STRICT_ANSI__ 1
#include <readline/readline.h>
#include <readline/history.h>



#ifdef DEBUG
#  define Dprintf(x) debug_printf (x)
#else
#  define Dprintf(x)
#endif


static int mon_printf (const char * fmp, ...);
static int debug_printf (const char * fmp, ...);
static int debug_level = 0;
static int tcp_file_handle = -1;
/// address of registers array inside chip r[31], sreg, sp, pc 

#define AVR_MONITOR_HOST (1)

#include "monitor.h"
#include "lpt.c"
#include "target.c"
#include "socket_init.c"
#include "gdb_packet.c"
#include "handle_read_line.c"







/* ----------------------------------------------------------------- */





static void term_perm(int meta)
{
}




int main(int argc, char **argv)
{
  int c;
  int gdb_session_p=0;
  int sock,size;
  struct sockaddr_in clientname, name;
  int main_argc = argc;
  char **main_argv = argv;


  if (main_argc >= 2)
  {
    if (strcmp (main_argv[1], "-h") == 0)
    {
      fprintf (stderr, "Usage: mon [-d|-h] [host[:port]]\n");
      return 0;
    }
    else if (strcmp (main_argv[1], "-d") == 0)
    {
      --main_argc;
      ++main_argv;
      debug_level = 1;
      debug_printf("Debug on\n");
    }
  }

  if (main_argc >= 2)
  {
    int PORT=11111;
    int ret;
    if (main_argc >= 3)
    {
      char *tail;
      int p = strtol (main_argv[2], &tail, 10);
      if (main_argv[2] != tail)
        PORT = p;
      else
        fprintf (stderr, "mon: error in port `%s' recognition.\n", main_argv[2]);
    }
    fprintf (stderr, "mon: restarted. port:host = %s:%d\n",main_argv[1], PORT);
    init_sockaddr (&name, main_argv[1], PORT);
    sock = make_socket ( &name, PORT );
    if (listen (sock, 1) < 0)
    {
      perror ("listen");
      exit (EXIT_FAILURE);
    }

    /* Connection request on original socket.  */
    size = sizeof (clientname);
    if ((tcp_file_handle = accept (sock, (struct sockaddr *) &clientname, &size)) < 0)
    {
      perror ("accept");
      exit (EXIT_FAILURE);
    }

    fprintf(stderr, "Server: connect from host %s, port %hd.\n",
          inet_ntoa (clientname.sin_addr), ntohs (clientname.sin_port));

    /* torhr: Changed the socket from being non-blocking to being
        blocking. This is the only way I seem to get the redirection
        scheme to work... */

/*       ret = fcntl (tcp_file_handle, F_SETFL, fcntl (tcp_file_handle, F_GETFL, 0) */
/*             | O_NONBLOCK | FASYNC); */

    ret = fcntl (tcp_file_handle, F_SETFL, (fcntl (tcp_file_handle, F_GETFL, 0)
            | FASYNC) & (~O_NONBLOCK));
    if (ret < 0)
    {
      perror ("fcntl(NONBLOCK) for tcp_file_handle");
      exit (1);
    }
    gdb_session_p = 1;
  }

  CalcDelay();  /* calibrate busy-wait loops */

#ifdef DEBUG
  debug_printf("n_per_100ms = %ld\n", get_n_per_100ms());
#endif // DEBUG 

  gdb_packet_init();
  
  fprintf(stderr, "Starting host for avr monitor.\n");

  if (ioperm (_LP_BASE, 8, 1) == 0)
  {
    ResetAVR();

    rl_prep_term_function = term_perm;

    while (1)
    {
      c = RecvByte ();
      if (c != TARGET2HOST_SIGTRAP)
      {
        //Debug prints
        if (gdb_session_p)
          fputc (c, stderr);
        else
          putchar (c);
      }
      else
      {
        fprintf(stderr, "\nTarget stopped.");
      
        target_read_monitor_info();
        
        
        if (gdb_session_p)
        {
          gdb_packet_read();
        }
        else {
          handle_read_line();
        }
      }
    }
  }
  else
  {
    perror ("ioperm");
  }
  return 0;
}



int debug_printf (const char * fmt, ...)
{
  va_list args;
  va_start (args, fmt);
  if (debug_level > 0)
    return vfprintf (stderr, fmt, args);
  else
    return 0;
}


int mon_printf(const char *fmt, ...)
{
  va_list args;
  va_start (args, fmt);
//  if (debug_level && !tty_p)
//    vfprintf (stderr, fmt, args);
  return vprintf (fmt, args);
}



