///Break points in target
typedef struct {
  int count; ///<Max number of breakpoints in target
  avr_breakpoint_t addr[AVR_MONITOR_NUM_BREAKPOINTS]; ///Break point addresses
} breakpoints_t;




//Read monitor info from target
static void target_read_monitor_info(void);

///In target monitor information
typedef struct {
	avr_ptr_t monitor_data_address;  ///<Address within target to the #avr_monitor_data_t struct
	avr_ptr_t hw_breakpoint_address; ///<Flash address to the hardware breakpoint array
  avr_breakpoint_t hw_bp_addr[8];     ///Compiled break point addresses
} avr_monitor_info_t;

///Read monitor info (monitor data offset in SRAM) from target
static const avr_monitor_info_t* target_monitor_info(void);


///Reads SRAM and IO area from target
static const uint8_t* target_read_data (avr_ptr_t addr, uint8_t len, const char * err);


///Writes to SRAM or IO area in target
static int target_write_data(avr_ptr_t addr,uint8_t data, const char * err);

/**
 * Read from program memory
 * @todo Does not support ATMega128. Changes in protocol needed...
 */
static const uint8_t* target_read_pgm(avr_ptr_t addr, uint8_t len, const char * err);

/**
 * Converts a SREG to readable string
 * @return Chars written to buffer not including zero termination characters
 */
static int target_sreg_bits_to_string(char* buf, uint8_t sreg);


///Steps instruction by instruction until break point
static int target_next(const char * err);


///Runs. Software break point are not handled. Only TRAPS halt execution
static int target_cont(const char * err);

///Read breakpoints from target to struct
static int breakpoints_read(breakpoints_t* breakpoints_p);

/**
 * remove break point and update target
 * @param addr to remove bp at
 * @retval -1 Could not read from target
 * @retval 0 BP not found
 * @retval 1 SW breakpoint removed
 * @retval 2 Compiled breakpoint removed
 */
static int breakpoints_remove(uint16_t addr);

///@return 1 if any sw breakpoints activated 0 if no sw breakpoints
static int breakpoints_is_any_set(void);

/**
 * Add breakpoint and update target
 * @param addr to insert bp at
 * @retval -1 Could not read from target
 * @retval 0 no free space for breakpoint
 * @retval 1 SW breakpoint inserted
 * @retval 2 Compiled breakpoint inserted
 */
static int breakpoints_insert(uint16_t addr);







/* ----------------------------------------------------------------- */


#define ELEMENTS_OF(_array) (sizeof(_array) / sizeof(_array[0]))



static avr_monitor_info_t monitor_data;
///
static struct avr_monitor_packet_s packet;
static struct avr_monitor_packet_s back_packet;

static int packet_action (void);


#define dbg_offset_of(s,m) debug_printf("\n%s.%s %x",#s,#m,offsetof(s,m))

static void target_read_monitor_info(void)
{
  static int first_time = 1;
  avr_ptr_t p;
  const uint8_t* data;
  
  p = RecvByte ();
  p |= RecvByte () << 8;
  monitor_data.monitor_data_address = p;
  
  p = RecvByte ();
  p |= RecvByte () << 8;
  monitor_data.hw_breakpoint_address = p;

  if (first_time) debug_printf ("\nMonitor target data @0x%04x hw_bp@0x%04x",monitor_data.monitor_data_address, monitor_data.hw_breakpoint_address);
  
  data = target_read_pgm(monitor_data.hw_breakpoint_address, sizeof(avr_breakpoint_t)*8, "rd hw bp");
  
  memset(monitor_data.hw_bp_addr,0,sizeof(monitor_data.hw_bp_addr));
  
  if (data)
  {
    int i;
    if (first_time) debug_printf("\nCompiled breakpoints:");
    for (i=0;i < ELEMENTS_OF(monitor_data.hw_bp_addr);i++)
    {
      monitor_data.hw_bp_addr[i] = *data++;
      monitor_data.hw_bp_addr[i] |= (*data++)<<8;
      if (first_time) debug_printf(" 0x%04x",monitor_data.hw_bp_addr[i]<<1);
    }      
  }
  
  first_time = 0;
}


static const avr_monitor_info_t* target_monitor_info()
{
	return &monitor_data;
}

static int target_write_data(avr_ptr_t addr,uint8_t data, const char * err)
{
  packet.cmd = 'w';
  packet.addr.addr = addr;
  packet.rw.raw = data;
  if (packet_action())
  {
    fprintf (stderr, ("Error in `write' packet.\n"
                "Command: %s\n"), err);
    return -1;
  }
	else {
		return 0;
	}
}

static const uint8_t* target_read_data (avr_ptr_t addr, uint8_t len, const char * err)
{
  packet.cmd = 'r';
  packet.addr.addr = addr;
  packet.rw.length = len;
  if (packet_action())
  {
    fprintf (stderr, ("Error in `read' packet.\n"
                "Command: %s\n"), err);
    return NULL;
  }
	else {
		return &back_packet.buffer[0];
	}
}

static const uint8_t* target_read_pgm(avr_ptr_t addr, uint8_t len, const char * err)
{
  packet.cmd = 'p';
  packet.addr.addr = addr;
  packet.rw.length = len;
  if (packet_action())
  {
    fprintf (stderr, ("Error in `read' packet.\n"
                "Command: %s\n"), err);
    return NULL;
  }
	else {
		return &back_packet.buffer[0];
	}
}



static int target_next(const char * err)
{
  packet.cmd = 'q';
  packet.rw.raw = 1;
  if (packet_action ())
  {
    fprintf (stderr, ("Error in `read' packet.\n"
                "Command: %s\n"), err);
    return -1;
  }
	else {
	  return 0;
	}
}


static int target_step(const char * err)
{
  packet.cmd = 'q';
  packet.rw.raw = 2;
  if (packet_action ())
  {
    fprintf (stderr, ("Error in `read' packet.\n"
                "Command: %s\n"), err);
    return -1;
  }
	else {
	  return 0;
	}
}

static int target_cont(const char * err)
{
  packet.cmd = 'q';
  packet.rw.raw = 0;
  if (packet_action ())
  {
    fprintf (stderr, ("Error in `read' packet.\n"
                "Command: %s\n"), err);
    return -1;
  }
	else {
	  return 0;
	}
}





static int packet_action (void)
{
  int length;
  /* Send packet */
  SendByte (packet.cmd);
  SendByte (packet.addr.raw.lo);
  SendByte (packet.addr.raw.hi);
  SendByte (packet.rw.raw);

  /* Receive back packet */
  back_packet.cmd = RecvByte ();
  back_packet.addr.raw.lo = RecvByte ();
  back_packet.addr.raw.hi = RecvByte ();
  back_packet.rw.length = RecvByte ();

  for (length = 0;length < back_packet.rw.length; length++)
  {
    back_packet.buffer[length] = RecvByte ();
  }
  return back_packet.cmd == 'E';
}





static int target_sreg_bits_to_string(char* buf, uint8_t sreg)
{
  static const char* bit_names = "CZNVSHTI";
  static const char* delimiter = "";
  int len = 0;
  int i;
  uint8_t mask = 0x01;
  for (i=0; i < 8; ++i)
  {
    len += sprintf(&buf[len],"%s%c=%d",delimiter, bit_names[i], !! (sreg & mask));
    mask<<=1;
    delimiter = " ";
  }
  return len;
}


static const avr_registers_t* target_read_avr_registers(avr_registers_t* regs_p)
{
  int i;
  const uint8_t* data_p = 
		target_read_data (monitor_data.monitor_data_address,AVR_MONITOR_REGS_SIZE, "Read registers");

  if (data_p == NULL) return NULL;
  
  for (i=0;i<32;i++)
		regs_p->reg[i] = *data_p++;

	regs_p->sreg = *data_p++;
	regs_p->sp = (*data_p++);
	regs_p->sp |= (*data_p++ << 8);
	regs_p->pc = (*data_p++);
	regs_p->pc |= (*data_p++ << 8);
		
  regs_p->pc <<= 1;

  return regs_p;
}






static int breakpoints_read(breakpoints_t* breakpoints_p)
{
  const uint8_t* data_p;
  breakpoints_p->count = AVR_MONITOR_NUM_BREAKPOINTS;
  
  data_p = target_read_data(monitor_data.monitor_data_address+AVR_MONITOR_BREAKPOINTS_OFFSET,AVR_MONITOR_BREAKPOINTS_SIZE,"read bp");
    
  if (data_p)
  {
    memcpy(&breakpoints_p->addr[0],data_p,AVR_MONITOR_BREAKPOINTS_SIZE);
    return 0;
  }
  else {
    return -1;
  }
}

static int breakpoints_remove(uint16_t addr)
{
  int i;
  int res;
  
  breakpoints_t breakpoints;
  breakpoints_t* breakpoints_p = &breakpoints;
  
  for (i=0;i < ELEMENTS_OF(monitor_data.hw_bp_addr);i++)
  {
    //Hardware breakpoint
    if (addr == monitor_data.hw_bp_addr[i])
    {
      uint16_t offset = monitor_data.monitor_data_address + AVR_MONITOR_BP_FLAGS_OFFSET;
      avr_hw_bp_flag_t flags; ///Enabled compiled break points
      const uint8_t* data;
    
      //Read current flag
      data = target_read_data (offset,sizeof(flags), "read hw bp flags");
      
      if (data)
      {
        flags = *data;
        flags &= ~(0x1 << i);
        //debug_printf("(0x%02x @ 0x%04x)",flags,offset);
        target_write_data (offset,flags & 0xFF, "set bp");
        return 2;
      }
      else {
        return -1;
      }
    }
  }      
  
  res = breakpoints_read(breakpoints_p);
  
  if (res < 0) return res;
  
  for (i=0;i<breakpoints_p->count;i++)
  {
    if (addr == 0xFFFF || addr == breakpoints_p->addr[i])
    {
			avr_ptr_t offset = monitor_data.monitor_data_address + AVR_MONITOR_BREAKPOINTS_OFFSET + i*sizeof(avr_breakpoint_t);
      breakpoints_p->addr[i] = 0;
      target_write_data(offset,0, "rm bp");
      target_write_data(offset+1,0, "rm bp");
      return 1;
    }
  }
  return 0;
}

static int breakpoints_is_any_set(void)
{
  int i;
  int res;
  breakpoints_t breakpoints;
  breakpoints_t* breakpoints_p = &breakpoints;
  
  res = breakpoints_read(breakpoints_p);
  
  for (i = 0; i < breakpoints_p->count; i++)
  {
    if (breakpoints_p->addr[i] != 0)
    {
      return 1;
    }
  }
  return 0;
}


static int breakpoints_insert(uint16_t addr)
{
  int i;
  int res;
  
  breakpoints_t breakpoints;
  breakpoints_t* breakpoints_p = &breakpoints;
  
  for (i=0;i < ELEMENTS_OF(monitor_data.hw_bp_addr);i++)
  {
    //Hardware breakpoint
    if (addr == monitor_data.hw_bp_addr[i])
    {
      uint16_t offset = monitor_data.monitor_data_address + AVR_MONITOR_BP_FLAGS_OFFSET;
      avr_hw_bp_flag_t flags; ///Enabled compiled break points
      const uint8_t* data;

      data = target_read_data (offset,sizeof(flags), "read hw bp flags");
      
      if (data)
      {
        flags = *data;
        flags |= 0x1 << i;
        //debug_printf(" (0x%02x @ 0x%04x)",flags,offset);
        target_write_data (offset,flags & 0xFF, "set bp");
        return 2;
      }
      else {
        return -1;
      }
    }
  }      
  
  res = breakpoints_read(breakpoints_p);
  
  if (res < 0) return res;
  
  for (i=0;i<breakpoints_p->count;i++)
  {
    if (breakpoints_p->addr[i] == 0)
    {
			avr_ptr_t offset = monitor_data.monitor_data_address + AVR_MONITOR_BREAKPOINTS_OFFSET + i*sizeof(avr_breakpoint_t);
    
      breakpoints_p->addr[i] = addr;

      //Write
      target_write_data (offset,addr & 0xFF, "set bp");
      target_write_data (offset+1,addr >> 8, "set bp");

      return 1;
    }
  }
  return 0;
}






