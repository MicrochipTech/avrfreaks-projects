/* STK200 Direct Parallel Access */
#define STK2_ENA1   0x04        /* D2 (base) - enable for RESET, MISO */
#define STK2_ENA2   0x08        /* D3 (base) - enable for SCK, MOSI */
#define STK2_SCK    0x10        /* D4 (base) */
#define STK2_DOUT   0x20        /* D5 (base) */
#define STK2_RESET  0x80        /* D7 (base) */
#define STK2_DIN    0x40        /* ACK (base + 1) */

/* 
 * bit defines for 8255 status port
 * base + 1
 * accessed with LP_S(minor), which gets the byte...
 */
#define LP_PBUSY	0x80  /* inverted input, active high */
#define LP_PACK		0x40  /* unchanged input, active low */
#define LP_POUTPA	0x20  /* unchanged input, active high */
#define LP_PSELECD	0x10  /* unchanged input, active high */
#define LP_PERRORP	0x08  /* unchanged input, active low */

/* 
 * defines for 8255 control port
 * base + 2 
 * accessed with LP_C(minor)
 */
#define LP_PINTEN	0x10  /* high to read data in or-ed with data out */
#define LP_PSELECP	0x08  /* inverted output, active low */
#define LP_PINITP	0x04  /* unchanged output, active low */
#define LP_PAUTOLF	0x02  /* inverted output, active low */
#define LP_PSTROBE	0x01  /* short high output on raising edge */

#define _LP_BASE 0x378

#define RD_PORT (inb (_LP_BASE+1))
#define SET_CLK SetClk();
#define CLR_CLK ClrClk();
#define OUT_DATA_BIT(bit) OutDataBit(bit);



/*------------------------------------------------------------------*/
/* Low level printer port manipulation                              */
/*------------------------------------------------------------------*/

/* Stores the last value written to _LP_BASE. Makes it possible for
   different parts of the program to change some bits without altering
   the rest. */

static int port_val;

/* Enable this to get a debug output for every transition on any of
   the communication lines. */

void PrintPort(void)
{
#if 0
  fprintf(stderr, "ENA1: %s  ", (port_val & STK2_ENA1) ? "*" : " ");
  fprintf(stderr, "ENA2: %s  ", (port_val & STK2_ENA2) ? "*" : " ");
  fprintf(stderr, "RST: %s  ", (port_val & STK2_RESET) ? "*" : " ");
  fprintf(stderr, "SCK: %s  ", (port_val & STK2_SCK) ? "*" : " ");
  fprintf(stderr, "DOUT: %s  ", (port_val & STK2_DOUT) ? "*" : " ");
  fprintf(stderr, "\n");
#endif
}

/* Resets the AVR and bring the target connection to a known initial
   state where the ISP is activated and RESET is inactive. Also
   initializes port_val. */

void ResetAVR(void)
{
  Dprintf("Reset AVR...");

  outb(STK2_RESET | STK2_ENA1 | STK2_ENA2, _LP_BASE);
  usleep(1000);
  outb(STK2_RESET, _LP_BASE);
  usleep(1000);
  outb(0, _LP_BASE);
  usleep(1000);
  outb(STK2_RESET, _LP_BASE);
  port_val = STK2_RESET;

  Dprintf("ok\n");
  PrintPort();
}

void SetClk(void)
{
/*   Dprintf("-> CLK HI\n"); */
/*   getc(stdin); */
  port_val = port_val | STK2_SCK;
  outb(port_val, _LP_BASE);
  PrintPort();
}

void ClrClk(void)
{
/*   Dprintf("-> CLK LOW\n"); */
/*   getc(stdin); */
  port_val = port_val & (~STK2_SCK);
  outb(port_val, _LP_BASE);
  PrintPort();
}

void OutDataBit(unsigned char bit)
{
  int b = bit;
/*   Dprintf("-> OUT_DATA_BIT\n"); */
/*   getc(stdin); */
  if (b) {
    port_val |= STK2_DOUT;
  } else {
    port_val &= ~STK2_DOUT;
  }
  outb(port_val, _LP_BASE);
  PrintPort();
}


/*------------------------------------------------------------------*/
/* Time related subroutines                                         */
/*------------------------------------------------------------------*/

#include <signal.h>
#include <sys/time.h>

static unsigned long n_per_100ms;
static volatile int yes_alarm;

static void my_alarm( int k ){
  yes_alarm = 0;
}

void DelayAtom(void)
{
  volatile int i;
  for (i=0;i<1000;i++);
}

void Delay_ms(unsigned long ms) {
  unsigned long n;
  n = (ms * n_per_100ms) / 100;
  while (n) { DelayAtom(); n--; }
}

void Delay_10us(unsigned long t) {
  unsigned long n;
  n = (t * n_per_100ms) / 10000;
  while (n) { DelayAtom(); n--; }
}

unsigned long CalcDelay(void)
{ /* pause x ms */
  long n = 0;
  struct itimerval it;
  it.it_interval.tv_sec = 0;
  it.it_value.tv_sec = 0;
  it.it_interval.tv_usec = 0;
  it.it_value.tv_usec = 100000;  /* 100 ms */
  signal(SIGALRM, my_alarm);
  setitimer(ITIMER_REAL, &it, NULL);
  yes_alarm = 1;
  while (yes_alarm){
    DelayAtom(); n++;
  }
  n_per_100ms = n;
  return n;
}

unsigned long get_n_per_100ms(void)
{
      return n_per_100ms;
}



/*------------------------------------------------------------------*/
/* STK200 communication routines                                    */
/*------------------------------------------------------------------*/

#define CLK_DELAY 3 /*3*/    /* Appx Tx/Rx clock period/2 */


int RxBit(void) {
  int bit;
  SetClk();
  Delay_10us(CLK_DELAY);
  if (RD_PORT & STK2_DIN)
    bit = 1;
  else
    bit = 0;
/*    printf("Got %d\n", bit); */
  ClrClk();
  Delay_10us(CLK_DELAY);
  return bit;
}

void TxBit(int b) {
  if (b) { OUT_DATA_BIT(1); /*  printf("Sent 1\n"); */ }
  else { OUT_DATA_BIT(0); /*  printf("Sent 0\n"); */ }
  Delay_10us(CLK_DELAY);
  SetClk();
  Delay_10us(CLK_DELAY);
  ClrClk();
  OUT_DATA_BIT(0)
}

int RxByte(void) {
  int i;
  int b = 0;
  for(i = 0; i < TARGET2HOST_BITS; i++) {
    b <<= 1;
    b |= RxBit();
  }
  if (b & 0xFF00) 
      return -1;
  else 
    return (b & 0x00FF);
}

void TxByte(int b) {
  int i;
  for(i = 0; i < HOST2TARGET_BITS; i++) {
    TxBit(b & (0x1<<(HOST2TARGET_BITS-1)));
    b <<= 1;
  }
}

int HuntTxSync(void) {
  unsigned int word = 0;
  while(1) 
  {
    word <<= 1;
    word |= RxBit();
    word &= (0x1<<TARGET2HOST_BITS)-1;
    if (word == TARGET_RX_SYNC) return(1);
    if (word == TARGET_TX_SYNC) return(-1);
  }
}

int HuntRxSync(void) {
  unsigned int word = 0;
  while(1) 
  {
    word <<= 1;
    word |= RxBit();
    word &= (0x1<<TARGET2HOST_BITS)-1;
    if (word == TARGET_TX_SYNC) return(1);
    if (word == TARGET_RX_SYNC) return(-1);
  }
}

int RecvByte(void) 
{
  int b;
  if (HuntRxSync() < 0) return -1;
  b = RxByte();
    //printf("RecvByte() = %02x\n", b); 
  return b;
}

int SendByte(int b) {
  if (HuntTxSync() < 0) return -1;
  TxByte(b);
    //printf("SendByte(%02x)\n", b);
  return 1;
}



int gstrob;

#define strobe() (gstrob=(!!(RD_PORT & LP_POUTPA)))
#define pr_strobe() printf ("%d\n", gstrob)
void test_lpp(void)
{
  int i;
  
  for (i=0; 1/*  i< 3000 */; ++i)
  {
    if (strobe())
	  {
	    pr_strobe ();
	    while (strobe ());
	    pr_strobe ();
	  }
    else
	  {
	    pr_strobe ();
	    while (!strobe ());
	    pr_strobe ();
	  }
  }
}

