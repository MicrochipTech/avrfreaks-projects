/*  
  Copyright (C) 1999 by Denis Chertykov (denisc@overta.ru)
  STK200 communication added by Tor Ringstad (torhr@pvv.ntnaddr.no).

  You can redistribute it and/or modify it under the terms of the GNU
  General Public License as published by the Free Software Foundation;
  either version 2, or (at your option) any later version.

  This program works with the connection scheme used in Atmels "STK200
  Starter Kit". The connection allows to program the AVR with Uros
  Platise `uisp' in `-dstk200' mode.

  Bugs: For me this work only if Parellel port in EPP mode.
        May be ECP mode also work? 



  Copyright 2003 J�rgen Birkler mailto:birkler@yahoo.com
  
  Some major updates. Now support the standard serial line protocol in GDB, no need to patch GDB.
  Monitor a little more tolerant to different hardware and easier to configure.
  
  @todo Borrow port control from UISP and support more than STK200
  @todo Make receiving a little more non-hanging by alertering attention
  between the socket and the target. Let recvbyte return -1 if no byte from target.
*/

#include <stdarg.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#if defined(__CYGWIN__)
#include "cygwin_io.c"
#else 
#include <sys/io.h>
#endif 
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <fcntl.h>

#define __STRICT_ANSI__ 1
#include <readline/readline.h>
#include <readline/history.h>



#ifdef DEBUG
#  define Dprintf(x) debug_printf (x)
#else
#  define Dprintf(x)
#endif


static int mon_printf (const char * fmp, ...);
static int debug_printf (const char * fmp, ...);
static int debug_level = 0;
static int tcp_file_handle = -1;

#define AVR_MONITOR_HOST (1)

#include "monitor.h"
#include "lpt.c"
#include "target.c"
#include "socket_init.c"
#include "gdb_packet.c"
#include "handle_read_line.c"







/* ----------------------------------------------------------------- */


int argc;
const char** argv;
char* argv_ok;


static void term_perm(int meta)
{
}


/* Find command line parameter's value.
   It searches the command line parameters of the form:
   
	argv_name=value
	
   Returns pointer to the value. 
*/
const char* GetCmdParam(const char* argv_name, int value_required)
{
  int argv_name_len = strlen(argv_name);
  int i;
  for (i=1; i<argc; i++)
  {
    if (strncmp(argv_name, argv[i], argv_name_len)==0)
    {
      if (argv[i][argv_name_len]==0)
      {
        if (value_required)
        {
          printf("Incomplete parameter:%s",argv[i]);
          exit(1);
	      }
	      argv_ok[i]=1;
        return &argv[i][argv_name_len];	
      }
      if (argv[i][argv_name_len]=='=')
      {
        argv_ok[i]=1;
        return &argv[i][argv_name_len+1];
      }
    }
  }
  return NULL;
}

static void PrintUsage(void)
{
  printf("AVR Monitor host for on target debugging\n");
  printf("\n");
  printf("Copyright (C) 2002-2003 by J�rgen Birkler (birkler@yahoo.com)\n");
  printf("Copyright (C) 2001 by Tor Ringstad (torhr@pvv.ntnaddr.no)\n");
  printf("Copyright (C) 1999 by Denis Chertykov (denisc@overta.ru)\n");
  printf("\n");
  printf("\n");
  printf("avr-monitor [-d[=lvl]] [--version | -v | --help | -h | - interactive | -i | -gdb=address]\n");
  printf("\n");
  printf("-d=lvl           Sets debug level from 0=none, 1=High level comm. 2=All bytes comm\n");
  printf("--version -v     Version info\n");
  printf("--help -h        This help screen\n");
  printf("--interactive -i Read commands from stdin, Denis original.\n");
  printf("--gdb=address    Wait from connection from avr-gdb using TCP/IP on address. uses GDB serial protocol.\n");
  printf("\n");
}



int main(int _argc, const char **_argv)
{
  int c;
  int gdb_session_p=0;
  int sock,size;
  char argv_ok_buf[100];
  const char* gdb_client_param;
  const char* debug_level_param;
  
  argc = _argc;
  argv = _argv;
  
  debug_level=0;  
  
  argv_ok = &argv_ok_buf[0];
  memset(argv_ok_buf,0,sizeof(argv_ok_buf));

  if ((debug_level_param = GetCmdParam("-d",0)))
  {
    debug_level = 1;
    sscanf(debug_level_param,"%i",&debug_level);
    debug_printf("Debug level is %d\n",debug_level);
  }

  if (GetCmdParam("--help",0) || GetCmdParam("-h",0))
  {
    PrintUsage();
    return 0;
  }
  else if (GetCmdParam("--version",0) || GetCmdParam("-v",0))
  {
    PrintUsage();
    return 0;
  }
  else if (GetCmdParam("--interactive",0) || GetCmdParam("-i",0))
  {
  }
  else if ((gdb_client_param = GetCmdParam("--gdb",1))) 
  {
    int ret;
    char address[100+1];
    const char* port_param;
    struct sockaddr_in clientname;
    struct sockaddr_in name;
  
    int tcp_port = 11111;
    
    strncpy(address,gdb_client_param,100);
    address[100] = 0;
    
    
    if ((port_param = strstr(address,":")))
    {
      char* tail;
      port_param++;
      int p = strtol (port_param, &tail, 10);
      if (port_param != tail)
      {
        address[port_param-address-1] = 0;
        
        tcp_port = p;
      }
      else
      {
        PrintUsage();
        return 1;
      }    
    }      
    
    fprintf (stdout, "Waiting for GDB on %s:%d\n",address, tcp_port);
    init_sockaddr (&name, address, tcp_port);
    sock = make_socket ( &name, tcp_port );
    if (listen (sock, 1) < 0)
    {
      perror ("listen");
      exit (EXIT_FAILURE);
    }

    /* Connection request on original socket.  */
    size = sizeof (clientname);
    if ((tcp_file_handle = accept (sock, (struct sockaddr *) &clientname, &size)) < 0)
    {
      perror ("accept");
      exit (EXIT_FAILURE);
    }

    printf("Connect from %s:%hd.\n",
          inet_ntoa (clientname.sin_addr), ntohs (clientname.sin_port));

    /* torhr: Changed the socket from being non-blocking to being
        blocking. This is the only way I seem to get the redirection
        scheme to work... */

/*       ret = fcntl (tcp_file_handle, F_SETFL, fcntl (tcp_file_handle, F_GETFL, 0) */
/*             | O_NONBLOCK | FASYNC); */

    ret = fcntl (tcp_file_handle, F_SETFL, (fcntl (tcp_file_handle, F_GETFL, 0)
            | FASYNC) & (~O_NONBLOCK));
            
    if (ret < 0)
    {
      perror ("fcntl(NONBLOCK) for tcp_file_handle");
      exit (1);
    }
    gdb_session_p = 1;

  }
  else {
    PrintUsage();
    return 1;
  }
  
  CalcDelay();  /* calibrate busy-wait loops */

#ifdef DEBUG
  debug_printf("n_per_100ms = %ld\n", get_n_per_100ms());
#endif // DEBUG 

  gdb_packet_init();
  
  fprintf(stdout, "Starting host for avr monitor.\n");

  if (ioperm (_LP_BASE, 8, 1) == 0)
  {
    ResetAVR();

    rl_prep_term_function = term_perm;

    while (1)
    {
      c = RecvByte ();
      if (c < 0)
      {
      }
      else if (c == TARGET2HOST_SIGTRAP)
      {
        fprintf(stdout, "\nTarget stopped.");
      
        target_read_monitor_info();
        
        if (gdb_session_p)
        {
          gdb_packet_read();
        }
        else {
          handle_read_line();
        }
      }
      else
      {
        //Debug prints
        if (gdb_session_p)
          fputc (c, stdout);
        else
          putchar (c);
      }
      fflush(stdout);
    }
  }
  else
  {
    perror ("ioperm");
  }
  return 0;
}


///@todo Channel all debug through stderr?
int debug_printf (const char * fmt, ...)
{
  va_list args;
  va_start (args, fmt);
  if (debug_level > 0)
    return vfprintf (stdout, fmt, args);
  else
    return 0;
}


int mon_printf(const char *fmt, ...)
{
  va_list args;
  va_start (args, fmt);
//  if (debug_level && !tty_p)
//    vfprintf (stdout, fmt, args);
  return vprintf (fmt, args);
}



