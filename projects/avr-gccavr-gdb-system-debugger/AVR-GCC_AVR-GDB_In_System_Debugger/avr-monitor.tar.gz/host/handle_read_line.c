///Handles input from standard input
static int handle_read_line(void);



static const char* MON_USAGE = 
  "Commands:\n"
  "r ADDRESS [COUNT] - read COUNT bytes from data memory\n"
  "w ADDRESS BYTE    - write BYTE to data memory\n"
  "p ADDRESS [COUNT] - read COUNT bytes from program memory\n"
  "P ADDRESS [COUNT] - read COUNT commands from program memory\n"
  "i ADDRESS         - read byte from IO space\n"
  "o ADDRESS BYTE    - write BYTE to IO space\n"
  "R                 - show registers\n"
  "X=NN              - set register X to NN\n"
  "n                 - execute instruction by PC\n"
  "bp ADDRESS        - set breakpoint.\n"
  "bc ADDRESS        - clear breakpoint. -1 as ADDRESS - clear all breakpoints.\n"
  "q                 - quit monitor (running or stepping AVR program)\n";

static void dump_usage(void)
{
  fprintf(stdout,MON_USAGE);
}

static void dump_avr_registers(void)
{
  avr_registers_t regs;
  const avr_registers_t* regs_p;

  regs_p = target_read_avr_registers(&regs); 
  if (regs_p)
  {
    int i,j;

    j = 1;
    for (i = 0; i < 32; ++i)
    {
      char s[30];
      sprintf (s, "r%-2d=%02x", i, regs_p->reg[i]);
      if ((j++ % 8) == 0)
        mon_printf ("%s\n", s);
      else
        mon_printf ("%-10s", s);
    }

    mon_printf ("X=%04x  Y=%04x  Z=%04x\n",
          regs_p->reg[26] | regs_p->reg[27] << 8,
          regs_p->reg[28] | regs_p->reg[29] << 8,
          regs_p->reg[30] | regs_p->reg[31] << 8);
          
    mon_printf ("SREG=%02x  ", regs_p->sreg);

    {
      char buf[30];
      
      target_sreg_bits_to_string(buf,regs_p->sreg);
      
      mon_printf ("%s", buf);
    }
    mon_printf ("\nPC=%05x  SP=%04x\n", regs_p->pc, regs_p->sp);
  }
}

static int handle_read_line(void)
{
  char tstr[10];
  char *line;
  int addr,data,len,ft=1;

  static int first_time = 1;

  if (first_time)
  {
		const avr_monitor_info_t* info_p = target_monitor_info();
    fprintf (stdout,"\nMonitor. (type `?' for help)\n");
    fprintf (stdout,"mon: address of `regs' = 0x%04x hw_bp=0x%04x\n", 
      info_p->monitor_data_address,info_p->hw_breakpoint_address);
      
    first_time = 0;
  }

  while (1)
  {
    char * to_free = NULL;

    to_free = line = readline ("mon>");

    if (!line)
      exit (0);

    while (isblank (*line))
      ++line;

    if (!*line || *line == '\n' || *line == '\r')
      continue;

    packet.cmd = *line;
        
    if (sscanf (line, "w %i %i", &addr, &data) == 2
        || sscanf (line, "o %i %i", &addr, &data) == 2)
    {
      if (*line == 'o')
      {
        addr += 32; /* Skip mapped registers */
      }

      if (addr > 0x60 && *line == 'o')
      {
        fprintf (stdout, "IO access out of range\n");
      }
      else if (addr)
      {
        target_write_data(addr & 0xFFFF,data,line);
      }
      else {
        fprintf (stdout, "Cannot write to FLASH\n");
      }
    }
    else if (sscanf (line, "%5[^=]=%i", tstr, &data) == 2
            && (sscanf (tstr, "r%i", &addr) == 1
                || (addr = 32, strcasecmp (tstr, "SREG") == 0)
                || (addr = 33, strcasecmp (tstr, "SP") == 0)
                || (addr = 35, strcasecmp (tstr, "PC") == 0)))
    {
      if (addr == 35)
      {
        if (data & 1)
          fprintf (stdout,
                  "Error: PC value must be even.\n");
        data >>= 1;
      }
      target_write_data (data, addr + monitor_data.monitor_data_address, line);
      if (addr >= 33)
      {
        target_write_data (addr + monitor_data.monitor_data_address + 1,data >> 8,  line );
      }
    }
    else if ((ft = sscanf (line, "r %i %i", &addr, &len)) >= 1
            || (ft = sscanf (line, "i %i %i",
                        &addr, &len)) >= 1)
    {
      const uint8_t* data_p;
      if (*line == 'i')
      {
        addr += 32; /* Skip mapped registers */
      }
      
      if (ft == 1)
      {
        len = 1;
      }

      if (addr >= 0x800000)
      {
        data_p = target_read_data(addr&0xFFFF,len,"read data");
      }
      else
      {
        data_p = target_read_pgm(addr,len,"read pgm");
      }

      if (data_p == NULL)
      {
        fprintf (stdout, ("Error in `read' packet.\n""Command: %s\n"), line);
      }
      else {
        int i;
        mon_printf ("0x%04x", *line == 'i'
              ? addr - 32
              : addr);

        for (i=0; i < len; ++i)
        {
          mon_printf (" 0x%x",data_p[i]);
        }

        mon_printf ("\n");
      }

      /*
          mon_printf ("0x%04x 0x%02x  '%c'\n",
                *line == 'i' ? back_packet.addr.addr - 32
                : back_packet.addr.addr,
                back_packet.rw.raw,
                isprint (back_packet.rw.raw) ?
                back_packet.rw.raw
                : '.'); */
    }
    else if ((ft = sscanf (line, "p %i %i", &addr, &len)) >= 1)
    {
      int i;
      const uint8_t* data_p;
      data_p = target_read_pgm(addr,len,"`read' packet");

      if (ft == 1) len = 1;

      if (data_p == NULL) {
        fprintf (stdout, ("Error in `read' packet.\n"
                      "Command: %s\n"), line);
      }
      else {
        for (i=0; i < len; ++i)
        {
          mon_printf ("0x%04x 0x%02x  '%c'\n",
                back_packet.addr.addr,
                data_p[i],
                isprint (data_p[i]) ?
                data_p[i]
                : '.');
        }
      }
    }
    else if ((ft = sscanf (line, "P %i %i", &addr, &len)) >= 1)
    {
      int i;
      if (ft == 1) len = 1;

      addr -= addr % 2;

      const uint8_t* data_p;
      data_p = target_read_pgm(addr,len*2,"`read' packet");

      if (data_p == NULL) {
        fprintf (stdout, ("Error in `read' packet.\n"
                      "Command: %s\n"), line);
      }
      else {
        for (i=0; i < len; ++i)
        {
          mon_printf ("0x%04x 0x%04x\n",
            addr+i*2,
            data_p[i*2]<<8 | data_p[i*2+1]);

        }
      }
    }
    else if (sscanf (line, "bp %i", &addr) == 1)
    {
      if (addr & 1)
      {
        fprintf (stdout, "Address must be even.\n");
      }
      else
      {
        addr >>= 1;
        if (breakpoints_insert(addr) > 0)
        {
        }
        else {
          fprintf (stdout, "No room for breakpoint `%s'\n", line);
        }
      }
    }
    else if (sscanf (line, "bc %i", &addr) == 1)
    {
      if ((addr & 1) && addr != -1)
      {
        fprintf (stdout, "Address bust be even.\n");
      }
      else
      {
        breakpoints_t bp;
        if (breakpoints_read(&bp) >= 0)
        {
          if (addr <0) 
          {
            addr = 0xFFFF;
          }
          else
          {
            addr >>= 1;
          }

          if (breakpoints_remove(addr) > 0)
          {
          }
          else {
            fprintf (stdout, "Can't find breakpoint `%s'\n",line);
          }
        }
      }
    }
        
    else if (*line == 'q')
    {
      breakpoints_t bp;
      if (breakpoints_read(&bp) >= 0)
      {
        if (breakpoints_is_any_set())
        {
          if (target_step("stepping") >= 0 && debug_level)
            fprintf (stdout, "Stepping...\n");
        }
        else {
          if (target_cont("cont") >= 0 && debug_level)
            fprintf (stdout, "Continue...\n");
        }
        break;
      }
    }
    else if (*line == 'n')
    {
      if (target_next("Step") >= 0)
      {
        if (debug_level)
          fprintf (stdout, "Step...\n");
      }
      break;
    }
    else if (*line == 'R')
    {
      dump_avr_registers ();
    }
    else if (*line == '?')
    {
      dump_usage();
    }
    else
    {
      fprintf (stdout, "Error in command: %s\n", line);
    }

    if (to_free)
    {
      free (to_free);
    }
  } //while (1)
  
  fflush (stdout);
  fflush (stdout);
  
  return 0;
} 
