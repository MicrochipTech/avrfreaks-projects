/**
 * @file
 *
 * Copyright 2003
 * J�rgen Birkler mailto:birkler@yahoo.com
 *
 * Implements the GDB serial protocol and translates it to the
 * avr host-target protocol.
 * It is based on the host stub for sparc found in the GDB sources.
 */

/**
 * @page avr_monitor_gdb_serial_commands GDB Serial protocol commands
 *
 * All commands and responses are sent with a packet which includes a
 * checksum.  A packet consists of
 *
 * $<packet info>#<checksum>.
 *
 * <packet info> ::= <characters representing the command or response>
 *
 * <checksum>    ::= <two hex digits computed as modulo 256 sum of <packetinfo>>
 *
 * When a packet is received, it is first acknowledged with either '+' or '-'.
 * '+' indicates a successful transfer.  '-' indicates a failed transfer.
 *
 * Example:
 * 
 * Host:                  Reply:
 * $m0,10#2a               +$00010203040506070809101112131415#42
 *
 *
 * The following gdb commands are supported. Addresses A are 32 bit, thus are eight 
 * characters long. Address range is split between Flash and SRAM, SRAM have a 0x00800000.
 *
 * \code
 * Cmd           Function                                Return value
 * -----         --------------------------------------  -------------
 * g             Return the value of the CPU registers   Data or ENN
 * G             Set the value of the CPU registers      OK or ENN
 * mA,L          Read L bytes at address A               hex data or ENN
 * MA,L          Write L bytes at address A              OK or ENN
 * c             Resume at current address               SNN   (signal NN)
 * s             Step one asm instruction                SNN
 * k             Kill 
 * ZA            Insert breakpoint at address A          OK or ENN             
 * zA            Remove breakpoint from address A        OK or ENN             
 * D             Disconnect?
 * ?             What was the last sigval ?              SNN   (signal NN)
 * \endcode
 *
 */


///GDB defines a set of signals, I guess there are from UNIX. 5 is for breakpoints
#define SIGTRAP 5



static void putDebugChar(int ch)
{
  char temp = ch;
  if (debug_level > 1)
    debug_printf("%c",ch);
  write(tcp_file_handle,&temp,1);
}



static int getDebugChar(void)
{
  char temp;
  if (read(tcp_file_handle,&temp,1) != 1)
  {
    if (debug_level > 1)
      debug_printf("EOF",temp);
    return -1;
  }
  else
  {
    if (debug_level > 1)
      debug_printf("%c",temp);
    return temp;
  }
}

#define BUFMAX 2048

static const char hexchars[]="0123456789abcdef";

static char remcomInBuffer[BUFMAX];
static char remcomOutBuffer[BUFMAX];

/* scan for the sequence $<data>#<checksum>     */

static int hex(unsigned char ch)
{
  if (ch >= 'a' && ch <= 'f')
    return ch-'a'+10;
  if (ch >= '0' && ch <= '9')
    return ch-'0';
  if (ch >= 'A' && ch <= 'F')
    return ch-'A'+10;
  return -1;
}

/**
 * While we find nice hex chars, build an int.
 * @returns Number of chars processed.
 */
static int hexToInt(char **ptr, int *intValue)
{
  int numChars = 0;
  int hexValue;

  *intValue = 0;

  while (**ptr)
  {
    hexValue = hex(**ptr);
    if (hexValue < 0)
			break;

    *intValue = (*intValue << 4) | hexValue;
    numChars ++;

    (*ptr)++;
  }

  return (numChars);
}


/* Convert the memory pointed to by mem into hex, placing result in buf.
 * Return a pointer to the last char put in buf (null)
 */
static unsigned char *
	mem2hex (const void *mem, unsigned char *buf, int count, int may_fault)
{
  unsigned char ch;

  while (count-- > 0)
  {
    ch = *((uint8_t*)mem)++;
    *buf++ = hexchars[ch >> 4];
    *buf++ = hexchars[ch & 0xf];
  }

  *buf = 0;

  return buf;
}

/** convert the hex array pointed to by buf into binary to be placed in mem
 * return a pointer to the character AFTER the last character read from input 
 */

static const char *
hex2mem (const char* buf, void* dest_p, int count, int may_fault)
{
  unsigned char * mem = (unsigned char *)dest_p;
  int i;
  unsigned char ch;

  for (i=0; i<count; i++)
  {
    ch = hex(*buf++) << 4;
    ch |= hex(*buf++);
    *mem++ = ch;
  }

  return buf;
}

unsigned char *
getpacket (void)
{
  unsigned char *buffer = &remcomInBuffer[0];
  unsigned char checksum;
  unsigned char xmitcsum;
  int count;
  char ch;

  while (1)
  {
    /* wait around for the start character, ignore all other characters */
    while ((ch = getDebugChar ()) != '$')
	    ;

    retry:
      checksum = 0;
      xmitcsum = -1;
      count = 0;

    /* now, read until a # or end of buffer is found */
    while (count < BUFMAX)
  	{
	    ch = getDebugChar ();
      if (ch == '$')
        goto retry;
	    if (ch == '#')
	      break;
	    checksum = checksum + ch;
	    buffer[count] = ch;
	    count = count + 1;
	  }
    buffer[count] = 0;

    if (ch == '#')
  	{
	    ch = getDebugChar ();
	    xmitcsum = hex (ch) << 4;
	    ch = getDebugChar ();
	    xmitcsum += hex (ch);

  	  if (checksum != xmitcsum)
	    {
	      putDebugChar ('-');	/* failed checksum */
	    }
	    else
	    {
	      putDebugChar ('+');	/* successful transfer */

	      /* if a sequence char is present, reply the sequence ID */
	      if (buffer[2] == ':')
		    {
		      putDebugChar (buffer[0]);
		      putDebugChar (buffer[1]);

		      return &buffer[3];
		    }
        
	      return &buffer[0];
	    }
	  }
  }
}

/* send the packet in buffer.  */
static void putpacket (unsigned char *buffer)
{
  unsigned char checksum;
  int count;
  unsigned char ch;

  /*  $<packet info>#<checksum>. */
  do
  {
    putDebugChar('$');
    checksum = 0;
    count = 0;

    while ((ch = buffer[count]) != 0)
    {
	    putDebugChar(ch);
	    checksum += ch;
	    count += 1;
    }

    putDebugChar('#');
    putDebugChar(hexchars[checksum >> 4]);
    putDebugChar(hexchars[checksum & 0xf]);

  } while (getDebugChar() == '-');
}


char* int2hex(unsigned int val, char* ptr)
{
  uint32_t temp = val;
  return mem2hex(&temp,ptr,sizeof(temp),0);
}


static void gdb_packet_init(void)
{
  remcomOutBuffer[0] = 0;
}



static void gdb_packet_read(void)
{
  putpacket(remcomOutBuffer);

  while (1)
  {
    char command;
    char* ptr;
    int addr;
    int length;
    remcomOutBuffer[0] = 0;

    ptr = getpacket();
    command = *ptr++;
    switch (command)
	  {
	    case '?':
        debug_printf("Get last signal");
        sprintf(remcomOutBuffer,"S%02x",SIGTRAP);
	      break;

	    case 'd':		
	      // toggle debug flag
        debug_printf("toggle debug flag");
	      break;

	    case 'D':		
	      //Disconnect
        debug_printf("\nDisconnect");
        exit(0);
	      return;
	      
	    case 'g':		
				// return the value of the CPU registers 
	      {
          avr_registers_t regs;
          const avr_registers_t* regs_p;
          int i;

          //Read from target
          regs_p = target_read_avr_registers(&regs); 
          
          if (regs_p)
          {
  	        char sreg_print_buf[50];
            target_sreg_bits_to_string(sreg_print_buf,regs_p->sreg);
            debug_printf("\nRead Registers:PC=0x%04x SP=0x%02x SREG=[%s]",regs_p->pc,regs_p->sp,sreg_print_buf);

            //Assume correct endianess and use mem2hex
	          ptr = &remcomOutBuffer[0];

            for (i=0;i<32;i++)
              ptr = mem2hex(&regs_p->reg[i],ptr,sizeof(regs_p->reg[i]),0);

            ptr = mem2hex(&regs_p->sreg,ptr,sizeof(regs_p->sreg),0);
            ptr = mem2hex(&regs_p->sp,ptr,sizeof(regs_p->sp),0);
            ptr = mem2hex(&regs_p->pc,ptr,sizeof(regs_p->pc),0);
          }
          else {
            strcpy(remcomOutBuffer,"E01");
          }
	      }
	      break;

	    case 'G':	   // set the value of the CPU registers - return OK 
	      {
	        const char* p = ptr;
          avr_registers_t regs;
	      
	        p = hex2mem(p,&regs,sizeof(regs),0);
	        
          debug_printf("\nWrite Registers");
          
          //Write
          ///@todo Do write code
          
	        strcpy(remcomOutBuffer,"E01");
	      }
	      break;

	    case 'm':	  
				/* mAA..AA,LLLL  Read LLLL bytes at address AA..AA */
	      /* Try to read %x,%x.  */
        {

	        if (hexToInt(&ptr, &addr)
	            && *ptr++ == ','
	            && hexToInt(&ptr, &length))
	        {
            const uint8_t* data_p;
            if (AVR_GCC_IS_SRAMIO(addr))
            {
              addr &= AVR_GCC_MASK_SRAM;
              debug_printf("\nRead SRAM/IO [0x%04x-0x%04x]:",addr,(addr+length));
            
              data_p = target_read_data(addr&0xFFFF,length,"rd data");
            }
            else if (AVR_GCC_IS_FLASH(addr))
            {
              addr &= AVR_GCC_MASK_FLASH;
              debug_printf("\nRead Flash   [0x%04x-0x%04x]:",addr,addr+length);
              data_p = target_read_pgm(addr,length,"rd pgm");
            }
            else if (AVR_GCC_IS_EEPROM(addr)) 
            {
              addr &= AVR_GCC_MASK_EEPROM;
              debug_printf("\nRead EEPROM [0x%04x-0x%04x]:",addr,(addr+length));
              debug_printf("Not supported!");
              data_p = NULL;
            }
            else {
              data_p = NULL;
            }

            if (data_p)
            {
              mem2hex(data_p, remcomOutBuffer, length, 0);
              debug_printf("%s",remcomOutBuffer);
            }
            else {
  	          strcpy (remcomOutBuffer, "E03");
            }
	        }
	        else
          {
	          strcpy(remcomOutBuffer,"E01");
          }
        }
	      break;

	    case 'M': 
				/* MAA..AA,LLLL: Write LLLL bytes at address AA.AA return OK */
	      /* Try to read '%x,%x:'.  */

	      if (hexToInt(&ptr, &addr)
	          && *ptr++ == ','
	          && hexToInt(&ptr, &length)
	          && *ptr++ == ':')
        {
					const char* p = ptr;
	        debug_printf("\nRemove breakpoint @ 0x%04x",addr);

          if (AVR_GCC_IS_SRAMIO(addr))
          {
            addr &= AVR_GCC_MASK_SRAM;
            debug_printf("\nWrite SRAM/IO [0x%04x-0x%04x]:%s",addr,addr+length,ptr);
   					strcpy(remcomOutBuffer, "OK");

						while (length-->0)
						{
							uint8_t byte;
							p = hex2mem(p, &byte, sizeof(byte), 0);
							if (target_write_data(addr,byte,"wr data") < 0)
							{
   							strcpy(remcomOutBuffer, "E01");
								break;
							}
						}
          }
          else if (AVR_GCC_IS_FLASH(addr))
          {
            addr &= AVR_GCC_MASK_FLASH;
            debug_printf("\nWrite Flash [0x%04x-0x%04x]:Failed",addr,addr+length);
  					strcpy(remcomOutBuffer, "E01");
          }
          else if (AVR_GCC_IS_EEPROM(addr)) 
          {
            addr &= AVR_GCC_MASK_EEPROM;
            debug_printf("\nWrite EEPROM [0x%04x-0x%04x]:Not supported yet",addr,(addr+length));
          }
          else
          {
  					strcpy(remcomOutBuffer, "E01");
          }
	      }
	      else
        {
	        strcpy(remcomOutBuffer, "E02");
        }
	      break;


      case 'z':
        {
          int zero;
          //Remove breakpoint
          if (hexToInt(&ptr, &zero)
	            && *ptr++ == ','
	            && hexToInt(&ptr, &addr))
          {
            int res;
            
            addr >>= 1;

            res = breakpoints_remove(addr);
            
            if (res >= 1)
            {
              if (res == 2) {
                debug_printf("\nRemove HW BP @ 0x%04x",addr<<1);
              }
              else {
                debug_printf("\nRemove SW BP @ 0x%04x",addr<<1);
              }
              strcpy(remcomOutBuffer,"OK");
            }
            else {
              fprintf (stderr, "Breakpoint not found\n");
              strcpy(remcomOutBuffer,"E01");
            }
          }
          else {
            strcpy(remcomOutBuffer, "E02");
          }
        }
        break;

      case 'Z':
        {
          int zero;
          //Insert breakpoint
          if (hexToInt(&ptr, &zero)
	            && *ptr++ == ','
	            && hexToInt(&ptr, &addr))
          {
            int res;
            
            addr >>= 1;

            res = breakpoints_insert(addr);
            
            if (res >= 1)
            {
              if (res == 2) {
                debug_printf("\nInsert HW BP @ 0x%04x",addr<<1);
              }
              else {
                debug_printf("\nInsert SW BP @ 0x%04x",addr<<1);
              }
              strcpy(remcomOutBuffer,"OK");
            }
            else {
              fprintf (stderr, "No room for BP\n");
              strcpy(remcomOutBuffer,"E01");
            }
          }
        }
        break;
        



	    case 'c':    
        /* cAA..AA    Continue at address AA..AA(optional) */
	      /* try to read optional parameter, pc unchanged if no parm */

	      if (hexToInt(&ptr, &addr))
	      {
          debug_printf("\nContinue from %04x:Not supported",addr);
          strcpy(remcomOutBuffer, "ENotImplemented yet.");
          //Write new PC
	      }
	      
	      
        if (breakpoints_is_any_set())
        {
          debug_printf("\nStepping",addr);
          
          if (target_step("stepping") >= 0)
          {
            sprintf(remcomOutBuffer,"S%02x",SIGTRAP);
            return;
          }
          else {
            strcpy(remcomOutBuffer, "E01");
          }
        }
        else {
          debug_printf("\nContinue");
          if (target_cont("cont") >= 0 && debug_level)
          {
            sprintf(remcomOutBuffer,"S%02x",SIGTRAP);
            return;
          }
          else {
            strcpy(remcomOutBuffer, "E01");
          }
        }
        break;

	    case 's':    /* step one asm instruction */
	      {
          debug_printf("\nStep",command);
          if (target_next("Step") >= 0)
          {
            sprintf(remcomOutBuffer,"S%02x",SIGTRAP);
            return;
          }
          else {
            strcpy(remcomOutBuffer, "E");
          }
	      }
    	  return;

  	  // kill the program 
	    case 'k' :		// do nothing 
        debug_printf("\nKill");
	      break;
    #if 0
	    case 't':		// Test feature 
	      break;
    #endif

	    case 'r':		// Reset 
        debug_printf("\nReset",command);
	      break;

      default:
        debug_printf("\nUnrecognized command:%c%s",command,ptr);
        break;
	  }			// switch 

    /* reply to the request */
    putpacket(remcomOutBuffer);
  }
}
