
/*------------------------------------------------------------------*/

int make_socket (struct sockaddr_in * name, unsigned short int port)
{
  int sock;
  int tmp;
  struct protoent *protoent;
     
  /* Create the socket.  */
  sock = socket (PF_INET, SOCK_STREAM, 0);
  if (sock < 0)
    {
      perror ("socket");
      exit (EXIT_FAILURE);
    }
  /* Allow rapid reuse of this port. */
  tmp = 1;
  setsockopt (sock, SOL_SOCKET, SO_REUSEADDR, (char *)&tmp, sizeof(tmp));
  
  /* Enable TCP keep alive process. */
  tmp = 1;
  setsockopt (sock, SOL_SOCKET, SO_KEEPALIVE, (char *)&tmp, sizeof(tmp));
     
  if (bind (sock, (struct sockaddr *) name, sizeof (*name)) < 0)
    {
      perror ("bind");
      exit (EXIT_FAILURE);
    }

  protoent = getprotobyname ("tcp");
  if (!protoent)
    {
      perror ("getprotobyname (\"tcp\")");
      exit (EXIT_FAILURE);
    }
  
  tmp = 1;
  if (setsockopt (sock, protoent->p_proto, TCP_NODELAY,
		  (char *)&tmp, sizeof(tmp)))
    {
      perror ("setsockopt");
      exit (EXIT_FAILURE);
    }
  return sock;
}
/*
   Here is another example, showing how you can fill in a `sockaddr_in'
   structure, given a host name string and a port number:
   */

void init_sockaddr (struct sockaddr_in *name,
     	       const char *hostname, unsigned short int port)
{
  struct hostent *hostinfo;
     
  name->sin_family = AF_INET;
  name->sin_port = htons (port);
  hostinfo = gethostbyname (hostname);
  if (hostinfo == NULL)
    {
      fprintf (stderr, "Unknown host %s.\n", hostname);
      exit (EXIT_FAILURE);
    }
  name->sin_addr = *(struct in_addr *) hostinfo->h_addr;
}
