//frequency counter for avr2313 author stephen dredge
//uses 2*24 HD44780 based lcd
//displays frequency over 1,10 and 100 second timebase
//also displays elapsed time since power on in H,M,S
//this can be used for a basic check,trim on xtal frequency
//port d4 is input pin.




#define USEASM			//remove this line to compile without inline
				//assembly at the cost of some accuracy
#include <io.h>   
#include <interrupt.h>
#include <sig-avr.h>
#include <eeprom.h>

//Pin definitions for connection of LCD 

#define ENABLEPORT 		PORTB
#define RSPORT			PORTB
#define D7PORT			PORTB
#define D6PORT			PORTB
#define D5PORT			PORTB
#define D4PORT			PORTB
#define ENABLEPIN 		5
#define RSPIN			4
#define D7PIN			3
#define D6PIN			2
#define D5PIN			1
#define D4PIN			0

//change these to suit crystal frequency

#define LCDDELAY	0x85		//delays 50uS with 3 cycle loop & 8MHz clock
#define TIMER1HIGH	0x86		//delay 1S with 7.9872 MHz crystal
#define TIMER1LOW	0x20		//and /256 prescale

#define LCD_ENTRY_INC           0x06   	//display shift off, inc cursor move dir 
#define LCD_DDRAM               7	//DB7:set DD RAM address 
#define LCD_START_LINE1         0x00    //DDRAM address of first char of line 1 
#define LCD_START_LINE2         0x40    //DDRAM address of first char of line 2 
#define LCD_WIDTH		24
#define CLEARDISPLAY		0x01	
#define ON			0x0C	//turns display on no cursor

//8 bit Counter/Timer Prescaler Values 
#define TMC8_STOP		0
#define TMC8_CK			BV(CS00)
#define TMC8_CK8		BV(CS01)
#define TMC8_CK64		(BV(CS00)+BV(CS01))
#define TMC8_CK256		BV(CS02)
#define TMC8_CK1024		(BV(CS02)+BV(CS00))
#define TMC8_EXTFAL		(BV(CS02)+BV(CS01))
#define TMC8_EXTRIS		(BV(CS02)+BV(CS01)+BV(CS00))

//16 bit Timer Counter Prescaler Values 
#define TMC16_CK		BV(CS10)
#define TMC16_CK8		BV(CS11)
#define TMC16_CK64		(BV(CS10)+BV(CS11))
#define TMC16_CK256		BV(CS12)
#define TMC16_CK1024		(BV(CS12)+BV(CS10))



//global variables
volatile unsigned char CaptureCompleate,IntFlagA,IntFlagB,TimerCount;
volatile unsigned int OverflowA,OverflowB;

SIGNAL(SIG_OVERFLOW1)			//timer1 overflow interrupt handler
{
outp(TIMER1HIGH,TCNT1H);        	//reload timer1
outp(TIMER1LOW,TCNT1L);        		//reload timer1
IntFlagA=inp(TIFR);			//store timer interrupt flags 
TimerCount=inp(TCNT0);			//store timer0 count
IntFlagB=inp(TIFR);			//store timer interrupt flags 
OverflowB=OverflowA;			//store timer0 overflow
IntFlagA&=BV(TOV0);IntFlagB&=BV(TOV0);				//mask for timer0 overflow
if(IntFlagA){OverflowB++;outp(TIFR,BV(TOV0));}			//overflow0 interrupt was pending so increment overflow and clear flag
if((IntFlagB)&&(!(IntFlagA))&&(TimerCount<0x80))		//timer0 overflowed as we were reading it
	{OverflowB++;outp(TIFR,BV(TOV0));}			//so increment overflow and clear flag
sbi(TIMSK,TOIE0);			//enable timer0 overflow interrupt
CaptureCompleate=1;			//signal we are done
}

#ifdef USEASM
SIGNAL(SIG_OVERFLOW0) __attribute__((signal,naked));		
#endif
SIGNAL(SIG_OVERFLOW0)						//Timer0 overflow interrupt handler, increments OverflowA
{
#ifdef USEASM
asm volatile (	"push r24"				"\n\t"
      		"push r25"				"\n\t"
		"in r24,__SREG__"			"\n\t"
      		"push r24"				"\n\t"

		"lds r24,OverflowA"			"\n\t"
 		"lds r25,(OverflowA)+1"			"\n\t"
      		"adiw r24,1"				"\n\t"
 		"sts (OverflowA)+1,r25"			"\n\t"
 		"sts OverflowA,r24"			"\n\t"

		"sei"					"\n\t"
		
		"pop r24"				"\n\t"
       		"out __SREG__,r24"			"\n\t"
        	"pop r25"				"\n\t"
      		"pop r24"				"\n\t"
      		"reti"					"\n\t"
		::);
#else
OverflowA++;
#endif
}

#ifdef USEASM
SIGNAL(SIG_OUTPUT_COMPARE1A) __attribute__((signal,naked));
#endif
SIGNAL(SIG_OUTPUT_COMPARE1A)					//Timer1 compare interrupt handler disables T0 overflow int
{
#ifdef USEASM
asm volatile (	"push r24"				"\n\t"
      		"push __tmp_reg__"			"\n\t"
		"in __tmp_reg__,__SREG__"		"\n\t"
      		"push __tmp_reg__"			"\n\t"

		"ldi r24,lo8(-3)"			"\n\t"
     		"in __tmp_reg__,57"			"\n\t"
      		"and __tmp_reg__,r24"			"\n\t"
		"out 57,__tmp_reg__"			"\n\t"

		"pop __tmp_reg__"			"\n\t"
      		"out __SREG__,__tmp_reg__"		"\n\t"
		"pop __tmp_reg__"			"\n\t"
      		"pop r24"				"\n\t"
		"reti"					"\n\t"
		::);
#else
cbi (TIMSK,TOIE0);
#endif
}

void StartCapture(void)
{
OverflowA=0;
TimerCount=0;
CaptureCompleate=0;
outp(BV(TOV1)|BV(OCF1A)|BV(TOV0),TIMSK);//Timer1 & Timer0 overflow,Timer1 Compare interrupts enabled 0xc2
outp(TIMER1LOW,TCNT1H);        		//load timer1 
outp(TIMER1LOW,TCNT1L);        		//
outp(0xff,OCR1H);			//load compare registers to interrupt
outp(0xff,OCR1L);			//256 clocks before timer1 overflows
outp(TMC16_CK256,TCCR1B);		//start timer1 CLK/256 250 ms delay

outp(TMC8_EXTFAL,TCCR0);		//start timer 1 counting external clock on falling edge

//outp(TMC8_CK8,TCCR0);           	//use this line instead to
					//test, instead of external count
					//crystal frequency/8 will be displayed if ok
}

void LcdDelay(void)			//delays aprox 50uS
{
unsigned char Count=LCDDELAY;
while(--Count);
} 

void LcdEnableDelay(void)
{
//empty function we just need a 1uS delay, just calling the funtion will be long enough
}

void Delay(unsigned int Timer)				//delays n mS
{
unsigned char Loops,Count;				// 20 * 50uS delay = 1mS delay;
while(Timer--){Loops=21;while(--Loops){Count=LCDDELAY;while(--Count);}}
}

void WriteLcd(unsigned char Data)
{
cbi(ENABLEPORT,ENABLEPIN);
cbi(D7PORT,D7PIN);
cbi(D6PORT,D6PIN);
cbi(D5PORT,D5PIN);
cbi(D4PORT,D4PIN);
if(Data&0x80)sbi(D7PORT,D7PIN);
if(Data&0x40)sbi(D6PORT,D6PIN);
if(Data&0x20)sbi(D5PORT,D5PIN);
if(Data&0x10)sbi(D4PORT,D4PIN);
LcdEnableDelay();
sbi(ENABLEPORT,ENABLEPIN);
LcdEnableDelay();
cbi(ENABLEPORT,ENABLEPIN);
cbi(D7PORT,D7PIN);
cbi(D6PORT,D6PIN);
cbi(D5PORT,D5PIN);
cbi(D4PORT,D4PIN);
if(Data&0x08)sbi(D7PORT,D7PIN);
if(Data&0x04)sbi(D6PORT,D6PIN);
if(Data&0x02)sbi(D5PORT,D5PIN);
if(Data&0x01)sbi(D4PORT,D4PIN);
LcdEnableDelay();
sbi(ENABLEPORT,ENABLEPIN);
LcdEnableDelay();
cbi(ENABLEPORT,ENABLEPIN);
LcdDelay();
}


void WriteLcdRegister(unsigned char Data)
{
cbi(RSPORT,RSPIN);
WriteLcd(Data);
}


void WriteLcdData(unsigned char Data)
{
sbi(RSPORT,RSPIN);
WriteLcd(Data);
}


void WriteLcdRegisterNibble(unsigned char Data)
{
cbi(RSPORT,RSPIN);
cbi(ENABLEPORT,ENABLEPIN);
cbi(D7PORT,D7PIN);
cbi(D6PORT,D6PIN);
cbi(D5PORT,D5PIN);
cbi(D4PORT,D4PIN);
if(Data&0x80)sbi(D7PORT,D7PIN);
if(Data&0x40)sbi(D6PORT,D6PIN);
if(Data&0x20)sbi(D5PORT,D5PIN);
if(Data&0x10)sbi(D4PORT,D4PIN);
LcdEnableDelay();
sbi(ENABLEPORT,ENABLEPIN);
LcdEnableDelay();
cbi(ENABLEPORT,ENABLEPIN);
LcdDelay();
}


void InitLCD(void)
{
sbi(ENABLEPORT-1,ENABLEPIN);		//set lcd interface pins as output
sbi(D7PORT-1,D7PIN);			//data direction register is one less
sbi(D6PORT-1,D6PIN);			//than data register
sbi(D5PORT-1,D5PIN);
sbi(D4PORT-1,D4PIN);
sbi(RSPORT-1,RSPIN);
Delay(1000);				//wait for power to be stable
WriteLcdRegisterNibble(0x30);		//reset LCD
Delay(20);
WriteLcdRegisterNibble(0x30);
Delay(1);
WriteLcdRegisterNibble(0x30);
Delay(1);
WriteLcdRegisterNibble(0x20);		//set to 4 bit mode
Delay(1);
WriteLcdRegister(0x28);			//set to 2 line display
Delay(1);
WriteLcdRegister(CLEARDISPLAY);
Delay(20);
WriteLcdRegister(LCD_ENTRY_INC);
Delay(1);
WriteLcdRegister(ON);
Delay(1);
}

void PutStringLCD(unsigned char *String)
{
unsigned char Index=0;
while(String[Index])WriteLcdData(String[Index++]);
}

void LcdGotoXY(unsigned int LcdX,unsigned int LcdY)
{
if ( LcdY==0 ) { WriteLcdRegister((1<<LCD_DDRAM)+LCD_START_LINE1+LcdX);  }
else { WriteLcdRegister((1<<LCD_DDRAM)+LCD_START_LINE2+LcdX);  }
}


//display long unsigned integer on lcd with decimal point
void PutLongLCD(unsigned long Value,unsigned char DotPosition)
{
unsigned char LcdData[10]={'0','0','0','0','0','0','0','0','0','0'};
unsigned char Position=10;

do 	{					//convert long to string 
	LcdData[--Position]=(Value%10)+'0';
	Value/=10;
	}while(Value); 
DotPosition=(10-DotPosition);			//convert to position in array
while(Position>=DotPosition)Position--;		//add zeros if required
while(Position<10)
				//display string with .
	{
	if( Position==DotPosition )WriteLcdData('.');  
	WriteLcdData(LcdData[Position++]);
	}
}

//display unsigned char with leading zero if less than 10
void PutUnsignedCharLCD(unsigned char Value)
{
if (Value<10)WriteLcdData('0');
PutLongLCD((long)Value,0);
}


void ClearDisplay(void)
{
unsigned char Loop=0;
WriteLcdRegister(CLEARDISPLAY);
while(Loop<40){LcdDelay();Loop++;}	// 40 * 50uS delay = 2mS delay
}

int main(void)
{
unsigned long Frequency=0,Count=0,LastCount=0;
unsigned long AvFrequencyA,AvFrequencyB=0;
unsigned char IndexA=0,IndexB,IndexC=40,Hours=0,Mins=0,Secs=0;
union{unsigned char Byte[4];unsigned long Long;}TempUnion;

sei();						//enable interrupts
cbi(DDRD,4);                      		//timer0 input pin set as input
while(IndexA<80)eeprom_wb(IndexA++,0);		//zero eeprom
IndexA=0;
InitLCD();
StartCapture();
while(CaptureCompleate==0);			//ignore first counting period
CaptureCompleate=0;
while(1){
while(CaptureCompleate==0)
	{					//go into idle mode so when Timer1 overflows
#ifdef USEASM					//we don't have to finish processing current 
	sbi(MCUCR,SE);				//instruction before we can execute int service
	asm  (	"sleep"		"\n\t"		
		::);
#endif
	}
CaptureCompleate=0;
if(++Secs==60){Secs=0;if(++Mins==60){Mins=0;Hours++;}}
Count=(((long)OverflowB*0x0100)+(long)TimerCount);
if (Count==LastCount)Frequency=0;
else if(Count>LastCount)Frequency=Count-LastCount;
else Frequency=(0x01000000-LastCount)+Count;
LastCount=Count;
if (IndexA==40)IndexA=0;
TempUnion.Long=Frequency;
eeprom_wb(IndexA,TempUnion.Byte[0]);
eeprom_wb(IndexA+1,TempUnion.Byte[1]);
eeprom_wb(IndexA+2,TempUnion.Byte[2]);
eeprom_wb(IndexA+3,TempUnion.Byte[3]);
IndexB=0;
AvFrequencyA=0;
while(IndexB<40)
	{
	eeprom_read_block(&TempUnion,IndexB,4);
	AvFrequencyA+=TempUnion.Long;
	IndexB+=4;
	}
IndexA+=4;
if (IndexA==40)
	{
	if (IndexC==80)IndexC=40;
	TempUnion.Long=AvFrequencyA;
	eeprom_wb(IndexC,TempUnion.Byte[0]);
	eeprom_wb(IndexC+1,TempUnion.Byte[1]);
	eeprom_wb(IndexC+2,TempUnion.Byte[2]);
	eeprom_wb(IndexC+3,TempUnion.Byte[3]);
	IndexB=40;
	AvFrequencyB=0;
	while(IndexB<80)
		{
		eeprom_read_block(&TempUnion,IndexB,4);
		AvFrequencyB+=TempUnion.Long;
		IndexB+=4;
		}
	IndexC+=4;
	}
ClearDisplay();				//display frequency
LcdGotoXY(0,0);
PutLongLCD(Frequency,0);
PutStringLCD(" Hz");
LcdGotoXY(0,1);
PutLongLCD(AvFrequencyA,1);
LcdGotoXY(LCD_WIDTH/2,1);
PutLongLCD(AvFrequencyB,2);
					//display time
LcdGotoXY(LCD_WIDTH/2,0);
PutUnsignedCharLCD(Hours);
if(Secs%2)WriteLcdData(':');
else WriteLcdData(' ');
PutUnsignedCharLCD(Mins);
if(Secs%2)WriteLcdData(':');
else WriteLcdData(' ');
PutUnsignedCharLCD(Secs);

}
}


