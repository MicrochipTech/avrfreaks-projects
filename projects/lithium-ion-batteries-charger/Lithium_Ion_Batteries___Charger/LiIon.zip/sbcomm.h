/**************************************************************************
* SBComm.H         Bit-bang master Smart Battery Interface for 68HC11
*
* This file contains an I2C Driver which implements an I2C bit-bang master
* in C on two Port D pins specifically configured to read data from a
* Smart Battery as defined by the Intel / Duracell spec.
*
*
* The transfer consists of the following transactions:
*
*                          Param to fill in:    Value to set in gI2C.mode:
*  .-------------------.   -----------------   ----------------------------
*  |     I2C START     |
*  >-------------------<
*  |    Chip Address   |     gI2C.address
*  >-------------------<
*  |      R/W bit      |                       I2CMODE_READ or I2CMODE_WRITE
*  >-------------------<
*  | Command           |     gI2C.subaddr1            I2CMODE_SUBADDR1
*  |                   |
*  >-------------------<
*  |   Repeated START  |                              I2CMODE_REPSTART
*  |    Chip Address   |
*  |       R/W bit     |                       I2CMODE_REPREAD or I2CMODE_REPWRITE
*  |     (optional)    |
*  >-------------------<
*  |                   |
*  |       data        |     data - LSByte
*  |       data        |
*  |                   |     data - MSByte
*  |                   |       
*  >-------------------<
*  |      I2C STOP     |
*  `-------------------'
*
*

***************************************************************************
* Written by Don Carveth, Feb.2001.
*
* Based on the I2C software by:
*
* Version 1.00
* (c) Copyright 2000 Grant Beattie
* This software is the property of Grant Beattie who specifically grants
* the user the right to modify, use and distribute this software provided
* this notice is not removed or altered.  All other rights are reserved.
* NO WARRANTY OF ANY KIND IS IMPLIED.  NO LIABILITY IS ASSUMED FOR
* INCIDENTAL OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING FROM
* THE FURNISHING, PERFORMANCE, OR USE OF THIS SOFTWARE.
**************************************************************************/
int SBRead(unsigned char);
unsigned char I2cInit(void);
unsigned char I2cGetLastError(void);

void SBWriteInt(unsigned char, int);
unsigned char SBWrite2Bytes(unsigned char, unsigned char, unsigned char);
void I2CTest(void);

// Values from I2cErrors variable returned via I2cGetLastError():
#define  I2CERR_BUS         0x01  // Misc bus error, pins frozen.
#define  I2CERR_NOACK       0x02  // Device failed to acknowlegde.
#define  I2CERR_NOSTOP      0x04  // SDA held when STOP attempted.
#define  I2CERR_OVERFLOW    0x08  // I2C buffer count request too big.

// Predefined Addresses
#define  ADDR_BATTERY	0x16
#define  ADDR_CHARGER   0x12

// Smart Battery Command Codes - only useful and accessible codes are listed
// Refer to the Smart Battery Data Specification for detailed descriptions
#define  BTY_REMAIN_CAP_ALARM     0x01  // Remaining Capacity Alarm, mAh (r/w)
#define  BTY_REMAIN_TIME_ALARM    0x02  // Remaining Time Alarm, minutes (r/w)
#define  BTY_MODE                 0x03  // Battery Mode, bit flags, (r/w)
                                        // Used for configuration, minor flags
#define  BTY_AT_RATE              0x04  // Used in remaining time calcs, mA (r/w)
#define  BTY_AT_RATE_TIME_TO_FULL 0x05  // Minutes
#define  BTY_AT_RATE_TIME_TO_EMPTY 0x06 // Minutes
#define  BTY_AT_RATE_OK           0x07  // Boolean

#define  BTY_TEMP                 0x08  // Battery Temperature, .1 deg K
#define  BTY_VOLTAGE              0x09  // Battery Voltage, mV
#define  BTY_CURRENT              0x0A  // Battery Current, mA
#define  BTY_AVG_CURRENT          0x0B  // Avg. Current, mA, 1 minute rolling avg

#define  BTY_REL_STATE_CHG        0x0d  // Relative State of Charge, %
#define  BTY_ABS_STATE_CHG        0x0e  // Absolute State of Charge, %
#define  BTY_REMAIN_CAP           0x0f  // Remaining Capacity, mAh
#define  BTY_FULL_CHG_CAP         0x10  // Full Charge Capacity, mAh

#define  BTY_RUN_TIME_TO_EMPTY    0x11  // minutes
#define  BTY_AVG_TIME_TO_EMPTY    0x12  // minutes
#define  BTY_AVG_TIME_TO_FULL     0x13  // minutes

#define  BTY_CHG_CURRENT          0x14  // mA - this value is reported to charger
#define  BTY_CHG_VOLTS            0x15  // mV - this value is reported to charger

#define  BTY_STATUS               0x16  // bit flags - Alarms and condition status
#define  BTY_CYCLE_COUNT          0x17  // Number of full charge/discharge cycles since new
#define  BTY_DESIGN_CAP           0x18  // mAh
#define  BTY_DESIGN_VOLTS         0x19  // mV
#define  BTY_SPEC_INFO            0x1A  // Battery specs, SBS version
#define  BTY_MFR_DATE             0x1B  // Date of manufacture, YYMM
#define  BTY_SERIAL_NUM           0x1c  // Serial Number 

// Smart Charger Command Codes
#define  CHG_STATUS               0x13  // Charger status - set of bit flags
#define  CHG_MODE                 0x12  // Charger mode as set by battery
#define  CHG_CURRENT              0x14  // Charger current as set by battery
#define  CHG_VOLTS                0x15  // Charger voltage as set by battery
#define  CHG_ALARM                0x16  // Charger alarm as set by battery

/*
| Global vars (public)
*/


/*
| Prototypes (public)
*/



