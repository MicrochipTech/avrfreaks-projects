////////////////////////////////////////////////////////////////////////////////
// file			joystick.c
// description	joystick driver
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// includes
////////////////////////////////////////////////////////////////////////////////
#include <mega8.h>
#include "servo.h"


////////////////////////////////////////////////////////////////////////////////
// definitions
////////////////////////////////////////////////////////////////////////////////
#define JOYSTICK_SPEED			0	// joystick speed -> port 0
#define JOYSTICK_STEERING		1	// joystick steering -> port 1
#define JOYSTICK_SERVO_LEFT		0	// servo left -> port 0
#define JOYSTICK_SERVO_RIGHT	1	// servo right -> port 1


////////////////////////////////////////////////////////////////////////////////
// data
////////////////////////////////////////////////////////////////////////////////
volatile char joystick_channel = 0;
volatile char joystick_sample[2];


////////////////////////////////////////////////////////////////////////////////
// function		joystick_init
// description	initialize joystick driver
////////////////////////////////////////////////////////////////////////////////
void joystick_init()
{       
	// set used pins on joystick port as input and disable their internal
	// pullups (ADC is using same pins as PORTC)
	// set the rest of the port's pins as output/zeros
	PORTC = 0x00;
	DDRC = ~0x03;	// only using the two first pins
	  
	// ADC initialization
	// ADC prescaling factor: 8 (so ADC clock lies somewhere in 100-250 KHz)
	// ADC interrupts: on
	ADCSRA = 0x8b;
              
	// ADC 8 bit precision
	// ADC input 0
	ADMUX = 0x20;

	// start the first AD conversion
	ADCSRA |= 0x40;
}


////////////////////////////////////////////////////////////////////////////////
// function		joystick_isr
// description	joystick ADC interrupt routine
////////////////////////////////////////////////////////////////////////////////
interrupt [ADC_INT] void joystick_isr()
{    
	char steering;
	char speed;
	char sample;
	unsigned char left_speed;
	unsigned char right_speed;

                           
	// the ADC sample is 0..255 and we want to scale it to -10..10
	sample = ADCH * ((double) 20) / 255 - 10;

	// treat samples [-2..2] as 0
	if(sample >= -2 && sample <= 2)
	{
		sample = 0;
 	}
 	               
 	// store sample
 	joystick_sample[joystick_channel] = sample;
 	                                                
 	// only change servo speed when we have 2 new samples (one from each channel)
	if(joystick_channel == 1)
	{		                               
		// read the two samples
 		steering = joystick_sample[JOYSTICK_STEERING];
		speed = joystick_sample[JOYSTICK_SPEED];
		
		// the servos are attached the opposite way and therefore we need to do
		// the "+" and "-" below
		left_speed = 150 + speed;
		right_speed = 150 - speed;

		// make the wheelchair turn
		left_speed -= steering;
		right_speed -= steering;
				
		// adjust for not correctly adjusted potientiometers in the servos
        left_speed += 3;
 		right_speed += 1;
		 		         
		// set the new speed for each servo
		servo_set_speed(JOYSTICK_SERVO_LEFT, left_speed);
		servo_set_speed(JOYSTICK_SERVO_RIGHT, right_speed);
	
		// toggle channel
		joystick_channel = 0;
	}
	else
	{
		// toggle channel
		joystick_channel = 1;
	}

	// select new channel
 	ADMUX.0 = joystick_channel;
	 		
	// start a new AD conversion
	ADCSRA |= 0x40;
}

