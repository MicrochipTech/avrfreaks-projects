////////////////////////////////////////////////////////////////////////////////
// file			seat.c
// description	seat driver
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// includes
////////////////////////////////////////////////////////////////////////////////
#include <mega8.h>
#include <delay.h>
#include "servo.h"


////////////////////////////////////////////////////////////////////////////////
// definitions
////////////////////////////////////////////////////////////////////////////////
#define SEAT_SERVO_FOOT	2	// id of leg rest servo
#define SEAT_SERVO_BACK	3	// id of back rest servo


////////////////////////////////////////////////////////////////////////////////
// function		seat_init
// description	initialize seat driver
////////////////////////////////////////////////////////////////////////////////
void seat_init()
{
	// set seat port pin 0..3 to input pins and enable the internal pullups
  	// set seat port pin 4..7 to output pins and write zeros
	DDRB = ~0xf;                                     
	PORTB = 0xf;
    
	// set initial servo position
	servo_set_speed(SEAT_SERVO_FOOT, 100);
	servo_set_speed(SEAT_SERVO_BACK, 100);
	
	// set timer2 prescaler to 1024
	TCCR2 = 0x7;

	// set timer2 value (64 ms interval)
	TCNT2 = 0x100 - 64;

	// enable timer2 overflow interrupt
	TIMSK |= 0x40;
}


////////////////////////////////////////////////////////////////////////////////
// function		seat_isr
// description	read and process input from toggle switches
////////////////////////////////////////////////////////////////////////////////
interrupt [TIM2_OVF] void seat_isr()
{    
	// process leg rest input
	if(PINB.0 == 0)
	{
		servo_inc_speed(SEAT_SERVO_FOOT);
	}
	else if(PINB.1 == 0)
	{
		servo_dec_speed(SEAT_SERVO_FOOT);
	}
	
	// process back rest input
	if(PINB.2 == 0)
	{
		servo_inc_speed(SEAT_SERVO_BACK);
	}
	else if(PINB.3 == 0)
	{
		servo_dec_speed(SEAT_SERVO_BACK);
	}
	
	// reset timer2 value (64 ms interval)
	TCNT2 = 0x100 - 64;
}