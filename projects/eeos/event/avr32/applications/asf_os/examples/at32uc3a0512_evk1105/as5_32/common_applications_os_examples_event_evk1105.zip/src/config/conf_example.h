#ifndef __CONF_EXAMPLE_H__
#define __CONF_EXAMPLE_H__

#define EXAMPLE_NB_TASKS 4

int example_pins[EXAMPLE_NB_TASKS] = {
	LED0_GPIO,
	LED1_GPIO,
	LED2_GPIO,
	LED3_GPIO
};

#endif // __CONF_EXAMPLE_H__
