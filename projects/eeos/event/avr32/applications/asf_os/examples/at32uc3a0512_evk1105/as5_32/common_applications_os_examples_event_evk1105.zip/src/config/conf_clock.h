#ifndef __CONF_CLOCK_H__
#define __CONF_CLOCK_H__

#define CONFIG_SYSCLK_SOURCE        SYSCLK_SRC_OSC0

#endif // __CONF_CLOCK_H__
