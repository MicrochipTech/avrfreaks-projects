#ifndef __CONF_BOARD_H__
#define __CONF_BOARD_H__

#endif // __CONF_BOARD_H__
