unsigned char ReadSharp(void)
{	
        unsigned char help=0x00;
	int i;
					//Initialiazing Sharp Gpd02
      	VinCLK = 0;
       	delay_ms(1);
	while (!Output) {}              // Wait until Sharp has done its measurement
      	Output = 1;                     // Go high
	delay_us(2);			// Wait some more time
       	for (i=0;i<10;i++)              // Why do i have to sample 10 times to get it rotated to the right place?
       	{                               // It should be enoug with 8 times.. Anyway 
		delay_us(2);	        // Wait 
		VinCLK = 0;		// Go low, to make n'th low pulse
		help<<=1;              	// rotate help left one place
	        help = help | Output;	// Output is sampled into "help"
		VinCLK = 1;             // Go high, to make the second half of the square pulse
 	 }
        delay_ms(2);                 	// This line can be deleted, if you measure less than 1.5 ms. 
	return help;                    // return hjelp to your main program
}                                       // IF it doesent work, try changing up on the pauses. or mail me at
					// tallard@online.no, I would be happy to help you.