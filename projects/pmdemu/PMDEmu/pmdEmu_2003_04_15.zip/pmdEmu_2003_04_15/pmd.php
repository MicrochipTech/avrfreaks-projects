
;    
;    PMDEmu - AVR based emulator of Czechoslovak microcomputer PMD-85 originally based on I8080
;    Copyright (C) 2003  Peter Chrenko <peto at kmit dot sk>
;
;    This program is free software; you can redistribute it and/or modify
;    it under the terms of the GNU General Public License as published by
;    the Free Software Foundation; either version 2 of the License, or
;    (at your option) any later version.
;
;    This program is distributed in the hope that it will be useful,
;    but WITHOUT ANY WARRANTY; without even the implied warranty of
;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;    GNU General Public License for more details.
;
;    You should have received a copy of the GNU General Public License
;    along with this program; if not, write to the Free Software
;    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
;

; PMD.ASM

 	 .include 	"8515def.inc"
	 .listmac 

	

;pmd_type:	<- register	
				; 0 = PMD-85-1
				; 1 = PMD-85-2
				; 2 = PMD-85-2 s BASICOM
				; 3 = Didaktik Alfa
				; 4 = PMD-85-2A
				; 5 = PMD-85-2A s BASICOM
				; 6 = PMD-85-2 s PASCALOM 
	                        ; 7 = PMD-85-2 with PASCAL modul
	                        
	 	
     	 .def	DATA		=	r2
     	 .def	pmd_type	=	r3	
	 .def	_zero		=	r4
         .def   _last_result  	=	r5
         .def	state		=	r6
	 .def	_255		=	r7
	 .def	L		=	r8	  
     	 .def	H		=	r9    
	 .def	A		=	r10
	 .def	color		=	r11
	 .def	_idle		=	r12
	 .def	PSW		=	r13
	 .def	_latch_isa_0a	=	r14	; pre VGA
	 .def	_latch_ram	=	r15	; SRAM

     
		
    .def	tmp		=	r16
	.def	tmp2		=	r17
	.def	write_tmp 	= 	r18 ; pre podprogram _write
	.def	kbd_flags	=	r19 ; flagy pre KBD
					    ; 7 = F0
					    ; 6 = STOP
					    ; 5 = SHIFT
					    ; 4 = ALT
					    ; 3 = 
					    ; 2 =
					    ; 1 =
    					    ; 0 =
.equ	STOP_bit	= 6
.equ	SHIFT_bit	= 5
.equ	ALT_bit		= 4
.equ	F0_bit		= 7
 ; lower 4 bits are kb_bitcount


					     	
	.def	B		=	r20	  ; pair register - musnt  use ADDIW	    
	.def	C		=	r21

	.def	D		=	r22	  ; pair register - musnt  use ADDIW
	.def	E		=	r23    
    
	
	.def	_SPL	=	r24	  ; may use addiw _SPL,1
    	.def	_SPH	=	r25
	
	; X je temp address(16bit register)
	; Z is used by ijmp and lpm too often
	
	.def	_PCL	=	r28   ; Y
	.def	_PCH	=	r29



.dseg
t1h:	.byte(1)
action:	.byte(1)
stop:	.byte(1)
.cseg



 		.org	0
 		rjmp 	after_reset

		.org	ICP1addr
		rjmp	keyboard_interrupt

		.org	OVF1addr
		rjmp	reload_timer1

		.org	OVF0addr
		rjmp	timer0_overflow

		
		.DSEG

kb_data:	.byte	1
kb_cols:	.byte   16  	; PMD malo 16 stlpcov selektovanych 74154
f0_received:	.byte	1	; ci bola predosly kod 0xF0
sound_on_off:	.byte	1	; 0xff = sound on, 0x00 = sound off
				
				
		.CSEG
		.include "macro.asm"
		.include "kbd.asm"
		.include "const_generated.asm"		


after_reset:
				clr		_zero			; temporary register : _zero = 0	
				clr		state
				mov		pmd_type,_zero		; PMD-85-1
				sts		color_scheme,_zero	; default : 0 = color scheme, 1 = monochomatic scheme
				ldi		r30,255
				mov		_255,r30
				mov		state,_255	        ; zero break main program, non zero is OK
				sts		sound_on_off,_255
				
				ldi		r30,IDLE
				mov		_idle,r30
				
				ldi		r30, low(RAMEND)               	
				out	   	SPL,r30
				ldi		r30, high(RAMEND)               	
				out		SPH, r30		; ukazatel zasobnika nastaveny

				sts		stop,_zero
				
				;ldi		tmp,'A'
				;mov		r0,tmp
				;rcall		_test_

				;sts	mgf_counter,_255
				;rcall	pmd_85_2_readbit
				;rcall	pmd_85_2_readbit
				;rcall	pmd_85_2_readbit
				;sts	mgf_counter,_255
				;rcall	pmd_85_2_readbit
											
				


				ldi		r30,LATCH_ISA_0a	;VGA base address is 0xa000
				mov		_latch_isa_0a,r30
				ldi		r30,LATCH_RAM
				mov		_latch_ram,r30
				
				
				ldi		r30, ~((1 << PD4)|(1<<PD1)) ; PD4 , PD1 - inputs, others are outputs
				; PD1 = IOCH RDY
				; PD4 = KBD_DATA
				out		DDRD,r30
				out		PORTD,_idle	 ; control bus = idle state	
			
				out		DDRB,_255		 ; portB vystup (address)
				out		DDRC,_255		 ; PORTC output (address)

				; ---------- inicialize PS/2 keyboard ---------------------------------------------
				ldi		kbd_flags,(1<<SHIFT_bit)|(1<<STOP_bit)|(1<<ALT_bit)| 11
							                        ; SHIFT & STOP & ALT released
								      		; f0_received = false
								      		; kb_bitcount := 11
				; ---------- end of inicializing PS/2 keyboard ---------------------------------------------


				;.equ	C_2048 = 256-50	;60 islo OK.		; for 2400 Hz int. freq
				.equ	C_2048 = 256-60	;60 islo OK.		; for 2400 Hz int. freq
				ldi		tmp,C_2048
				out		TCNT0, tmp 
				ldi		tmp,0b11	; spustenie timera 0; cita frekvenciu CLK/64
				out		TCCR0,tmp			


				
				ldi		tmp,(1 << ICNC1)|( 1<< CS10 )    	; ICP interrupt on falling edge, ICNC1=1  =>noise canceller
				                                 			; TIMER 1 zastaveny
				out		TCCR1B,tmp
				
				.equ		T01	= (1 << TICIE1) | (1 << TOIE1)  | ( 1<< TOIE0 )
				.equ		T1	= (1 << TICIE1) | (1 << TOIE1)
					
				ldi		tmp, T01
				out		TIMSK, tmp   		; enable interrupt from ICP pin and TIMER 0,1
				
				out		OCR1BH,_255	
				out		OCR1BL,_255	
				
				;--------------- inicialize internal UART ----------------------------------------------------------
				
				; enable RxD/TxD and interrupts 
    				ldi		r30,  (1 << TXEN)|(1<<RXEN) ; //|( 1 << TXCIE) | (1<<RXEN) (1 << TXEN)| 
				out   	UCR, r30

				
			    	; set UART baud rate (speed) - uncomment one line 
				;.equ	UART_BAUD_SELECT = 12 	; 51= 9600 (8 MHz); 12 = 38400 Bd (8 MHz)
				
				.equ	UART_BAUD_SELECT = 4 	; 115 kbps (9.216 MHz)
				;.equ	UART_BAUD_SELECT = 14 	; 38.4 kbps (9.216 MHz)
				ldi		r30, UART_BAUD_SELECT
    				out		UBRR,r30
				
				;--------------- end of inicializing internal UART ----------------------------------------------------------
				
				; inicializacia mgf ....
				
				sts	file_no,_zero
				

				sei		 	  ; enable global interrupt	
				rcall	vga_inic_graphics
				rcall	vga_clrscr
				rcall	change_pmd_type
				
				;rjmp	_pmd_go
				
				; download FLASH from serial line - command 'F'
				; run PMD-85 emulator - command 'G' or stroke keyboard
				; upload content FLASH to serial line in hexa form - command 'M' 
				
				_uart_wait:
				mov		tmp,kbd_flags
				andi		tmp,0x0f
				cpi		tmp,11				; pressed some key -> GO!
				brne	_pmd_go

				in		tmp,USR
				andi	tmp,1<<RXC
				breq	_uart_wait

				rcall		_get_uart_data
				cpi		tmp,'G'				; GO !
				breq	_pmd_go

				
				cpi		tmp,'M'				; upload content of FLASH memories via serial line in hexa form
				breq	control_monitor				

				cpi		tmp,'F'				; command F 
										; 1. erase all external FLASH
										; 2. from serial line download all its content
				brne	_uart_wait
				
				rcall	flash_erase  
				
				clr	XL
				clr	XH
				clr	r0
				
				_uart_wait2:
				
				rcall	_get_uart_data	; tmp = data
				mov	r1,tmp
				
				rcall	flash_write   ; zapise na adresu r0:X hodnotu v r1
				
				adiw	XL,1		  ; inkrementacia pointera	
				adc		r0,_zero
				rjmp	_uart_wait2
				
				
control_monitor:	; kontrola FLASH
				ldi		XL,0
				ldi		XH,0
				clr		r1
cycle2:
				rcall	flash_read
				rcall	_putch
				;rcall	uart_send_byte ;- as binarny content
				adiw	XL,1
				adc	r1,_zero				
				
				sbrs	r1,4	  ; 16 * 64 KB = 1 MB
				rjmp	cycle2
				rjmp	PC			; loop forever



					
_pmd_go:		
				rcall	print_file_name			

				; moze prepadnut aj nastavit flags pri RESET-e

				out		DDRA,_255			; PA vystup
				out		PORTA,_latch_ram		; PA = LATCH_ISA
				ALE_pulse
				
				
				out		DDRA,_zero			; PORTA = vstup
				MEMRD_active
				



;------------- begin of instruction cycle with handling PSW & flags ------

clr_CH:			
				clc		; C = 0
				clh		; H = 0
set_flags:		
				in		PSW,SREG
save_parity:
				mov		_last_result,A
				
				out		PORTB,_PCL
				out		PORTC,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				cpse		state,_zero		; request to break main cycle ? 
				ijmp					; no -> make instruction cycles
				rjmp		special_action		

;------------- begin of instruction cycle with substractions handling PSW & flags ------

set_flags_sub:		
		 		 mov	_last_result,A
set_flags_cmp:		

				 ldi	tmp,1<< ATMEL_H
				 in	PSW,SREG
				 eor	PSW,tmp


				out		PORTB,_PCL
				out		PORTC,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				cpse		state,_zero		; request to break main cycle ? 
				ijmp					; no -> make instruction cycles
				rjmp		special_action		

				

;------------- begin of instruction cycle without handling PSW & flags ------

i_cycle:
				ldi		ZH, high(i_table)      
i_cycle_turbo:
				out		PORTB,_PCL
				out		PORTC,_PCH
				adiw		_PCL,1			; wait a minute
				
				in		ZL, PINA
				cpse		state,_zero		; request to break main cycle ? 
				ijmp					; no -> make instruction cycles
				
;----------------------- process special action ------
; 0 - change PMD type
; 1 - change color settings
; 2 - file manager key up pressed
; 3 - file manager key down pressed
; 4 - sound on/off
; 5 - print help
special_action:
				MEMRD_deactive
				sbiw		_PCL,1
				
   				ldi		ZL,low(tblAction)
				ldi		ZH,high(tblAction)
				lds		tmp,action
				
				add		ZL,tmp
				adc		ZH,_zero
				
				icall
				mov		state,_255
				out		DDRA,_255			; PORTA out
				out		PORTA,_latch_ram		; PA = LATCH_ISA
				ALE_pulse
				out		DDRA,_zero			; PORTA in
				MEMRD_active
		

				rjmp		i_cycle				; restart instruction cycle
			
tblAction:			rjmp	change_pmd_type
				rjmp	change_color_settings
				rjmp	fm_key_up
				rjmp	fm_key_down
				rjmp	change_sound_on_off
				rjmp	print_help
				rjmp	pause_on_off		; ALT+P

pause_on_off:			lds	tmp,stop
				cp	tmp,_zero
				breq	pause_on_off
				ret

change_sound_on_off:
				rcall	wr_kbd_pc
				ret
 								
change_color_settings:			
					
					lds		XL,pallete_before
			                lds		XH,color_scheme
			                cpi		XH,0
                			brne		cs1
				cs0:                
   					cp		XL,XH
   					breq		cs0_no_change             
                			ldi		ZL,low(vga_pallete0 << 1)		
					ldi		ZH,high(vga_pallete0 << 1)		
					ldi		XL,0
					rjmp		pal_set	


				cs1:	cpi		XL,1
					breq		blink
					ldi		ZL,low(vga_pallete1 << 1)		
					ldi		ZH,high(vga_pallete1 << 1)		
					ldi		XL,1
					rjmp		pal_set
				blink:		
					ldi		ZL,low(vga_pallete2 << 1)		
					ldi		ZH,high(vga_pallete2 << 1)		
					ldi		XL,2
		
				pal_set:
					sts		pallete_before,XL
					rcall		set_pallete		
				cs0_no_change:		


test_ret:				ret
							
_putch:			; vstup: r0; vysle na ser.linku hexa obraz registra r0
				push    r16
				push    r17
				push	r0

				rcall	r0_to_ascii
				mov	r0,r16
				rcall	uart_send_byte
				mov	r0,r17
				rcall	uart_send_byte

				pop	    r0
				pop	    r17
				pop	    r16
				ret

_putch2:			; vstup: r0; print on screen r0 in hexa
				push    r16
				push    r17
				push	r0

				rcall	r0_to_ascii
				mov	r0,r16
				rcall	_putchar
				mov	r0,r17
				rcall	_putchar

				pop	    r0
				pop	    r17
				pop	    r16
				ret

r0_to_ascii: ;	number in r0 convert to hexa(ascii chars) to r16 & r17 

				mov	r16,r0
				mov	r17,r0
				andi	r17,0x0f
				andi	r16,0xf0
				swap	r16

				subi	r16, - '0'
				cpi	r16,'0'+10
				brlo	r16_ok
				subi	r16, - ('A'-'0'-10)
			r16_ok:
				subi	r17, - '0'
				cpi	r17,'0'+10
				brlo	r17_ok
				subi	r17, - ('A'-'0'-10)
			
			r17_ok: ret


.macro	IOCH_RDY
		; check for IOCH RDY ( break if low )
		rcall	_delay
.endmacro
				
_wr_normal:
		MEMRD_deactive
		out		DDRA,_255			; portA output (write mode)
		out		PORTA,DATA
		MEMWR_pulse
		out		DDRA,_zero			; PORTA again to input (read mode)
		MEMRD_active
		
		
_wr_ret:	ret 		; ret 


_write_HL:	; wrapper for write to (HL) address - prepend to _write subroutine	
		mov		XL,L
		mov		XH,H
		
_write: 	
		; write to PMD memory
		; some areas:
		; RAM        0x0000 to 0x7fff  for all models
		; ROM        0x8000 to 0x8fff  for PMD-85-1,PMD-85-2, DIDAKTIK ALFA
		; ROM modul  0x9000 to 0xbfff  for DIDAKTIK ALFA
		; RAM        0x8000 to 0xbfff  for PMD-85/2A
		; videoram   0xc000 to 0xffff  for all models
		  
		out		PORTB,XL    ; output 16 bit address 
		out		PORTC,XH
		
		
		ldi		write_tmp,0x80
		cpse		pmd_type,_zero	; ak pmd-85-1 skip 
		ldi		write_tmp,0xc0
		
		
		cp		XH, write_tmp
		brlo	_wr_normal	
		
		; protected ROM 0x8000 to 0xc000
		sbrs		XH,6	; 0xc0
		ret			; avoid write to ROM
		
		mov		write_tmp, XL
		andi	write_tmp,0b00111111
		cpi		write_tmp,0b00110000
		brsh    _wr_normal   ; same or higher ( >= )
		
		in		color, PINA	; color je tu pouzity ako pomocna premenna
		cp		color,DATA
		breq	_wr_ret			; zapisuje sa ta ista hodnota aka je v pamati ?

		MEMRD_deactive			; ak nie - zapiseme ju do SRAM 
		out		DDRA,_255
		out		PORTA,DATA
		MEMWR_pulse



		; VGA, be now

		andi	XL, 0b11000000
		andi	XH, 0b00111111
		;v XH 	je	Y suradnica ako nasobok 64
		;vo write_tmp je X suradnica ( nasobok 6tic )
		
		mov		ZL,XL
		mov		ZH,XH
		
		lsr		XH
		ror		XL

		lsr		XH
		ror		XL

		add		ZL,XL
		adc		ZH,XH

		.equ	vga_offset =	46*80+7
		.equ	block_0	   =    0x80		; on unvisible videopage 1 - buffer 256 bytes long - sprite cache
		.equ	block_1	   =    block_0+1	; on unvisible videopage 1 - buffer 256 bytes long - sprite cache	 

		subi	ZL, low(-vga_offset)	; offset for PMD window on screen 
		sbci	ZH, high(-vga_offset )
		
		; v Z by mala byt adresa v VGA v zavislosti od Y suradnice
		
		mov		r0,write_tmp
		bst		write_tmp,0		; T:= flag; 0 = write 1+1/2 byte; 1 = 1/2 + 1 byte 
		lsr		r0

		lsl		write_tmp
		sub		write_tmp,r0
		add		ZL,write_tmp
		adc		ZH,_zero		; pripocita sa 2*X  - X/2
		
		
		in		XL,PORTB		; obnovime X
		in		XH,PORTC
		; v Z je uplna adresa zaciatku bloku v HCG pamati prepocitana na 8mice ;)
		
		; upper 4 address bits set to select videoram, disable select SRAM and FLASH
		; DDRA is output
		out		PORTA,_latch_isa_0a		; PA = LATCH_ISA
		ALE_pulse


		ldi		write_tmp,block_0		
		bld		write_tmp,0		; ktora mapa ?
		
		out		PORTB,DATA
		out		PORTC,write_tmp
		out		DDRA,_zero		; akoze citame
		MEMRD_active
		IOCH_RDY
		MEMRD_deactive				; nacitame vysledok z neviditelnej stranky videopamati
		
		out		DDRA,_255		; PA vystup
		
		
		; 3ce je stale na 8 -> ukazuje na bitmask register
		ldi		write_tmp,0xcf
		out		PORTB,write_tmp
		ldi		write_tmp,0x03
		out		PORTC,write_tmp
		out		PORTA,_zero		; nezmen obsah latch registrov
		IOWR_pulse
			
		out		PORTB,ZL
		out		PORTC,ZH
		;empty write
		MEMWR_active



		clr		r1
		brts	__wr1		; 0 = 1 + 1/2 bytes;    1 = 1/2 + 1 bytes 

__wr0:
		adiw	ZL,1
		
		ldi		write_tmp,0b11110000


			
		bst		DATA,4
		bld		r1,7
		bld		r1,6
		bst		DATA,5
		bld		r1,5
		bld		r1,4

		rjmp	_go_away			

		
__wr1:	
		sbiw	ZL,1
		
		ldi		write_tmp,0b00001111
		
		bst		DATA,0
		bld		r1,3
		bld		r1,2
		bst		DATA,1
		bld		r1,1
		bld		r1,0

		; continue to _go_away
		

_go_away:
		; zapis posledneho bytu polovicky - spolocne pre obe situacie 1+1/2 aj 1/2+1 !
		clr		color
		bst		DATA,7
		bld		color,1
		bst		DATA,6
		bld		color,0
		inc		color
		
		IOCH_RDY
		MEMWR_deactive		; dokoncenie zapisu prveho (celeho) bytu
		
		;druhy polbyte
		
		eor		write_tmp,r1		; maska 
		                                        ; nastavime priznaky , skok az neskor !!!				
		breq		no_paint1			; ak netreba nic mazat
		
		out		PORTA,write_tmp		; bit mask - robime iba s nasou stvoricou	
		ldi		write_tmp,0xcf
		out		PORTB,write_tmp
		ldi		write_tmp,0x03
		out		PORTC,write_tmp
		IOWR_pulse
		
		; ocernenie stvorice bodov
		out		PORTB,ZL
		out		PORTC,ZH
		
		out		DDRA,_zero		
		MEMRD_active
		IOCH_RDY
		MEMRD_deactive			; nacitame do LATCH 8 pixelov


		out		DDRA,_255		; PA vystup
		out		PORTA,_zero		; ociernenie, cierna farba = 0  
		MEMWR_active
		IOCH_RDY
		MEMWR_deactive

		; nafarbenie prislusnou farbou
		cp		r1,_zero		; je vobec co farbit ?		
		breq		no_paint2
no_paint1:		
		out		PORTB,ZL
		out		PORTC,ZH
		
		out		DDRA,_zero		
		MEMRD_active
		IOCH_RDY
		MEMRD_deactive			; povodna farba 8 mice

		out		DDRA,_255		
		ldi		write_tmp,0xcf
		out		PORTB,write_tmp
		ldi		write_tmp,0x03
		out		PORTC,write_tmp

		out		PORTA,r1
		IOWR_pulse


		out		PORTB,ZL
		out		PORTC,ZH
		out		PORTA,color
		MEMWR_active
		IOCH_RDY
		MEMWR_deactive

no_paint2:
		; uklid :-) zbernic 
    		
    		out		PORTA,_latch_ram		; PA = LATCH_ISA
		ALE_pulse

		out		DDRA,_zero			; PORTA vstup
		MEMRD_active
		ret 		; ret 

<?php function CYCLES($n)
{
		return	"	nop\n";
		return	"	subi		cycles,$n\n";
}
?> 		

;***********************************************************************************************
;***********************************************************************************************
;***********************************************************************************************
;***********************************************************************************************

_nop:
_none:
_mov_aa:    
_ei: 
_mov_bb: 
_mov_hh:	
_mov_ll:
_mov_cc: 
_mov_dd:	
_mov_ee:
  Wniop:   
  niop:	    
  _di:
  _hlt:
		<?php echo CYCLES(4) ?>
		rjmp	i_cycle_turbo
		





<?
	
function prepare($r)
{
   	if( $r == 'i' )
   	{
   		echo "
			out		PORTB,_PCL
			out		PORTC,_PCH
			adiw		_PCL,1
		     ";
   	}	
   	
   	
   	if( $r == 'm' )
   	{
   		echo "
   			out		PORTB,L
			out		PORTC,H
		     ";
	}
		     		
   	if( $r == 'm' || $r == 'i')
   	{
		echo	CYCLES(7) ."
         		in		DATA,PINA
         		";
         	return "DATA";     
         }
         else
         {
         	echo "\n" . CYCLES(4) ."\n";
         	return strtoupper($r);
         }         		
	
}

$reg = array ( 'a', 'b','c','d','e','h','l', 'm','i' );
 
 foreach( $reg as $r1) 
 {
   $R1 = strtoupper($r1);
   
   if( $r1 != 'm' && $r1 != 'i' )
   {
   
   echo "_inr_$r1:\n";
   INR8($R1);
   echo "\n";

   echo "_dcr_$r1:\n";
   DCR8($R1);
   echo "\n";
   
   echo "_mvi_$r1:\n";
   MVI($R1);
   echo "\n";
   
   echo "_mov_${r1}m:\n";
   MOVRM($R1);
   echo "\n";

   echo "_mov_m${r1}:\n";
   MOVMR($R1);
   echo "\n";
   
   }
   
   
   if( $r1 != 'i' )
     echo "_add_$r1:\n";
   else
     echo "_adi:\n";
     
   ADD8(prepare($r1));
   echo "\n";


   if( $r1 != 'i' )
     echo "_adc_$r1:\n";
   else
     echo "_aci:\n";

   ADC8(prepare($r1));
   echo "\n";

  if( $r1 != 'i' )
     echo "_sub_$r1:\n";
   else
     echo "_sui:\n";

   SUB8(prepare($r1));
   echo "\n";

   
   if( $r1 != 'i' )
     echo "_sbb_$r1:\n";
   else
     echo "_sbi:\n";

   SBB8(prepare($r1));
   echo "\n";

   
   if( $r1 != 'i' )
     echo "_cmp_$r1:\n";
   else
     echo "_cpi:\n";
   
   CMP8(prepare($r1));
   echo "\n";

   $r = "i";
   if( $r1 != 'i' ) $r = "a_$r1";

   echo "_an$r:\n";
   AND8(prepare($r1));
   echo "\n";

   echo "_or$r:\n";
   OR8(prepare($r1));
   echo "\n";

   echo "_xr$r:\n";
   XOR8(prepare($r1));
   echo "\n";

 }



function INR8($r) 
{
  echo "
		bst		PSW,0 
		ldi		tmp,1
		add		$r,tmp
		in		PSW,SREG
		bld		PSW,0 	; copy old CY
		mov		_last_result,$r
		".CYCLES(4)."
		rjmp		i_cycle_turbo
       ";

}



function DCR8($r)
{
	echo "
		 bst		PSW,0 		; save CY
		 ldi		tmp,1
		 sub		$r,tmp

		 mov		_last_result,$r
		 in		PSW,SREG
		 bld		PSW,0 ; obnovenie CY
		 ".CYCLES(4)."
		 rjmp		i_cycle_turbo";
}		 
		 

?>

_inr_m:	
		out		PORTB,L
		out		PORTC,H
		bst		PSW,0 		; wait a minute & save CY
		in		DATA,PINA

		ldi		tmp,1
		add		DATA,tmp

		mov		_last_result,DATA
 		in		PSW,SREG
		bld		PSW,0 ; obnovenie CY

		rcall	_write_HL
		<? echo CYCLES(11); ?>
		rjmp	i_cycle

_dcr_m:	
		out		PORTB,L
		out		PORTC,H
		bst		PSW,0 		; wait a minute & save CY
		in		DATA,PINA

          	ldi		tmp,1
		sub		DATA,tmp
		
		mov		_last_result,DATA
        	in		PSW,SREG
		bld		PSW,0 	; obnovenie CY

		rcall		_write_HL
	 	<? echo CYCLES(11); ?>
		rjmp	i_cycle



_inx_b:
			subi	C,low(-1)
			sbci	B,high(-1)
 		 	<? echo CYCLES(6); ?>
			rjmp	i_cycle_turbo

_inx_d:
			subi	E,low(-1)
			sbci	D,high(-1)
 		 	<? echo CYCLES(6); ?>
 		 	rjmp	i_cycle_turbo

_inx_h:		
			ldi	tmp,1
			add	L,tmp
			adc	H,_zero
 		 	<? echo CYCLES(6) ?>
			rjmp	i_cycle_turbo

_inx_sp:
			adiw 	_SPL,1
 		 	<? echo CYCLES(6) ?>
			rjmp	i_cycle_turbo


_dcx_b:
			subi	C,low(1)
			sbci	B,high(1)
 		 	<? echo CYCLES(6) ?>
			rjmp	i_cycle_turbo
			

_dcx_d:		
			subi	E,low(1)
			sbci	D,high(1)
 		 	<? echo CYCLES(6) ?>
			rjmp	i_cycle_turbo
			

_dcx_h:
			ldi	tmp,1
			sub		L,tmp
			sbc		H,_zero
 		 	<? echo CYCLES(6) ?>
			rjmp	i_cycle_turbo
			
_dcx_sp:
			sbiw 	_SPL,1
 		 	<? echo CYCLES(6) ?>
			rjmp	i_cycle_turbo



;*********************** scitanie 16-bit **********
; ovplynuje len CY 

<?

function LXI( $r1, $r2)
{
   echo "
		out		PORTB,_PCL
		out		PORTC,_PCH
		adiw	_PCL,1
		in		$r2,PINA 
		out		PORTB,_PCL
		out		PORTC,_PCH
		adiw	_PCL,1
		in		$r1,PINA
	        ".CYCLES(10)."	
		rjmp		i_cycle_turbo
  ";
}
function ADD16($h,$l)
{
	echo "
	                ;  high,low 
			ror		PSW		
			add		L,$l
			adc		H,$h
			rol		PSW
 		 	".CYCLES(11)."
		 	rjmp		i_cycle_turbo
   "; 
}  ?>

_dad_b:		<? ADD16('B','C'); ?>
_lxi_b:		<? LXI('B','C'); ?>

_dad_d:		<? ADD16('D','E'); ?>
_lxi_d:		<? LXI('D','E'); ?>

_dad_h:		<? ADD16('H','L'); ?>
_lxi_h:		<? LXI('H','L'); ?>

_dad_sp:	<? ADD16('_SPH','_SPL'); ?>
_lxi_sp:	<? LXI('_SPH','_SPL'); ?>


<?


function SUB8($r)
{
 	echo	 "
		 sub	A,$r
		 rjmp	set_flags_sub
			";
}			


function SBB8($r)
{
 	echo	 "
		 ror	PSW
		 sez		; must be	
		 sbc	A,$r
		 rjmp	set_flags_sub
		 ";
}			



function  ADD8($r)
{  
  	echo  "
	     add A,$r
	     rjmp	set_flags
	     ";
} 

function  ADC8($r)
{  
  	echo  "
	     ror	PSW
	     adc 	A,$r
	     rjmp	set_flags
	     ";
} 



function CMP8($r)
{
	echo "
			mov	tmp,A
			sub	tmp,$r
			mov	_last_result,tmp
			rjmp	set_flags_cmp
	     ";
}


function AND8($r)
{
   echo 	"
   		and		A,$r
   		rjmp		clr_ch
   		";
}  		


function XOR8($r)
{
   echo 	"
   		eor		A,$r
   		rjmp		clr_ch
   		";
}  		


function OR8($r)
{
   echo "
   		or		A,$r
   		rjmp		clr_ch
   		";
}  		


?>






;**************************** MOV ra,rb  ********
<?
 $reg = array ( 'a', 'b','c','d','e','h','l' );
 
 foreach( $reg as $r1) 
 {
   $R1 = strtoupper($r1);
   foreach( $reg as $r2 )
   
   {
   $R2 = strtoupper($r2);
   if( $R2 != $R1 )
     echo "_mov_$r1$r2:\t
     		mov		$R1,$R2
          ".CYCLES(4)."
		rjmp		i_cycle_turbo
          ";
   }
 
 
 
 
 }


function MVI($r)
{
   echo "
		out		PORTB,_PCL
		out		PORTC,_PCH 
		adiw		_PCL,1 
		in		$r,PINA 
		".CYCLES(7)."
		rjmp		i_cycle_turbo
	";	
}

function MOVRM($r)
{
   echo "
		out		PORTB,L
		out		PORTC,H
	".CYCLES(7)."
		in		$r,PINA
		rjmp		i_cycle_turbo
	";
		
	
	
}	

function MOVMR($r)
{
	echo	"
			mov		DATA,$r
			rcall	_write_HL
		".CYCLES(7)."
			rjmp	i_cycle
		";	
}
?>




;******************************** bitove operacie ********************
			.equ	_CY  =		1
			.equ	_Z	 = 		2
			.equ	_S	 =		0x10
			.equ	_AC	 =		0x20

_cmc:		
			ldi		tmp,_CY
			eor		PSW,tmp	; C u Atmela je 0.bit
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

_stc:	
			set
			bld		PSW,0
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

_cma:		; PSW unchanged
			com		A
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

_rlca:			;okrem CY neovplyvnuje nic
			ror		PSW
			bst		A,7
			rol		A
			bld		A,0
			rol		PSW
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

_rrca:			;okrem CY neovplyvnuje nic
			ror		PSW
			bst		A,0
			ror		A
			bld		A,7
			rol		PSW
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

_rla:			;okrem CY neovplyvnuje nic
			ror		PSW
			rol		A
			rol		PSW
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo
			
_rra:			;okrem CY neovplyvnuje nic
			ror		PSW
			ror		A
			rol		PSW
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

;************************** zasobnikove sracky *******************************
<?php
function PUSH16($h,$l, $cycles)
{

      echo 	"		
			mov		DATA,$h    ; high
			sbiw		_SPL,1
			mov		XL,_SPL
			mov		XH,_SPH
			rcall	_write
			sbiw		_SPL,1
			mov		XL,_SPL
			mov		XH,_SPH
			mov		DATA,$l	   ; low
			rcall	_write
		".CYCLES($cycles)."		
		";
			
}

function POP16( $r0,$r1, $c) 
{
   echo "
			out		PORTB,_SPL
			out		PORTC,_SPH
			adiw	_SPL,1
			in		$r1,PINA
			out		PORTB,_SPL
			out		PORTC,_SPH
			adiw	_SPL,1
			in		$r0,PINA			
	".CYCLES($c)."		
	";		
}

?>

_push_h:	<?	PUSH16('H','L',11); ?>
			rjmp	i_cycle
_push_d:	<?	PUSH16('D','E',11); ?>
			rjmp	i_cycle
_push_b:	<?	PUSH16('B','C',11); ?>
			rjmp	i_cycle
_push_a:		
			; from PSW & _last_result ---> tmp
			; tmp & A --> STACK
			ldi		tmp2,0x02
			bst		PSW,0
			bld		tmp2,0  ; CY copied
			bst		PSW,1
			bld		tmp2,6  ; Z copied
			bst		PSW,2
			bld		tmp2,7	; S copied
			bst		PSW,5
			bld		tmp2,4	; A copied
			rcall	odd_parity	;  T = P bit
			bld		tmp2,2	;P copied
		<?	PUSH16('A','tmp2',11); ?>    
			rjmp	i_cycle

			
_pop_h:		<? POP16('H','L',10); ?>
			rjmp	i_cycle_turbo
_pop_d:		<? POP16('D','E',10); ?>
			rjmp	i_cycle_turbo
_pop_b:		<? POP16('B','C',10); ?>
			rjmp	i_cycle_turbo

_pop_a:			
		<?	POP16('A','tmp',10); ?>
			ldi		tmp2,0x80
			mov		PSW,tmp2	; I = 1 => mustbe !!! , inak bysa mohlo zakazat prerusenie a blbla by klavesnica a speaker
			bst		tmp,0  	; CY copied
			bld		PSW,0
			bst		tmp,6   ; Z copied
			bld		PSW,1
			bst		tmp,7	; S copied
			bld		PSW,2
			bst		tmp,4	; A copied
			bld		PSW,5
			mov		_last_result,_zero
			sbrs		tmp,2   ; T = P; if tmp.2 == 1 => skip next
						; parita nuly je jedna !!!, 0x01 => P=0; 0x5b => P = 0
		
			inc		_last_result	;	_last_result := 1			


			rjmp	i_cycle_turbo

;**************** calls & jumps & rets *****************************************



odd_parity:	; vypocita paritu z registra _last_result; vystup bude v bite T 
		; parita v 8080 znamenala neparnu paritu => paritny bit doplnal vysledok operacie do neparneho poctu bitov
	        ; even parity = parna 
	        ; odd  parity = neparna
	        
		mov 	r0,_last_result
		swap 	r0
		eor 	r0,_last_result
		mov	r1,r0
		lsr	r1
		lsr	r1
		eor	r0,r1
		mov	r1,r0
		lsr	r1
		eor	r0,r1
		com	r0	
		bst	r0,0
		ret
	
	

		
_ret:		
			<? POP16('_PCH','_PCL',10) ?>
			rjmp	i_cycle_turbo

_rpe:	
			rcall	odd_parity
			brts	_ret
						; EVEN = (PARITY == 1)
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rpo:       
			rcall	odd_parity
			brtc	_ret
						; ODD = (PARITY == 0)
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rz:			out		SREG,PSW
			brbs	1,_ret	  ;	bit 1 of SREG is Z and if is set  ( 1 ) do return
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rnz:			out		SREG,PSW
			brbc	1,_ret	  ;	bit 1 of SREG is Z and if is clear  ( 0 ) do return
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rc:			out		SREG,PSW
			brbs	0,_ret	  ;	bit 0 of SREG is C and if is set  ( 1 ) do return
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rnc:			out		SREG,PSW
			brbc	0,_ret	  ;	bit 0 of SREG is C and if is clear  ( 0 ) do return
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rp:        		;return PLUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brpl	_ret	  ;	bit 2 of SREG is N and if is CLEAR !!!!  ( 0 ) do return
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo

_rm:        		;call MINUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brmi	_ret	  ;	bit 2 of SREG is N and if is SET !!!!  ( 1 ) do return
			<? echo CYCLES(5); ?>
			rjmp	i_cycle_turbo


_call:		
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw	_PCL,1
			in		tmp,PINA
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw	_PCL,1
			in		tmp2,PINA
			<? echo CYCLES(6); ?>
_rst_entry:
			<? PUSH16('_PCH','_PCL',11); ?>	 ; navratova adresa do stacku
			mov		_PCL,tmp
			mov		_PCH,tmp2
			rjmp	i_cycle

_cpe:	
			rcall	odd_parity
			brts	_call 		; EVEN = (PARITY == 1)
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_cpo:       
			rcall	odd_parity
			brtc	_call 		; ODD = (PARITY == 0)

			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo


_cz:			out	SREG,PSW
			brbs	1,_call	  ;	bit 1 of SREG is Z and if is set  ( 1 ) do call
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_cnz:			out	SREG,PSW
			brbc	1,_call	  ;	bit 1 of SREG is Z and if is clear  ( 0 ) do call
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo


_cc:			out	SREG,PSW
			brbs	0,_call	  ;	bit 0 of SREG is C and if is set  ( 1 ) do call
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_cnc:			out	SREG,PSW
			brbc	0,_call	  ;	bit 0 of SREG is C and if is clear  ( 0 ) do call
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_cp:        		;call PLUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brpl	_call	  ;	bit 2 of SREG is N and if is CLEAR !!!!  ( 0 ) do call
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_cm:        		;call MINUS		-> use N(negative) flag at atmel
			out		SREG,PSW
			brmi	_call	  ;	bit 2 of SREG is N and if is SET !!!!  ( 1 ) do call
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo


			
_jmp:
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		tmp,PINA
			out		PORTB,_PCL	
			out		PORTC,_PCH
			mov		_PCL,tmp
			in		_PCH,PINA
			<? echo CYCLES(10); ?>
			rjmp		i_cycle_turbo

_jpe:	
			rcall	odd_parity
			brts	_jmp 		; EVEN = (PARITY == 1)
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_jpo:			rcall	odd_parity
			brtc	_jmp 		; ODD = (PARITY == 0)
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_jz:			out	SREG,PSW
			brbs	1,_jmp	  ;	bit 1 of SREG is Z and if is set  ( 1 ) do jump
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_jnz:			out	SREG,PSW
			brbc	1,_jmp	  ;	bit 1 of SREG is Z and if is clear  ( 0 ) do jump
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo


_jc:			out	SREG,PSW
			brbs	0,_jmp	  ;	bit 0 of SREG is C and if is set  ( 1 ) do jump
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_jnc:			out	SREG,PSW
			brbc	0,_jmp	  ;	bit 0 of SREG is C and if is clear  ( 0 ) do jump
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_jp:        		;call PLUS	-> use N(negative) flag at atmel
			out	SREG,PSW
			brpl	_jmp	  ;	bit 2 of SREG is N and if is CLEAR !!!!  ( 1 ) do jump
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo

_jm:        		;call MINUS	-> use N(negative) flag at atmel
			out		SREG,PSW
			brmi	_jmp	  ;	bit 2 of SREG is N and if is SET !!!!  ( 1 ) do jump
			adiw	_PCL,2
			<? echo CYCLES(10); ?>
			rjmp	i_cycle_turbo
                                                 

;******************* RST instructions ****************************************			

<? function RST($n)
   { 
	echo "
			ldi		tmp,low(8*$n)
			ldi		tmp2,low( high(8*$n))
			rjmp	_rst_entry
	     ";
   }
   
   for($i = 0; $i < 8 ; $i++ )
   {
    echo "_rst$i:\t";
    RST($i);
   } 	     	 	

?>
;************************ OPERACIE S pamatou *********************

_lda:		
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		tmp,PINA
			out		PORTB,_PCL	
			out		PORTC,_PCH
			subi		_PCL,low(-1)	; adiw _PCL,1; decomposition due make little time delay
			in		tmp2,PINA
			
			out		PORTB,tmp
			out		PORTC,tmp2
			sbci		_PCH,high(-1)	; adiw _PCL,1; decomposition due make little time delay
			in		A,PINA
			<? echo CYCLES(13); ?>
			rjmp		i_cycle_turbo			

_sta:		
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		XL,PINA
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		XH,PINA
			mov		DATA,A
			rcall		_write
			<? echo CYCLES(13); ?>
			rjmp		i_cycle	
			

_mvi_m:
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		DATA,PINA
			rcall		_write_HL
			<? echo CYCLES(10); ?>
			rjmp		i_cycle


;************************ a := [ r16 ] nepriame adresovanie pomocou r16. *****

_ldax_b:	
			out		PORTB,C
			out		PORTC,B
			<? echo CYCLES(7); ?>
			in		A,PINA
			rjmp		i_cycle_turbo

_stax_b:	
			mov		XL,C
			mov		XH,B
			mov		DATA,A
			rcall		_write
			<? echo CYCLES(7); ?>
			rjmp		i_cycle


_ldax_d:	
			out		PORTB,E
			out		PORTC,D
			<? echo CYCLES(7); ?>
			in		A,PINA
			rjmp		i_cycle_turbo

_stax_d:	
			mov		XL,E
			mov		XH,D
			mov		DATA,A
			rcall		_write
			<? echo CYCLES(7); ?>
			rjmp		i_cycle

_lhld:
			out		PORTB,_PCL
			out		PORTC,_PCH
			adiw		_PCL,1
			in		XL,PINA
			
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		XH,PINA

			out		PORTB,XL
			out		PORTC,XH
			subi		XL,low(-1)	; decomposition due make little time delay
			in		L,PINA
			
			out		PORTB,XL
			out		PORTC,XH
			sbci		XH,high(-1)	; decomposition due make little time delay
			in		H,PINA
			<? echo CYCLES(16); ?>
			rjmp		i_cycle_turbo


_shld:			out		PORTB,_PCL
			out		PORTC,_PCH
			adiw		_PCL,1
			in		XL,PINA
			out		PORTB,_PCL	
			out		PORTC,_PCH
			adiw		_PCL,1
			in		XH,PINA

			mov		DATA,L
			rcall		_write
			adiw		XL,1
			mov		DATA,H
			rcall		_write
			<? echo CYCLES(16); ?>
			rjmp		i_cycle	


_sphl:
			mov		_SPL,L
			mov		_SPH,H
			<? echo CYCLES(6); ?>
			rjmp		i_cycle_turbo


_pchl:
			mov		_PCL,L
			mov		_PCH,H
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo


_xthl:			mov		XL,_SPL
			mov		XH,_SPH
			
			out		PORTB,XL
			out		PORTC,XH
			mov		DATA,L			
			in		L,PINA
			rcall		_write
			adiw		XL,1

			out		PORTB,XL
			out		PORTC,XH
			mov		DATA,H			
			in		H,PINA
			rcall		_write
			<? echo CYCLES(19); ?>
			rjmp		i_cycle			


_xchg:			eor		E,L
			eor		L,E
			eor		E,L

			eor		D,H
			eor		H,D
			eor		D,H
			<? echo CYCLES(4); ?>
			rjmp		i_cycle_turbo

_daa:		
			clr		tmp 	    ; add register
			mov		tmp2,A	
			andi		tmp2,0x0f   ; low nibble of A
			cpi		tmp2,9 + 1
			brlo		_daa1
			ori		tmp,6
	_daa1:		sbrc		PSW,ATMEL_H		
			ori		tmp,6
			sbrc		PSW,ATMEL_C
			ori		tmp,0x60
			mov		tmp2,A
			cpi		tmp2,0x9f+1
			brlo		_daa2
			ori		tmp,0x60
	_daa2:		
			cpi		tmp2,0x99+1
			brlo		_daa3
			set
			bld		PSW,ATMEL_C ; CY :=1	
	_daa3:		
			cpi		tmp2,0x90+1
			brlo		_daa4
			andi		tmp2,0x0f   ; low nibble of A
			cpi		tmp2,9 + 1
			brlo		_daa4
			ori		tmp,0x60
	_daa4:		
			add		A,tmp
			<? echo CYCLES(4); ?>
			rjmp		save_parity
					
			
.macro xxxxzxz			
			; by look up table in FLASH memory ; flash_read ( r1 =FLASH[r0:X] )
			
			mov		XL,A
			clr		XH
			bst		PSW,0
			bld		XH,0
			bst		PSW,5
			bld		XH,1
			
			
			lsl		XL	; X = X*2
			rol		XH
			
			subi 		XL, LOW( -C_daa_start)
			sbci 		XH, HIGH( -C_daa_start)
			
			mov		r1,_zero  
			rcall		flash_read
			mov		A,r0
			
			inc		XL		; X is pair number, this is effectiveally (addiw XL,1)
			rcall		flash_read
			mov		PSW,r0
			mov		_last_result,A			
			<? echo CYCLES(4); ?>
			rjmp		in_out_end_force	
.endmacro



;*********************************************************************
;****            I/O subsystem                                    ****
;*********************************************************************
in_channels:
			rjmp	in_channel0
			rjmp	in_channel1	
			rjmp	in_channel2
            rjmp	in_channel3
            rjmp	in_channel4
            rjmp	in_channel5
            rjmp	in_channel6
            rjmp	in_channel7

out_channels:
			rjmp	out_channel0
			rjmp	out_channel1	
			rjmp	out_channel2
            rjmp	out_channel3
            rjmp	out_channel4
            rjmp	out_channel5
            rjmp	out_channel6
            rjmp	out_channel7

rd_usart_status:
			
			
			mov	tmp2,pmd_type
			
			cpi	tmp2,0
			breq	pmd_1		; PMD-85-1
			cpi	tmp2,3	
			breq	pmd_1		; Didaktik Alfa

			;	tu mozeme plnit data pre PMD-85-2
			; data su posielanie rychlostou 1200 Bd, modulovane frekvenciou 1200 Hz pomocou XOR :-)
			; 1 START BIT, 8 udajovuch bitov ( d0 - d7 )  , STOP bit, bezparity
			; prijem dat sa uskutocnuje citanim 7.bitu stavoveho registra USART-u
			
			rcall 	pmd_85_2_readbit	; funkcia nam vracia v registi tmp status usartu					
			
			rjmp	pmd_2			
pmd_1:			ldi		tmp,6	; data vzdy prijate; TxE = 1, RxRDY=1 
pmd_2:			                        
			
			;in	tmp2,TIFR
			;bst	tmp2,TOV0
			; T = TxRDY
			
			lds	tmp2,tr_complete
			bst	tmp2,7
			bld		tmp,0	; TxC (vyslane) T -> A[0.bit]
			mov		A,tmp
			rjmp	in_out_end_force

			
							





rd_kbd_pb:	lds		tmp,kbd_ports + 0  ; hodnota PA 
			andi	tmp,0b1111		; nechame iba spodne 4 bity
			ldi	XL, low( kb_cols )
			ldi	XH, high( kb_cols )
			add	XL,tmp
			;adc	XH,_zero
			ld	A,X				; nacitame hodnotu stlpca = riadkova hodnota
			mov	tmp,kbd_flags
			andi	tmp,(1<<SHIFT_bit)|(1<<STOP_bit)
			or	A,tmp				; ZAPISEME hodnotu SHIFT + STOP
			
			rjmp	i_cycle

rd_pmd_kbd: andi	tmp2,0b11       ; interne cislo portu v 8255
			cpi		tmp2,1          ; PB ?
			breq	rd_kbd_pb
			ldi		XL, low( kbd_ports )
			ldi		XH, high( kbd_ports )
			add		XL,tmp2
			adc		XH,_zero
			ld		A,X				; nacitame do reg. A
			rjmp	i_cycle


_in:		
			out		PORTB,_PCL
			out		PORTC,_PCH
			adiw	_PCL,1
			<? echo CYCLES(11); ?>

			in		tmp,PINA
			
			mov	tmp2,tmp		; v tmp2 je cislo portu

			
			andi	tmp,0b10001100
			cpi	tmp,0b10000100
			breq	rd_pmd_kbd
			cpi		tmp,0b10001000
			breq	rd_rom_modul
			cpi		tmp,0b00001100
			breq	rd_channel_0_7
			cpi	tmp2,0xf0		; support for USART Didaktiku Alfa ....
			breq	in_channel1
			cpi	tmp2,0xf1
			breq	in_channel1
			
			rjmp	i_cycle		; citanie z neexistujuceho portu 
			
in_channel1:  
			;1C a 1E  = DATA
			;rozskok podla tmp2 na citanie statusu/ dat z uartu
			
			
			bst	tmp2,0 ; DATA/status
			brts	rd_usart_status
rd_usart_data:
			rcall	next_byte_from_tape		; nici Z
			mov	A,r0
			
			
in_out_end_force:
			
			out		DDRA,_255	; PA vystup
			out		PORTA,_latch_ram		; PA = LATCH_RAM
			ALE_pulse
				
			out		DDRA,_zero		; PORTA = vstup
			MEMRD_active
			
			rjmp	i_cycle

.dseg
_rom:	.byte(4)	
.cseg

rd_rom_modul: 
			andi	tmp2,0b11       ; interne cislo portu v 8255
			breq	rd_rom_modul_from_flash
			ldi		XL,low(_rom)
			ldi		XH,high(_rom)
			add		XL,tmp2
			adc		XH,_zero
			ld		A,X
			rjmp	i_cycle

rd_channel_0_7:
			mov		tmp,tmp2
			swap	tmp
			andi	tmp,0x0f
			ldi		ZH,high(in_channels)
			ldi		ZL,low(in_channels)
			add		ZL,tmp
			adc		ZH,_zero
			ijmp



rd_rom_modul_from_flash: ;r0 = [r1:X] 
			
			ldi		ZL,low(rom_modul_table<<1)
			ldi		ZH,high(rom_modul_table<<1)
			mov		tmp,pmd_type
			add		tmp,tmp				; tmp := pmd_type * 2
			add		ZL,tmp
			adc		ZH,_zero
			
			lpm	
			mov		XL,r0
			adiw		ZL,1
			lpm
			mov		XH,r0
			
						
			clr		r1		; byte3 - rom moduls are stored on begining of FLASH space
			lds		tmp,_rom + 1	; byte1
			add		XL,tmp
			lds		tmp,_rom + 2	; byte2
			;andi		tmp,0b01111111
			adc		XH,tmp
			adc		r1,_zero
			
			rcall	flash_read
			mov		A,r0
			rjmp	in_out_end_force

			.include "pmd852.asm"
			

delay:		; cakacia slucka
			;ret	;kvoli TESTU v AVRstudiu
			
			push	ZH
			push	ZL
			
			ldi		ZL,0xff
			ldi		ZH,0x40

delay_1:		rjmp	PC+1
			sbiw	ZL,1
			brne	delay_1

			pop		ZL
			pop		ZH
			ret


delay2:		; cakacia slucka
			;ret	;kvoli TESTU v AVRstudiu
			
			push	ZH
			push	ZL
			
			ldi		ZL,0x7f
			ldi		ZH,0x01

delay_12:		rjmp	PC+1
			sbiw	ZL,1
			brne	delay_12

			pop		ZL
			pop		ZH
			ret




				
out_channel1:		;	KVOLI HLIPE ;) 	
			sts	tr_complete,_zero
			
			; prepadne dole
				
out_channel0:	
out_channel2:
out_channel3:
out_channel4:				
out_channel5: 
out_channel6:
out_channel7: 
			rjmp	i_cycle


in_channel4:					; aby sa joystick nehybal ;-)
in_channel5: ; TODO
in_channel7: ; TODO
			mov		A,_255
in_channel0:
in_channel2:
in_channel3:
in_channel6:
			rjmp	i_cycle




wr_rom_modul:
			andi	tmp2,0b11       ; interne cislo portu v 8255
			ldi		XL,low(_rom)
			ldi		XH,high(_rom)
			add		XL,tmp2
			adc		XH,_zero
			st		X,A
			rjmp	i_cycle

wr_channel_0_7:
			mov		tmp,tmp2
			swap	tmp
			andi	tmp,0x0f
			ldi		ZH,high(out_channels)
			ldi		ZL,low(out_channels)
			add		ZL,tmp
			adc		ZH,_zero
			ijmp



_out:
			out		PORTB,_PCL
			out		PORTC,_PCH
			adiw		_PCL,1
			in		tmp,PINA
			<? echo CYCLES(11); ?>

			mov		tmp2,tmp		; v tmp2 je cislo portu
			
			
			andi	tmp,0b10001100
			cpi		tmp,0b10000100
			breq	wr_pmd_kbd
			cpi		tmp,0b10001000
			breq	wr_rom_modul
			cpi		tmp,0b00001100
			breq	wr_channel_0_7

			rjmp	i_cycle

reload_timer1:
			push		r0
			lds		r0,t1h
			out		TCNT1H,r0
			out		TCNT1L,_zero
			pop		r0
			reti

wr_pmd_kbd:		andi	tmp2,0b11       ; interne cislo portu v 8255
			ldi		XL, low( kbd_ports )
			ldi		XH, high( kbd_ports )
			add		XL, tmp2
			adc		XH, _zero
			
			st		X,A				; zapiseme reg. A
			
			cpi		tmp2,3			; CW ?
			breq	wr_kbd_cw
			
			cpi		tmp2,2			; PC ?
			brne		wr_kbd_duplicity
			rcall		wr_kbd_pc			


wr_kbd_duplicity:
         		rjmp	i_cycle
				




wr_kbd_cw:			bst	A,7
				brts 	wr_kbd_duplicity      ; CW.7 == 1 => nemeni sa PC -> chod na dalsiu instrukciu
			
				mov		tmp2,A
				lsr		tmp2				 
				andi	tmp2,0b111 			  ; v tmp2 je cislo bitu
				sec
				clr		tmp

mask_compute:			rol		tmp
				dec		tmp2
				brne	mask_compute
				
				lds 	tmp2,kbd_ports + 2     	       ; tmp2 = port C of 8255
				com		tmp                    ; mask AND  
				and		tmp2,tmp			   
				com		tmp		       ; mask OR 	
				sbrc	A,0			       ; skip if zero bit must be written	
				or		tmp2,tmp
				sts 	kbd_ports + 2,tmp     ; tmp = port C
				
				rcall		wr_kbd_pc			
				rjmp		i_cycle

wr_kbd_pc:
 ; on port PC was connected  LEDs a repro
 ; PC0        00 = repro vypnute    11=ton3
 ;      =     01 = ton1
 ; PC1        10 = ton2

 ; PC2 = zlta ledka - log.1 svieti a vypina repro
 ; PC3 = cervena ledka
 
 ; ton1 = 976 Hz = 8 MHz / 8 / 1022 
 ; ton2 = 1953 Hz = 8 MHz / 8 / 510
 ; ton3 = 3905 Hz = 8 MHz / 1 / 2046

			lds	tmp,sound_on_off		; 0xff = ON , 0 = OFF
			cpse	tmp,_255
  			rjmp	sound_off
  			
			lds 	tmp,kbd_ports + 2 ; port C
			andi	tmp,0b111
			breq	sound_off		  ; ak PC0 = PC1 == 0 tiez vypni zvuk
			
			andi	tmp,0b11
			brne	sound_on	; tmp == 1 , 2 or 3 ?
			
			ldi		tmp,0b00100000		; PWM DISABLE, CLEAR OC1B
			cli
			out		TCCR1A, tmp
			out		TCNT1H,_255
			out		TCNT1L,_255
			reti
			
sound_table:		.db	high( 0xffff - 5000),high( 0xffff - 2500),high( 0xffff - 1250) 

sound_on:		ldi	ZL,low((sound_table<<1) - 1 )
			ldi	ZH,high((sound_table<<1) - 1 )
			add	ZL,tmp
			adc	ZL,_zero
			lpm
			sts		t1h,r0
			ldi		tmp,0b00010000		; PWM DISABLE, TOGGLE OC1B
			cli
			out		TCCR1A, tmp
			out		TCNT1H,_255
			out		TCNT1L,_255
			reti
			
sound_off:
			ldi		tmp,0b00110000
			cli
			out		TCCR1A, tmp    			; PWM DISABLE, SET OC1B
        		out		TCNT1H,_255
			out		TCNT1L,_255
			reti

; ******** communication with ISA I/O space ( 1 Kbytes address space in original)
outportb_fast_3ce_08:
				
				;  pouziva: write_tmp
				
				;zapise na 3ce:08 	
                                
                                
				out		DDRA,_255; PA vystup
				
				ldi		write_tmp,LATCH_ISA_00
				out		PORTA,write_tmp		; PA = LATCH_ISA
				ALE_pulse

				ldi		write_tmp,0xce
				out		PORTB,write_tmp
				ldi		write_tmp,0x03
				out		PORTC,write_tmp
				
				ldi		write_tmp,0x08
				out		PORTA,write_tmp
				IOWR_pulse
				
				ret

outportb:	
				; tmp2 = low ( address )
				; r0   = data

				push	tmp
				
				MEMRD_deactive
				
				out		DDRA, _255		; PORTA = vystup

				ldi		tmp,LATCH_ISA_00
				out		PORTA,tmp		; PA = LATCH_ISA
				ALE_pulse

				out		PORTB,tmp2
				ldi		tmp,0x03
				out		PORTC,tmp
				
				out		PORTA,r0
				IOWR_pulse
				pop		tmp

				ret
				

inportb_3da:	
				ldi		tmp2,0xda
				rcall	inportb
				ret

inportb:	
				; tmp2 = low ( address ) : VSTUP
				; r0 = data : VYSTUP

				push	tmp
				
				MEMRD_deactive
				
				out		DDRA, _255		; PORTA = vystup

				ldi		tmp,LATCH_ISA_00
				out		PORTA,tmp		; PA = LATCH_ISA
				ALE_pulse

				out		PORTB,tmp2
				ldi		tmp,0x03
				out		PORTC,tmp

				out		DDRA, _zero		; PORTA = vstup

				IORD_active
				IOCH_RDY
				in		r0,PINA
				IORD_deactive
				pop		tmp

				ret

			.dseg
kbd_ports:	.byte   4

mgf_start_at:	.byte	3
mgf_pointer: 	.byte	3
mgf_stop_at:	.byte	3

			.cseg


next_byte_from_tape:		 ; podprogram - cita z MGF pasky
				 ; vystup : r0 - precitane DATA
				 ; nici registre SREG,Z,X,tmp,r1,r0				
			MEMRD_deactive
			
			ldi		ZL,low(mgf_start_at)
			ldi		ZH,high(mgf_start_at)
			
			ldd		XL,Z+3+0
			ldd		XH,Z+3+1
			ldd		r1,Z+3+2
					
			rcall		flash_read
			rcall		print_mgf_pointer			
			adiw		XL,1
			adc		r1,_zero
			
			
			ldd		tmp,Z+6+0		
			cp		XL, tmp
			ldd		tmp, Z+6+1
			cpc		XH,tmp
			ldd		tmp, Z+6+2
			cpc		r1,tmp
			brlo		mgf_pointer_store
			
			rcall		create_pause_pmd852
						
			ldd		XL,  Z+0+0
			ldd		XH,  Z+0+1
			ldd		r1,  Z+0+2
			
mgf_pointer_store:	
			std		Z+3+0,XL
			std		Z+3+1,XH
			std		Z+3+2,r1

			ret


uart_send_byte:		; funckia posle bajt do UART, resp. zaradi ho do fronty na odvysielanie
			;input : r0
		sbis	USR,UDRE
		rjmp	uart_send_byte
		;rcall	delay2
		out	UDR,r0
		ret
		

vga_3d4: 	.db	0xd4, 0x19		; prve adresa , druhe pocet
		.db	0x5f,0x4f,0x50,0x82,0x54,0x80,0xbf,0x1f,0,0x40,0,0,0,0,0,0,0x9c,0xae,0x8f,0x28,0,0x96,0xb9,0xe3,0xff

vga_3ce: 	.db	0xce, 0x09
		.db	0,0,0,0b00000000,0,2,5,0xf,0xff ; REPLACE , zapisovaci rezim 2, citaci 0
	     ; 2 = zapisovy rezim 
vga_3c4: .db	0xc4, 0x05
		 .db	3,1,0xf,0,6


vga_pallete0:	; COLOR PALLETE v tvare RGB
		.db		0x00,0x00,0x00,  0x3f,0x3f,0x3f		; 01
		.db		0x00,0x3f,0x00,  0x3f,0x00,0x00		; 23
		.db		0x00,0x00,0x3f,  0x18,0x24,0x3f         ; 45 	
		; colours: black(0), white(1), green(2), red(3), blue(4), menu color(5)
		

vga_pallete1:	; MONOCHROMATIC PALLETE v tvare RGB
		.db		0x00,0x00,0x00,  0x20,0x20,0x20		; 01
		.db		0x3f,0x3f,0x3f,  0x3f,0x3f,0x3f		; 23
		.db		0x20,0x20,0x20,  0x18,0x24,0x3f         ; 45 	

vga_pallete2:	; MONOCHROMATIC PALLETE v tvare RGB
		.db		0x00,0x00,0x00,  0x20,0x20,0x20		; 01
		.db		0x3f,0x3f,0x3f,  0x00,0x00,0x00		; 23
		.db		0x00,0x00,0x00,  0x18,0x24,0x3f		; 45 	


vga_set_pallete_trio:
			; r0 = index, Z je ukazatel na paletu
			push	tmp
			
			ldi		tmp2,0xc8	; PEL Address register ( write )
			rcall	outportb
			inc		tmp2		; PEL DATA register	( write )

			lpm
			adiw	ZL,1
			rcall	outportb

			lpm
			adiw	ZL,1
			rcall	outportb

			lpm
			adiw	ZL,1
			rcall	outportb

			pop	tmp
			ret


vga_inic_graphics:
			
			out		DDRA, _255		; PORTA = vystup
			ldi		tmp,LATCH_ISA_RESET
			out		PORTA,tmp		; PA = RESETNEME gr.kartu
			
			ALE_pulse
			rcall	delay
			
			out		DDRA, _255		; PORTA = vystup
			ldi		tmp,LATCH_ISA_IDLE
			out		PORTA,tmp		; PA = RESETNEME gr.kartu
			
			ALE_pulse
			
			
			ldi		tmp2,0xc2
			ldi		tmp,0b11000011		; 400 bodiek
			mov		r0,tmp
			rcall	outportb
			
			ldi		ZL, low( vga_3d4 << 1)
			ldi		ZH, high( vga_3d4 << 1)
			rcall	fill_vga_regs
			
			ldi		ZL, low( vga_3ce << 1)
			ldi		ZH, high( vga_3ce << 1)
			rcall	fill_vga_regs

			ldi		ZL, low( vga_3c4 << 1)
			ldi		ZH, high( vga_3c4 << 1)
			rcall	fill_vga_regs


			ldi		XL,0x20
			ldi		ZL, low( vga_3c1 << 1)
			ldi		ZH, high( vga_3c1 << 1)

zzzzz:
			rcall	inportb_3da
			
			ldi		tmp2,0xc0
			mov		r0,XL
			rcall	outportb

			lpm		
			adiw	ZL,1
			ldi		tmp2,0xc0
			rcall	outportb
			
			inc		XL
			cpi		XL,0x35
			brlo	zzzzz

			ldi		tmp2,0xc3
			mov		r0,_255
			rcall	outportb
			
			ldi		tmp2,0xc6
			mov		r0,_255
			rcall	outportb

			ldi		ZL, low( vga_pallete0 << 1)
			ldi		ZH, high( vga_pallete0 << 1)
			sts		pallete_before,_zero
			rcall		set_pallete

			ret


set_pallete:		; set pallete subroutine. 
			; Z is pointer to palette
			clr		tmp

pallete_set_cycle:
			mov		r0,tmp
			rcall	vga_set_pallete_trio
			inc		tmp
			cpi		tmp, 6
			brlo	pallete_set_cycle

			ret


vga_clrscr2:	
			ldi		ZL,low(640/8*350)
			ldi		ZH,high(640/8*350)

clear_screen:		; Z = end of videoram
			rcall	outportb_fast_3ce_08
			
			ldi		tmp2,0xcf
			mov		r0,_255		; BIT MASK = 0xff
			rcall	outportb

			out		DDRA,_255; PA vystup
 			out		PORTA,_latch_isa_0a		; PA = LATCH_ISA
			ALE_pulse

			out		PORTA,_zero		; color 0 = black

vga_clrscr_cycle:

			out		PORTB,ZL
			out		PORTC,ZH
			MEMWR_active
			IOCH_RDY
			MEMWR_deactive
			sbiw	ZL,1
			brcc	vga_clrscr_cycle
			
			out		DDRA,_zero		; input
			ret

vga_clrscr:	



			ldi		ZL,0xff  ;low(640/8*480)
			ldi		ZH,0xff  ;high(640/8*480)

			rcall		clear_screen			
			
			; create look-up table for writing bytes
			
			
					; cierne pozadie do latch-ov
			out		PORTB,_zero
			out		PORTC,_zero
			out		DDRA,_zero		; akoze citame
			MEMRD_active
			IOCH_RDY
			MEMRD_deactive				; cierna z a000:0000 do latchov
			out		DDRA,_255		; PA vystup

		clr	DATA
			
table_cycle:			
		ldi	ZH,block_0
		

		clr		color
		bst		DATA,7
		bld		color,1
		bst		DATA,6
		bld		color,0
		inc		color

		bst		DATA,0
		bld		r0,7
		bld		r0,6
		bst		DATA,1
		bld		r0,5
		bld		r0,4
		bst		DATA,2
		bld		r0,3
		bld		r0,2
		bst		DATA,3
		bld		r0,1
		bld		r0,0
		
		rcall	write_r0_Z				

		ldi	ZH,block_1	

		bst		DATA,2
		bld		r0,7
		bld		r0,6
		bst		DATA,3
		bld		r0,5
		bld		r0,4
		bst		DATA,4
		bld		r0,3
		bld		r0,2
		bst		DATA,5
		bld		r0,1
		bld		r0,0

		rcall	write_r0_Z
		sec				
		adc	DATA,_zero
		brcc	table_cycle				
			
		ret ; clrscr


write_r0_Z:	; vstup r0(data),color,Z(adresa)
                ; meni write_tmp 
                out		DDRA,_255		; output
		ldi		write_tmp,0xcf
		out		PORTB,write_tmp
		ldi		write_tmp,0x03
		out		PORTC,write_tmp
		out		PORTA,r0
		IOWR_pulse
			
		out		PORTB,DATA
		out		PORTC,ZH
		out		PORTA,color
		MEMWR_active
		IOCH_RDY
		MEMWR_deactive		; dokoncenie zapisu prveho (celeho) bytu
                out		DDRA,_zero	; input
		
		ret			; end of clrscr routine 

			
vga_3c1:	.db 	0,1,2,3,4,5,6,7,0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,1,0,0x0f,0,0

fill_vga_regs:	; Z register ukazatel 
			lpm	
			adiw	ZL,1
			mov		tmp2,r0		; address
			lpm		
			mov		tmp,r0		; count 
			adiw	ZL,1
			clr		r2		; index
vga_fill_next:
			
			mov		r0,r2		
			rcall	outportb		; write index
			lpm	
			adiw	ZL,1
			inc		tmp2
			rcall	outportb		; write data
			dec		tmp2		; move back to index register
			inc		r2
			cp		r2,tmp	
			brlo	vga_fill_next
			

			ret








_delay:				;rjmp	PC+1
				;rjmp	PC+1
				;rjmp	PC+1
				;rjmp	PC+1
			
				sbis	PIND,PD1		; check for IOCH RDY ( break if low )
				rjmp	PC-1
				ret


print_help:			
				rcall	print_text
				rcall	vga_clrscr2			
				rcall	outportb_fast_3ce_08
				ldi	XH,0xc0
				ldi	XL,0x00
				
refresh_screen_cycle2:		ldi	tmp,48	
refresh_screen_cycle:		
				
				out		DDRA,_255		; PORTA output
				out		PORTA,_latch_ram	
				ALE_pulse
				out		PORTB,XL    ; output 16 bit address 
				out		DDRA,_zero
				out		PORTC,XH
				MEMRD_active
				nop
				in		DATA,PINA
				com		DATA
				rcall		_wr_normal
				com		DATA
				rcall		_write
				;adiw		XL,1
				inc		XL
				dec		tmp
				brne		refresh_screen_cycle
				adiw		XL,16
				brcc		refresh_screen_cycle2							
				MEMRD_deactive
				
				rcall	print_file_name		; refresh file info		
			
				ret
							
print_text:			
				ldi		XL,byte1(C_kbd_text_start)
				ldi		XH,byte2(C_kbd_text_start)
				ldi		tmp,byte3(C_kbd_text_start)
				mov		r1,tmp

new_screen:
				sts	cursor_y,_zero
				sts	attribute,_zero


cycle_y:				
				sts	cursor_x,_zero
				lds	tmp2,cursor_y
				inc	tmp2
				sts	cursor_y,tmp2
						
cycle_x:	
			rcall	flash_read
			adiw	XL,1
			adc	r1,_zero
		
			mov	tmp2,r0
			cpi	tmp2, 0x0a	; 0x0a = end of line	
			brne	no_cycle_y
	fill_spaces:	lds	tmp2,cursor_x
			cpi	tmp2,79
			breq	cycle_y
			ldi	tmp2,' '
			mov	r0,tmp2
			rcall	_putchar
			rjmp	fill_spaces
						
	no_cycle_y:	rcall	_putchar
			
			cpi	tmp2,0xff	; 0xff = end of text
			breq	print_text_end
			cpi	tmp2,0x00	; 0x00 = end of screen
			brne	cycle_x
	
	print_text_end:		
			rcall	wait_for_kbd_release
			rcall	wait_for_kbd_stroke

			cpi	tmp2,0xff	; 0xff = end of text
			brne	new_screen	
			
			ret
			
wait_for_kbd_release:	
			rcall	kbd_state
			brne	wait_for_kbd_release
			ret
			
wait_for_kbd_stroke:
			rcall	kbd_state
			breq	wait_for_kbd_stroke
			ret
				

kbd_state:		; return : 
                        ; SREG:Z = 0 <=> some keys are pressed
                        ; SREG:Z = 1 <=> no key is pressed
                               
			ldi	ZL,low(kb_cols)
			ldi	ZH,high(kb_cols)
			mov	write_tmp,_255
	wfkr_cycle:		
			ld	r0,Z+
			and	write_tmp,r0
			cpi	ZL,low(kb_cols+16)
			brne	wfkr_cycle
			
			mov	ZL,kbd_flags	
			andi	ZL,(1<<SHIFT_bit)|(1<<STOP_bit)
			or	write_tmp,ZL
			cpi	write_tmp,0x7f
			
			ret




		.include "flash.asm"
		.include "print.asm"
		
monitor_table:		.dw	C_monit1_start,C_monit2_start,C_monit2_start,C_monitalf_start,C_monit2a_start, C_monit2a_start,C_monit2_start
rom_modul_table:	.dw	C_basic1_start,0,             C_basic2_start,C_basica_start,  0,               C_basic2a_start,C_pascal_start

_get_uart_data:	
			sbis	USR,RXC
			rjmp	_get_uart_data

			;sts	cursor_y,_zero
			;sts	attribute,_zero
			;sts	cursor_x,_zero

			in	tmp,UDR		  ; r1 vystup
			;push	r0
			;mov	r0,tmp
			;rcall	_putch2
			;pop	r0
			ret
			
;----------------------- subroutine for download rom modul into SRAM from 0x8000 to 0xbffff 	
change_pmd_type:				
								; urobime download monitora do SRAM z external FLASH
				ldi		_PCL,0x00
				ldi		_PCH,0x80  		; after RESET  PC = 0x8000

				mov		ZL,pmd_type
				clr		ZH
				lsl		ZL
				;rol		ZH	- zbytocne - pracujeme s malymi cislami
				subi		ZL,low(-monitor_table<<1)
				sbci		ZH,high(-monitor_table<<1)

				lpm
				mov		XL,r0
				adiw		ZL,1
				lpm	
				mov		XH,r0
				
				ldi		ZL, low( 0x8000 )
				ldi		ZH, high( 0x8000 ) 
				
				ldi		tmp,high(0x9000)  ; hi of ( end address + 1 )
				; X: source from first page in FLASH 
				; Z: destination in SRAM
				; tmp: end source address ( high byte ) 
				rcall		monitor_download

				ldi		tmp,3
				cp		pmd_type,tmp
				brne		download_ret				
				
				ldi		XL,low(C_basica_start)	; DIDAKTIK Alfa support
				ldi		XH,high(C_basica_start)

				; DIDAKTIK ALFA has BASIC not in rom modul, but it is stored in 0x9000 location after its monitor

				ldi		tmp,high(0xC000)  ; high of ( end address + 1 )
				rcall		monitor_download

download_ret:			rcall		kbd_inic_buffer
				ret
				


; -------------------- monitor download from flash 				
monitor_download:		
				clr		r1		        ; byte3 of address in FLASH 
_monitor_download:				
                		rcall		flash_read
				adiw		XL,1
				
								
				out		DDRA,_255		; PORTA = vystup
				out		PORTA,_latch_ram		; PA = LATCH_ISA
				ALE_pulse
				
				out		PORTB,ZL
				out		PORTC,ZH
				out		PORTA,r0
				adiw		ZL,1
				
				MEMWR_pulse

				cp		ZH, tmp 	; end block ? ( each 256 bytes )
				brlo		_monitor_download
				ret





		.org	(high(PC) + (low(PC) != 0) ) *256 ; zarovna na nasobok 256 words

i_table:		
		.include	"8080.asm"		
 

			
		.org	( (PC/128) + ((PC&0x7f) != 0) ) *128 ; zarovna na nasobok 256

kb_lookup: .include	"kb_lookup.asm"

			