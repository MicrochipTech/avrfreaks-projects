/*   Room Temperature Monitor and Controller			*/

#include <io.h>
#include <interrupt.h>
#include <sig-avr.h>
#include <eeprom.h>
#include <progmem.h>

// Function Decalaration
void delay_us(unsigned int);
void  binarytoBCD(void); 
char getKeyStatus(void);
int sensorStatus(void); 

#define CPU_FREQ	4000000		//  MCU  speed
// Port wher the Display units are interfaced
#define SEGMENT_PORT 	PORTB
#define DISPLAY_PORT	PORTD
#define SegmentDisplay0  PINB0
#define SegmentDisplay1  PINB1
#define SegmentDisplay2	 PINB2
// Value of the indiviuial segment of the 7-segment display
#define SEGMENT_A  	0x01 			
#define SEGMENT_B  	0x02
#define SEGMENT_C  	0x04 
#define SEGMENT_D  	0x08
#define SEGMENT_E  	0x10 
#define SEGMENT_F  	0x20
#define SEGMENT_G  	0x40
#define SEGMENT_DP 	0x80
// Push Button Port Defination and pins 
#define KEY_PINS	PINC
#define UP_KEY_PIN	PC0
#define MODE_KEY_PIN	PC2
// Port  and pin where the Relay is interfaced  
#define RELAY_PORT	PORTB
#define RELAY_PIN	PINB4
// Port  and pin where the Temperature sensor is interfaced
#define SENSOR_INPUT	PB5
#define SENSOR_PIN	PINB		
#define REFRESH_VAL	125      // Display Refresh Value  for Timer-0 
// EEPROM Addres where the  Temperature setting and Hysteresis values are stored 
#define SET_TEMP_EEPROM   		0x17 	// Temperature Setting 
// Value, with  which a range of temperature can be set, to prevent the oscillation at a fixed temperature point 
// If Set Temperature is 25 Degrees and Hysteresis is 2 Degree, then relay output  will be active at (25+2 = 27 Degrre) and deactivate at (25-2= 23 Degree)
#define TEMP_HYSTERESIS_EEPROM	  	0x19	
			
// The value of the displayed digits 
char display[]={
		 (SEGMENT_A|SEGMENT_B|SEGMENT_C|SEGMENT_D|SEGMENT_E|SEGMENT_F),  // display 0
		 (SEGMENT_B|SEGMENT_C),						// display 1
		 (SEGMENT_A|SEGMENT_B|SEGMENT_D|SEGMENT_E|SEGMENT_G),		// display 2
		 (SEGMENT_A|SEGMENT_B|SEGMENT_C|SEGMENT_D|SEGMENT_G),		// display 3
 		 (SEGMENT_B|SEGMENT_F|SEGMENT_G|SEGMENT_C),			// display 4
		 (SEGMENT_A|SEGMENT_C|SEGMENT_D|SEGMENT_F|SEGMENT_G),		// display 5
		 (SEGMENT_A|SEGMENT_C|SEGMENT_D|SEGMENT_E|SEGMENT_F|SEGMENT_G),	// display 6
		 (SEGMENT_A|SEGMENT_B|SEGMENT_C),				// display 7
		 (SEGMENT_A|SEGMENT_B|SEGMENT_C|SEGMENT_D|SEGMENT_E|SEGMENT_F|SEGMENT_G), // display 8
		 (SEGMENT_A|SEGMENT_B|SEGMENT_C|SEGMENT_D|SEGMENT_F|SEGMENT_G),	// display 9
		 (SEGMENT_B|SEGMENT_C|SEGMENT_D|SEGMENT_E|SEGMENT_F), // represet U
		 (SEGMENT_C|SEGMENT_E|SEGMENT_G),	// represte n 
		 (SEGMENT_C|SEGMENT_D|SEGMENT_E|SEGMENT_G),   
		 (SEGMENT_D|SEGMENT_E|SEGMENT_F|SEGMENT_G),  // represent t 
		 (SEGMENT_B|SEGMENT_C|SEGMENT_E|SEGMENT_F|SEGMENT_G) // represent H 
		};
// variable declaration
volatile unsigned long bcd ;
int width;
volatile unsigned char ch, mode,range, temp_val, count, temp_val_decimal, key_status, set_temp, temp_hyst;
float a;
char DISPLAY_ON=0;
 
// ISR for Timer0, displays value on the 7-segment display, by selecting a desired display unit 
// One after the other, without causing  flickering in the display
SIGNAL(SIG_OVERFLOW0)
{	
	cbi(SEGMENT_PORT , SegmentDisplay0);	// Disable all the display units
	cbi(SEGMENT_PORT , SegmentDisplay1);
	cbi(SEGMENT_PORT , SegmentDisplay2);
   if (range == 0)	// When data is within the range
   {
	if((DISPLAY_ON == 0) | (DISPLAY_ON==1))	// Value of left hand side of decimal
		count = temp_val;
		
	if(DISPLAY_ON == 2)
		count  = temp_val_decimal;	// Value of right hand side of decimal
	
	binarytoBCD();		// Convert binary data into BCD format for displaying
	

	if (DISPLAY_ON == 0)		// Put data on the data-bus for first display     
	{
		outp(~display[(bcd & 0xf0 )>>4 ] , DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay0);
	}	
	
	if (DISPLAY_ON == 1)		// Put data on the second display with decimal  on the data-bus 
	{
		outp( ~display[(bcd & 0x0f)] & ~SEGMENT_DP , DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay1);
	}	
	if(DISPLAY_ON ==2)		// put decimal data 
	{	
		outp(~display[(bcd & 0x0f)   ], DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay2);
	}
  }
  
   if(range == 1)		// When data  is out of range i.e. Under-Range
   {     
   	if (DISPLAY_ON == 0)
	{
		outp(~display[10], DISPLAY_PORT);	
		sbi(SEGMENT_PORT, SegmentDisplay1);
	}	
	if(DISPLAY_ON ==1)
	{
		outp(~display[11], DISPLAY_PORT);	
		sbi(SEGMENT_PORT, SegmentDisplay2);
	}
	if(DISPLAY_ON ==2)
	{	
		cbi(SEGMENT_PORT, SegmentDisplay2);
	}
   }
   	
   if (range == 2 ) 	// When data  is out of range i.e. Over-Range
   {	
  	if (DISPLAY_ON == 0)
	{	
		outp(~display[12], DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay1);
	}	
	if(DISPLAY_ON ==1)
	{
		outp(~display[10], DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay2);
	}
	if(DISPLAY_ON ==2)
	{  
		cbi(SEGMENT_PORT, SegmentDisplay2);
	}
  	
   }
   
   if (range == 5 )			//  In  Temperature setting mode i.e. will display 't' in rightmost display unit
   {
      	count  = set_temp;
      	binarytoBCD();
	if (DISPLAY_ON == 0)		// put data on first display     
	{
		outp(~display[(bcd & 0xf0 )>>4 ] , DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay0);
	}	
	
	if (DISPLAY_ON == 1)		// put data on the second display with decimal 
	{
		outp( ~display[(bcd & 0x0f)] & ~SEGMENT_DP , DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay1);
	}	
	if(DISPLAY_ON ==2)		// put decimal data 
	{	
		outp(~display[13], DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay2);
	}   	
	
    }

   if (range == 7 )			//  In  hysteresis setting mode i.e. will display 'H in rightmost display unit
   {
      	count  = temp_hyst;
      	binarytoBCD();
	if (DISPLAY_ON == 0)		// Put data on first display     
	{
		outp(~display[(bcd & 0xf0 )>>4 ] , DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay0);
	}	
	
	if (DISPLAY_ON == 1)		// Put data on the second display with decimal 
	{
		outp( ~display[(bcd & 0x0f)] & ~SEGMENT_DP , DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay1);
	}	
	if(DISPLAY_ON ==2)		// put decimal data 
	{	
		outp(~display[14], DISPLAY_PORT);
		sbi(SEGMENT_PORT, SegmentDisplay2);
	}   	
	
    }
   
   	++DISPLAY_ON;		// Increment the display unit value
	if (DISPLAY_ON >2)
		DISPLAY_ON=0;	// Re-intialioze it to 0 i.e. with first display unit
	outp(REFRESH_VAL, TCNT0);// Re-intailize the refresh value for Timer-0
}


	
int main(void)			// --------------------- MAIN PROGRAM STARTS HERE -----------------
{			
	char t1s, ch ;
	count = 0;mode = 0;ch = 0;range = 0;
	set_temp = 21;		// Initial value of the Temperature setting and Hysteresis
	temp_hyst = 2;
	
	// Set the PORT for Both Read and Write Mode
	outp((1<< SegmentDisplay0)|(1<< SegmentDisplay1)|(1<< SegmentDisplay2)|(1<< RELAY_PIN), DDRB);outp((1<< SegmentDisplay0)|(1<< SegmentDisplay1)|(1<< SegmentDisplay2)|(1<< RELAY_PIN), DDRB);
	outp((1<<PC0) | (1<<PC1) | (1<<PC2), PORTC); // Internally pulled high
	
	outp(0xff, DDRD);	// DISPLAY_PORT in output mode 	
	outp(0x00, DISPLAY_PORT);

	// Set the Timer-0 IRQ and start the timer
	// Intialize the timer for display routine 
	outp(0x04, TCCR0);		//  Prescaling Timer-0 
	outp((1<< TOIE0), TIMSK);	
	outp(REFRESH_VAL, TCNT0);	// Load the refresh value  and enable interrupt
 	sei();				
	outp(0, TCCR1A);		// Set-up the Timer1   and 
	outp(0x00, TCNT1H);		// Intialize the counters with 0000
	outp(0x00, TCNT1L);	
	
	// Read paramter values from the EEPROM at the Power-Up Condition
	set_temp = eeprom_rb(SET_TEMP_EEPROM);
	if (set_temp > 94 )
		set_temp = 20;
	if (set_temp <  6) 
		set_temp =  20;
	temp_hyst = eeprom_rb(TEMP_HYSTERESIS_EEPROM);
	if (temp_hyst > 5 ) 
		temp_hyst = 5;
	if (temp_hyst < 1  ) 
		temp_hyst = 1;

	while(1)		//  Control Loop starts here 
	{
		if ( range != 5 && range != 7)		// If not in setup mode, then read the sensor data
		{	
			cli();			// Disable IRQ
			width = sensorStatus();		// Get the pulse width 
			sei();			// Enable IRQ
			if (width <= 7321 && width >= 5360 ) // Chek The limits from 0 to 99.9
			{		
				a = (CPU_FREQ- (2* width *273.15) )/(2*width );		
				temp_val= a;
				temp_val_decimal =  (a*10)-(temp_val*10);
				if ( temp_val >=  set_temp + temp_hyst)	// Switch the Relay Output drive depending upon the comparison points
					sbi(RELAY_PORT, RELAY_PIN);
				if ( temp_val < set_temp - temp_hyst )
					cbi(RELAY_PORT, RELAY_PIN);
				range = 0;		// Set the range and mode values
				mode = 0;					
			}
			// Check for under  and overflow
	  		if (width > 7321)	// If less than 0
	  		{	range = 1;	mode = 0; }
	  		if (width < 5360)	//  If greater than 99.9
	   		{	range = 2;	mode = 0; }
	  }
	
	// Get the key status  and enter setup mode if  mode key has been pressed first
	// Will enter temperature setting mode on first mode key  press 
	// and Hysteresis setting when mode key is pressed second time
	// On Third mopde key press, the data will be written to EEPROM, if any changes has been made to parameters 
	// and then return to sensor read loop
	key_status = getKeyStatus();
	if (key_status == 0x04 )		// If 'Mode' Key is pressed 
	{
		mode++;				
		if (mode == 1)			
			range = 5;			// Set value for proper indication on the Display unit
		if (mode == 2)			// i.e. to display 't' or 'h'
			range = 7;
		if (mode == 3 && ch == 1)	// Write the value to the EEPROM if changes to the parametrs have been made
		{				// and return  to   program to read data from sensor 
			eeprom_wb(SET_TEMP_EEPROM, set_temp);
			eeprom_wb(TEMP_HYSTERESIS_EEPROM, temp_hyst);
			range = 6;
			ch = 0;mode = 0;
			
		}		
		if (mode == 3 && ch == 0)	// If no changes have been made to the parameter data
		{
			mode = 0;		// and return  to   program to read data from sensor 
			range = 6;
		}
		for (t1s=0; t1s<= 32; t1s++)	// Display delay to indicate  that display fields are changing depending  upon the mode key press
			delay_us(32000);
	
	}

	if (mode != 0 )				// Delay in change of the  parameter value 
		for (t1s=0; t1s<= 10; t1s++)
			delay_us(32000);
	
	if (key_status == 0x01 && mode != 0)	//  Up key has been pressed, will increment the temperature or hysteresis value
	{					// If mode key has been pressed
		if (mode != 0)
		{
		if ( range == 5)
		{
			++set_temp;
			if (set_temp > 94)
				set_temp = 6;
			ch = 1;
		}		
		if (range == 7)			// Increment Hysteresis value 
		{
			++temp_hyst;
			if (temp_hyst >  5)
				temp_hyst = 1;
			ch = 1;
		}
		}
		key_status = 0;
	}  
     }
}		// ----------------- END of the MAIN PROGRAM---------------------

// Routine which check and return the value of the  button/key pressed
char getKeyStatus(void)
{
 	char res;
	delay_us(32000);	// Delay to take care of the key-debounce
	delay_us(32000);
	res = inp(PINC);
	res = res & 0x05;
	if (res  == 0x05 || res == 0x0)		// If both  the keys or none of them is pressed
		return 0;
	if (res  == 0x04 )			// If Mode key is  pressed 
		return 0x04;
	if (res  == 0x01 )			// If Up key is pressed 
		return 0x01;
}

 // Routine to find the temperatur sensor data's  pulse width 
int sensorStatus(void)  
{
		unsigned char   resb, h, l;
		int w; 
		resb = 0;
		resb= inp(PINB);
		resb  = resb & 0x20;	// Read The sensor's signal logic state 
		while(resb == 0x20 )	//  Signal is in is high state
		{ 
			resb= inp(PINB);
			resb  = resb & 0x20;
		 }
		resb= inp(PINB);
		resb  = resb & 0x20;
		while(resb == 0) 	//  Signal is in is low state 
		{ 
			resb= inp(PINB);
			resb  = resb & 0x20;
		 }
		outp(1, TCCR1B);	// Enable the timer at first rising edge of the pulse
	
		resb= inp(PINB);
		resb  = resb & 0x20;
		while(resb == 0x20 )
		{ 
			resb= inp(PINB);
			resb  = resb & 0x20;
		 }
		outp(0, TCCR1B);	//Disable the timer at first falling edge of the pulse
		l = inp(TCNT1L);	// Get the counter value i.e pulse width value
		h = inp(TCNT1H);	
		w =  (h*256)  +  l;
		outp(0x00, TCNT1H);	// Re-load the timer   with 0000 value
		outp(0x00, TCNT1L);
		return w;		//  Return the pulse width value 
}

// Binary Data Conversion to BCD number routine 
void  binarytoBCD(void)
{
        int i, j;
		for (i=0;i<8;i++)
		{
			j = count % 10;
			bcd >>= 4;
			bcd |= ((unsigned long)j << 28);
			count /= 10;
		}
}

// Delay subroutine, argument value is in Micro-second 
void delay_us(unsigned int us) 
{		
    while (us)
      	us--;    
} 

