; data.h - included source for Dutchtronix Oscilloscope Clock
;
;  Copyright � 2008 Johannes P.M. de Rie
;
;  All Rights Reserved
;
;  This file is part of the Dutchtronix Oscilloscope Clock Distribution.
;  Use, modification, and re-distribution is permitted subject to the
;  terms in the file named "LICENSE.TXT", which contains the full text
;  of the legal notices and should always accompany this Distribution.
;
;  This software is provided "AS IS" with NO WARRANTY OF ANY KIND.
;
;  This notice (including the copyright and warranty disclaimer)
;  must be included in all copies or derivations of this software.
;
; Firmware for Dutchtronix AVR Oscilloscope Clock
;
; Scope Clock data
;

	.dseg
	.org	SRAM_START
;
; Clock Display Scan Table
;
; Each table entry consists of a pointer to program memory containing
; a list of vectors positions plus an Xoffset and Yoffset field (to be added to the vector positions)
;

.equ SCANTABLEN =   8
ScanTbl:
ScanTbl_Dial:		.byte	4
ScanTbl_Full:		.byte	4
ScanTbl_SecHand:	.byte	4
ScanTbl_SecHand2:	.byte	4
ScanTbl_MinHand:	.byte	4
ScanTbl_MinHand2:	.byte	4
ScanTbl_HrHand:		.byte	4
ScanTbl_HrHand2:	.byte	4
;
; Pointer(s) to Code Space based Text
;
.equ SCANSTRTABLEN =   4
ScanTbl_Str:
ScanTbl_Str1:		.byte	4		;Push To Start
ScanTblStatG:		.byte	4		;Status
ScanTblStatB:		.byte	4		;Status
ScanTblStatP:		.byte	4		;Status
;
; Pointer(s) to SRam Space based Text
;
.equ SCANSSTRTABLEN =   3
ScanTbl_Str3:		.byte	4		;Usr Name Display
ScanTbl_Str4:		.byte	4		;Numeric Text Display
ScanTbl_Str5:		.byte	4		;Chrono Display
;
; Menu Display String Table.
;
.equ MENUSCANTABLEN =   26
MScanTbl:
MScanTbl_Logo:		.byte	4
MScanTbl_Ver:		.byte	4
MScanTbl_Num:		.byte	4		;display  Numeric Mode
MScanTbl_NumVal:	.byte	4
MScanTbl_Dial:		.byte	4		;display  Dial Mode
MScanTbl_DialVal:	.byte	4
MScanTbl_GPS:		.byte	4		;display GPS mode
MScanTbl_GPSVal:	.byte	4
MScanTbl_DST:		.byte	4
MScanTbl_DSTVal:	.byte	4
MScanTbl_Boot:		.byte	4
MScanTbl_Demo:		.byte	4
MScanTbl_Chrono:	.byte	4
MScanTbl_ChronoVal:	.byte	4
MScanTbl_Cal:		.byte	4
MScanTbl_CalVal:	.byte	4		;display  Cal Mode
MScanTbl_Led:		.byte	4
MScanTbl_LedVal:	.byte	4		;display  Led Mode
MScanTbl_BurnIn:	.byte	4
MScanTbl_BurnInVal:	.byte	4		;display  BurnIn Mode
MScanTbl_Fun:		.byte	4
MScanTbl_PlayVal:	.byte	4		;display  Fun Mode
MScanTbl_Init:		.byte	4
MScanTbl_InitVal:	.byte	4
MScanTbl_UsrName:	.byte	4
MScanTbl_UsrNameVal:.byte	4		;display UsrName Mode
;
; Pointer to SRam based User Name Text
;
MScanTbl_UsrNameTxt:.byte	4
;
.equ	DISPBUFLEN =	12
NumDispBuf:			.byte	DISPBUFLEN	;Numeric display text
NumFlashDispBuf:	.byte	DISPBUFLEN	;same but for flashing
#if CHRONOMETER
.equ	CHRONOBUFLEN =	3
ChronoDispBuf:		.byte	CHRONOBUFLEN
#endif
UsrNameBuf:			.byte	MAXUSRNAMELEN+1 ;User Name display text. Room for 0
#if DEBUG
UsrNameBufGuard:	.byte	4
#endif
UsrNameFlashBuf:	.byte	MAXUSRNAMELEN+1 ;same but for flashing (used when editing)
					.byte	1
;
; Flash Control Table
;
; Each entry describes a ScanTbl entry that needs to flash/blink:
;
;	ScanTbl ptr, VectorTbl ptr, On/Off status, FlashCnt, Original VectorTbl ptr, Alternate VectorTbl ptr
;
; Original VectorTbl ptr table entry is to deal with errors
;
#define MaxFlashTblEntries 6
#define FlashTblEntrySize 10
FlashTbl:			.byte	FlashTblEntrySize * (MaxFlashTblEntries+1)

#if GPS
;
; GPS input buffer
;
#define	GPSInBufLength	100
GPSInBuf:			.byte	GPSInBufLength
#if DEBUG
GPSInBufGuard:		.byte	4
#endif
#if DEBUG
GPSUpdateRTCTime:	.byte	1
GPSUpdateRTCDate:	.byte	1
GPSInCnt:			.byte	1
#endif
MenuGPSVal:			.byte	1
GPSOKToUpdate:		.byte	1
#endif		; GPS

GlobalVars:

#define TimeTicks		Y+(xTimeTicks-GlobalVars)
xTimeTicks:			.byte	1
;
; The following six variables can also be addressed
; using a TimeDateBlock Ptr,
;
AVRTimeDateBlk:
xAvrSecs:			.byte	1
xAvrMins:			.byte	1
xAvrHrs:			.byte	1
xAvrDay:			.byte	1
xAvrMonth:			.byte	1
xAvrYear:			.byte	1
;
; Y relative addressing
;
#define AvrSecs			Y+(xAvrSecs-GlobalVars)
#define AvrMins			Y+(xAvrMins-GlobalVars)
#define AvrHrs			Y+(xAvrHrs-GlobalVars)
#define AvrDay			Y+(xAvrDay-GlobalVars)
#define AvrMonth		Y+(xAvrMonth-GlobalVars)
#define AvrYear			Y+(xAvrYear-GlobalVars)

#if GPS
;
; The following six variables can also be addressed
; using a TimeDateBlock Ptr,
;
UTCTimeDateBlk:
xUTCSecs:			.byte	1
xUTCMins:			.byte	1
xUTCHrs:			.byte	1
xUTCDay:			.byte	1
xUTCMonth:			.byte	1
xUTCYear:			.byte	1
;
; Y relative addressing
;
#define UTCSecs			Y+(xUTCSecs-GlobalVars)
#define UTCMins			Y+(xUTCMins-GlobalVars)
#define UTCHrs			Y+(xUTCHrs-GlobalVars)
#define UTCDay			Y+(xUTCDay-GlobalVars)
#define UTCMonth		Y+(xUTCMonth-GlobalVars)
#define UTCYear			Y+(xUTCYear-GlobalVars)
#endif
;
; Z relative Time addressing
;
#define pSecs			Z+(xAvrSecs-AVRTimeDateBlk)
#define pMins			Z+(xAvrMins-AVRTimeDateBlk)
#define pHrs			Z+(xAvrHrs-AVRTimeDateBlk)
#define pDay			Z+(xAvrDay-AVRTimeDateBlk)
#define pMonth			Z+(xAvrMonth-AVRTimeDateBlk)
#define pYear			Z+(xAvrYear-AVRTimeDateBlk)

#define PPSTimeOutCnt	Y+(xPPSTimeOutCnt-GlobalVars)
xPPSTimeOutCnt:		.byte	1			;in case PPS signal fails
#define ReloadPPSTimeOutCnt Y+(xReloadPPSTimeOutCnt-GlobalVars)
xReloadPPSTimeOutCnt: .byte	1
#define CurScanTblLen	Y+(xCurScanTblLen-GlobalVars)
xCurScanTblLen:		.byte	1			;current length of Display Scan Table
#define ShowCalibration		Y+(xShowCalibration-GlobalVars)
xShowCalibration:	 .byte	1			;if true, show Calibration Pattern
#define FlashCount		Y+(xFlashCount-GlobalVars)
xFlashCount:		.byte	1			;countdown for flash fields
#define RotationIndex	Y+(xRotationIndex-GlobalVars)
xRotationIndex:		.byte	1			;current index in Grid Offset Rotation. 0xff means disabled.
#define RotationCountdown Y+(xRotationCountdown-GlobalVars)
xRotationCountdown:	.byte	1			;Countdown for RotateGrid
#define UART_Ready		Y+(xUART_Ready-GlobalVars)
xUART_Ready:		.byte	1
#define pUART_Buffer	Y+(xpUART_Buffer-GlobalVars)
xpUART_Buffer:		.byte	2
#define TXBufferIndex	Y+(xTXBufferIndex-GlobalVars)
xTXBufferIndex:		.byte	1
#define RXBufferHead	Y+(xRXBufferHead-GlobalVars)
xRXBufferHead:		.byte	1
#define RXBufferTail	Y+(xRXBufferTail-GlobalVars)
xRXBufferTail:		.byte	1
#define	DisplayRedrawFlg Y+(xDisplayRedrawFlg-GlobalVars)
xDisplayRedrawFlg:	.byte	1
#define Timer0Counter	Y+(xTimer0Counter-GlobalVars)
xTimer0Counter:		.byte	1
#define Timer1Counter	Y+(xTimer1Counter-GlobalVars)
xTimer1Counter:		.byte	2
#define	BtnPosition		Y+(xBtnPosition-GlobalVars)
xBtnPosition:		.byte	1
#define	KeyState		Y+(xKeyState-GlobalVars)
xKeyState:			.byte	1
#define	CModState		Y+(xCModState-GlobalVars)
xCModState:			.byte	1
#define	CMenuState		Y+(xCMenuState-GlobalVars)
xCMenuState:		.byte	1
#define	CModFlashPtr1	Y+(xCModFlashPtr1-GlobalVars)
xCModFlashPtr1:		.byte	2
#define	CModFlashPtr2	Y+(xCModFlashPtr2-GlobalVars)
xCModFlashPtr2:		.byte	2
#define	CMenuFlashPtr	Y+(xCMenuFlashPtr-GlobalVars)
xCMenuFlashPtr:		.byte	2
#define	PPSFlashPtr		Y+(xPPSFlashPtr-GlobalVars)
xPPSFlashPtr:		.byte	2
#define	BatteryLow		Y+(xBatteryLow-GlobalVars)
xBatteryLow:		.byte	1			;RTC reported low battery
#define	DialFlashPtr	Y+(xDialFlashPtr-GlobalVars)
xDialFlashPtr:		.byte	2
#define	fpSpecialClockWorks		Y+(xfpSpecialClockWorks-GlobalVars)
xfpSpecialClockWorks: .byte	2		;ptr to function
#define	CTextFlashPtr	Y+(xCTextFlashPtr-GlobalVars)
xCTextFlashPtr:		.byte	2
#define	UsrNameEditIdx	Y+(xUsrNameEditIdx-GlobalVars)
xUsrNameEditIdx:		.byte	1
#define	MenuUsrNameCnt	Y+(xMenuUsrNameCnt-GlobalVars)
xMenuUsrNameCnt:		.byte	1
#define	CurrPlayMode	Y+(xCurrPlayMode-GlobalVars)
xCurrPlayMode:		.byte	1
#define	TextFlashField	Y+(xTextFlashField-GlobalVars)
xTextFlashField:		.byte	1		;Buf Field Mod Flag
#define	CurrDial12DigitsPtr	Y+(xCurrDial12DigitsPtr-GlobalVars)
xCurrDial12DigitsPtr:		.byte	2
#define	CurrDial24DigitsPtr	Y+(xCurrDial24DigitsPtr-GlobalVars)
xCurrDial24DigitsPtr:		.byte	2
#define	MenuCalVal	Y+(xMenuCalVal-GlobalVars)
xMenuCalVal:			.byte	1
#define	MenuLedVal	Y+(xMenuLedVal-GlobalVars)
xMenuLedVal:			.byte	1
#define	MenuBurninVal	Y+(xMenuBurninVal-GlobalVars)
xMenuBurninVal:		.byte	1
#define	MenuDialVal	Y+(xMenuDialVal-GlobalVars)
xMenuDialVal:		.byte	1
#define	MenuNumVal	Y+(xMenuNumVal-GlobalVars)
xMenuNumVal:			.byte	1
#define	MenuPlayVal	Y+(xMenuPlayVal-GlobalVars)
xMenuPlayVal:			.byte	1
#define	G2_FLAGS		Y+(xG2_FLAGS-GlobalVars)
xG2_FLAGS:			.byte	1

MenuChronoVal:		.byte	1
MenuDSTMode:		.byte	1
MenuUsrNameVal:		.byte	1
MenuEEInitVal:		.byte	1
BatFlashPtr:		.byte	2
RTCNotPresent:		.byte	1
SavedRotationIndex:	.byte	1
UsrNameDflt:		.byte	1
CurrNumericHPos:	.byte	1
;
; Critical Data Order. These Variables are read as a block from EEProm
;
EEConfigData:
LedDisabled:		.byte	1		;if true, disable LED blinking (power saver)
Verbose:			.byte	1		;spit out more info
oldAVRClockMaster:	.byte	1		;can be reused after init
oldNum:				.byte	1		;can be reused after init
oldAMPM:			.byte	1		;can be reused after init
ClockEverRun:		.byte	1
BurnInDisabled:		.byte	1
oldFullDial:		.byte	1		;can be reused after init
CurrNumVal:			.byte	1
CurrDialVal:		.byte	1
PPSTrigger:			.byte	1		;Positive or Negative going edge
DSTMode:			.byte	1		;Daylight Saving Time mode (none, US, EU)
DSTFYears:			.byte	1		;bit array marking years for which DST Forward has been applied
DSTBYears:			.byte	1		;bit array marking years for which DST Backward has been applied
GPSInEnabled:		.byte	1
GPSOffset:			.byte	1		;Local Time Zone Offset
UsrNameFlg:			.byte	1		;Display UsrName or not
UsrNameCnt:			.byte	1		;UsrName length in EEprom
BeamParkVal:		.byte	1		;Current Beam Parking Method UNUSED in V3.0
ChronoEnabled:		.byte	1
EEConfigDataEnd:
;
; End Critical Data Order. These Variables are read as a block from EEProm
;
#if Mega32
LedStatus:			.byte	1
#endif

#if DEMOMODE
DemoEnabled:		.byte	1
#endif

TXBuffer:			.byte	MAXTXBUFFERLEN
RXBuffer:			.byte	MAXRXBUFFERLEN
RXLFDetected:		.byte	1

#if CHRONOMETER
RefreshCnt:			.byte	2
#endif
;
; Daylight Saving Time data
;
DSTForwardHr:		.byte	1
DSTBackMonth:		.byte	1
DSTForwardDay:		.byte	1
DSTBackDay:			.byte	1
GPSLastHrFlag:		.byte	1
AllowDSTFix:		.byte	1
