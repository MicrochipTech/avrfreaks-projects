; dac.h -- included source for Dutchtronix Oscilloscope Clock
;
;  Copyright � 2008 Johannes P.M. de Rie
;
;  All Rights Reserved
;
;  This file is part of the Dutchtronix Oscilloscope Clock Distribution.
;  Use, modification, and re-distribution is permitted subject to the
;  terms in the file named "LICENSE.TXT", which contains the full text
;  of the legal notices and should always accompany this Distribution.
;
;  This software is provided "AS IS" with NO WARRANTY OF ANY KIND.
;
;  This notice (including the copyright and warranty disclaimer)
;  must be included in all copies or derivations of this software.
;
; Firmware for Dutchtronix AVR Oscilloscope Clock 
;
#if ZINVERTED
#define BEAMON	cbi DACZX			;low implies no Z-axis control
#define BEAMOFF	sbi	DACZX			;high means decreased intensity
#else
#define BEAMON	sbi DACZX			;Hi implies no Z-axis control
#define BEAMOFF	cbi	DACZX			;Lo means decreased intensity
#endif


