Dutchtronix AVR Oscilloscope Clock V3.0

Firmware for the Dutchtronix AVR Oscilloscope clock.

February 19, 2008

This project needs to be build with the Atmel AVR Studio tools, freely available from Atmel. I am using V4.13 SP2, build 571 but expect older versions to work as well. See (http://www.atmel.com/dyn/products/tools_card.asp?tool_id=2725).
The only 2 files needed from the distribution are "avrasm2.exe" and "m168def.inc". Use the file "AvrBuild.bat" to assemble the software (it expects the AVR Studio files to be installed in the default locations). Alternatively, you can create a new AVR Studio "Atmel AVR Assembler" project and add the file "Scopeclock.asm" as the source file; the other source files will be included.

Programming the AVR clock with the Atmel Dragon is possible by uncommenting the last command line in the batch file (assuming you have installed the 10-pin header on the AVR clock board and have installed the proper cable, incl. a 6-pin to 10-pin adapter)
Of course, you can use your favorite AVR Programmer. Just keep in mind that you will lose the bootstrap loader present on the AVR clock (if you purchased a kit incl. pre-programmed ATmega168)  using this method. I suggest saving the existing firmware first, so you can reload the clock, complete with the bootstrap loader, later on.

If you don't have an AVR programmer, you can use the serial port on your PC to update the Dutchtronix AVR Oscilloscope Clock. Updating the Dutchtronix AVR Oscilloscope Clock, is described in detail on the Dutchtronix website:

	http://dutchtronix.com/ClockFirmwareUpdate.htm

Operating instructions are listed on the AVR Oscilloscope Clock page:

	http://dutchtronix.com/Operating.htm


The Dutchtronix AVR Oscilloscope Clock hardware uses an Atmega168, which is the default build target. However, this application will also work on an Atmega32, if you add the RTC, DAC and RS-232 level converter hardware yourself. See ScopeClockConfig.h for possible pin use.

Due to the design of the Atmega168, no port has all 8 bit available for I/O if you want to use the serial port and a crystal. This is the reason for the splitting of the DAC access across 2 ports. Some of the bits of PORTC, PC4 and PC5, are used to access the Real Time Clock using the I2C protocol. By setting these bits to INPUT when the RTC is not being accessed, we can set the lower 4 bits of PORTC while ignoring the effect on the upper 4 bits, thus speeding up access to the DAC. The code for the ATmega32, which was used for development (it supports JTAG which is a much faster debugging environment than "debugwire") is simpler since the ATmega32 has a full port dedicated to the DAC (PORTA). 

The source code is formatted for tabs=4, the default in AVR Studio. It was optimized for minimal space since the firmware needs to fit in 15 KBytes to allow for the bootloader (word address 0..0x3bff)).

The file "avr.inc" is used for various handy macro definitions. This file originates from ChaN (http://elm-chan.org/)

Please respect the license conditions included in each file; see the file LICENSE.TXT for details.

Suggestions for improvements and notification of bugs are always welcome: jdr@dutchtronix.com

Good luck

Jan de Rie
Dutchtronix
