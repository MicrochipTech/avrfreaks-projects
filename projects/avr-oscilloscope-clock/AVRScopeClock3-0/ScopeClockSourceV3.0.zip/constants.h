; constants.h -- included source for Dutchtronix Oscilloscope Clock
;
;  Copyright � 2008 Johannes P.M. de Rie
;
;  All Rights Reserved
;
;  This file is part of the Dutchtronix Oscilloscope Clock Distribution.
;  Use, modification, and re-distribution is permitted subject to the
;  terms in the file named "LICENSE.TXT", which contains the full text
;  of the legal notices and should always accompany this Distribution.
;
;  This software is provided "AS IS" with NO WARRANTY OF ANY KIND.
;
;  This notice (including the copyright and warranty disclaimer)
;  must be included in all copies or derivations of this software.
;
; Firmware for Dutchtronix AVR Oscilloscope Clock 
;
; Scope Clock Constants
;
.equ	NULL = 0
.equ	CR	=	13
.equ	LF	=	10
.equ	TICKS_HZ =			60
.equ	TIMEOUTTICKS =  	62	;>1  second timeout
.equ	FASTTIMEOUTTICKS =  2	;force clock to run fast
.equ	FLASHPERSEC = 		4
.equ	FLASHTICKS	=		TICKS_HZ/FLASHPERSEC
.equ	BURNINCOUNTDOWN =	5	;move grid every 5 minutes to prevent burn-in
.equ	INP_TIMEOUT = 		30	;must be <60
.equ	TIMER0TIMEOUT = 	125	;a little over 1 second
.equ	TIMER1TIMEOUT = 	1800 ;about 30 seconds
.equ	TIMER1TIMEOUT4SEC = 240	;about 4 seconds

;
; Timer1 computations
;
; 16 Mhz:		60 Hz: -1042 = oxfbee
; 20 Mhz:		60 Hz: -1302 = 0xfaea
;
#if Mega88|Mega168
.equ	Timer1CountUpL = low(1302)	;timer1 set for 60 Hz
.equ	Timer1CountUpH = high(1302)
.equ	Timer0CountUp	= 127		;timer0 set for 6.5536 mSec
.equ	Timer2CountUp = 195			;timer2 set for 9.98 mSec
#elif Mega32
.equ	Timer1CountUpL = low(1042)	;timer1 set for 60 Hz
.equ	Timer1CountUpH = high(1042)
.equ	Timer0CountUp	= 102		;timer0 set for 6.528 mSec
.equ	Timer2CountUp = 156			;timer2 set for 9.98 mSec
#endif

#define MAXTXBUFFERLEN	256
#define MAXRXBUFFERLEN	128
#define RXBUFFERMASK	0b01111111	;2^7-1
;
; G_FLAGS bits
;
#define		fRcvdChar	0
#define		fUpdSecond	2
#define		fTC0		3
#define		fMIN		4
#define		fUP			5
#define		fFLASH		6
#define		fTimeOut	7
;
; G2_FLAG bits (infrequent)
;
#define		fHR			1
#define		fDOWN		3
#define		fDBGT		5
;
; flags in DemoEnabled
;
#define		fDemoGoing	0
#define		fDemoPPS	1
#define		fDemoBurnIn	2
;
; EEPROM layout
;
; Certain status flags are saved in the EEPROM area.
; These flags must have a default (normal) value of 0
; since the EEProm is 0xFF when unprogrammed which will be
; mapped to 0 when begin read by the clock.
;
; Note that the bootloader will save some data at the EEPROM End area
;
; the EEPROM Configuration area is read all at once at startup.
;
#define EEPROM_LED	0
#define EEPROM_VERBOSE 1
#define EEPROM_AVR	2			;Unused in V3
#define EEPROM_NUM	3			;Unused in V3
#define EEPROM_AMPM	4			;Unused in V3
#define EEPROM_RTCINIT 5
#define EEPROM_BURN 6
#define EEPROM_FD 7				;Unused in V3
#define	EEPROM_NUMERIC	8		;numeric display mode
#define	EEPROM_DIAL		9		;clock dial mode
#define	EEPROM_PPSTRIG	10		;PPS Trigger mode
#define	EEPROM_DSTMODE	11		;Daylight Savings Time mode
#define	EEPROM_DSTFVEC	12		;Daylight Savings Time Forward bit vector
#define	EEPROM_DSTBVEC	13		;Daylight Savings Time Backward bit vector
#define	EEPROM_GPSMODE	14		;GPSEnabled mode (Can't use composite value for GPS)
#define EEPROM_GPSOFFSET 15		;Local Time Offset from UTC/GPS
#define EEPROM_USRNAMEFLG 16
#define EEPROM_USRNAMECNT 17    ;USRNAME char count (0 means no UsrName)
#define	EEPROM_BEAMPARK 18		;Beam Parking method. Unused in V3
#define EEPROM_CHRONO	19		;Chronometer enabled


#define EEPROM_USRNAME 30		;Assume Max Len = 20
#define MAXUSRNAMELEN 20

#define	EEPROM_DEMOHELP 50

#define EEPROM_HELP 170

#define	DEFCHARWIDTH		12
#define	HALFSPACECHARWIDTH	4
#define	COLONCHARWIDTH		8
#define	DASHCHARWIDTH		10
#define	MINNUMERICH			6
#define	MINNUMERICV			8
#define	NUMERICVPOS			(81 - MINNUMERICV)
#define	NUMERICCHRONOPOS	(6*DEFCHARWIDTH+3*COLONCHARWIDTH)

#define LOGOHPOS			25
#define LOGOVPOS			235
#define MENUHPOS			5
#define MENUH2POS			130
#define MENU0VPOS			195
#define MENU1VPOS			170
#define MENU2VPOS			145
#define MENU3VPOS			120
#define MENU4VPOS			95
#define MENU5VPOS			70
#define MENU6VPOS			45
#define MENU7VPOS			20

#define	DEMOHPOS			105
#define	DEMOVPOS			45

#define	STATUSGHPOSANALOG	121	
#define	STATUSGHPOSBIN		121
#define	STATUSBHPOSANALOG	107	
#define	STATUSBHPOSBIN		107
#define	STATUSPHPOSANALOG	135	
#define	STATUSPHPOSBIN		135
#define	STATUSVPOSANALOG	180
#define	STATUSVPOSBIN		1

#define TEXTACLOCKVPOS 		145
#define TEXTBCLOCKVPOS 		25
#define TEXTHPOS			40		;initially

#define	P2SVPOS				DEMOVPOS
#define	P2SHPOS				55

#define ESCAPE				0x0b	;make sure this ESCAPE value is never used in the vector tables
#define	SPACE				32
#define	UNDERSCORE			95
#define	HALFSPACE			128

#define BINVPOS0			105
#define BINVPOS1			140
#define BINVPOS2			175
#define BINVPOS3			210

#define LedHHHPOS			32
#define LedHLHPOS			55
#define LedMHHPOS			110
#define LedMLHPOS			133
#define LedSHHPOS			184
#define LedSLHPOS			207

#define CMODIDLE			40
#define CMODPREHRNR			41
#define CMODHRNR			42
#define CMODMINNR			43
#define CMODSECNR			44
#define CMODPREHRHAND		45
#define CMODHRHAND			46
#define	CMODMINHAND			47
#define	CMODSECHAND 		48
#define	CMODPRESET			49
#define	CMODSET				50
#define CMODCANCEL			51

#define	CMODPREHRBIN 		60
#define	CMODHRBIN			61
#define	CMODMINBIN			62
#define	CMODSECBIN			63

#define	CMODDATE	0b01000000
#define CMODDAY		(0|CMODDATE)
#define CMODMONTH	(1|CMODDATE)
#define CMODPREYEAR	(2|CMODDATE)
#define CMODYEAR	(3|CMODDATE)
#define	CMODDATESET (4|CMODDATE)
#define CMODPREDAY	(5|CMODDATE)
;
#define CMENUIDLE			79
#define CMENUNUM			80
#define CMENUDIAL			81
#define CMENUGPS			82
#define CMENUDST			83
#define CMENUBOOT			84
#define CMENUDEMO			85
#define CMENUCHRONO			86
#define	CMENUCAL			87
#define CMENULED			88
#define CMENUBURN			89
#define CMENUFUN			90
#define CMENUINIT			91
#define CMENUNAME			92
#define	CMENUNAMEDIT		93
#define CMENULAST      		CMENUNAMEDIT

#define FUNNORM       		32
#define FUNREV          	33
#define FUNFASTF        	34
#define FUNFASTR        	35
#define RUNCLOCKREVERSE 	0
#define RUNCLOCKFAST    	1

#define USRNAMEOFF      	0
#define USRNAMEON       	1
#define USRNAMEEDIT     	2

#define DIAL12HR			10
#define DIAL24HR			11
#define DIALROMAN			12
#define DIALBIN				13
#define DIALMIN				14

#define	NUM12HR				20
#define	NUM24HR				21
#define	NUMHEX				22
#define	NUMDATE				23
#define	NUMOFF				24

#define	NOGPS				60
#define	GPSOFSMIN12			61
#define	GPSOFSPLUS12 		85

#define NOPUSH				0x80
;
; DOUBLESTRING is ((1 << DOUBLEPTRBIT) * 256)
#define DOUBLESTRING		((1 << DOUBLEPTRBIT) * 256)
#define DOUBLEPTRBIT		6
;
; STRINGFLASH is ((1 <<STRINGFLASHBIT) * 256)
#define STRINGFLASH			((1 <<STRINGFLASHBIT) * 256)
#define STRINGFLASHBIT		7
#define	HourInString		1
#define	MinInString			2
#define	SecInString			3
#define DayInString			HourInString
#define	MonthInString		4
#define YearInString		5
#define NoneInString		6

#define	DSTUS				0
#define	DSTEU				1
#define	DSTNONE				2
#define DSTFORWARDMONTH 	3
#define	DSTUSBACKMONTH 		11
#define	DSTEUBACKMONTH 		10
#define DSTBACKHOUR 		2
#define DSTUSFORWARDHR 		2
#define DSTEUFORWARDHR 		1


