#!/bin/bash
#
#
# Added by Scott Vitale for AttoBASIC support
make clean > /dev/null 2>&1 ; make USB1286-8M > /dev/null 2>&1 
make clean > /dev/null 2>&1 ; make USB1286-16M > /dev/null 2>&1 
make clean > /dev/null 2>&1 ; make M32U4-8M > /dev/null 2>&1 
make clean > /dev/null 2>&1 ; make M32U4-16M > /dev/null 2>&1 
make clean > /dev/null 2>&1 ; make TEENSYPP20 > /dev/null 2>&1 
make clean > /dev/null 2>&1 
