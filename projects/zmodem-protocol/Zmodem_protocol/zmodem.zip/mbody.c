/*********************************************
Project : ZModem
Version : V2.02
Date    : 21 April 2002
Author  : Radu Hristea (radu.hristea@aptrans-group.com; transeast@programmer.net)
Company : TransEast s.r.l. - Bucharest
Comments: Total size = less than 3000 words !!! (including the UART communication 
		  stuff, the dummy "file-functions" and also the demo program !!!)
		  Remark: This version implements ONLY the basic features of ZModem.

Chip type           : ATmega128
Program type        : Application
Clock frequency     : 7.372800 MHz
Memory model        : Small
Internal SRAM size  : 4096
External SRAM size  : 0
Data Stack size     : 1024
*********************************************/

#include <mega128.h>   
// include other headers   
#include <stdio.h> 
#include <stdlib.h>
#include <string.h> 
#include <delay.h> 
#include "defs.h"

//USARTs (Rx & Tx)
#define UPE  2
#define OVR  3
#define FE   4
#define UDRE 5

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR  (1<<UPE)
#define DATA_OVERRUN  (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
     
// USART0 Receiver buffer
#define RX_BUFFER_SIZE0 32
byte rx_buffer0[RX_BUFFER_SIZE0];
byte rx_wr_index0, rx_rd_index0, rx_counter0;
// This flag is set on USART0 Receiver buffer overflow
bit rx_buffer_overflow0;

// USART0 Receiver interrupt service routine
#pragma savereg-
interrupt [USART0_RXC] void uart0_rx_isr(void)
{
 byte status, data;
 #asm
    push r26
    push r27
    push r30
    push r31
    in   r26,sreg
    push r26
 #endasm
 status = UCSR0A;
 data   = UDR0;
 if((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN)) == 0)
 {
   rx_buffer0[rx_wr_index0] = data;
   if(++rx_wr_index0 == RX_BUFFER_SIZE0) 
      rx_wr_index0 = 0;
   if(++rx_counter0 > RX_BUFFER_SIZE0)
      rx_buffer_overflow0 = 1;
 }
 #asm
    pop  r26
    out  sreg,r26
    pop  r31
    pop  r30
    pop  r27
    pop  r26
 #endasm
}
#pragma savereg+

#ifndef _DEBUG_TERMINAL_IO_
// Get a character from the USART0 Receiver buffer
#define _ALTERNATE_GETCHAR_
#pragma used+
char getchar(void)
{
  char data;
  
  while(rx_counter0 == 0);
  data = rx_buffer0[rx_rd_index0];
  if(++rx_rd_index0 == RX_BUFFER_SIZE0) 
  	 rx_rd_index0 = 0;	
  #asm("cli")
   --rx_counter0;
  #asm("sei")
  return data;
}          
#pragma used-
#endif 

// USART0 Transmitter buffer
#define TX_BUFFER_SIZE0 8
byte tx_buffer0[TX_BUFFER_SIZE0];
byte tx_wr_index0,tx_rd_index0,tx_counter0;

// USART0 Transmitter interrupt service routine
#pragma savereg-
interrupt [USART0_TXC] void uart0_tx_isr(void)
{
 #asm
    push r26
    push r27
    push r30
    push r31
    in   r26,sreg
    push r26
 #endasm
 if(tx_counter0)
 {
   --tx_counter0;
   UDR0 = tx_buffer0[tx_rd_index0];
   if(++tx_rd_index0 == TX_BUFFER_SIZE0) 
      tx_rd_index0 = 0;
 }
#asm
    pop  r26
    out  sreg,r26
    pop  r31
    pop  r30
    pop  r27
    pop  r26
#endasm
}
#pragma savereg+

#ifndef _DEBUG_TERMINAL_IO_
// Write a character to the USART0 Transmitter buffer
#define _ALTERNATE_PUTCHAR_
#pragma used+
void putchar(char c)
{
 while(tx_counter0 == TX_BUFFER_SIZE0);
 #asm("cli")
 if(tx_counter0 || ((UCSR0A & DATA_REGISTER_EMPTY) == 0))
 {
   tx_buffer0[tx_wr_index0] = c;
   if(++tx_wr_index0 == TX_BUFFER_SIZE0) 
      tx_wr_index0 = 0;
   ++tx_counter0;
 }
 else UDR0 = c;
 #asm("sei")
}
#pragma used-
#endif

// USART1 Receiver buffer
#define RX_BUFFER_SIZE1 48
byte rx_buffer1[RX_BUFFER_SIZE1];
byte rx_wr_index1, rx_rd_index1, rx_counter1;
// This flag is set on USART1 Receiver buffer overflow
bit rx_buffer_overflow1;

// USART1 Receiver interrupt service routine
#pragma savereg-
interrupt [USART1_RXC] void uart1_rx_isr(void)
{
 byte status, data;
 #asm
    push r26
    push r27
    push r30
    push r31
    in   r26,sreg
    push r26
 #endasm
 status = UCSR1A;
 data   = UDR1;
 if((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN)) == 0)
 {
   rx_buffer1[rx_wr_index1] = data;
   if(++rx_wr_index1 == RX_BUFFER_SIZE1) 
      rx_wr_index1 = 0;
   if(++rx_counter1 > RX_BUFFER_SIZE1)
      rx_buffer_overflow1 = 1;
 }
 #asm
    pop  r26
    out  sreg,r26
    pop  r31
    pop  r30
    pop  r27
    pop  r26
 #endasm
}
#pragma savereg+

// Get a character from the USART1 Receiver buffer
#pragma used+
char getchar1(void)
{
  byte data;
  
  while(rx_counter1 == 0);
  data = rx_buffer1[rx_rd_index1];
  if(++rx_rd_index1 == RX_BUFFER_SIZE1) 
     rx_rd_index1 = 0;
  #asm("cli")
   --rx_counter1;
  #asm("sei")
  return data;
}
#pragma used-

// USART1 Transmitter buffer
#define TX_BUFFER_SIZE1 8
byte tx_buffer1[TX_BUFFER_SIZE1];
byte tx_wr_index1, tx_rd_index1, tx_counter1;

// USART1 Transmitter interrupt service routine
#pragma savereg-
interrupt [USART1_TXC] void uart1_tx_isr(void)
{
#asm
    push r26
    push r27
    push r30
    push r31
    in   r26,sreg
    push r26
#endasm
   if(tx_counter1)
   {
     --tx_counter1;
     UDR1 = tx_buffer1[tx_rd_index1];
     if(++tx_rd_index1 == TX_BUFFER_SIZE1) 
     	tx_rd_index1 = 0;
   }
#asm
    pop  r26
    out  sreg,r26
    pop  r31
    pop  r30
    pop  r27
    pop  r26
#endasm
}
#pragma savereg+

// Write a character to the USART1 Transmitter buffer
#pragma used+
void putchar1(char c)
{
  while(tx_counter1 == TX_BUFFER_SIZE1);
  #asm("cli")
  if(tx_counter1 || ((UCSR1A & DATA_REGISTER_EMPTY) == 0))
  {
     tx_buffer1[tx_wr_index1] = c;
     if(++tx_wr_index1 == TX_BUFFER_SIZE1) 
     	tx_wr_index1 = 0;
     ++tx_counter1;
  }
  else UDR1 = c;
  #asm("sei")
}
#pragma used-   


// Declare your global variables here
extern dword fileSize;
extern byte fileName[];

//-----------------------------------------------------------------------------
void main(void)
//-----------------------------------------------------------------------------
{
// Declare your local variables here


// USART0 initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART0 Receiver: On
// USART0 Transmitter: On
// USART0 Mode: Asynchronous
// USART0 Baud rate: 38400 (Double Speed Mode)
UCSR0A=0x02;
UCSR0B=0xD8;  
UCSR0C=0x06;
UBRR0L=0x17;
UBRR0H=0x00;

// USART1 initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART1 Receiver: On
// USART1 Transmitter: On
// USART1 Mode: Asynchronous
// USART1 Baud rate: 9600 (Double Speed Mode)
UCSR1A=0x02;
UCSR1B=0xD8;
UCSR1C=0x06;
UBRR1L=0x5F;
UBRR1H=0x00;

// Watchdog Timer initialization
// Watchdog Timer Prescaler: OSC/2048
WDTCR=0x1F;
WDTCR=0x0F;

// Global enable interrupts
#asm("sei") 
      
//------------------------------------------------------------------------------------
//			*** MY DEMO APPLICATION ***
//			- connect AVR UART0 to CodeVision's Terminal (38400 bps, 8N1)
//			- connect AVR UART1 to Windows HyperTerminal (9600 bps, 8N1)
//			- type 's' in CV's Terminal to send a dummy file to PC's HyperTerminal
//			- use "Rx File" from CV's Terminal to receive a file from HyperTerminal
//------------------------------------------------------------------------------------

 fileSize = FILE_SIZE; // dummy size
 strcpyf(fileName, "demo.txt");
 //
 while(TRUE)
 {
   wdogtrig();
   if(rx_counter0 && getchar() == 's') // press 's' to <start> the "SEND FILE operation"
   {
      // send a "dummy" file
      rZModem_ZSend();
   }
   if(rx_counter1) // is there any pending file ?	
   {  // receive the file  
      rZModem_ZReceive();
   } 
 }
}
     
