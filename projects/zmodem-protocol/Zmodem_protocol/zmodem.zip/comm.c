//-----------------------------------------------------------------------------
// Project:		ZModem
// Version:		V2.02
// Date:		21 April 2002
// Author:		Radu Hristea (radu.hristea@aptrans-group.com; transeast@programmer.net)
// File:		Comm.c
// Description:	This module handles all the UART communication stuff for ZModem
//-----------------------------------------------------------------------------

#include "defs.h" 

/* These functions must run very fast! So, stuff them as little as possible ! */
//-----------------------------------------------------------------------------
byte rComm_getUART(byte* buffer) /* Read from ZModem's UART... one byte */
//-----------------------------------------------------------------------------
{	// This function reads IMMEDIATELY.
	if(rx_counter1 == 0)
	   return FALSE; 
	if(rx_buffer_overflow1) // if overflow has occured, clear & return  
	{
	   rComm_clearInBound(); // clear the RX buffer
	   return FALSE;
	}     
	*buffer = getchar1(); // OK ! get the byte from the UART
	//
	return TRUE; // successful
}

/* this function can read with max. 3 sec. wait */
//-----------------------------------------------------------------------------
byte rComm_readByte(byte* buffer) 
//-----------------------------------------------------------------------------
{	//
	byte success;
	word cnt;
	//
	for(cnt = 0; cnt < 3000; cnt++) 
	{
	  wdogtrig();
	  success = rComm_getUART(buffer);
	  if(success == FALSE)
	     delay_ms(1); 
	  else // success = TRUE  
		 break;
	} 
	if(success == FALSE)                     
	   LastError = ZMODEM_TIMEOUT;
	return success;
}

//-----------------------------------------------------------------------------
// use this function to clear the RX buffer
void rComm_clearInBound(void) 
//-----------------------------------------------------------------------------
{ // Now make sure the RX line is clean...
  #asm("cli")
   rx_buffer_overflow1 = rx_counter1 = 0;
   rx_rd_index1 = rx_wr_index1 = 0;
  #asm("sei") 
}

