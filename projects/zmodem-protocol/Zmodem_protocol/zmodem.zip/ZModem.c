//-----------------------------------------------------------------------------
// Project:		ZModem
// Version:		V2.02
// Date:		21 April 2002
// Author:		Radu Hristea (radu.hristea@aptrans-group.com; transeast@programmer.net)
// File:		ZModem.c
// Description:	A module that implements a basic ZModem protocol.
//				Not all possible features are supported. 
//				Sending data is done using a 1024 bytes buffer.
//				Receiving is event-driven using "byte after byte" technique.
//-----------------------------------------------------------------------------

#include "defs.h" 

//***
	bit GotSpecial;
	bit GotHeader;
	bit MoreData;
	bit AllowFileWrite;
	byte LastError; 
	byte ch;
	byte NeedZACK;  
	byte HeaderType;
	byte HeaderData[4]; 
	word NrBytes;
	dword GoodOffset;
	dword fileSize;
	byte fileName[13]; 
	byte ZMBuffer[ZMAX_BUF];
//***	

//-----------------------------------------------------------------------------
// purpose:	sending file
// params:	none ->	global var. "FileIndex" is the file to send
// returns:	success (TRUE or FALSE)
byte rZModem_ZSend(void)
//-----------------------------------------------------------------------------
{	// 
	byte fin   = FALSE;
	byte quit  = FALSE;
	byte ok    = FALSE;
	byte tries = 0;
	// 
	GoodOffset = 0;
	LastError = NO_ERROR;
	//	
	// HERE: open the file 
	// send initialization string 
	putchar1('r');putchar1('z');putchar1(CR);
	while(ALLOK && !fin && (tries++ < ZMAX_RETRY)) // Send
	{
		wdogtrig();
		rZModem_sendHexHeader(ZRQINIT);//send ZRQINIT
		rZModem_getZMHeader();
		if(ALLOK)
		{
			switch(HeaderType)
			{
				case ZCAN://canceled from other side ???
					 return FALSE;
				break;
				
				case ZRINIT:// OK, let's communicate
					 // start sending files
					 ok = rZModem_sendFiles();
					 fin = TRUE;
				break;
			}//switch
		}//if(ALLOK)
		else
		{
			if((LastError == ZMODEM_TIMEOUT) || (LastError == ZMODEM_CRC) || // Send
			   (LastError == ZMODEM_BADHEX))    
			{
				LastError = NO_ERROR;
			}
		}
	}//while(...)
	// sendig is over, finish session
	if(ALLOK) 
	{
	   tries = 0;
	   while(!quit && (tries++ < ZMAX_RETRY))
	   {
      		 wdogtrig();
      		 rZModem_sendHexHeader(ZFIN); 
      		 rZModem_getZMHeader();
			 if(ALLOK)
			 { 
			    switch(HeaderType)
			    { 
         	      case ZCAN:
         	      	   return FALSE;
         	      break;	

			      case ZFIN:
         	           quit = TRUE; //other side has finish accepted
         	      break;
         	    }       
			 }
			 else
			 {
				LastError = NO_ERROR;
			 }
	   }
	   putchar1('O');putchar1('O'); //over and out
	}
    delay_ms(100);
    rComm_clearInBound(); // reject the garbage
	return (fin && ok && quit);
}

//-----------------------------------------------------------------------------
// purpose:	receiving file
// params:	none ->	global var. "FileIndex" is the file to receive
// returns:	success (TRUE or FALSE)
byte rZModem_ZReceive(void)
//-----------------------------------------------------------------------------
{	// 
	byte quit  = FALSE;
	byte tries = 0;
	// 
	LastError = NO_ERROR;
	AllowFileWrite = FALSE;
	//	
    // HERE: open the file      
    //
	while(ALLOK && !quit && (tries++ < ZMAX_RETRY))
	{
		  wdogtrig();
		  rZModem_getZMHeader(); 
		  if(ALLOK)
		  {
			 switch(HeaderType)
			 {
         	   case ZCAN:
         	      	return FALSE;
         	   break;	
			   
			   case ZRQINIT:
					rZModem_sendHexHeader(ZRINIT);
			   break;
				  
			   case ZFILE://file transfer signaled
					NeedZACK = 0x00;
					rZModem_getData(); // get file info     
					if(ALLOK)
					{
					   GoodOffset = 0;
					   AllowFileWrite = TRUE;
					   rZModem_receiveFile();//receive current file   
					   rZModem_sendHexHeader(ZRINIT);
					}
					else if(LastError == ZMODEM_CRC) 
					{
					   LastError = NO_ERROR;
					   rZModem_sendHexHeader(ZRINIT);
					}   
			   break;   

			   case ZFIN://other side has finish signaled
					rZModem_sendHexHeader(ZFIN);//reply
					rZModem_getOO(); //try to get "Over & Out" signal
					quit = TRUE;
			   break;
			 }
		  }
		  else
		  {
			 if((LastError == ZMODEM_TIMEOUT) || (LastError == ZMODEM_CRC) ||
				(LastError == ZMODEM_BADHEX)) // Receive  
			 {
				 LastError = NO_ERROR;
				 rZModem_sendHexHeader(ZRINIT);
			 }
		  }
	}             
	if(quit == FALSE)
	   rZModem_sendCAN();
    delay_ms(100);
    rComm_clearInBound(); // reject the garbage
	return quit; 
}

// Layer 3 ####################################################################
//-----------------------------------------------------------------------------
byte rZModem_sendFiles(void)
//-----------------------------------------------------------------------------
{	// 
	byte tries = 0;
	byte sent  = FALSE;
	byte rw    = FALSE;
	byte fileinfosent = FALSE;
	//******************************************************************
	while(ALLOK && !sent && (tries++ < ZMAX_RETRY)) // sendFiles
	{
		  wdogtrig();
		  if(!fileinfosent)
		  {
			 rZModem_sendBinHeader(ZFILE);
			 rZModem_sendFileInfo();
			 fileinfosent = TRUE;
		  }	
		  rZModem_getZMHeader(); 
		  if(ALLOK)
		  {
			 switch(HeaderType)
			 { 
         	   case ZCAN:
         	   	    return FALSE;
         	   break;	
	           
			   case ZRPOS:
				    GoodOffset = ((dword)HeaderData[2] << 16) |
							     ((dword)HeaderData[1] << 8)  | HeaderData[0];
				   	/*seek(GoodOffset);*/
					rw = rZModem_sendFile();
					sent = TRUE;
			   break;
			   
			   case ZNAK: //send again
					fileinfosent = FALSE;
	 		   break;
             }
		  }
		  else 
		  {
			   if(LastError == ZMODEM_TIMEOUT) // sendFiles
				  LastError = NO_ERROR;
		  }    
	}
	// HERE: close the file
	return rw;
}

//-----------------------------------------------------------------------------
byte rZModem_sendFile(void)
//-----------------------------------------------------------------------------
{	// 
	byte tries = 0;
	byte state = SM_SENDZDATA;
	//              
	while(ALLOK && (tries < ZMAX_RETRY))  
	{
		wdogtrig();
		switch(state)
		{
		   case SM_SENDZDATA: 
				while(rComm_getUART(&ch))
				{
				      wdogtrig();
				      if(ch == ZPAD || ch == CAN)
				      {
				         state = SM_GETHEADER; 
				         break;
				      }
				}  
		        if(state != SM_GETHEADER)
		        { 
				   rZModem_sendBinHeader(ZDATA);
				   state = SM_SENDDATA;
				}
		   break;
		   
		   case SM_SENDDATA:
				rDummy_readFromFile(ZMBuffer, ZMAX_BUF, &NrBytes);
				MoreData = (NrBytes == ZMAX_BUF);
				//
				if(ALLOK)
				{   // send ZCRCG if more data, ZCRCE otherwise
				    if(MoreData)
				    {
				       rZModem_sendData(ZCRCG);
				    }   
				    else
				    {
				       rZModem_sendData(ZCRCE);
				       state = SM_SENDZEOF;
				    } 
				    while(rComm_getUART(&ch))
				    {
				       wdogtrig();
				       if(ch == ZPAD || ch == CAN)
				       {
				          NrBytes = 0; 
				          rZModem_sendData(ZCRCE); // empty data subPacket    
				          state = SM_GETHEADER; 
				          break;
				       }
				    }   
				}  
		   break;
		   
		   case SM_GETHEADER:
		        rZModem_getZMHeader();   
				if(ALLOK)
				{ 
				   switch(HeaderType)
				   { 
         	      	 case ZCAN: 
         	      	 case ZFERR:
         	      	      return FALSE;
         	         break;	
				     
				     case ZRINIT:
				     case ZFIN  :
				          return TRUE;
				     break;
				     
				     case ZRPOS: 
				  	      state = SM_ACTIONRPOS;
				  	 break;  
				  	 
				  	 default:
				  	      tries++;
				   }
				}  
				else 
				{
					 LastError = NO_ERROR; 
					 tries++;
				}    
		   break;
		   
		   case SM_ACTIONRPOS:
				tries++;
				GoodOffset = ((dword)HeaderData[2] << 16) |
							 ((dword)HeaderData[1] << 8)  |	HeaderData[0];
				/*seek(GoodOffset);*/
				state = SM_SENDZDATA; 
		   break;
		   
		   case SM_SENDZEOF:
				rZModem_sendHexHeader(ZEOF);
				state = SM_GETHEADER;
		   break;
		}//switch
	}//while
	return FALSE; 
}

//-----------------------------------------------------------------------------
void rZModem_receiveFile(void)
//-----------------------------------------------------------------------------
{	// 
	byte quit  = FALSE;
	byte tries = 0; 
	// 
	while(ALLOK && !quit && (tries++ < ZMAX_RETRY))
	{
		  wdogtrig();
		  rZModem_sendHexHeader(ZRPOS);
		  rZModem_getZMHeader(); 
		  if(ALLOK)
		  {
			 switch(HeaderType)
			 {
			   case ZCAN:
			        LastError = ZMODEM_GOTZCAN;
			        return;
			   break; 
			 
			   case ZDATA:
				    rZModem_receiveData();
				    quit = TRUE;
			   break;
			 }
		  }
		  else
		  {
			 if((LastError == ZMODEM_TIMEOUT) || (LastError == ZMODEM_CRC) ||
			    (LastError == ZMODEM_BADHEX)) // receiveFile
			 {
				 LastError = NO_ERROR;
			 }
		  }
	}
}

//-----------------------------------------------------------------------------
void rZModem_receiveData(void)
//-----------------------------------------------------------------------------
{	// 
	byte quit  = FALSE;
	byte tries = 0;  
	//          
	NeedZACK = 0x01;
	MoreData = TRUE;
	while(ALLOK && !quit)
	{
		wdogtrig();
		if(MoreData)
		{
		   rZModem_getData();
		   if(ALLOK)
			  tries = 0;
		}
		else
		{
			if(NeedZACK == 0x03)
			{
			   rZModem_sendHexHeader(ZACK);
			   NeedZACK = 0x01;
			}
			rZModem_getZMHeader(); 
			if(ALLOK)
			{
			   switch(HeaderType)
			   {
			     case ZCAN:
			          LastError = ZMODEM_GOTZCAN;
			     break; 
			     
			     case ZDATA:
				      if(rZModem_positionMatch())
					     MoreData = TRUE;
			     break;
			     
			     case ZEOF:
				      if(rZModem_positionMatch())
					     quit = TRUE;
			     break;
			   }
			}
		}
		if(!ALLOK)
		{
		   if((LastError == ZMODEM_TIMEOUT) || (LastError == ZMODEM_LONGSP) || // receiveData
			  (LastError == ZMODEM_CRC)) 
		   {
			   if(tries++ < ZMAX_RETRY) // receiveData
			   {
				  LastError = NO_ERROR;
				  MoreData = FALSE;
				  rZModem_sendHexHeader(ZRPOS);
			   }
		   }
		}
	}
	// HERE: close the file
	if(quit == FALSE)
	{
	   // HERE: delete the file if it is not OK !
	}
}

// Layer 2 ####################################################################
//-----------------------------------------------------------------------------
void rZModem_getZMHeader(void)
//-----------------------------------------------------------------------------
{	// 
    byte count = 0;
    //
	GotHeader = FALSE;  
	rComm_readByte(&ch);
	if(ALLOK)
	{
	   while(ALLOK && (ch != ZPAD)) 
	   {
			 wdogtrig(); 
			 if(ch == CAN)
			 {
			    if(++count == 5)
			    {
			       GotHeader = TRUE;
			       HeaderType = ZCAN;
			       return;
			    } 
			 }
			 else
			    count = 0;
			 rComm_readByte(&ch);
	   }		 
	   if(ALLOK)
	   {
		  rComm_readByte(&ch);
		  while(ALLOK && (ch == ZPAD))
		  {
				wdogtrig();
				rComm_readByte(&ch);
		  }		
		  if(ALLOK && (ch == ZDLE))
		  {
			 rComm_readByte(&ch);
			 if(ALLOK)
			 {
				if(ch == ZBIN)
				   rZModem_getBinaryHeader();
				else
				   rZModem_getHexHeader();
			 }
		  }
	   }
	}
}

//-----------------------------------------------------------------------------
void rZModem_getOO(void) 
//-----------------------------------------------------------------------------
{   
	rComm_readByte(&ch); // get an 'O'
	if(ALLOK)
	   rComm_readByte(&ch); // another 'O'
	if(LastError == ZMODEM_TIMEOUT) 
	   LastError = NO_ERROR;
}

//-----------------------------------------------------------------------------
void rZModem_sendFileInfo(void)
//-----------------------------------------------------------------------------
{	// File size = max. 7 digits
	byte s[8];
	// 
   	ltoa(fileSize, s);
    sprintf(ZMBuffer, "%s%c%s%c", fileName, '\0', s, '\0');   
    NrBytes = (strlen(fileName) + 1 + strlen(s) + 1);
    rZModem_sendData(ZCRCW);
}

// Layer 1 ####################################################################
//-----------------------------------------------------------------------------
void rZModem_sendHexHeader(byte hType)
//-----------------------------------------------------------------------------
{	// 
	word crc = 0;
	byte i;
	//      
	wdogtrig();
	switch(hType)
	{
	  case ZRINIT :
	  case ZFIN   :
	  case ZRQINIT:
	       for(i = 0; i < 4; i++)
	           HeaderData[i] = 0;
	       if(hType == ZRINIT)
	           HeaderData[3] = CANOVIO;
	  break;                           
	  
	  case ZRPOS  :  
	       /*seek(GoodOffset);*/
	  case ZEOF   :
	  case ZACK   :
	       for(i = 0; i < 4; i++)
	           HeaderData[i] = (byte)(GoodOffset >> (byte)(8 * i));
	  break;
	}
	// sending now ...
	putchar1(ZPAD);
	putchar1(ZPAD);
	putchar1(ZDLE);
    putchar1(ZHEX);
   	ch = hType;
    crc = rZModem_crcUpdate(crc, ch); 
	rZModem_sendHexChar();
	for(i = 0; i < 4; i++)
	{
	   	wdogtrig();
	   	ch = HeaderData[i];
		crc = rZModem_crcUpdate(crc, ch);
    	rZModem_sendHexChar();
	}
   	ch = (byte)(crc >> 8); 
	rZModem_sendHexChar();
   	ch = (byte)crc; 
	rZModem_sendHexChar();
	//**************************
	putchar1(CR);putchar1(LF);
	if(hType != ZFIN && hType != ZACK)
	   putchar1(XON);
}

//-----------------------------------------------------------------------------
void rZModem_sendBinHeader(byte hType)
//-----------------------------------------------------------------------------
{	// 
	word crc = 0;
	byte i;
    // 
    wdogtrig();
    switch(hType)
    {
      case ZFILE:
	       for(i = 0; i < 3; i++)  
	           HeaderData[i] = 0;
	       HeaderData[3] = ZCRECOV;
      break;
      
      case ZDATA:
	       for(i = 0; i < 4; i++) 
	           HeaderData[i] = (byte)(GoodOffset >> (byte)(8 * i));
      break;
    }
    // sending now ...
	putchar1(ZPAD);
	putchar1(ZDLE);
	putchar1(ZBIN);
   	ch = hType;
    crc = rZModem_crcUpdate(crc, ch); 
	rZModem_sendDLEChar(); 
	for(i = 0; i < 4; i++)
	{
	   	wdogtrig();
	   	ch = HeaderData[i];
		crc = rZModem_crcUpdate(crc, ch);
    	rZModem_sendDLEChar(); 
	}
   	ch = (byte)(crc >> 8); 
	rZModem_sendDLEChar(); 
   	ch = (byte)crc; 
	rZModem_sendDLEChar(); 
}

//-----------------------------------------------------------------------------
void rZModem_getHexHeader(void)
//-----------------------------------------------------------------------------
{	// 
	word crc = 0;
	byte i;
	// 
	rZModem_getNextHexCh();
	if(ALLOK)
	{
		HeaderType = ch;
		crc = rZModem_crcUpdate(crc, ch);
		rZModem_getNextHexCh();
		if(ALLOK)
		{
		   for(i = 0; i < 4; i++)
		   {
		   	   wdogtrig();
		   	   HeaderData[i] = ch;
			   crc = rZModem_crcUpdate(crc, ch);
			   rZModem_getNextHexCh();
		   }
		}
		if(ALLOK)
		{
			crc = rZModem_crcUpdate(crc, ch);
			rZModem_getNextHexCh();
		}
		if(ALLOK)
		{
			crc = rZModem_crcUpdate(crc, ch);
			// try to throw away 2 bytes: CR/LF ...
			rZModem_getOO(); // tricky, but very (re-)useful !!! 
			// now test the CRC ...
			if(crc)
				LastError = ZMODEM_CRC;
			else
				GotHeader = TRUE;
		}
	}
}

//-----------------------------------------------------------------------------
void rZModem_getBinaryHeader(void)
//-----------------------------------------------------------------------------
{	// 
	word crc = 0;
	byte i;
	// 
	rZModem_getNextDLECh();
	if(ALLOK)
	{
		HeaderType = ch;
		crc = rZModem_crcUpdate(crc, ch);
		rZModem_getNextDLECh();
		if(ALLOK)
		{
      	   for(i = 0; i < 4; i++)
      	   {
      		   wdogtrig();
      		   HeaderData[i] = ch;
			   crc = rZModem_crcUpdate(crc, ch);
			   rZModem_getNextDLECh();
		   }
		}
		if(ALLOK)
		{
      		crc = rZModem_crcUpdate(crc, ch);
			rZModem_getNextDLECh();
		}
		if(ALLOK)
		{
      		crc = rZModem_crcUpdate(crc, ch);
			if(crc)
				LastError = ZMODEM_CRC;
			else
				GotHeader = TRUE;
		}
	}
}


//-----------------------------------------------------------------------------
byte rZModem_positionMatch(void)
//-----------------------------------------------------------------------------
{	// 
	dword temp;
	// 
	temp = HeaderData[2]; 
	temp = (temp << 8) | HeaderData[1]; 
	temp = (temp << 8) | HeaderData[0]; 
	return (temp == GoodOffset);
}

//-----------------------------------------------------------------------------
void rZModem_getData(void)
//-----------------------------------------------------------------------------
{   // 
	byte quit = FALSE; 
	word crc = 0;
	word i = 0;
	// 
	while(ALLOK && (i <= 1024) && !quit)
	{
		  wdogtrig();
		  rZModem_getNextDLECh();
		  if(ALLOK)
		  {
			 if(GotSpecial)
			 {  
				switch(ch)
				{
				  case ZCRCW:
				  	   NeedZACK |= 0x02;
				  case ZCRCE:	
				       MoreData = FALSE;
				  break;
				}   
			    crc = rZModem_crcUpdate(crc, ch);
				rZModem_getNextDLECh();
				if(ALLOK)
				{
				   crc = rZModem_crcUpdate(crc, ch);
				   rZModem_getNextDLECh();
				}
				if(ALLOK)
				{
				   crc = rZModem_crcUpdate(crc, ch);
				   if(crc)
					  LastError = ZMODEM_CRC;
				   else
				   {
					  GoodOffset += i;
					  quit = TRUE;
				   }
				}
			 }
			 else
			 {  // write this byte to file !
				if(AllowFileWrite) 
				   rDummy_writeToFile(ch);
				crc = rZModem_crcUpdate(crc, ch);
				i++;
			 }
		  }
	}
	if(i > 1024)	
	   LastError = ZMODEM_LONGSP;  
	/****************************/   
	if(!ALLOK)
	   MoreData = FALSE;
}

//-----------------------------------------------------------------------------
void rZModem_sendData(byte frameEnd)     
//-----------------------------------------------------------------------------
{	// 
	word crc = 0;   
	word i; 
	// 
	for(i = 0; i < NrBytes; i++)
	{
		wdogtrig();
		ch = ZMBuffer[i];  
		crc = rZModem_crcUpdate(crc, ch);
   		rZModem_sendDLEChar();
	}
	putchar1(ZDLE);     // send one ZDLE for escape
	putchar1(frameEnd); // send the frameEnd now
  	crc = rZModem_crcUpdate(crc, frameEnd); 
    // now send the CRC:	
	ch = (byte)(crc >> 8);
	rZModem_sendDLEChar();   
	ch = (byte)crc;
	rZModem_sendDLEChar();   
	if(frameEnd == ZCRCW)
	{
	  putchar1(XON); // DLE encoded ? 
	  delay_ms(100); // 100 msec. or maybe more...
	} 
   	/**************************/
	GoodOffset += NrBytes;
}

// Layer 0 ####################################################################
//-----------------------------------------------------------------------------
void rZModem_getNextHexCh(void)
//-----------------------------------------------------------------------------
{	// 
	byte tempCh; 
 	// 
	rComm_readByte(&ch);
	if(ALLOK)
	{
		if ((ch >= '0') && (ch <= '9'))
			tempCh = ch - 0x30; 			 // '0' = 0x30
		else if ((ch >= 'a') && (ch <= 'f')) // 'a' = 0x61
			tempCh = 0x0a + (ch - 0x61);
		else
			LastError = ZMODEM_BADHEX;

		if(ALLOK)
			rComm_readByte(&ch);

		if(ALLOK)
		{
			tempCh <<= 4;
			if ((ch >= '0') && (ch <= '9'))
         		ch = ch - 0x30;
			else if ((ch >= 'a') && (ch <= 'f'))
         		ch = 0x0a + (ch - 0x61);
			else
         		LastError = ZMODEM_BADHEX;
		}
		if(ALLOK)
      		ch |= tempCh;
	}
}   

//-----------------------------------------------------------------------------
void rZModem_getNextDLECh(void)
//-----------------------------------------------------------------------------
{
	GotSpecial = FALSE;
	rComm_readByte(&ch);
	if(ALLOK)
	{
	   if(ch == ZDLE)
	   {
      	  rComm_readByte(&ch);
		  if(ALLOK)
		  {
         	 if((ch & 0x60) == 0x40)
				 ch &= 0xbf;
			 else
            	 GotSpecial = TRUE;
		  }
	   }
	}
} 

//-----------------------------------------------------------------------------
// purpose: escaping special characters with ZDLE
//			HEX: 0x18(ZDLE itself) 0x10 0x90 0x11 0x91 0x13 0x93 0x0d 0x8d
//			OCT:  030               020 0220  021 0221  023 0223  015 0215
void rZModem_sendDLEChar(void)
//-----------------------------------------------------------------------------
{   //  
	switch(ch)
	{
	  case 015 :  // CR   = 0x0d =  13 (don't know why ...!?)
	  case 0215:  //      = 0x8d = 141 ( - // - // - // - )
   	  case ZDLE:  // CAN  = 0x18 =  24
   	  case 020 :  //      = 0x10 =  16
   	  case 0220:  //      = 0x90 = 144
	  case 021 :  // XON  = 0x11 =  17
	  case 0221:  //      = 0x91 = 145
	  case 023 :  // XOFF = 0x13 =  19
	  case 0223:  //      = 0x93 = 147
      	   putchar1(ZDLE);
		   ch ^= 0x40;
	} 
    putchar1(ch);
}

//-----------------------------------------------------------------------------
void rZModem_sendHexChar(void)
//-----------------------------------------------------------------------------
{	// 
    byte hexDigit[] = "0123456789abcdef"; 
	// 
	putchar1(hexDigit[ch >> 4]);
   	putchar1(hexDigit[ch & 0x0f]);
}

//-----------------------------------------------------------------------------
void rZModem_sendCAN(void)                                                 
//-----------------------------------------------------------------------------
{ // Send a ZModem CANcel sequence to the other guy: 8 CANs
  byte i;
  //
  for(i = 0; i < 8; i++)
  {
      putchar1(CAN);
      delay_ms(100); // the pause seems to make reception of the sequence more reliable
  }   
}

// CRC computing ##############################################################
/* CRC is computed using the self-made function presented below */
#pragma warn-    
//-----------------------------------------------------------------------------
word rZModem_crcUpdate(word crc, byte serialData)
//-----------------------------------------------------------------------------
{   // Please, DO NOT MODIFY ! Any change may cause severe malfunction !
#asm    
	ldd	 r30, y+2	
	ldd  r31, y+1	
	ld	 r27, y
	eor  r30, r27
	mov  r26, r30
	swap r26
	andi r26, 0x0f
	eor  r30, r26
	mov  r26, r30
	swap r26
	andi r26, 0xf0
	eor  r31, r26
	mov  r26, r30
	swap r26
	andi r26, 0xf0
	lsl  r26 
	mov  r27, r30
	lsr  r27
	lsr  r27
	lsr  r27
	eor  r31, r27
	eor  r30, r26   
#endasm 
} 
#pragma warn+

