//-----------------------------------------------------------------------------
// Project:		ZModem
// Version:		V2.02
// Date:		21 April 2002
// Author:		Radu Hristea (radu.hristea@aptrans-group.com; transeast@programmer.net)
// File:		Dummy.c
// Description:	This module contains some dummy functions for READ and WRITE 
//				operation. The user must adapt these functions to his needs.
//-----------------------------------------------------------------------------

#include "defs.h" 

extern dword GoodOffset; 

/*** HERE BELOW: ONLY DUMMY FUNCTIONS ***/

//-----------------------------------------------------------------------------
// dummy function: read some bytes from the data source
void rDummy_readFromFile(byte* zBuffer, word bytes2Read, word* bytesRead)
//-----------------------------------------------------------------------------
{  //
   word i;
   dword readOffset;
   static byte dummy;
   //
   readOffset = GoodOffset;
   *bytesRead = 0;    
   for(i = 0; (i < bytes2Read) && (readOffset < fileSize); i++)
   {
      wdogtrig();
      zBuffer[i] = dummy++;
      //putchar(zBuffer[i]); // send a copy to the terminal (if U want to compare...)
      readOffset++;
      (*bytesRead)++;
   }
}  

//-----------------------------------------------------------------------------
// dummy function: write a byte to the data storage
void rDummy_writeToFile(byte c)
//-----------------------------------------------------------------------------
{
   putchar(c);
}

