This is a link library for the Nokia 6610, 6100, 7250, 7250i, 3100, 3200, 5100 colordisplay and compatible. 
Version 2.1.

Copyright 2004 Hagen Reddmann, HaReddmann at T-Online dot de
Greatings goes to F. Maximilian Thiele aka Ape, me at apetech dot de 
http://www.apetech.de/nokia6100.php


The Nokia is a 132x132x4096 color display.
The display use a SPI communication with MOSI/MISO connected together internal.
The controller is a PCF8833 and can be used with an SPI clock of 6.5 MHz. But on my testcases it run without any problems
upto 8Mhz on an ATmega32 16MHz severals days. Thus if possible the library setup SPI2X.


The grafic library is for WinAVR C compiler, but use only gcc assembler source, handmade.


What supports the library ?
- colors
- pixel setting
- lines
- rectangles with border and filling, transparent and full color
- ellipses and circles with border and filling, transparent and full color
- proportional and fixed fonts with multiple colors
- fonts are highly compressed with an table based RLE coding, like a mini Huffmann
- fontroutines use an separate window for display texts (glcd_Window)
- a full featured font creator for MS Window is included
- with fonts it is easy possible to design own bitmaps and icons with transparency
- all font routines such as glcdPrint() can work on nullterminated strings stored in Flash or RAM
- the font data access can be controlled trough own callbacks to support external I2C EEPROMs or other external memories,
  thus there is no need to store large fonts in flash
- all display operation can be truncated with a clipping rect
- all display operation can be rotated to 0,90,180,270 degree
- all display operation supports transparency
- hardware scrolling of PCF8833 is always possible trough diect access
- the 256 and 65536 color modes of the PCF8833 are supported
- own bitmap data can be used
- with some hopefully small changes on the base display functions in glcd00.S it should be easily possible to support 
  other controllers, mainly all highlevel routines such as glcdLine(), glcdEllipse() are hardware independend.
- display resolution can be upto 254x254 without any changes
- the library use half software and hardware based 9 bit SPI, where the first bit is transmitted by software and the remaining
  8 Bits transmitted with hardware SPI in background and interrupt driven, thus the target device must support hardware SPI.

- inculded are a LFSR-SG (linear feedback shift register shrinking generator) as random generator with period 2**63-2
- this RNG is faster, stronger and far more resource fiendly as the gcc inbuild LCG rand() function
- i have included 2x 1000 random and certified irreducible polynomials for the LFSR
 

Whats not supported ?
- the library don't use double buffering of display RAM, otherwise we need 18-26 KByte SRAM
- the PCF8833 don't support reading of internal display RAM
- thus any operation, such as pixel XOR'ing, that need reading of display can't be supported
- 12 bit colormode, eg. 4096 colormode, is'nt supported. The pixel transfer is to complicated and on expiriences the 16 bit color mode is only
  10-25% slower as 8bit mode. Thus useing 16bit colormode with truncated 12bit color informations get higher SPI transmissions with hardware SPI,
  as 12bit colormode with software emulated SPI. With full 16 bit color information the PCF8833 dither the remaining colors. This dithering seems
  to me very good.
- the colormode can be switched on runtime for special purposes, but that's not supported by the library !
- the hardware scrolling of the PCF8833 can be used manually, but the library don't care about it and have no functions for it, the only
  assumtion made by the library are the free access to all coordinates. Means, the lib support accessing column 0, row 0, column 131 and row 131,
  but these rows and columns are'nt visible on the screen, except the hw-scrolling are used. 
- the adressspace for the font routines is assumed to 16bit and don't support 24bits directly. But with installing an own font read callback there
  exists the possibility to access any memory space in chunks of 64Kb. Thus take care on useing fonts on MCU's with 128 Kb flash.
- one font can't and must not excide 64Kb.
- i can't give expensive support, thus use the lib as is without any warrenties


best reagrds, Hagen



Changes:

Version 2.1.

- bugfix in glcdEllipse(), the handling of tranparency was not correct
- glcdEllipse() performance boost, trough buffering of pixel colors
- bugfix glcdLine(), the handling of tranparency was not correct
- minor optimizations in font routines to reduce codesize and increase performance
- LFSR-SG random number generator can be per define now used with variable polynoms S and A, thus it can be used for cryptography
  if both polynoms are considered as keys.

Version 2.0.

- this version is a fully rewrite from plain C source into full handmade assembler
- the library is a full link library now, and the gcc linker can suppress unused function
- the performance and features are great increased
- the resourcesize of used code is drasticaly reduced, in plain gcc C the lib need on wortscase useing all function 4500 bytes,
  now in same worstcase with more features included it use maximal 2800 bytes. On best case the lib need only 600 bytes code.
- the lib use now always the hardware SPI interrupt to reset the LCD chip select signal, this made the high speed SPI
  communication with the display more stable

Version 1.2.

- first version released